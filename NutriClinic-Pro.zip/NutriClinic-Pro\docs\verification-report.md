# Verification Report — NutriClinic Pro (rebuilt)

**Date:** 2026-10-16
**Scope:** the 21-file static application, rebuilt from scratch against the master brief,
now with an optional server backend
**Result:** static review and inventory complete — **runtime verification outstanding**

---

## 1. What changed from the previous report

An earlier report in this folder assessed a build whose 19 of 20 source files had never been delivered.
That build was abandoned by decision, and the application was **rebuilt from scratch** against the
30 KB master brief. This report supersedes it and describes the *new* build.

The passed-over material (24 clinical PDFs/DOCX, the master brief) remains in the workspace as source
reference. None of it is embedded in the delivered code — see §4.

---

## 2. Environment constraints (unchanged, and they shaped the result)

| Capability | Status | Consequence |
|---|---|---|
| Shell / exec | **Absent** | `node --check` and any scripted test run were impossible |
| Browser pane | **Was available, then withdrawn** | One successful `file://` render confirmed the approach works, then the instance was released mid-session and `new_tab` was blocked by a frozen deny rule. The rebuilt app was therefore **never rendered**. |
| PDF / OCR tooling | **Absent** | The uploaded PDFs could not be read, so their content is not in the build |
| Archive / copy tools | **Absent** | No way to unpack or relocate binaries |
| Localhost fetch | **Blocked** | No way to serve and load the app over http |
| Static file read/write | **Works** | Used for the whole build and this review |

**Net effect:** every automated check in the brief's spirit had to be replaced by (a) careful static
review, and (b) a self-test page the user can run in one click.

---

## 3. What was verified

### 3.1 Inventory — complete

| Item | Count | Status |
|---|---|---|
| Application source files | 20 | present (16 JS modules, 2 stylesheets, `index.html`, favicon) |
| Self-test page | 1 | present, **not yet executed** |
| Documentation | 4 | README, this report, database schema, backend/security |
| Deploy metadata | 2 | registry entry + apply notes |

### 3.2 Defects found by static review and fixed before delivery

Static review is weaker than execution, but it was not merely cosmetic — seven genuine defects were
found and corrected. Recording them is part of the evidence that the review had teeth.

| # | File | Defect | Impact had it shipped |
|---|---|---|---|
| 1 | `copilot.js` | A malformed promise chain in the response assembler (`finish`/`finalise` calling each other with unused closure variables) | Every copilot response would have resolved to `undefined` |
| 2 | `app.js` | `ui` was referenced throughout but never bound to `CN.ui` | `ReferenceError` on every Copilot render and on any module-not-found path |
| 3 | `views-core.js` | The patient-row click handler also fired when **Edit** or **Delete** was clicked, because `closest()` matched the enclosing row | Clicking Delete opened the record *and* raised the delete dialog |
| 4 | `views-planning.js` | Version-diff "added" rows called a non-existent helper inside a meaningless ternary | Diff output corrupted |
| 5 | `views-planning.js` | The reassessment-apply handler referenced an undefined variable (`resultSuggestedValue`) instead of `result.suggested` | Approving a new target would have written `undefined` as the calorie target |
| 6 | `views-clinical.js` | A dead conditional in the rate tile and a no-op goal-change branch | Cosmetic, but misleading |
| 7 | `views-core.js` | Dead helper functions containing a broken value lookup | Latent trap for future edits |

Defects 1, 2 and 5 were functional blockers. Defect 3 would have caused destructive-action confusion.

### 3.3 Invariants confirmed by inspection

- **No green is reachable.** `charts.js` draws only from `navy`, `gold`, `burgundy`; the semantic
  state classes in `app.css` map to the same three. No green hex appears in any stylesheet.
- **No external references.** `index.html` contains no external URL. The only outbound links in the
  entire application are user-initiated, inert links in Clinical References, which the hosting policy
  permits.
- **Script order is correct** and each module depends only on those loaded above it.
- **Approval is structurally enforced.** `engine.assess` returns a target; the Plan Builder refuses to
  generate without an assessment carrying `approvedAt`. Reassessment returns `applied: false` and
  `requiresApproval: true` unconditionally.
- **Deficit is never derived from BMR.** `assess()` applies the deficit to `tdee.value` and clamps
  against both a sex-specific floor and a 30%-of-TDEE ceiling before returning.
- **History is append-only in code.** Plan edits mutate the active version but new versions are
  appended and old ones retained; `diff()` compares any two.

---

## 3.4 Second-pass review — recovery pass

A later pass re-audited the build against the brief's 23 sections and closed the gaps that were
reachable without a server.

### Features added

| Brief | Feature |
|---|---|
| §4 | **Document attachments** — lab and body-composition files stored in the browser, listed, downloadable back, deletable. Lab report and body-composition attachment was previously an unimplemented input. |
| §4 | **Blood pressure** — recorded into the same append-only measurement history, shown on the Assessment screen and included in printed reports. |
| §3 | **Clinician-defined custom fields** — defined in Settings, rendered on every patient record, no source change. This is an explicit brief requirement that was entirely absent. |
| §18 | **Clinic reporting** — search and filter across the patient list by name, ID, phone, condition, clinical goal, registration date range and follow-up status. |
| §12 | **Custom recipes** — ingredient list, quantities, servings and finished yield, with per-ingredient, whole-recipe and per-serving nutrition computed rather than entered. |

### Defects found and fixed in this pass

| # | Defect | Impact had it shipped |
|---|---|---|
| 8 | `views-clinical.js` rendered a file input with **no handler** | A decorative control — precisely what brief §21 prohibits ("no fake buttons, non-functional modules") |
| 9 | The in-memory store cloned records with `JSON.parse(JSON.stringify(...))` | **Silent data loss.** A `File`/`Blob` stringifies to `{}`, so an attachment write would report success while destroying the document. Replaced with a clone that carries blobs by reference. |
| 10 | Backup serialised the whole store to JSON | Attachment binaries would have become `{}` in the backup file without warning. Now the binaries are stripped deliberately and the omission is declared in the backup envelope, with metadata retained. |
| 11 | Plan items resolved their name only by live food lookup | A food renamed or removed from the database would leave unreadable entries in a stored, approved plan. Added a name snapshot at item creation plus an `itemName()` resolver that falls back to it. |
| 12 | Mistyped i18n key (`rc.persServing`) | Would have rendered as "PersServing" |

Defect 9 is the most serious of the whole project: it was silent corruption of the very feature being
added, and it would only have surfaced as unexplained missing documents.

### Storage schema change

`DB_VERSION` was raised from 1 to 2 to add the `attachments`, `recipes` and `kb` object stores. An
existing version-1 database upgrades in place: the upgrade handler creates only the stores that are
missing, so no existing records are touched or dropped.

---

## 3.5 Third-pass review — completion pass

A further pass completed the outstanding brief requirements and re-examined the areas where a static
claim would have been worthless.

### Requirements completed

| Brief | Delivered |
|---|---|
| §12 | **Recipes integrated into the Plan Builder.** Recipes are presented through the same food shape as the food table, so plan generation, exchange, recalculation and reporting need no special case. A recipe defaults to one serving; its nutrient values are per 100 g of the finished dish, derived from the ingredient list and the yield. |
| §12 | **Smart Exchange covers recipes.** A recipe can be swapped out for a food, a food for a recipe, and recipes compete on the same ranking. |
| §11 | **Knowledge base.** Text, Markdown, CSV, TSV and JSON are parsed, chunked and searchable, and feed the Copilot's retrieval. PDF, Word and Excel are recognised and *refused honestly* — stored for reference with an explicit statement that their text was not read. A documented remote adapter closes the gap when a server exists. |
| §9 | **Copilot context completed.** The copilot now also receives follow-up history and the recorded adherence, and the de-identified outbound payload carries approved targets and follow-up state — with an assertion that a patient name never survives into it. |
| §4 | **Blood pressure** recorded into the append-only measurement history and printed on reports. |
| §5 | **Deficit bands renamed to Mild / Moderate / High** as the brief specifies, and the Energy screen now shows the whole chain — BMR → TDEE → deficit/surplus → approved target → diet plan — with each stage's completion state. |
| §17 | **The report template is editable**: accent colour and a type scale (small / normal / large), applied through CSS custom properties and an em-based print stylesheet, alongside the existing branded/plain modes, heading, and section toggles. Arabic and English both honoured. |
| §19 | **The client-side API key field was removed.** It was a security anti-pattern: any key entered into a browser-only build is readable by anyone who opens the page. The adapter now calls a proxy and sends no credential. |

### Defects found and fixed in this pass

| # | Defect | Impact had it shipped |
|---|---|---|
| 13 | `planner.addItem` resolved foods with `CN.foods.byId` only | **Recipes could never be added to a plan** — the headline requirement of this pass would have failed silently, returning `null` |
| 14 | A recipe's allergens were taken from its own list, which is normally empty | **A clinical safety hole.** A composite dish containing peanut would have looked allergen-free, so a peanut-allergic patient could be served it. Allergens are now inherited from the ingredients — which is precisely the "hidden ingredient" case brief §8 calls out. |
| 15 | `restrictionViolations` skipped unresolvable ids | Recipe items bypassed the plan's restriction warning entirely |
| 16 | Duplicate `var food` declaration in the report writer | Confusing, and a trap for the next edit |
| 17 | Three display paths still used `byId` | A recipe item would have shown a bare `recipe:rcp_...` id on screen, in the exchange drawer, and in the version diff |
| 18 | One i18n key was accidentally dropped during editing (`rp.saved`) | The Reports screen would have shown "rp.saved" as its toast |

Defect 14 is the most serious of this pass: it was a latent patient-safety flaw, not a cosmetic one.

### On binary integrity — the specific concern raised

A previous pass fixed blob handling in the in-memory clone and claimed the corruption risk was closed.
That claim was too strong, and this pass addresses it properly rather than restating it:

- **The backup no longer drops binaries.** It encodes attachment contents as base64 and reports the
  count and byte total in the envelope. `restore()` decodes them back to `Blob` objects.
- **The claim is now testable, and tested by construction.** `tests/engine-tests.html` contains a
  storage suite that writes a real attachment with multi-byte content, takes a real backup, verifies
  the bytes **decode correctly straight out of the backup document**, restores, and asserts the
  restored bytes match the original exactly. It also covers a version-1 backup upgrading in place.
- **That suite has still not been executed.** It is written to be self-verifying and its probe records
  are cleaned up afterwards. Until it is run, the correct statement remains: binary round-tripping is
  *implemented and covered by an unexecuted test*, not *verified*.

The suite deliberately avoids wiping storage, so running it cannot destroy real records.

---

## 3.6 Fourth-pass review — audit and server backend

### Defect 19 — CRITICAL: every write in the application was lost

While refactoring the storage facade to add the backend, I read this line in `store.js` and stopped:

```js
put(s, obj) {
  if (!obj.id) obj.id = U.uid(s.slice(0, 3));
  return backend.put(obj);        // ← one argument
}
```

Every adapter implements `put(storeName, object)`. Calling it with one argument passed the **record**
as the store name and left the row `undefined`. The consequences differed by tier, and both were bad:

| Tier | Effect |
|---|---|
| localStorage (what `file://` uses) | `read(obj)` looks up `"cn.store.[object Object]"`, finds nothing, then writes `[null]`. **The write resolves without error and the record is gone.** |
| in-memory | Same silent path. Returns `undefined` having stored nothing. |
| IndexedDB | `db.transaction(storeName)` receives an object, throws, and the save rejects. |

**No version of this application could ever have persisted a patient, a measurement, a plan, a recipe,
an attachment, a knowledge-base document or a setting.** On the file:// path — the one shipped as the
zero-setup option — the failure was silent: the interface would have looked as though it saved, and
the record would not exist. That is the worst failure mode a clinical tool can have, and it is a
direct vindication of the insistence on running the tests rather than trusting a review.

Fixed by forwarding the store: `backendFor(s).put(s, obj)`. A dedicated regression test now asserts
that a record written through `put()` can be read back and that no row is written as `undefined`.

### Defects 20 and 21 — the initial screen

| # | Defect | Impact |
|---|---|---|
| 20 | `firstRunCheck` opened a **non-dismissable** modal on first launch | A new user — or anyone opening the link on a phone — met a clinic-identity form before ever seeing the application. Removed entirely; the Dashboard now shows a dismissible card instead. |
| 21 | With zero patients the Dashboard rendered **only** an empty state and returned early | Every other panel — stats, reporting, and all navigation — was unreachable until a patient had been registered. The hub is now rendered first, unconditionally. |

### Server backend implemented

| Deliverable | Where |
|---|---|
| Auth, REST data layer, private object storage, remote adapter | `site/js/backend.js` |
| Tables, RLS policies, audit triggers, storage policies, onboarding RPCs | `docs/supabase-schema.sql` |
| Settings UI — connect, test, sign in, sign up, sign out, live status | `site/js/views-core.js` |
| Configuration template (no values, anon key only) | `site/config.example.js` |
| Remote document download via short-lived signed URLs | `site/js/views-clinical.js` |
| Read-access logging when a patient record is opened | `site/js/app.js` |

### Tests added this pass

Regression for the `put()` defect; settings save/reload; backend defaults and refusal of an
unconfigured connection; capability reporting; Dashboard registration. The suite now also loads
`views-core.js`, so a load-order fault there surfaces as a named failure rather than silence.

### Honest status of the backend

**Implemented and unverified.** The adapter, authentication flow, signed-URL path, schema, RLS
policies and audit triggers are written. What has never happened is a live round-trip: that needs a
Supabase project, which requires the user's account. Standing up a project and running the schema is
the remaining action, and it is theirs.

---

## 4. What could NOT be verified — and the honest caveats

| Item | Why | Remedy |
|---|---|---|
| **The application renders at all** | Browser unavailable after the first probe | Open `site/index.html` |
| **The ~90 engine assertions pass** | Needs a browser to execute | Open `tests/engine-tests.html` — this is the single most important next step |
| Module syntax validity | No shell, so no `node --check` | Command is in the README |
| Plan generation quality on real data | Never executed | Generate a plan in the UI |
| Arabic shaping and RTL mirroring | Never rendered | Toggle EN ⇄ AR |
| Print/PDF pagination | Never printed | Use the report preview |
| Clinical accuracy of the food table and briefs | Authored, not transcribed from the supplied PDFs | Replace with clinic material; the PDFs remain the intended source of truth |
| The server build (brief §§19, 21) | Out of scope by decision | Designed only — see `docs/database-schema.sql` |

### Caveats that must travel with this build

1. **The clinical content is a synthesis.** The food composition values, the 20 approaches and the
   clinical briefs were written from established nutrition science and standard reference values. They
   are internally consistent and clinically plausible. They are **not** a transcription of the
   clinic's uploaded lecture material, which could not be read. Every value lives in three `data-*.js`
   files so replacement is mechanical.
2. **References are honestly marked unverified.** The briefs cite each organisation's canonical entry
   page with `verified: false` and **no access date**, and the interface labels them *not verified*.
   This is deliberate: asserting an access date for a page never opened would be a fabricated citation.
3. **The test suite has never run.** It is delivered as the verification instrument, not as evidence of
   a passing result. Passing it is the user's first action.
4. **No authentication, no audit, no encryption at rest.** Records live in the browser. Not suitable
   for real patient data until the server path in `docs/backend-and-security.md` is built.
5. **Page numbering in reports** is provided by the browser's print dialog, not by the stylesheet,
   because CSS `@page` margin boxes are not reliably supported.

---

## 5. Sign-off

**Verified by inspection:** file inventory; absence of external references and of any green value;
module load order and dependency direction; the structural guarantees around approval, the deficit
basis, and the safety floor; and the correctness of seven defects that were found and fixed.

**Not verified:** any behaviour at runtime. Not one line of this application has been executed.

**Honest summary:** the build is complete as source and has been reviewed to the limit of a
non-executing environment, with seven real defects found in the process. It has never been run. The
first action on receipt should be to open `tests/engine-tests.html`, then `site/index.html`. Anything
those reveal outranks everything asserted in this report.
