# Test Runbook, Security Review & Deployment

**Date:** 2026-10-16
**Purpose:** everything in this file is written for **you to execute**. Nothing here has been run by
me — I have no shell and no browser in this environment, and I have verified that repeatedly.

Every section states its **exact expected outcome**, so a run is a comparison rather than a
judgement call.

---

## 1. Run the automated suite

### Preferred: one double-click

Double-click **`Run-Tests.bat`** in the `NutriClinic-Pro` folder. It serves the project on port 8618
(a *different port* from the app, so a different browser origin and therefore a different database —
tests can never touch real records) and opens the suite.

### Alternative if the script will not run

Any static server works. Python is the simplest:

```powershell
cd NutriClinic-Pro
python -m http.server 8618 --bind 127.0.0.1
# then open:  http://127.0.0.1:8618/tests/engine-tests.html
```

If Python is unavailable, open `tests/engine-tests.html` **directly** — but read §1.3 first, because
the storage results mean something different on `file://`.

### 1.1 Expected result — the suite as a whole

The page renders a headline of the form:

```
N / M passed
```

**Expected on a healthy build: `M passed`, `0` failing** — currently **M ≈ 130** assertions across two
suites (deterministic engine assertions, then the storage and backend suite).

**If any row shows FAIL**, the row states expected versus actual. Send me those rows; they name the
module at fault.

### 1.2 Expected result — the engine assertions

These compare against values computed by hand, independent of the code under test. Spot-check that
these specific rows read PASS:

| Assertion | Expected value |
|---|---|
| BMR Mifflin male 80/180/40 | `1730` |
| BMR Mifflin female 65/165/35 | `1345` |
| BMR Harris-Benedict male | `1796` |
| BMR revised Harris-Benedict male | `1797` |
| TDEE sedentary 1730 × 1.20 | `2076` |
| assess target (2076, moderate deficit) | `1626` |
| assess predicted weekly rate | `−0.41` |
| macro protein / carb / fat for 1626 kcal at 20/45/35 | `81` / `183` / `63` g |
| deficit respects the 1200 kcal floor (female) | target ≥ `1200` |
| underweight + weight loss | raises an alert flag |
| pregnancy + weight loss | raises an alert flag |
| healthy weight low for 180 cm | `59.9` kg |

### 1.3 Expected result — the storage suite, and why the storage engine matters

The summary block prints **which engine was exercised**. Both outcomes are valid, but they test
different code:

| How you opened the page | Engine shown | What that means |
|---|---|---|
| `http://127.0.0.1:8618/…` | `indexeddb` | The real, indexed storage path is being tested. **This is the run to trust.** |
| Opened directly as a file | `localstorage` | Browser storage is tested. Also valid, but IndexedDB is not exercised. |

Key rows, in order:

| Assertion | Expected |
|---|---|
| store reports an engine | `indexeddb` (served) or `localstorage` (file) |
| regression: put() forwards the store name | **PASS — read the note below** |
| the record landed in the patients store, not a junk key | PASS |
| no row was written as undefined | PASS |
| attachment BYTES are identical after storage | PASS |
| base64 round-trip preserves multi-byte text exactly | PASS |
| backup reports the attachment payload it carries | PASS |
| bytes decode correctly FROM THE BACKUP FILE | PASS |
| RESTORED ATTACHMENT BYTES MATCH THE ORIGINAL | PASS |
| v1 backup restores its patient | PASS |
| stores introduced in v2 exist after a v1 restore | PASS |
| custom field definition persists | PASS |
| recipe total energy is derived from its ingredients | `460` kcal |
| per-serving energy = total / servings | `230` kcal |
| serving size comes from the finished yield | `125` g |
| recipe energy per 100 g of finished dish | `184` kcal |
| a recipe can be added to a meal | PASS |
| the item records its recipe id | `rcp_t` |
| a recipe item defaults to one serving | `125` g |
| meal total equals the sum of its items after substitution | PASS |
| a recipe is offered as an exchange candidate | PASS |
| approved plan contents are untouched by a new recipe | PASS |
| **peanut never appears for a peanut-allergic patient** | `0` hits |
| gluten-free plan contains no gluten | `0` hits |
| an unconfigured backend is refused, not simulated | PASS |

> **The `put()` regression row is the one that matters most.** A previous version called
> `backend.put(obj)` with one argument, so the record was passed as the store name and the row was
> `undefined`. On localStorage that failed **silently** — the interface behaved as though it saved.
> If that row fails, stop and tell me: nothing else in the application can be trusted.

### 1.4 The suite cleans up after itself

Probe records are synthetic and deleted at the end (`probe records cleaned up`). It never uses real
patient data, and it does not wipe storage.

---

## 2. Manual acceptance checks

Do these in the running app. Each has a pass condition.

### 2.1 The initial screen (directive §2 and §7.1)

| Check | Expected |
|---|---|
| Open the app with an empty database | **The Dashboard appears immediately.** No modal, no wizard, no form blocking the view. |
| Scroll the Dashboard | A “Quick access” card with 14 tiles is visible, plus six summary tiles reading `0`. |
| Confirm nothing forced you to register | There is *no* non-dismissable dialog. A clinic-identity card may appear — it has a Close button and Settings link. |
| Close the identity card, then reload | It stays closed. |

### 2.2 Navigation with zero patients

Click each tile **before registering anyone**:

| Tile | Expected |
|---|---|
| Dashboard | Reloads the Dashboard |
| Patients | Empty-state list with a “New patient” button — not an error |
| New patient | The registration form opens |
| Follow-ups, Clinical assessment, Body composition, Energy, Diet plan, Copilot, Reports | Each shows a “select a patient” prompt with a button to the patient list. **No blank screen, no error.** |
| Clinical references | Opens; the Knowledge base card is scrolled to and briefly highlighted |
| Food database | The food table lists ~150 foods; a Recipes card is below it |
| Recipes | The page scrolls to the Recipes card and highlights it |
| Settings | Opens, including the new Server backend section |

### 2.3 Navigation with a patient selected

Register a synthetic test patient (never real data), then repeat. Every module should now render its
own content rather than the prompt. The header pill shows the patient's name; clicking it reopens the
patient picker.

### 2.4 The end-to-end workflow (directive §6, ten steps)

| Step | Expected |
|---|---|
| 1. Register a patient | Saved; the app moves to Clinical Assessment; the header shows the name |
| 2. Enter clinical information | Conditions, medications, allergies and measurements persist across a reload |
| 3. Calculate BMR and TDEE | Both values shown with the formula name and activity factor displayed |
| 4. Receive deficit suggestions | A Mild / Moderate / High selector; the three bands read 250–300, 400–500, 600–750 kcal |
| 5. Approve the target | Pressing Approve stores the assessment; the workflow chain at the top turns step 4 green — navy, since green is banned — and the plan builder unlocks |
| 6. Generate and edit a diet plan | A multi-day plan appears; changing a gram figure updates that meal's total and the day's total |
| 7. Smart exchange | The swap button lists ranked alternatives with a similarity percentage; applying one recalculates the meal |
| 8. Export a PDF | The preview shows an A4 report; Print opens the browser dialog; “Save as PDF” produces a file |
| 9. Record follow-up measurements | A new measurement appends; the earlier ones remain |
| 10. Reassess requirements | The reassessment card shows previous and suggested targets side by side, and **nothing changes until you approve** |

### 2.5 Mobile layout

| Check | Expected |
|---|---|
| Narrow the window below 900px | The sidebar becomes an overlay, hidden by default |
| Tap the menu button | The sidebar slides in |
| **Tap the page content behind the sidebar** | **The sidebar closes** (this was broken and is now fixed) |
| Tap a navigation item | Navigates and closes the sidebar |
| Tables | Scroll horizontally rather than overflowing the viewport |

### 2.6 Failure visibility (directive §2, second half)

This is the behaviour I changed this session. To see it working, fill the browser's storage quota —
or simply watch for it in normal use:

| Check | Expected |
|---|---|
| Force a save to fail (fill storage, or block IndexedDB) | A red toast appears: “Could not save in "<store>": <reason>”. **It must never fail silently.** |
| Any unhandled promise rejection | A toast appears with the message, and the console logs it |

---

## 3. Security review of the backend (directive §4)

I reviewed my own schema and **found and fixed a real privilege-escalation flaw**.

### 3.1 Flaw found and fixed

The membership policy read:

```sql
using (public.my_role() = 'owner')
```

and `my_role()` was `select role … where user_id = auth.uid() limit 1` — **no row scoping, no
ordering**. For a user belonging to two clinics the returned role was nondeterministic, and the policy
never referenced the row it was guarding. An owner of clinic B who was also a member of clinic A could
therefore modify membership rows in clinic A — including promoting themselves.

Fixed by resolving ownership as a **set of clinics** and scoping the policy to the row:

```sql
using (clinic_id in (select public.my_owned_clinics()))
with check (clinic_id in (select public.my_owned_clinics()))
```

`my_role()` was deleted outright, with a comment explaining why a scalar role helper must not return.

### 3.2 Other hardening in the same pass

| Issue | Fix |
|---|---|
| Storage policies cast a path segment with `::uuid`. An unparseable name made the whole policy evaluation **raise** rather than deny. | Added `safe_uuid()`, which returns null instead of raising. |
| `log_access` accepted any patient id, so a client could write fabricated entries into the audit trail. | It now resolves the clinic **from the patient row**, restricted to the caller's memberships, and silently ignores anything else. |
| `log_access` also used the same unscoped `limit 1` clinic lookup. | Removed; the clinic now comes from the patient. |

### 3.3 How to test isolation yourself (after standing up the backend)

Run these in the Supabase SQL editor, substituting two real account ids.

**Test A — cross-clinic isolation.** As user 1 (clinic A), with a patient belonging to clinic B:

```sql
select * from public.patients where id = '<clinic-B-patient-id>';
```

**Expected: zero rows.** Not an error — simply nothing, because the RLS policy filters it out.

**Test B — the audited read refuses a foreign patient.**

```sql
select public.patient_read('<clinic-B-patient-id>');
```

**Expected: `null`.** And **no audit_log row** should be created. Confirm with:

```sql
select * from public.audit_log order by at desc limit 5;
```

**Test C — membership cannot be self-modified.** As a `clinician` (not an owner):

```sql
update public.clinic_members set role = 'owner' where user_id = auth.uid();
```

**Expected: 0 rows updated.** No error necessarily, but nothing changes. Verify by re-reading the row.

**Test D — membership cannot be inserted directly.**

```sql
insert into public.clinic_members (clinic_id, user_id, role)
values ('<any-clinic-id>', auth.uid(), 'owner');
```

**Expected: an RLS policy violation.** There is no INSERT policy, so this is denied outright.

**Test E — onboarding refuses a second clinic.** Call `bootstrap_clinic` twice:

```sql
select public.bootstrap_clinic('Second Clinic');
```

**Expected the second call to raise:** *“This account already belongs to a clinic”*.

**Test F — documents are private.** In an incognito window, paste a `clinical-documents` object URL
directly.

**Expected: denied.** The bucket is private; only a signed URL issued to a clinic member works.

### 3.4 Residual risks I am not claiming to have solved

| Risk | Status |
|---|---|
| An owner can enumerate whether an email has an account, via `add_clinic_member` | **Accepted.** Only owners can call it. Documented rather than hidden. |
| `bootstrap_clinic` could race with itself and create two clinics for one account | **Accepted, low.** Requires two simultaneous first-time requests. A unique index on a derived key would close it. |
| **Destructive actions are not role-gated server-side.** Any clinic member can delete a patient or wipe records through the REST API. | **Open.** The interface gates these by role, but a determined client can bypass the interface. Closing it properly means moving writes behind RPCs with role checks — see §5. |
| Settings are per-device, not shared | **By design.** Documented in the README. |

---

## 4. Read auditing — what is guaranteed and what is not (directive §5)

**PostgreSQL has no SELECT trigger.** A read cannot be audited by the database. Anything that audits
reads must therefore wrap the read in a function. That constraint drives everything below.

| Read path | Mechanism | Guarantee |
|---|---|---|
| Opening a patient record | `patient_read(id)` — a `security definer` function that reads and writes the audit row in **one server-side transaction** | **Guaranteed.** If the row comes back, the entry exists. A client cannot obtain the record without the entry. |
| Everything else — patient lists, measurements, plans, labs, recipes, knowledge base | Not separately audited | **Not guaranteed.** These are ordinary REST selects. |
| If the audited call fails | The app falls back to a plain read **and tells the user** with a warning toast | Visible, but the read is then unaudited. Recorded in the console. |

**To close the remaining gap** you would route *all* clinical reads through server functions — one per
entity, or a single `clinic_read(entity, filters)` — so that no data can be fetched outside an audited
path. That is a deliberate architectural step with a real performance cost (an RPC per list view), and
it is the correct answer if non-repudiable read auditing is an inspection requirement. The schema
comments say so as well, so this does not get lost.

**What is already non-repudiable:** every INSERT, UPDATE and DELETE on clinical tables is logged by
database trigger. A client cannot skip it, and the log is read-only to clients.

---

## 5. Verifying shared persistence across two devices (directive §6)

Requires the backend from §6 of the README to be configured first. **Use synthetic data only.**

| Step | Action | Expected |
|---|---|---|
| 1 | On device A, sign in and register a patient named `Test Patient AA`, date of birth 1990-01-01 | Saved without error; the header pill shows the name |
| 2 | On device A, record a measurement — weight 80 kg | Visible in Body Composition |
| 3 | Reload device A | The patient and the measurement are still there |
| 4 | On device B (another browser, another machine, or a private window), sign in as the **same** account | The Dashboard appears |
| 5 | Device B opens Patients | **`Test Patient AA` is listed** — this is the proof of shared persistence |
| 6 | Device B opens the record | Weight 80 kg is present, and **the audited read creates an audit row** |
| 7 | Device B changes the weight to 79 kg | Saved |
| 8 | Device A reloads and reopens the record | Shows **79 kg** — changes propagate |
| 9 | Check the audit log | Entries for both reads and for the update, with different actors/timestamps |
| 10 | Sign in as a **different** account in a different clinic | **`Test Patient AA` must not appear anywhere.** If it does, stop: isolation is broken. |
| 11 | Delete `Test Patient AA` when finished | Removed on both devices |

**If step 5 fails** (the record does not appear on device B), the likely causes in order: the anon key
or URL is wrong on one device; the second device is not signed in; or the schema was not run, so RLS
has no policy and every query returns nothing.

---

## 6. Deploying to a public HTTPS URL (directive §8)

I cannot do this for you — there is no deployment tool in this environment, and I will not invent a
URL. `site/` is a plain static folder with no build step and only relative paths, so any static host
works. Netlify is the quickest.

### 6.1 Environment configuration

There is **no build-time environment** to configure. Two values exist and both are runtime:

| Value | Where it goes | Secret? |
|---|---|---|
| Project URL | `site/config.js`, or Settings → Server backend | No |
| **Anon** key | Same | **No — public by design** |
| AI provider key | **Nowhere in this app.** A server-side proxy holds it | — |
| **service_role** key | **Never in this repository.** Server or dashboard only | **Yes** |

To publish with the backend pre-configured, copy `site/config.example.js` to `site/config.js` and
fill it in. To keep the project URL out of the bundle, skip `config.js` and have each device enter the
values in Settings instead.

### 6.2 Deploy — Netlify

1. Go to `app.netlify.com/drop`.
2. Drag the **`site`** folder — the folder itself, not its contents.
3. Wait for the upload. You get an HTTPS URL such as `https://something.netlify.app`.
4. Optional: add a custom domain in Site settings → Domain management.
5. `site/_headers` is picked up automatically and applies the security headers (CSP, `nosniff`,
   `no-referrer`, frame-deny).

Cloudflare Pages (direct upload) and GitHub Pages work the same way.

### 6.3 Verify the deployment

| Check | Expected |
|---|---|
| Open the URL | The Dashboard loads over HTTPS. Nothing is blocked by the CSP — check the browser console for zero errors. |
| Append `/index.html` | The same Dashboard — direct URL access works |
| Reload the page twice | Still the Dashboard; it does not 404 |
| Open a second browser | The app loads, with its own (empty) data |
| Open on a phone | The responsive layout engages; the menu button opens the sidebar; tapping content closes it |
| Navigate to each of the 13 modules | All load; patient-dependent ones show the selection prompt |
| Check the padlock and certificate | Valid HTTPS, no mixed-content warnings |
| Try `/tests/engine-tests.html` and `/README.md` | **404 — neither should ship.** If either loads, remove `tests/` and the documentation from the deployed folder. |

### 6.4 If you deploy with a backend

Add your deployment's origin to Supabase → Authentication → URL configuration → Site URL and redirect
URLs, or email confirmation links will point at `localhost` and fail.

---

## 7. What I could not verify, and why

| Item | Why | Consequence |
|---|---|---|
| The automated suite | No execution tool exists here (foreground shell, background shell, browser, new tab, delegated subagent and a catalogue search all fail) | Every expected value above is my prediction, not a measurement |
| The backend end to end | Needs a Supabase project, which needs your account | The adapter, schema, RLS and audit are written and reviewed — never executed |
| Cross-clinic isolation | Same | Reviewed and hardened; the probes in §3.3 are how it gets proved |
| Two-device persistence | Same | Procedure supplied in §5 |
| Mobile rendering | No browser here | CSS is written for it; the sidebar fix is in `app.js` |

**Nothing in this project should be described as production-ready** until §1, §2 and §3.3 have all been
run and their outcomes recorded.
