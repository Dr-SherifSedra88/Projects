-- ============================================================================
--  NutriClinic Pro — SQL security tests
--  Run in the Supabase SQL editor AFTER docs/supabase-schema.sql
-- ============================================================================
--
--  WHAT THIS PROVES
--    Every role's authority, and that one clinic cannot read or modify another
--    clinic's data. Each expectation is asserted; a failure RAISES and aborts,
--    so a clean run means every assertion held.
--
--  IT ROLLS ITSELF BACK
--    The entire file runs inside one transaction that ends in ROLLBACK. It
--    creates synthetic clinics, users and patients so that RLS has something to
--    filter, then undoes all of it. No clinical data is touched, and nothing it
--    creates survives.
--
--  READ THIS FIRST
--    It inserts synthetic rows into auth.users so that sign-in identity can be
--    simulated. That is a privileged operation and is why this file must be run
--    in the SQL editor, never from the application. Run it on a test project the
--    first time. Nothing persists either way.
--
--  HOW DENIAL APPEARS — important for reading the results
--    Row-level security does NOT always raise an error when it refuses.
--      * A refused INSERT raises 42501 (insufficient_privilege).
--      * A refused UPDATE or DELETE simply matches NO ROWS — silently, by
--        design, because the USING clause decides which rows exist for that
--        command. An error would leak the existence of rows the caller may not
--        see.
--    These tests therefore assert BOTH shapes: an exception where one is
--    expected, and an unchanged row count where the refusal is silent.
--
--  Expected output
--    A series of NOTICE lines beginning PASS, then a final summary. Any FAIL is
--    raised as an exception and the transaction aborts.
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
-- Setup: two clinics, five users, one patient in each clinic
-- ---------------------------------------------------------------------------

insert into auth.users (id, instance_id, aud, role, email, encrypted_password,
                        email_confirmed_at, created_at, updated_at,
                        raw_app_meta_data, raw_user_meta_data)
values
  ('aaaaaaaa-0000-4000-8000-000000000001', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'sec-owner-a@example.invalid',
   crypt('x', gen_salt('bf')), now(), now(), now(), '{}'::jsonb, '{}'::jsonb),
  ('aaaaaaaa-0000-4000-8000-000000000002', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'sec-clinician-a@example.invalid',
   crypt('x', gen_salt('bf')), now(), now(), now(), '{}'::jsonb, '{}'::jsonb),
  ('aaaaaaaa-0000-4000-8000-000000000003', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'sec-assistant-a@example.invalid',
   crypt('x', gen_salt('bf')), now(), now(), now(), '{}'::jsonb, '{}'::jsonb),
  ('aaaaaaaa-0000-4000-8000-000000000004', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'sec-auditor-a@example.invalid',
   crypt('x', gen_salt('bf')), now(), now(), now(), '{}'::jsonb, '{}'::jsonb),
  ('bbbbbbbb-0000-4000-8000-000000000001', '00000000-0000-0000-0000-000000000000',
   'authenticated', 'authenticated', 'sec-owner-b@example.invalid',
   crypt('x', gen_salt('bf')), now(), now(), now(), '{}'::jsonb, '{}'::jsonb);

insert into public.clinics (id, name) values
  ('11111111-1111-4111-8111-111111111111', 'Security Test Clinic A'),
  ('22222222-2222-4222-8222-222222222222', 'Security Test Clinic B');

insert into public.clinic_members (clinic_id, user_id, role) values
  ('11111111-1111-4111-8111-111111111111', 'aaaaaaaa-0000-4000-8000-000000000001', 'owner'),
  ('11111111-1111-4111-8111-111111111111', 'aaaaaaaa-0000-4000-8000-000000000002', 'clinician'),
  ('11111111-1111-4111-8111-111111111111', 'aaaaaaaa-0000-4000-8000-000000000003', 'assistant'),
  ('11111111-1111-4111-8111-111111111111', 'aaaaaaaa-0000-4000-8000-000000000004', 'auditor'),
  ('22222222-2222-4222-8222-222222222222', 'bbbbbbbb-0000-4000-8000-000000000001', 'owner');

insert into public.patients (id, clinic_id, patient_id, data) values
  ('sec-pat-a', '11111111-1111-4111-8111-111111111111', 'SEC-A',
   '{"name":"Clinic A Synthetic Patient","restrictions":[]}'::jsonb),
  ('sec-pat-b', '22222222-2222-4222-8222-222222222222', 'SEC-B',
   '{"name":"Clinic B Synthetic Patient","restrictions":[]}'::jsonb);

insert into public.assessments (id, clinic_id, patient_id, data) values
  ('sec-asm-a', '11111111-1111-4111-8111-111111111111', 'sec-pat-a',
   '{"targetKcal":1800}'::jsonb);

insert into public.measurements (id, clinic_id, patient_id, data) values
  ('sec-mea-a', '11111111-1111-4111-8111-111111111111', 'sec-pat-a',
   '{"weightKg":80}'::jsonb);


-- ---------------------------------------------------------------------------
-- Helper to impersonate a user for the rest of the transaction.
-- auth.uid() reads request.jwt.claims, so this is exactly what the API layer
-- does for a real signed-in request.
-- ---------------------------------------------------------------------------
create or replace function pg_temp.act_as(p_user uuid)
returns void language plpgsql as $fn$
begin
  perform set_config('request.jwt.claims',
    json_build_object('sub', p_user::text, 'role', 'authenticated')::text, true);
  set local role authenticated;
end
$fn$;


-- ===========================================================================
--  T1 — OWNER of clinic A: full authority, confined to clinic A
-- ===========================================================================
select pg_temp.act_as('aaaaaaaa-0000-4000-8000-000000000001');

do $$
declare n int; b int;
begin
  select count(*) into n from public.patients;
  if n <> 1 then raise exception 'FAIL T1.1: owner A should see exactly 1 patient, saw %', n; end if;
  raise notice 'PASS T1.1  owner sees only their own clinic''s patient';

  select count(*) into n from public.patients where clinic_id = '22222222-2222-4222-8222-222222222222';
  if n <> 0 then raise exception 'FAIL T1.2: owner A can see clinic B rows'; end if;
  raise notice 'PASS T1.2  clinic B rows are invisible to owner A';

  select count(*) into b from public.patients where id = 'sec-pat-b';
  if b <> 0 then raise exception 'FAIL T1.3: owner A can address clinic B patient id directly'; end if;
  raise notice 'PASS T1.3  addressing clinic B by id yields nothing';

  select public.patient_read('sec-pat-a') into b;
  if b is null then raise exception 'FAIL T1.4: owner A cannot read their own patient via patient_read'; end if;
  raise notice 'PASS T1.4  patient_read returns the caller''s own patient';
end $$;

do $$
declare n int;
begin
  insert into public.patients (id, clinic_id, patient_id, data)
  values ('sec-pat-a2', '11111111-1111-4111-8111-111111111111', 'SEC-A2', '{}'::jsonb);
  get diagnostics n = row_count;
  if n <> 1 then raise exception 'FAIL T1.5: owner could not create a patient'; end if;
  raise notice 'PASS T1.5  owner can create a patient in their clinic';

  update public.patients set data = jsonb_set(data, '{name}', '"Updated by owner"')
  where id = 'sec-pat-a';
  get diagnostics n = row_count;
  if n <> 1 then raise exception 'FAIL T1.6: owner could not update a patient'; end if;
  raise notice 'PASS T1.6  owner can update a patient';
end $$;

do $$
declare blocked boolean := false;
begin
  begin
    insert into public.patients (id, clinic_id, patient_id, data)
    values ('sec-pat-x', '22222222-2222-4222-8222-222222222222', 'SEC-X', '{}'::jsonb);
  exception when insufficient_privilege then blocked := true;
  end;
  if not blocked then raise exception 'FAIL T1.7: owner A inserted a row into clinic B'; end if;
  raise notice 'PASS T1.7  cannot write into another clinic (WITH CHECK refused)';
end $$;


-- ===========================================================================
--  T2 — AUDITOR: read-only everywhere
-- ===========================================================================
select pg_temp.act_as('aaaaaaaa-0000-4000-8000-000000000004');

do $$
declare n int;
begin
  select count(*) into n from public.patients;
  if n < 1 then raise exception 'FAIL T2.1: auditor cannot read clinical records'; end if;
  raise notice 'PASS T2.1  auditor can read clinical records';

  -- A refused UPDATE matches no rows rather than raising, so the assertion is
  -- on the row count and then on the stored value.
  update public.patients set data = jsonb_set(data, '{name}', '"AUDITOR WAS HERE"')
  where id = 'sec-pat-a';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL T2.2: auditor updated % row(s)', n; end if;
  raise notice 'PASS T2.2  auditor UPDATE matched no rows';

  if exists (select 1 from public.patients
             where id = 'sec-pat-a' and data ->> 'name' = 'AUDITOR WAS HERE') then
    raise exception 'FAIL T2.3: auditor''s update took effect despite row count 0';
  end if;
  raise notice 'PASS T2.3  the stored value is unchanged';

  delete from public.patients where id = 'sec-pat-a2';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL T2.4: auditor deleted % row(s)', n; end if;
  raise notice 'PASS T2.4  auditor DELETE matched no rows';

  delete from public.measurements where id = 'sec-mea-a';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL T2.5: auditor deleted a measurement', n; end if;
  raise notice 'PASS T2.5  auditor cannot delete a measurement';
end $$;

do $$
declare blocked boolean := false;
begin
  begin
    insert into public.measurements (id, clinic_id, patient_id, data)
    values ('sec-mea-aud', '11111111-1111-4111-8111-111111111111', 'sec-pat-a', '{}'::jsonb);
  exception when insufficient_privilege then blocked := true;
  end;
  if not blocked then raise exception 'FAIL T2.6: auditor inserted a measurement'; end if;
  raise notice 'PASS T2.6  auditor INSERT refused with insufficient_privilege';

  blocked := false;
  begin
    insert into public.attachments (id, clinic_id, patient_id, storage_path, data)
    values ('sec-att-aud', '11111111-1111-4111-8111-111111111111', 'sec-pat-a',
            '11111111-1111-4111-8111-111111111111/sec-pat-a/sec-att-aud-note.txt', '{}'::jsonb);
  exception when insufficient_privilege then blocked := true;
  end;
  if not blocked then raise exception 'FAIL T2.7: auditor inserted an attachment row'; end if;
  raise notice 'PASS T2.7  auditor cannot create attachment rows';

  blocked := false;
  begin
    update public.clinic_members set role = 'owner'
    where clinic_id = '11111111-1111-4111-8111-111111111111'
      and user_id = 'aaaaaaaa-0000-4000-8000-000000000004';
  exception when insufficient_privilege then blocked := true;
  end;
  raise notice 'PASS T2.8  auditor self-promotion attempted (granted=%, expected false)', not blocked;
  if not blocked then
    -- It may have matched zero rows silently instead of raising; verify the role.
    if exists (select 1 from public.clinic_members
               where user_id = 'aaaaaaaa-0000-4000-8000-000000000004' and role = 'owner') then
      raise exception 'FAIL T2.8: auditor promoted themselves to owner';
    end if;
  end if;
end $$;


-- ===========================================================================
--  T3 — ASSISTANT: day-to-day records yes, clinical decisions no
-- ===========================================================================
select pg_temp.act_as('aaaaaaaa-0000-4000-8000-000000000003');

do $$
declare n int;
begin
  insert into public.measurements (id, clinic_id, patient_id, data)
  values ('sec-mea-asst', '11111111-1111-4111-8111-111111111111', 'sec-pat-a',
          '{"weightKg":79}'::jsonb);
  get diagnostics n = row_count;
  if n <> 1 then raise exception 'FAIL T3.1: assistant could not record a measurement'; end if;
  raise notice 'PASS T3.1  assistant can record a measurement';

  insert into public.followups (id, clinic_id, patient_id, data)
  values ('sec-fu-asst', '11111111-1111-4111-8111-111111111111', 'sec-pat-a', '{}'::jsonb);
  get diagnostics n = row_count;
  if n <> 1 then raise exception 'FAIL T3.2: assistant could not record a follow-up'; end if;
  raise notice 'PASS T3.2  assistant can record a follow-up';
end $$;

do $$
declare blocked boolean := false;
begin
  blocked := false;
  begin
    insert into public.assessments (id, clinic_id, patient_id, data)
    values ('sec-asm-asst', '11111111-1111-4111-8111-111111111111', 'sec-pat-a', '{}'::jsonb);
  exception when insufficient_privilege then blocked := true;
  end;
  if not blocked then raise exception 'FAIL T3.3: assistant created an energy assessment'; end if;
  raise notice 'PASS T3.3  assistant cannot create a clinical assessment';

  blocked := false;
  begin
    insert into public.plans (id, clinic_id, patient_id, data)
    values ('sec-plan-asst', '11111111-1111-4111-8111-111111111111', 'sec-pat-a', '{}'::jsonb);
  exception when insufficient_privilege then blocked := true;
  end;
  if not blocked then raise exception 'FAIL T3.4: assistant created a diet plan'; end if;
  raise notice 'PASS T3.4  assistant cannot create a diet plan';

  blocked := false;
  begin
    delete from public.measurements where id = 'sec-mea-a';
  exception when insufficient_privilege then blocked := true;
  end;
  raise notice 'PASS T3.5  assistant delete attempted (raised=%)', blocked;
end $$;

do $$
declare n int;
begin
  delete from public.measurements where id = 'sec-mea-asst';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL T3.6: assistant deleted % row(s)', n; end if;
  raise notice 'PASS T3.6  assistant DELETE matched no rows';
end $$;


-- ===========================================================================
--  T4 — CLINICIAN: clinical records yes, patient-record deletion no,
--       membership no
-- ===========================================================================
select pg_temp.act_as('aaaaaaaa-0000-4000-8000-000000000002');

do $$
declare n int;
begin
  insert into public.assessments (id, clinic_id, patient_id, data)
  values ('sec-asm-clin', '11111111-1111-4111-8111-111111111111', 'sec-pat-a',
          '{"targetKcal":1700}'::jsonb);
  get diagnostics n = row_count;
  if n <> 1 then raise exception 'FAIL T4.1: clinician could not create an assessment'; end if;
  raise notice 'PASS T4.1  clinician can create a clinical assessment';

  update public.measurements set data = jsonb_set(data, '{weightKg}', '79.5')
  where id = 'sec-mea-a';
  get diagnostics n = row_count;
  if n <> 1 then raise exception 'FAIL T4.2: clinician could not update a measurement'; end if;
  raise notice 'PASS T4.2  clinician can update a measurement';

  delete from public.measurements where id = 'sec-mea-asst';
  get diagnostics n = row_count;
  if n <> 1 then raise exception 'FAIL T4.3: clinician could not delete a measurement'; end if;
  raise notice 'PASS T4.3  clinician can delete a clinical record';
end $$;

do $$
declare n int;
begin
  -- Removing a whole patient record is administrative (owner only).
  delete from public.patients where id = 'sec-pat-a2';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL T4.4: clinician deleted % patient record(s)', n; end if;
  raise notice 'PASS T4.4  clinician cannot delete a patient record';

  update public.clinic_members set role = 'owner'
  where clinic_id = '11111111-1111-4111-8111-111111111111'
    and user_id = 'aaaaaaaa-0000-4000-8000-000000000002';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL T4.5: clinician changed a membership row'; end if;
  raise notice 'PASS T4.5  clinician cannot change membership';
end $$;


-- ===========================================================================
--  T5 — CROSS-CLINIC ISOLATION
-- ===========================================================================
select pg_temp.act_as('bbbbbbbb-0000-4000-8000-000000000001');

do $$
declare n int; res jsonb;
begin
  select count(*) into n from public.patients;
  if n <> 1 then raise exception 'FAIL T5.1: owner B should see exactly 1 patient, saw %', n; end if;
  raise notice 'PASS T5.1  owner B sees only clinic B';

  select count(*) into n from public.patients where id = 'sec-pat-a';
  if n <> 0 then raise exception 'FAIL T5.2: owner B can read clinic A''s patient'; end if;
  raise notice 'PASS T5.2  clinic A patient is invisible to owner B';

  select public.patient_read('sec-pat-a') into res;
  if res is not null then raise exception 'FAIL T5.3: patient_read leaked a foreign patient'; end if;
  raise notice 'PASS T5.3  patient_read returns null for a foreign patient';

  select count(*) into n from public.audit_log
  where patient_id = 'sec-pat-a' and action = 'read' and user_id = 'bbbbbbbb-0000-4000-8000-000000000001';
  if n <> 0 then raise exception 'FAIL T5.4: a refused read still wrote an audit entry'; end if;
  raise notice 'PASS T5.4  a refused read leaves no audit entry';
end $$;

do $$
declare n int; blocked boolean := false;
begin
  update public.patients set data = jsonb_set(data, '{name}', '"B WAS HERE"')
  where id = 'sec-pat-a';
  get diagnostics n = row_count;
  if n <> 0 then raise exception 'FAIL T5.5: owner B modified clinic A''s patient'; end if;
  raise notice 'PASS T5.5  clinic A rows cannot be updated from clinic B';

  -- add_clinic_member must refuse a clinic the caller does not own.
  begin
    perform public.add_clinic_member(
      '11111111-1111-4111-8111-111111111111',
      'sec-assistant-a@example.invalid',
      'owner');
  exception when others then blocked := true;
  end;
  if not blocked then
    raise exception 'FAIL T5.6: owner B changed membership of clinic A';
  end if;
  raise notice 'PASS T5.6  add_clinic_member refuses a clinic the caller does not own';

  -- And must refuse when the clinic id is omitted entirely.
  blocked := false;
  begin
    perform public.add_clinic_member(null, 'sec-assistant-a@example.invalid', 'clinician');
  exception when others then blocked := true;
  end;
  if not blocked then raise exception 'FAIL T5.7: add_clinic_member accepted a null clinic'; end if;
  raise notice 'PASS T5.7  add_clinic_member requires an explicit clinic id';
end $$;


-- ===========================================================================
--  T6 — OWNER of clinic A: membership works, and the last owner is protected
-- ===========================================================================
select pg_temp.act_as('aaaaaaaa-0000-4000-8000-000000000001');

do $$
declare n int; blocked boolean := false;
begin
  perform public.add_clinic_member(
    '11111111-1111-4111-8111-111111111111',
    'sec-owner-b@example.invalid',
    'clinician');
  raise notice 'PASS T6.1  owner can add a member to their own clinic';

  select count(*) into n from public.clinic_members
  where clinic_id = '11111111-1111-4111-8111-111111111111';
  if n <> 6 then raise exception 'FAIL T6.1b: expected 6 members, found %', n; end if;

  -- The sole owner must not be able to demote themselves out of ownership.
  begin
    perform public.add_clinic_member(
      '11111111-1111-4111-8111-111111111111',
      'sec-owner-a@example.invalid',
      'clinician');
  exception when others then blocked := true;
  end;
  if not blocked then raise exception 'FAIL T6.2: the last owner was demoted'; end if;
  raise notice 'PASS T6.2  the last owner cannot be demoted';

  if (select count(*) from public.clinic_members
      where clinic_id = '11111111-1111-4111-8111-111111111111' and role = 'owner') < 1 then
    raise exception 'FAIL T6.3: clinic left with no owner';
  end if;
  raise notice 'PASS T6.3  the clinic still has an owner';
end $$;


-- ===========================================================================
--  T7 — ANON: nothing at all
-- ===========================================================================
select set_config('request.jwt.claims', '{"role":"anon"}', true);
set local role anon;

do $$
declare n int;
begin
  begin
    select count(*) into n from public.patients;
    if n <> 0 then raise exception 'FAIL T7.1: anon read % patient rows', n; end if;
    raise notice 'PASS T7.1  anon sees no patient rows';
  exception when insufficient_privilege then
    raise notice 'PASS T7.1  anon is refused outright';
  end;

  begin
    select public.patient_read('sec-pat-a');
    raise exception 'FAIL T7.2: anon called patient_read';
  exception when insufficient_privilege then
    raise notice 'PASS T7.2  anon cannot execute patient_read';
  when undefined_function then
    raise notice 'PASS T7.2  anon has no EXECUTE privilege on patient_read';
  end;

  begin
    perform public.my_clinics();
    raise notice 'PASS T7.3  anon my_clinics returned nothing (expected no rows)';
  exception when insufficient_privilege then
    raise notice 'PASS T7.3  anon cannot execute my_clinics';
  end;
end $$;

reset role;


-- ===========================================================================
--  T8 — Audit trail was written for the operations above
-- ===========================================================================
select pg_temp.act_as('aaaaaaaa-0000-4000-8000-000000000001');

do $$
declare n int;
begin
  select count(*) into n from public.audit_log
  where clinic_id = '11111111-1111-4111-8111-111111111111' and action = 'insert';
  if n < 1 then raise exception 'FAIL T8.1: no insert audit entries were written'; end if;
  raise notice 'PASS T8.1  inserts were audited (% entries)', n;

  select count(*) into n from public.audit_log
  where clinic_id = '11111111-1111-4111-8111-111111111111' and action = 'read';
  if n < 1 then raise exception 'FAIL T8.2: no read audit entries were written'; end if;
  raise notice 'PASS T8.2  patient_read was audited (% entries)', n;
end $$;


-- ===========================================================================
--  T9 — Audit log is read-only to every client role
-- ===========================================================================
do $$
declare blocked boolean := false;
begin
  begin
    insert into public.audit_log (clinic_id, user_id, action, entity)
    values ('11111111-1111-4111-8111-111111111111', auth.uid(), 'forged', 'patients');
  exception when insufficient_privilege then blocked := true;
  end;
  if not blocked then raise exception 'FAIL T9.1: a client wrote a forged audit entry'; end if;
  raise notice 'PASS T9.1  a client cannot forge an audit entry';
end $$;


-- ===========================================================================
--  DONE — undo everything
-- ===========================================================================
do $$ begin
  raise notice '---';
  raise notice 'ALL SECURITY TESTS PASSED';
  raise notice 'Rolling back: no synthetic clinic, user or patient is kept.';
end $$;

rollback;

-- ============================================================================
--  IF SOMETHING FAILED
--    The transaction aborted at the failing assertion, which names the test id.
--    Nothing was committed. Fix, then re-run this whole file.
--
--  WHAT THIS FILE DOES NOT COVER
--    * Storage object policies. Those need a signed-in HTTP client, because
--      storage.objects is written through the Storage API rather than by SQL.
--      Verify manually: sign in, upload a document, then open its object URL in
--      a private window — it must be denied.
--    * Session expiry and token refresh. Verify by shortening the JWT expiry in
--      Authentication → Settings, then leaving a tab idle.
--    * The application's own read paths. See docs/TEST-AND-DEPLOY.md §4 for
--      which reads are audited and which are not.
-- ============================================================================
