/* ==========================================================================
   NutriClinic Pro — planner.js
   Diet plan generation, editing operations, smart exchange, version diffing
   and templates.

   Generation is DETERMINISTIC: the same patient, targets, approaches and
   duration always produce the same plan. Food choice rotates by day index so
   a seven-day plan has variety without randomness — which also makes the
   output reproducible and testable.

   Hard rule (brief §8): a food excluded by a patient restriction is never
   placed in a plan. Soft restrictions are avoided where alternatives exist.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  var MEAL_TIMES = ['08:00', '11:00', '14:00', '17:00', '20:00'];
  var IF_WINDOW = { start: '12:00', end: '20:00' };

  /* -------------------------------------------------------- restrictions --- */
  /**
   * Build predicate functions from a patient's restriction list.
   * Returns { hard: [fn], soft: [fn] }
   *   hard — allergy, medical, religious: must never appear
   *   soft — intolerance, preference: avoided where an alternative exists
   */
  function buildRestrictions(restrictions) {
    var keys = CN.foods.allergens.map(function (a) { return a[0]; });
    var hard = [], soft = [];

    (restrictions || []).forEach(function (r) {
      if (!r || !r.substance) return;
      var s = String(r.substance).trim().toLowerCase();
      var fn;

      if (keys.indexOf(s) !== -1) {
        fn = function (f) { return (f.allergens || []).indexOf(s) !== -1; };
      } else if (/red meat|لحم أحمر/.test(s)) {
        fn = function (f) { return f.category === 'meat'; };
      } else if (/dairy|milk|ألبان|حليب/.test(s)) {
        fn = function (f) { return (f.allergens || []).indexOf('milk') !== -1 || (f.allergens || []).indexOf('lactose') !== -1; };
      } else if (/seafood|fish|أسماك|سمك/.test(s)) {
        fn = function (f) { return f.category === 'fish'; };
      } else if (/meat|لحوم/.test(s)) {
        fn = function (f) { return f.category === 'meat' || f.category === 'poultry'; };
      } else if (/egg|بيض/.test(s)) {
        fn = function (f) { return (f.allergens || []).indexOf('egg') !== -1; };
      } else if (/sugar|سكر/.test(s)) {
        fn = function (f) { return f.category === 'sweets'; };
      } else if (/fried|مقلي/.test(s)) {
        fn = function (f) { return /fried/.test(f.id); };
      } else {
        fn = function (f) {
          return f.nameEn.toLowerCase().indexOf(s) !== -1 || String(f.nameAr || '').indexOf(r.substance) !== -1;
        };
      }

      var kind = String(r.kind || '').toLowerCase();
      if (kind === 'allergy' || kind === 'medical' || kind === 'religious') hard.push(fn);
      else soft.push(fn);
    });

    return { hard: hard, soft: soft };
  }

  function violates(food, preds) {
    return (preds || []).some(function (fn) { return fn(food); });
  }

  /* ------------------------------------------------- approach constraints --- */
  /**
   * Approach-specific food admissibility and slot weighting.
   * Returns { allow(food), dropCategories:[], fatScale:number }
   */
  function approachRules(codes) {
    var set = codes || [];
    var dropCats = [];
    var fatScale = 1;

    if (set.indexOf('ketogenic') !== -1) {
      // Ketogenic: starches, most fruit and sweets are excluded.
      dropCats = dropCats.concat(['grains', 'bread', 'sweets', 'beverages']);
      fatScale = 1.25;
    }
    if (set.indexOf('vegan') !== -1) {
      dropCats = dropCats.concat(['meat', 'poultry', 'fish', 'eggs', 'dairy']);
    }
    if (set.indexOf('vegetarian') !== -1 && set.indexOf('vegan') === -1) {
      dropCats = dropCats.concat(['meat', 'poultry', 'fish']);
    }
    if (set.indexOf('dairy_free') !== -1 || set.indexOf('lactose_free') !== -1) {
      dropCats = dropCats.concat(['dairy']);
    }
    if (set.indexOf('low_fat') !== -1) fatScale = 0.6;
    if (set.indexOf('low_sodium') !== -1 || set.indexOf('dash') !== -1) fatScale *= 0.95;
    if (set.indexOf('gluten_free') !== -1) {
      // handled through allergen predicates below
    }

    var requiresExclusions = CN.approaches.requiredExclusions(set);

    return {
      dropCategories: dropCats,
      requiresExclusions: requiresExclusions,
      fatScale: fatScale,
      allow(food) {
        if (dropCats.indexOf(food.category) !== -1) return false;
        // Gluten-free must exclude gluten-bearing foods outright.
        if (set.indexOf('gluten_free') !== -1 && (food.allergens || []).indexOf('gluten') !== -1) return false;
        if (set.indexOf('vegan') !== -1) {
          if ((food.allergens || []).indexOf('milk') !== -1) return false;
          if ((food.allergens || []).indexOf('egg') !== -1) return false;
        }
        if (set.indexOf('low_sodium') !== -1 && food.sodium > 600 && food.category !== 'vegetables') return false;
        if (set.indexOf('dash') !== -1 && food.sodium > 700) return false;
        return true;
      }
    };
  }

  /* ------------------------------------------------------- food selection --- */
  /** Practical portion rounding: 5 g steps for solids, 10 ml for liquids. */
  function roundPortion(grams, food) {
    var g = Math.max(0, Number(grams) || 0);
    if (!food) return U.round(g, 0);
    if (['beverages', 'dairy'].indexOf(food.category) !== -1) {
      return Math.max(50, Math.round(g / 10) * 10);
    }
    if (g < 15) return Math.max(5, Math.round(g / 5) * 5);
    return Math.max(5, Math.round(g / 5) * 5);
  }

  /** Candidates for a slot: admissible, not hard-excluded, preferences avoided. */
  function slotCandidates(cats, ctx) {
    var base = CN.foods.items.filter(function (f) {
      if (cats.indexOf(f.category) === -1) return false;
      if (!ctx.rules.allow(f)) return false;
      if (ctx.approachExclusions.length &&
        CN.foods.conflicts(f, ctx.approachExclusions).length) return false;
      if (violates(f, ctx.restr.hard)) return false;
      return true;
    });
    if (!base.length) return [];
    var preferred = base.filter(function (f) { return !violates(f, ctx.restr.soft); });
    return preferred.length ? preferred : base;
  }

  function makeItem(food, grams, note) {
    var n = CN.foods.nutrientsFor(food, grams);
    return {
      id: U.uid('itm'),
      foodId: food.id,
      // Snapshot of the display name. A stored plan must stay readable even if
      // the underlying food is later renamed or removed from the database.
      label: food.nameEn || '',
      labelAr: food.nameAr || '',
      grams: grams,
      kcal: n.kcal,
      protein: n.protein,
      carb: n.carb,
      fat: n.fat,
      fiber: n.fiber,
      sodium: n.sodium,
      approximate: !!note,
      note: note || '',
      needsVerify: !!food.needsVerify,
      // Recipes travel with the plan so the item remains explainable later.
      recipeId: food.isRecipe ? food.recipeId : null,
      isRecipe: !!food.isRecipe
    };
  }

  function sumItems(items) {
    return {
      kcal: U.round(U.sum(items.map(function (i) { return i.kcal; })), 0),
      protein: U.round(U.sum(items.map(function (i) { return i.protein; })), 1),
      carb: U.round(U.sum(items.map(function (i) { return i.carb; })), 1),
      fat: U.round(U.sum(items.map(function (i) { return i.fat; })), 1),
      fiber: U.round(U.sum(items.map(function (i) { return i.fiber; })), 1),
      sodium: U.round(U.sum(items.map(function (i) { return i.sodium; })), 0)
    };
  }

  /* ------------------------------------------------------------- generate --- */
  /**
   * generate({ patient, targetKcal, macros, approachCodes, durationDays,
   *            startDate, patternKey, assessments })
   * Returns a plan version object (status 'draft').
   */
  function generate(input) {
    input = input || {};
    var target = Number(input.targetKcal);
    if (!(target > 0)) return { ok: false, reason: 'no_target' };

    var codes = input.approachCodes || [];
    var pattern = CN.approaches.patterns[input.patternKey] ||
      CN.approaches.patterns[(CN.approaches.byCode(codes[0]) || {}).pattern || '3_meals_1_snack'];
    var duration = U.clamp(Number(input.durationDays) || 7, 1, 28);

    var ctx = {
      rules: approachRules(codes),
      approachExclusions: CN.approaches.requiredExclusions(codes),
      restr: buildRestrictions(input.patient ? input.patient.restrictions : []),
      targetKcal: target,
      macros: input.macros || null,
      fatScale: 1
    };
    ctx.fatScale = ctx.rules.fatScale;

    var labels = CN.approaches.mealLabelsFor(pattern);
    var startDate = input.startDate || U.todayISO();
    var days = [];
    var warnings = [];
    var excludedCount = 0;
    var verifyCount = 0;

    // Count what the restrictions removed, for the plan's provenance note.
    CN.foods.items.forEach(function (f) {
      if (violates(f, ctx.restr.hard)) excludedCount++;
    });

    for (var d = 0; d < duration; d++) {
      var meals = [];
      for (var mi = 0; mi < pattern.shares.length; mi++) {
        var share = pattern.shares[mi];
        var mealKcal = target * share;
        var occasion = CN.approaches.occasionFor(pattern, mi);
        var recipe = CN.approaches.occasionRecipes[occasion] || CN.approaches.occasionRecipes.lunch;
        var items = [];

        recipe.forEach(function (slot, si) {
          var cats = slot.cats;
          var pool = slotCandidates(cats, ctx);
          if (!pool.length) {
            // Fall back to a broader pool rather than leaving the slot empty.
            pool = slotCandidates(['vegetables', 'legumes', 'grains'], ctx);
          }
          if (!pool.length) return;

          // Deterministic rotation: varies by day, occasion and slot.
          var idx = (d * 31 + mi * 7 + si * 3) % pool.length;
          var food = pool[idx];

          var slotKcal = mealKcal * slot.share;
          if (slot.slot === 'fat') slotKcal *= ctx.fatScale;
          if (slot.slot === 'starch' && codes.indexOf('ketogenic') !== -1) slotKcal *= 0.4;

          var grams = roundPortion(slotKcal / (food.kcal / 100 || 1), food);
          // Do not propose implausible portions.
          if (grams < 5) return;
          if (food.category === 'fats' && grams > 40) grams = 40;
          if (food.category === 'nuts' && grams > 60) grams = 60;

          var item = makeItem(food, grams);
          if (food.needsVerify) {
            item.note = 'Composite dish — ingredient list incomplete.';
            verifyCount++;
          }
          items.push(item);
        });

        var totals = sumItems(items);
        meals.push({
          id: U.uid('mel'),
          labelEn: labels[mi] ? labels[mi].en : ('Meal ' + (mi + 1)),
          labelAr: labels[mi] ? labels[mi].ar : ('وجبة ' + (mi + 1)),
          time: (pattern.key === '2_meals_if' || pattern.key === '3_meals_if')
            ? null
            : MEAL_TIMES[mi] || null,
          instructions: '',
          items: items,
          totals: totals
        });
      }

      // Fasting-window guidance and hydration belong on the plan, not in code.
      if (pattern.key === '2_meals_if' || pattern.key === '3_meals_if') {
        meals[0].instructions = 'Eating window ' + IF_WINDOW.start + '–' + IF_WINDOW.end +
          '. Water, and unsweetened tea or coffee, are permitted outside the window.';
      }

      days.push({
        dayIndex: d,
        date: addDays(startDate, d),
        meals: meals,
        totals: sumItems(meals.reduce(function (acc, m) { return acc.concat(m.items); }, []))
      });
    }

    if (excludedCount) {
      warnings.push(excludedCount + ' food(s) were excluded by the patient\u2019s restrictions.');
    }
    if (verifyCount) {
      warnings.push(verifyCount + ' composite item(s) carry an incomplete ingredient list and are flagged for verification.');
    }
    if (ctx.approachExclusions.length) {
      warnings.push('The selected approaches themselves require excluding: ' +
        ctx.approachExclusions.map(function (a) { return CN.foods.allergenLabel(a); }).join(', ') + '.');
    }

    return {
      ok: true,
      id: U.uid('ver'),
      versionNo: 1,
      status: 'draft',
      createdAt: new Date().toISOString(),
      approachCodes: codes,
      patternKey: pattern.key,
      durationDays: duration,
      startDate: startDate,
      targetKcal: target,
      macros: input.macros || null,
      assessmentId: input.assessmentId || null,
      generatedBy: input.generatedBy || 'engine',
      days: days,
      warnings: warnings,
      excludedCount: excludedCount,
      parentVersionId: null
    };
  }

  function addDays(iso, n) {
    var d = U.parseDate(iso) || new Date();
    d.setDate(d.getDate() + n);
    return d.toISOString().slice(0, 10);
  }

  /* ------------------------------------------------------------- recalc ----- */
  /** Recompute an item's nutrients from its gram weight. */
  function recalcItem(item) {
    var food = resolveFood(item.foodId);
    // Unresolvable source (a recipe not yet loaded, for instance): keep the
    // stored values rather than zeroing a clinical record.
    if (!food) return item;
    var n = CN.foods.nutrientsFor(food, item.grams);
    item.kcal = n.kcal; item.protein = n.protein; item.carb = n.carb;
    item.fat = n.fat; item.fiber = n.fiber; item.sodium = n.sodium;
    return item;
  }

  /** Recompute every meal and day total in place. Returns the version. */
  function recalc(version) {
    (version.days || []).forEach(function (day) {
      (day.meals || []).forEach(function (meal) {
        meal.items.forEach(function (it) { recalcItem(it); });
        meal.totals = sumItems(meal.items);
      });
      day.totals = sumItems((day.meals || []).reduce(function (a, m) { return a.concat(m.items); }, []));
    });
    return version;
  }

  /** Where a day or the average day sits against the approved target. */
  function adherenceToTarget(version) {
    var m = version.macros || {};
    var days = version.days || [];
    if (!days.length) return null;
    var avg = {
      kcal: U.round(U.mean(days.map(function (d) { return d.totals.kcal; })), 0),
      protein: U.round(U.mean(days.map(function (d) { return d.totals.protein; })), 0),
      carb: U.round(U.mean(days.map(function (d) { return d.totals.carb; })), 0),
      fat: U.round(U.mean(days.map(function (d) { return d.totals.fat; })), 0),
      fiber: U.round(U.mean(days.map(function (d) { return d.totals.fiber; })), 0),
      sodium: U.round(U.mean(days.map(function (d) { return d.totals.sodium; })), 0)
    };
    var dev = {
      kcal: avg.kcal - version.targetKcal,
      protein: m.proteinG ? avg.protein - m.proteinG : null,
      carb: m.carbG ? avg.carb - m.carbG : null,
      fat: m.fatG ? avg.fat - m.fatG : null
    };
    function band(delta, target, tol) {
      if (delta === null || !target) return 'na';
      var f = Math.abs(delta) / target;
      if (f <= (tol || 0.05)) return 'on';
      return delta > 0 ? 'over' : 'under';
    }
    return {
      average: avg,
      deviation: dev,
      kcalStatus: band(dev.kcal, version.targetKcal, 0.05),
      proteinStatus: band(dev.protein, m.proteinG, 0.10),
      carbStatus: band(dev.carb, m.carbG, 0.10),
      fatStatus: band(dev.fat, m.fatG, 0.10),
      sodiumOver: (m.sodiumMaxMg && avg.sodium > m.sodiumMaxMg) ? avg.sodium - m.sodiumMaxMg : 0
    };
  }

  /* ---------------------------------------------------------- smart swap ---- */
  /**
   * suggestSwaps(item, { patient, approachCodes, objective, limit })
   * Ranked alternatives matched on the chosen objective. Approximate matches
   * are labelled as such (brief §10) rather than presented as equivalent.
   */
  function suggestSwaps(item, opts) {
    opts = opts || {};
    var food = resolveFood(item.foodId);
    if (!food) return [];

    var ctx = {
      rules: approachRules(opts.approachCodes || []),
      approachExclusions: CN.approaches.requiredExclusions(opts.approachCodes || []),
      restr: buildRestrictions(opts.patient ? opts.patient.restrictions : [])
    };

    var objective = opts.objective || 'kcal';
    var baseGrams = Number(item.grams) || 100;

    // Compare at the exchange-portion level so portions stay realistic.
    var refGrams = 100;

    // Recipes compete on exactly the same terms as foods, so a clinician can
    // swap a composite dish in or out of a meal.
    var candidates = CN.foods.items.slice();
    recipes().forEach(function (r) {
      var rf = recipeAsFood(r);
      if (rf) candidates.push(rf);
    });

    var pool = candidates.filter(function (f) {
      if (f.id === food.id) return false;
      if (!ctx.rules.allow(f)) return false;
      if (ctx.approachExclusions.length && CN.foods.conflicts(f, ctx.approachExclusions).length) return false;
      if (violates(f, ctx.restr.hard)) return false;
      return true;
    });

    var scored = pool.map(function (f) {
      // Grams of `f` that match the objective quantity of the original.
      var grams;
      var orig = CN.foods.nutrientsFor(food, baseGrams);
      var value;
      if (objective === 'kcal') {
        grams = roundPortion(orig.kcal / (f.kcal / 100 || 1), f);
        value = CN.foods.nutrientsFor(f, grams).kcal;
        value = Math.abs(value - orig.kcal);
      } else {
        var per100 = objective === 'protein' ? f.protein : (objective === 'carb' ? f.carb : f.fat);
        var origPer = objective === 'protein' ? orig.protein : (objective === 'carb' ? orig.carb : orig.fat);
        grams = roundPortion(origPer / (per100 / 100 || 1), f);
        var got = CN.foods.nutrientsFor(f, grams);
        value = Math.abs((objective === 'protein' ? got.protein : (objective === 'carb' ? got.carb : got.fat)) - origPer);
      }
      if (grams < 5 || grams > 600) return null;

      var got2 = CN.foods.nutrientsFor(f, grams);
      // Distance across all four macro dimensions, normalised.
      var dKcal = Math.abs(got2.kcal - orig.kcal) / Math.max(1, orig.kcal);
      var dP = Math.abs(got2.protein - orig.protein) / Math.max(1, orig.protein);
      var dC = Math.abs(got2.carb - orig.carb) / Math.max(1, orig.carb);
      var dF = Math.abs(got2.fat - orig.fat) / Math.max(1, orig.fat);
      var distance = (dKcal * 1.2 + dP + dC + dF) / 4.2;
      var penalties = [];
      if (violates(f, ctx.restr.soft)) penalties.push('preference');
      if (f.needsVerify) penalties.push('verify');

      return {
        food: f,
        grams: grams,
        nutrients: got2,
        deltaKcal: U.round(got2.kcal - orig.kcal, 0),
        deltaProtein: U.round(got2.protein - orig.protein, 1),
        similarity: U.round(U.clamp(1 - distance, 0, 1), 3),
        approximate: distance > 0.22,
        penalty: penalties.join(', ')
      };
    }).filter(Boolean);

    // Soft-restricted and unverified options rank below clean matches.
    scored.sort(function (a, b) {
      if (!!a.penalty !== !!b.penalty) return a.penalty ? 1 : -1;
      return b.similarity - a.similarity;
    });

    return scored.slice(0, opts.limit || 8);
  }

  /** Apply a swap in place and recalculate the affected meal and day. */
  function applySwap(version, dayIndex, mealIndex, itemId, newFoodId, grams, markApproximate) {
    var day = version.days[dayIndex];
    if (!day) return { ok: false, reason: 'no_day' };
    var meal = day.meals[mealIndex];
    if (!meal) return { ok: false, reason: 'no_meal' };
    var item = meal.items.filter(function (i) { return i.id === itemId; })[0];
    if (!item) return { ok: false, reason: 'no_item' };

    var newFood = resolveFood(newFoodId);
    if (!newFood) return { ok: false, reason: 'no_food' };

    var old = resolveFood(item.foodId);
    var oldName = old ? old.nameEn : (item.label || item.foodId);

    item.foodId = newFoodId;
    // Refresh the snapshots so the stored plan stays readable and honest.
    item.label = newFood.nameEn || '';
    item.labelAr = newFood.nameAr || '';
    item.recipeId = newFood.isRecipe ? newFood.recipeId : null;
    item.isRecipe = !!newFood.isRecipe;
    item.needsVerify = !!newFood.needsVerify;
    item.grams = Number(grams) || item.grams;
    item.approximate = !!markApproximate;
    recalcItem(item);
    item.note = (item.note ? item.note + ' ' : '') + 'Replaced ' + oldName + '.';

    meal.totals = sumItems(meal.items);
    day.totals = sumItems(day.meals.reduce(function (a, m) { return a.concat(m.items); }, []));

    return { ok: true, item: item, meal: meal, day: day };
  }

  /* ----------------------------------------------------- edit operations ---- */
  function addMeal(version, dayIndex, labelEn, labelAr) {
    var day = version.days[dayIndex];
    if (!day) return null;
    var meal = {
      id: U.uid('mel'),
      labelEn: labelEn || ('Additional meal ' + (day.meals.length + 1)),
      labelAr: labelAr || 'وجبة إضافية',
      time: null, instructions: '', items: [], totals: sumItems([])
    };
    day.meals.push(meal);
    return meal;
  }

  function removeMeal(version, dayIndex, mealIndex) {
    var day = version.days[dayIndex];
    if (!day) return false;
    day.meals.splice(mealIndex, 1);
    day.totals = sumItems(day.meals.reduce(function (a, m) { return a.concat(m.items); }, []));
    return true;
  }

  function addItem(version, dayIndex, mealIndex, foodId, grams) {
    // resolveFood, not byId: a recipe must be addable as an item too.
    var food = resolveFood(foodId);
    if (!food) return null;
    var meal = version.days[dayIndex] && version.days[dayIndex].meals[mealIndex];
    if (!meal) return null;
    // A recipe defaults to one serving — which is how it is actually
    // prescribed — while a food defaults to a weighed 100 g.
    var defaultG = (food.isRecipe && food.servingG) ? food.servingG : 100;
    var item = makeItem(food, roundPortion(grams || defaultG, food));
    meal.items.push(item);
    recalc(version);
    return item;
  }

  function removeItem(version, dayIndex, mealIndex, itemId) {
    var meal = version.days[dayIndex] && version.days[dayIndex].meals[mealIndex];
    if (!meal) return false;
    meal.items = meal.items.filter(function (i) { return i.id !== itemId; });
    recalc(version);
    return true;
  }

  function setItemGrams(version, dayIndex, mealIndex, itemId, grams) {
    var meal = version.days[dayIndex] && version.days[dayIndex].meals[mealIndex];
    if (!meal) return false;
    var it = meal.items.filter(function (i) { return i.id === itemId; })[0];
    if (!it) return false;
    it.grams = Math.max(0, Number(grams) || 0);
    recalc(version);
    return true;
  }

  /** Does the version contain anything excluded by a hard restriction? */
  function restrictionViolations(version, patient) {
    var preds = buildRestrictions(patient ? patient.restrictions : []);
    var out = [];
    (version.days || []).forEach(function (day) {
      day.meals.forEach(function (meal) {
        meal.items.forEach(function (it) {
          // Resolve through the planner so recipe items are checked against their
          // INHERITED allergens, not treated as unknown and skipped.
          var f = resolveFood(it.foodId);
          if (f && violates(f, preds.hard)) {
            out.push({ day: day.dayIndex, meal: meal.labelEn, food: f.nameEn, itemId: it.id });
          }
        });
      });
    });
    return out;
  }

  /* ----------------------------------------------------------------- diff --- */
  /**
   * Structural comparison of two plan versions.
   * Returns { totals, added, removed, changed, unchangedCount, identical }
   */
  function diff(a, b) {
    if (!a || !b) return null;
    var added = [], removed = [], changed = [];
    var maxDays = Math.max(a.days.length, b.days.length);

    for (var d = 0; d < maxDays; d++) {
      var da = a.days[d], db = b.days[d];
      var maxMeals = Math.max(da ? da.meals.length : 0, db ? db.meals.length : 0);
      for (var m = 0; m < maxMeals; m++) {
        var ma = da && da.meals[m], mb = db && db.meals[m];
        var ia = (ma ? ma.items : []).slice();
        var ib = (mb ? mb.items : []).slice();

        var usedB = {};
        ia.forEach(function (x) {
          var matchIdx = -1;
          for (var k = 0; k < ib.length; k++) {
            if (usedB[k]) continue;
            if (ib[k].foodId === x.foodId) { matchIdx = k; break; }
          }
          if (matchIdx === -1) {
            removed.push({ day: d, meal: (ma ? ma.labelEn : ''), food: x.foodId, grams: x.grams });
          } else {
            usedB[matchIdx] = true;
            var y = ib[matchIdx];
            if (Math.abs(y.grams - x.grams) > 4) {
              changed.push({
                day: d, meal: (mb ? mb.labelEn : ma.labelEn), food: x.foodId,
                from: x.grams, to: y.grams, deltaKcal: U.round(y.kcal - x.kcal, 0)
              });
            }
          }
        });
        ib.forEach(function (y, k) {
          if (!usedB[k]) added.push({ day: d, meal: (mb ? mb.labelEn : ''), food: y.foodId, grams: y.grams });
        });
      }
    }

    var avgA = U.round(U.mean((a.days || []).map(function (x) { return x.totals.kcal; })), 0);
    var avgB = U.round(U.mean((b.days || []).map(function (x) { return x.totals.kcal; })), 0);

    return {
      added: added, removed: removed, changed: changed,
      totals: {
        avgKcalA: avgA, avgKcalB: avgB, deltaKcal: (avgB || 0) - (avgA || 0),
        targetA: a.targetKcal, targetB: b.targetKcal
      },
      identical: !added.length && !removed.length && !changed.length
    };
  }

  /* ------------------------------------------------------------ templates --- */
  /** Capture a portable skeleton from a version. */
  function toTemplate(version, name) {
    return {
      id: U.uid('tpl'),
      name: name || 'Template',
      approachCodes: (version.approachCodes || []).slice(),
      durationDays: version.durationDays,
      patternKey: version.patternKey,
      structure: (version.days || []).map(function (d) {
        return d.meals.map(function (m) {
          return { labelEn: m.labelEn, labelAr: m.labelAr, time: m.time, foodIds: m.items.map(function (i) { return i.foodId; }) };
        });
      }),
      createdAt: new Date().toISOString()
    };
  }

  /** Rebuild a plan from a template against new targets, honouring exclusions. */
  function fromTemplate(template, input) {
    input = input || {};
    var ctx = {
      rules: approachRules(template.approachCodes || []),
      approachExclusions: CN.approaches.requiredExclusions(template.approachCodes || []),
      restr: buildRestrictions(input.patient ? input.patient.restrictions : [])
    };
    var labels = CN.approaches.mealLabelsFor(CN.approaches.patterns[template.patternKey] ||
      CN.approaches.patterns['3_meals_1_snack']);
    var target = Number(input.targetKcal) || 1800;
    var duration = U.clamp(Number(input.durationDays) || template.durationDays || 7, 1, 28);
    var days = [], substitutions = 0;

    for (var d = 0; d < duration; d++) {
      var skeleton = template.structure[d % template.structure.length] || [];
      var meals = skeleton.map(function (ms, mi) {
        var items = ms.foodIds.map(function (fid) {
          var food = CN.foods.byId(fid);
          // Substitute anything now excluded rather than silently keeping it.
          if (!food || !ctx.rules.allow(food) || violates(food, ctx.restr.hard)) {
            var alt = slotCandidates([food ? food.category : 'vegetables'], ctx)[0];
            if (!alt) return null;
            substitutions++;
            food = alt;
          }
          return makeItem(food, 100);
        }).filter(Boolean);

        var mealShare = 1 / Math.max(1, skeleton.length);
        var mealKcal = target * mealShare;
        // Scale portions so the rebuilt day lands on the new target.
        var rawKcal = U.sum(items.map(function (i) { return i.kcal; })) || 1;
        var scale = mealKcal / rawKcal;
        items.forEach(function (i) {
          var f = CN.foods.byId(i.foodId);
          i.grams = roundPortion(i.grams * scale, f);
          recalcItem(i);
        });

        return {
          id: U.uid('mel'),
          labelEn: ms.labelEn || (labels[mi] ? labels[mi].en : 'Meal'),
          labelAr: ms.labelAr || (labels[mi] ? labels[mi].ar : 'وجبة'),
          time: ms.time || null, instructions: '',
          items: items, totals: sumItems(items)
        };
      });

      days.push({
        dayIndex: d,
        date: addDays(input.startDate || U.todayISO(), d),
        meals: meals,
        totals: sumItems(meals.reduce(function (a, m) { return a.concat(m.items); }, []))
      });
    }

    return {
      ok: true, id: U.uid('ver'), versionNo: 1, status: 'draft',
      createdAt: new Date().toISOString(),
      approachCodes: (template.approachCodes || []).slice(),
      patternKey: template.patternKey, durationDays: duration,
      startDate: input.startDate || U.todayISO(),
      targetKcal: target, macros: input.macros || null,
      assessmentId: input.assessmentId || null,
      templateId: template.id, generatedBy: 'template',
      days: days,
      warnings: substitutions ? [substitutions + ' item(s) were substituted to honour current exclusions.'] : [],
      excludedCount: substitutions, parentVersionId: null
    };
  }

  /* ------------------------------------------------------------- recipes --- */
  /**
   * Nutrition of a clinic recipe, computed from its ingredients.
   * `yieldG` is the weight of the finished dish (cooking changes mass), and
   * `servings` divides that into portions — both are required for the figure
   * to mean anything, so both are surfaced rather than assumed silently.
   */
  function recipeNutrition(recipe) {
    recipe = recipe || {};
    var items = recipe.items || [];
    var total = { kcal: 0, protein: 0, carb: 0, fat: 0, fiber: 0, sodium: 0 };
    var missing = [];
    var ingredientWeight = 0;

    items.forEach(function (it) {
      var f = CN.foods.byId(it.foodId);
      ingredientWeight += Number(it.grams) || 0;
      if (!f) { missing.push(it.foodId); return; }
      var n = CN.foods.nutrientsFor(f, it.grams);
      total.kcal += n.kcal; total.protein += n.protein; total.carb += n.carb;
      total.fat += n.fat; total.fiber += n.fiber; total.sodium += n.sodium;
    });

    var servings = Number(recipe.servings) || 1;
    var declaredYield = Number(recipe.yieldG) || 0;
    // Cooking changes mass. When the clinician has not weighed the finished
    // dish, fall back to the raw ingredient weight and SAY SO, rather than
    // inventing a shrinkage factor.
    var yieldAssumed = !(declaredYield > 0);
    var yieldG = yieldAssumed ? ingredientWeight : declaredYield;

    var perServing = {
      kcal: U.round(total.kcal / servings, 1),
      protein: U.round(total.protein / servings, 1),
      carb: U.round(total.carb / servings, 1),
      fat: U.round(total.fat / servings, 1),
      fiber: U.round(total.fiber / servings, 1),
      sodium: U.round(total.sodium / servings, 1)
    };
    var round = function (v) { return U.round(v, 1); };
    Object.keys(total).forEach(function (k) { total[k] = round(total[k]); });

    return {
      total: total,
      perServing: perServing,
      servings: servings,
      yieldG: yieldG,
      declaredYield: declaredYield,
      yieldAssumed: yieldAssumed,
      ingredientWeight: U.round(ingredientWeight, 1),
      servingG: yieldG > 0 ? U.round(yieldG / servings, 1) : null,
      missingFoodIds: missing
    };
  }

  /** Nutritional contribution of one ingredient, for the recipe editor table. */
  function ingredientNutrition(foodId, grams) {
    var f = CN.foods.byId(foodId);
    if (!f) return null;
    return CN.foods.nutrientsFor(f, grams);
  }

  /* ---------------------------------------------------- recipe as a food ---
     Recipes are presented to the rest of the application through exactly the
     same shape as a food record, so the plan builder, the exchange engine and
     the report writer need no special case for them. */
  var recipeIndex = {};

  /** Register the loaded recipes so they resolve synchronously everywhere. */
  function setRecipeIndex(list) {
    recipeIndex = {};
    (list || []).forEach(function (r) { if (r && r.id) recipeIndex[r.id] = r; });
    return recipeIndex;
  }

  function getRecipe(id) { return recipeIndex[id] || null; }
  function recipes() { return Object.keys(recipeIndex).map(function (k) { return recipeIndex[k]; }); }

  /**
   * A recipe expressed as a food record.
   * Nutrient values are per 100 g of the FINISHED dish, so gram-based portion
   * maths is identical to any other food. One serving is offered as its own
   * household measure, which is how a clinician actually prescribes it.
   */
  function recipeAsFood(recipe) {
    if (!recipe) return null;
    var n = recipeNutrition(recipe);
    if (!(n.yieldG > 0)) return null;   // no basis for a portion
    var per100 = function (v) { return U.round(v / n.yieldG * 100, 2); };
    var servingG = n.servingG || n.yieldG;

    // Allergens are INHERITED from the ingredients. A composite dish is exactly
    // where a hidden allergen hides (brief §8), so a recipe must never look
    // allergen-free merely because its own list is empty.
    var allergenSet = {};
    (recipe.items || []).forEach(function (it) {
      var f = CN.foods.byId(it.foodId);
      if (!f) return;
      (f.allergens || []).forEach(function (a) { allergenSet[a] = true; });
    });
    (recipe.allergens || []).forEach(function (a) { allergenSet[a] = true; });
    var allergens = Object.keys(allergenSet);

    return {
      id: 'recipe:' + recipe.id,
      isRecipe: true,
      recipeId: recipe.id,
      nameEn: recipe.nameEn || 'Recipe',
      nameAr: recipe.nameAr || '',
      category: 'dishes',
      categoryAr: CN.foods.categoryLabel('dishes'),
      isEgyptian: false,
      // An assumed yield, or an ingredient that could not be resolved, makes the
      // figure uncertain — so it is flagged rather than presented as exact.
      needsVerify: n.yieldAssumed || n.missingFoodIds.length > 0,
      allergens: allergens,
      kcal: per100(n.total.kcal),
      protein: per100(n.total.protein),
      carb: per100(n.total.carb),
      fat: per100(n.total.fat),
      fiber: per100(n.total.fiber),
      sodium: per100(n.total.sodium),
      sugar: 0,
      source: 'Clinic recipe',
      yieldG: n.yieldG,
      yieldAssumed: n.yieldAssumed,
      servings: n.servings,
      servingG: servingG,
      portions: [
        { measure: 'serving', measureAr: 'حصة', grams: servingG,
          labelEn: 'One serving', labelAr: 'حصة واحدة',
          assumptionNote: 'One serving = ' + servingG + ' g of the finished dish.' },
        { measure: 'g', measureAr: 'جرام', grams: 100, labelEn: 'Weighed (100 g)',
          assumptionNote: 'Grams of the finished dish.' }
      ]
    };
  }

  /** Resolve a food OR a recipe by id. Recipes carry a `recipe:` prefix. */
  function resolveFood(id) {
    if (!id) return null;
    var s = String(id);
    if (s.indexOf('recipe:') === 0) {
      var r = getRecipe(s.slice(7));
      return r ? recipeAsFood(r) : null;
    }
    return CN.foods.byId(s);
  }

  /**
   * Resolve a plan item's display name. Food is looked up live, falling back to
   * the name snapshot taken when the item was created.
   */
  function itemName(item, lang) {
    var food = item && item.foodId ? resolveFood(item.foodId) : null;
    if (food) return lang === 'ar' ? (food.nameAr || food.nameEn) : food.nameEn;
    if (!item) return '';
    return lang === 'ar' ? (item.labelAr || item.label || item.foodId)
                         : (item.label || item.foodId);
  }

  CN.planner = {
    buildRestrictions: buildRestrictions,
    recipeNutrition: recipeNutrition,
    ingredientNutrition: ingredientNutrition,
    setRecipeIndex: setRecipeIndex,
    getRecipe: getRecipe,
    recipes: recipes,
    recipeAsFood: recipeAsFood,
    resolveFood: resolveFood,
    itemName: itemName,
    approachRules: approachRules,
    roundPortion: roundPortion,
    sumItems: sumItems,
    generate: generate,
    recalc: recalc,
    recalcItem: recalcItem,
    adherenceToTarget: adherenceToTarget,
    suggestSwaps: suggestSwaps,
    applySwap: applySwap,
    addMeal: addMeal,
    removeMeal: removeMeal,
    addItem: addItem,
    removeItem: removeItem,
    setItemGrams: setItemGrams,
    restrictionViolations: restrictionViolations,
    diff: diff,
    toTemplate: toTemplate,
    fromTemplate: fromTemplate
  };
})();
