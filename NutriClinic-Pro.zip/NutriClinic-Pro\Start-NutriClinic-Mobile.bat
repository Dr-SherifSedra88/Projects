@echo off
setlocal EnableExtensions EnableDelayedExpansion
title NutriClinic Pro - Network mode
cd /d "%~dp0"

rem ===========================================================================
rem  Serves NutriClinic Pro to your whole network, so you can open it on a
rem  phone, a tablet, or another computer on the same Wi-Fi.
rem
rem  READ THIS: the app has no login yet, so anyone on the same network could
rem  open it too. Use this on a network you trust (home, clinic LAN) and stop
rem  the server when you are finished.
rem ===========================================================================

set "PORT=8617"
set "PY="

where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)

if not exist "%~dp0site\index.html" (
  echo.
  echo   Could not find site\index.html next to this script.
  echo.
  pause
  exit /b 1
)

if not defined PY (
  echo.
  echo   Python was not found, so network mode is unavailable.
  echo.
  echo   Install Python from https://www.python.org/downloads/
  echo   then run this script again. Meanwhile you can open
  echo   site\index.html directly, on this computer only.
  echo.
  pause
  exit /b 0
)

echo.
echo   NutriClinic Pro - network mode
echo   ==============================
echo.
echo   On THIS computer:
echo       http://127.0.0.1:%PORT%/
echo.
echo   On your PHONE, TABLET or any other computer on the same network:
echo.

set "FOUND="
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
  set "L=%%a"
  set "L=!L: =!"
  if not "!L!"=="" if not "!L:~0,3!"=="127" (
    echo       http://!L!:%PORT%/
    set "FOUND=1"
  )
)

if not defined FOUND (
  echo       (No network address detected. Are you connected to Wi-Fi?)
)

echo.
echo   If Windows asks whether to allow Python through the firewall,
echo   choose "Private networks" and Allow. Without it, other devices
echo   cannot connect.
echo.
echo   Keep this window open while using the app on another device.
echo   Press Ctrl+C to stop.
echo.

start "" "http://127.0.0.1:%PORT%/"
%PY% -m http.server %PORT% --bind 0.0.0.0 --directory "%~dp0site"

echo.
echo   Server stopped.
pause
exit /b 0
