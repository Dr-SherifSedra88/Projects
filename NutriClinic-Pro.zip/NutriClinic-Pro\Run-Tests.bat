@echo off
setlocal EnableExtensions
title NutriClinic Pro - Test Suite
cd /d "%~dp0"

rem Served on a DIFFERENT PORT on purpose: a different origin means a different
rem IndexedDB database, so the test probe records can never touch real clinic data.
set "PORT=8618"
set "PY="

where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)

if not defined PY goto :nopython

if not exist "%~dp0tests\engine-tests.html" (
  echo   Could not find tests\engine-tests.html next to this script.
  pause
  exit /b 1
)

echo.
echo   NutriClinic Pro - automated test suite
echo   Open: http://127.0.0.1:%PORT%/tests/engine-tests.html
echo.
echo   Run over this server so the storage suite exercises IndexedDB.
echo   The page reports every assertion as PASS or FAIL.
echo   Close this window when you are done.
echo.

start "" "http://127.0.0.1:%PORT%/tests/engine-tests.html"
%PY% -m http.server %PORT% --bind 127.0.0.1 --directory "%~dp0"

pause
exit /b 0

:nopython
echo.
echo   Python was not found, so the test suite cannot be served.
echo   Opening it directly instead - the storage suite will then
echo   exercise browser storage rather than IndexedDB.
echo.
start "" "%~dp0tests\engine-tests.html"
pause
exit /b 0
