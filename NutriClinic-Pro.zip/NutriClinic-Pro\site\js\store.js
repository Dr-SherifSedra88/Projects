/* ==========================================================================
   NutriClinic Pro — store.js
   Persistence with two interchangeable adapters:

     indexedDB  — persistent, the normal case when served over http(s)
     memory     — automatic fallback, e.g. when opened from file:// where
                  Chromium blocks IndexedDB on opaque origins

   The rest of the application is unaware of which adapter is active. The
   Settings screen surfaces the active engine and warns when data is
   session-only, because silently losing records would be unacceptable in a
   clinical context.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  var DB_NAME = 'nutriclinic_pro';
  var DB_VERSION = 2;
  var STORES = ['patients', 'measurements', 'labs', 'assessments', 'plans', 'followups',
    'templates', 'settings', 'attachments', 'recipes', 'kb'];

  var localBackend = null;     // browser storage: indexeddb | localstorage | memory
  var remoteBackend = null;    // optional Supabase adapter (clinical data only)
  var engineName = 'memory';   // 'indexeddb' | 'localstorage' | 'memory'
  var readyPromise = null;

  /**
   * Which adapter serves a given store.
   *
   * Settings stay LOCAL even when a backend is connected: they are device
   * preferences — language, report template, storage overrides — and silently
   * sharing them across a clinic would be surprising.
   */
  function backendFor(name) {
    if (remoteBackend && name !== 'settings') return remoteBackend;
    return localBackend;
  }

  /* ------------------------------------------------------ binary helpers --- */
  /**
   * Attachment binaries are encoded for the backup. A backup that quietly drops
   * the documents is not a backup, so the payload travels with the record; the
   * encoder is explicit and reversible rather than lossy.
   */
  function blobToDataUrl(blob) {
    return new Promise(function (res, rej) {
      var r = new FileReader();
      r.onload = function () { res(String(r.result)); };
      r.onerror = function () { rej(r.error); };
      r.readAsDataURL(blob);
    });
  }

  /** Exact inverse of blobToDataUrl. Returns null on malformed input. */
  function dataUrlToBlob(dataUrl) {
    var m = /^data:([^;,]*);base64,(.*)$/.exec(String(dataUrl || ''));
    if (!m) return null;
    try {
      var bin = atob(m[2]);
      var bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new Blob([bytes], { type: m[1] || 'application/octet-stream' });
    } catch (e) {
      return null;
    }
  }

  /* ------------------------------------------------- localstorage adapter ---
     Used when IndexedDB is unavailable — notably on file:// origins in
     Chromium, which is exactly what happens when index.html is double-clicked.
     Records then survive a reload, which is what makes the delivered file
     genuinely usable without a server.

     localStorage is capped at a few megabytes, so attachment binaries are
     encoded only while they fit a budget. Past that the record is kept WITHOUT
     its content and marked as such, rather than failing silently. */
  function LocalStorageAdapter() {
    var PREFIX = 'cn.store.';
    var BLOB_BUDGET_BYTES = 3 * 1024 * 1024;

    function read(s) {
      try {
        var raw = localStorage.getItem(PREFIX + s);
        if (!raw) return [];
        var v = JSON.parse(raw);
        return Array.isArray(v) ? v : [];
      } catch (e) { return []; }
    }

    function write(s, rows) {
      try { localStorage.setItem(PREFIX + s, JSON.stringify(rows)); return true; }
      catch (e) { return false; }
    }

    function encode(s, rows) {
      if (s !== 'attachments') return Promise.resolve(rows);
      var used = 0;
      return Promise.all(rows.map(function (r) {
        if (!r.blob) return r;
        var est = Math.ceil((r.blob.size || 0) * 4 / 3);
        if (used + est > BLOB_BUDGET_BYTES) {
          var dropped = Object.assign({}, r);
          delete dropped.blob;
          dropped.contentIncluded = false;
          return dropped;
        }
        used += est;
        return blobToDataUrl(r.blob).then(function (d) {
          var copy = Object.assign({}, r);
          delete copy.blob;
          copy.dataUrl = d;
          copy.contentIncluded = true;
          return copy;
        }).catch(function () {
          var meta = Object.assign({}, r);
          delete meta.blob;
          meta.contentIncluded = false;
          return meta;
        });
      }));
    }

    function decode(s, rows) {
      if (s !== 'attachments') return rows;
      return rows.map(function (r) {
        if (!r.dataUrl) return r;
        var copy = Object.assign({}, r);
        copy.blob = dataUrlToBlob(r.dataUrl);
        delete copy.dataUrl;
        return copy;
      });
    }

    return {
      name: 'localstorage',
      all(s) { return Promise.resolve(decode(s, read(s))); },
      get(s, id) {
        var row = read(s).filter(function (r) { return r.id === id; })[0];
        return Promise.resolve(row ? decode(s, [row])[0] : null);
      },
      put(s, obj) {
        var rows = read(s);
        var i = rows.findIndex(function (r) { return r.id === obj.id; });
        var next = rows.slice();
        if (i === -1) next.push(obj); else next[i] = obj;
        return encode(s, next).then(function (encoded) {
          if (write(s, encoded)) return obj;
          // Quota exhausted: retry with every attachment payload stripped.
          var stripped = encoded.map(function (r) {
            if (s !== 'attachments' || !r.dataUrl) return r;
            var m = Object.assign({}, r);
            delete m.dataUrl;
            m.contentIncluded = false;
            return m;
          });
          if (write(s, stripped)) return obj;
          return Promise.reject(new Error(
            'Browser storage is full, so this record could not be saved. ' +
            'Launch NutriClinic Pro with the included start script for unrestricted storage.'));
        });
      },
      del(s, id) {
        write(s, read(s).filter(function (r) { return r.id !== id; }));
        return Promise.resolve(true);
      },
      clear(s) { write(s, []); return Promise.resolve(true); },
      wipe() { STORES.forEach(function (s) { write(s, []); }); return Promise.resolve(true); },
      raw() {
        var out = {};
        STORES.forEach(function (s) { out[s] = decode(s, read(s)); });
        return Promise.resolve(out);
      },
      load(snapshot) {
        return Promise.all(STORES.map(function (s) {
          return encode(s, snapshot[s] || []).then(function (rows) { write(s, rows); });
        })).then(function () { return true; });
      }
    };
  }

  /* ------------------------------------------------------ memory adapter --- */
  /**
   * Clone that PRESERVES binary payloads.
   * JSON-based cloning silently reduces a File/Blob to {} — which would look
   * like a successful write while destroying the document. Blobs are therefore
   * carried by reference and everything else is deep-copied.
   */
  function cloneValue(v) {
    if (v === null || typeof v !== 'object') return v;
    if (typeof Blob !== 'undefined' && v instanceof Blob) return v;   // File extends Blob
    if (Array.isArray(v)) return v.map(cloneValue);
    var out = {};
    Object.keys(v).forEach(function (k) { out[k] = cloneValue(v[k]); });
    return out;
  }

  function MemoryAdapter() {
    var data = {};
    STORES.forEach(function (s) { data[s] = []; });
    return {
      name: 'memory',
      all(s) { return Promise.resolve(cloneValue(data[s] || [])); },
      get(s, id) {
        var row = (data[s] || []).filter(function (r) { return r.id === id; })[0];
        return Promise.resolve(row ? cloneValue(row) : null);
      },
      put(s, obj) {
        data[s] = data[s] || [];
        var i = data[s].findIndex(function (r) { return r.id === obj.id; });
        if (i === -1) data[s].push(cloneValue(obj));
        else data[s][i] = cloneValue(obj);
        return Promise.resolve(obj);
      },
      del(s, id) {
        data[s] = (data[s] || []).filter(function (r) { return r.id !== id; });
        return Promise.resolve(true);
      },
      clear(s) { data[s] = []; return Promise.resolve(true); },
      wipe() { STORES.forEach(function (s) { data[s] = []; }); return Promise.resolve(true); },
      raw() { return cloneValue(data); },
      load(snapshot) {
        STORES.forEach(function (s) { data[s] = (snapshot[s] || []).slice(); });
        return Promise.resolve(true);
      }
    };
  }

  /* --------------------------------------------------- indexeddb adapter --- */
  function openIDB() {
    return new Promise(function (resolve, reject) {
      var settled = false;
      function fail(e) { if (!settled) { settled = true; reject(e); } }
      try {
        if (!window.indexedDB) return fail(new Error('IndexedDB unavailable'));
        var req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = function (ev) {
          var db = ev.target.result;
          STORES.forEach(function (s) {
            if (db.objectStoreNames.contains(s)) return;
            var os = db.createObjectStore(s, { keyPath: 'id' });
            if (s !== 'settings' && s !== 'templates') {
              try { os.createIndex('patientId', 'patientId', { unique: false }); } catch (e) { /* optional */ }
            }
          });
        };
        req.onsuccess = function (ev) { if (!settled) { settled = true; resolve(ev.target.result); } };
        req.onerror = function (ev) { fail((ev.target && ev.target.error) || new Error('open failed')); };
        req.onblocked = function () { fail(new Error('blocked by another tab')); };
        // Some environments neither succeed nor error; do not hang the app.
        setTimeout(function () { fail(new Error('IndexedDB open timed out')); }, 2500);
      } catch (e) { fail(e); }
    });
  }

  function tx(db, store, mode) {
    return db.transaction(store, mode).objectStore(store);
  }

  function wrap(req) {
    return new Promise(function (res, rej) {
      req.onsuccess = function () { res(req.result); };
      req.onerror = function () { rej(req.error); };
    });
  }

  function IndexedDbAdapter(db) {
    return {
      name: 'indexeddb',
      all(s) { return wrap(tx(db, s, 'readonly').getAll()); },
      get(s, id) { return wrap(tx(db, s, 'readonly').get(id)); },
      put(s, obj) { return wrap(tx(db, s, 'readwrite').put(obj)).then(function () { return obj; }); },
      del(s, id) { return wrap(tx(db, s, 'readwrite').delete(id)); },
      clear(s) { return wrap(tx(db, s, 'readwrite').clear()); },
      wipe() {
        return Promise.all(STORES.map(function (s) {
          return wrap(tx(db, s, 'readwrite').clear());
        }));
      },
      raw() {
        var out = {};
        return STORES.reduce(function (p, s) {
          return p.then(function () {
            return wrap(tx(db, s, 'readonly').getAll()).then(function (rows) { out[s] = rows; });
          });
        }, Promise.resolve()).then(function () { return out; });
      },
      load(snapshot) {
        return Promise.all(STORES.map(function (s) {
          var os = tx(db, s, 'readwrite');
          return wrap(os.clear()).then(function () {
            return Promise.all((snapshot[s] || []).map(function (row) {
              return wrap(os.put(row));
            }));
          });
        }));
      }
    };
  }

  /* ------------------------------------------------------------- settings --- */
  var DEFAULTS = {
    id: 'clinic',
    clinicName: 'NutriClinic Pro',
    clinicAddress: '',
    clinicPhone: '',
    clinicEmail: '',
    physicianName: '',
    physicianTitle: 'Clinical Nutritionist',
    defaultFormula: 'mifflin_st_jeor',
    defaultActivity: 'moderate',
    defaultDeficit: 'moderate',
    defaultSurplus: 'moderate',
    defaultDuration: 7,
    units: 'metric',
    portionDisplay: 'both',
    aiEnabled: false,
    aiEndpoint: '',
    reportMode: 'branded',
    reportAccent: '#14213D',
    reportFontScale: 1,
    reportShowNutrients: true,
    reportShowSignature: true,
    customFields: [],
    seeded: false
  };

  function loadSettings() {
    return localBackend.get('settings', 'clinic').then(function (row) {
      return Object.assign({}, DEFAULTS, row || {});
    });
  }

  function saveSettings(patch) {
    return loadSettings().then(function (cur) {
      var next = Object.assign({}, cur, patch || {});
      return localBackend.put('settings', next).catch(function (e) {
        CN.bus.emit('store-error', { action: 'put', store: 'settings', error: e });
        throw e;
      }).then(function () {
        CN.bus.emit('settings', next);
        return next;
      });
    });
  }

  /* --------------------------------------------------------------- public --- */
  function probeLocalStorage() {
    try {
      var k = '__cn_probe__';
      localStorage.setItem(k, '1');
      localStorage.removeItem(k);
      return true;
    } catch (e) { return false; }
  }

  function initAdapter() {
    return openIDB().then(function (db) {
      localBackend = IndexedDbAdapter(db);
      engineName = 'indexeddb';
    }).catch(function (err) {
      // IndexedDB is commonly unavailable on file:// origins. localStorage at
      // least keeps records across reloads, which is what makes a double-clicked
      // index.html usable rather than a demo that forgets everything.
      if (probeLocalStorage()) {
        localBackend = LocalStorageAdapter();
        engineName = 'localstorage';
        if (window.console) {
          console.warn('[NutriClinic] IndexedDB unavailable (' + (err && err.message) +
            ') — using localStorage so records persist.');
        }
      } else {
        localBackend = MemoryAdapter();
        engineName = 'memory';
        if (window.console) {
          console.warn('[NutriClinic] falling back to an in-memory store:', err && err.message);
        }
      }
    });
  }

  function byPatient(store, patientId) {
    return backendFor(store).all(store).then(function (rows) {
      return rows.filter(function (r) { return r.patientId === patientId; });
    });
  }

  var store = {
    /** Resolves when the storage backend is chosen and usable. */
    ready() {
      if (!readyPromise) readyPromise = initAdapter();
      return readyPromise;
    },
    get engine() { return engineName; },
    isPersistent() { return engineName !== 'memory'; },

    /**
     * What this storage tier can actually do, so the interface never promises
     * more than the environment can keep.
     */
    capabilities() {
      var eff = remoteBackend ? 'supabase' : engineName;
      return {
        engine: eff,
        persistent: eff !== 'memory',
        fullDocumentStorage: eff === 'indexeddb' || eff === 'supabase',
        // In server mode documents live in private object storage, so browser
        // quota is irrelevant.
        documentsInObjectStorage: eff === 'supabase',
        maxAttachmentBytes: (eff === 'indexeddb' || eff === 'supabase')
          ? 8 * 1024 * 1024 : 1500 * 1024,
        label: eff === 'supabase' ? 'st.storageServer'
          : (eff === 'indexeddb' ? 'st.storageIdb'
            : (eff === 'localstorage' ? 'st.storageLocal' : 'st.storageMemory'))
      };
    },

    // A failed write must be VISIBLE. Every view calls put() and most ignore
    // rejections, so failures are announced centrally here rather than relying
    // on twenty-five call sites to each remember a catch block. A clinician
    // must never believe a record was saved when it was not.
    all(s) {
      return backendFor(s).all(s).catch(function (e) {
        CN.bus.emit('store-error', { action: 'read', store: s, error: e });
        throw e;
      });
    },
    get(s, id) {
      return backendFor(s).get(s, id).catch(function (e) {
        CN.bus.emit('store-error', { action: 'read', store: s, id: id, error: e });
        throw e;
      });
    },
    put(s, obj) {
      if (!obj || typeof obj !== 'object') {
        var bad = new Error('Nothing was saved: a record must be an object.');
        CN.bus.emit('store-error', { action: 'put', store: s, error: bad });
        return Promise.reject(bad);
      }
      if (!obj.id) obj.id = U.uid(s.slice(0, 3));
      // The store name MUST be forwarded. An earlier version of this line read
      // `backend.put(obj)` — one argument — which passed the record itself as
      // the store name and left the row undefined, so every write in the
      // application either threw (IndexedDB) or silently discarded the record
      // (localStorage and memory). Nothing could ever have been saved.
      return backendFor(s).put(s, obj).catch(function (e) {
        CN.bus.emit('store-error', { action: 'put', store: s, id: obj.id, error: e });
        throw e;
      });
    },
    del(s, id) {
      return backendFor(s).del(s, id).catch(function (e) {
        CN.bus.emit('store-error', { action: 'delete', store: s, id: id, error: e });
        throw e;
      });
    },
    clear(s) {
      return backendFor(s).clear(s).catch(function (e) {
        CN.bus.emit('store-error', { action: 'clear', store: s, error: e });
        throw e;
      });
    },
    byPatient: byPatient,

    settings() { return loadSettings(); },
    saveSettings: saveSettings,

    /** Delete a patient and every dependent record. */
    deletePatient(patientId) {
      var deps = ['measurements', 'labs', 'assessments', 'plans', 'followups', 'attachments', 'recipes'];
      return Promise.all(deps.map(function (s) {
        return byPatient(s, patientId).then(function (rows) {
          return Promise.all(rows.map(function (r) { return backendFor(s).del(s, r.id); }));
        });
      })).then(function () { return backendFor('patients').del('patients', patientId); });
    },

    /* ------------------------------------------------------------ backup --- */
    /**
     * Backup. Attachment binaries ARE included, base64-encoded, so a restore is
     * lossless. Base64 inflates the payload by roughly a third; the envelope
     * reports what was carried and flags anything that could not be read.
     */
    backup() {
      var clinicalSource = remoteBackend ? remoteBackend.raw() : localBackend.raw();
      return Promise.all([clinicalSource, localBackend.raw(), loadSettings()]).then(function (r) {
        // In server mode clinical records come from the server and settings from
        // this device. Locally, one source serves everything.
        var data = {};
        STORES.forEach(function (s) {
          data[s] = (remoteBackend && s !== 'settings') ? (r[0][s] || []) : (r[1][s] || []);
        });
        var list = data.attachments || [];
        var included = 0, failed = 0, bytes = 0;

        return Promise.all(list.map(function (a) {
          var meta = Object.assign({}, a);
          delete meta.blob;
          if (!a.blob) { meta.contentIncluded = false; return meta; }
          return blobToDataUrl(a.blob).then(function (d) {
            meta.dataUrl = d;
            meta.contentIncluded = true;
            included++;
            bytes += a.blob.size || 0;
            return meta;
          }).catch(function () {
            meta.contentIncluded = false;
            failed++;
            return meta;
          });
        })).then(function (attachments) {
          data.attachments = attachments;
          return JSON.stringify({
            app: 'NutriClinic Pro',
            schema: DB_VERSION,
            exportedAt: new Date().toISOString(),
            engine: remoteBackend ? 'supabase' : engineName,
            attachments: included
              ? { count: included, bytes: bytes, encoding: 'base64' }
              : { count: 0 },
            excluded: failed ? [failed + ' attachment file(s) could not be read'] : [],
            settings: r[2],
            data: data
          }, null, 2);
        });
      });
    },

    /** Replace everything from a backup document. Validates before wiping. */
    restore(jsonText) {
      var parsed;
      try { parsed = JSON.parse(jsonText); }
      catch (e) { return Promise.reject(new Error('That file is not valid JSON.')); }

      if (!parsed || parsed.app !== 'NutriClinic Pro' || !parsed.data) {
        return Promise.reject(new Error('That file is not a NutriClinic Pro backup.'));
      }
      if (Number(parsed.schema) > DB_VERSION) {
        return Promise.reject(new Error('This backup was written by a newer version of the app.'));
      }

      var snap = {};
      STORES.forEach(function (s) {
        snap[s] = Array.isArray(parsed.data[s]) ? parsed.data[s] : [];
      });

      // Rebuild attachment binaries from the encoded payload. A record whose
      // content was absent (an older, metadata-only backup) is kept without a
      // blob so the interface can ask for the document to be re-attached.
      snap.attachments = (parsed.data.attachments || []).map(function (a) {
        var copy = Object.assign({}, a);
        if (copy.dataUrl) {
          copy.blob = dataUrlToBlob(copy.dataUrl);
          copy.contentIncluded = !!copy.blob;
          delete copy.dataUrl;
        } else {
          copy.blob = null;
          copy.contentIncluded = false;
        }
        return copy;
      });

      snap.settings = [];
      if (parsed.settings) snap.settings = [Object.assign({}, DEFAULTS, parsed.settings)];

      if (!remoteBackend) {
        return localBackend.load(snap).then(function () {
          CN.bus.emit('data', { action: 'restore' });
          return true;
        });
      }

      // Server mode: clinical data goes to the server, settings stay on device.
      var clinicalSnap = {}, settingsSnap = {};
      STORES.forEach(function (s) {
        clinicalSnap[s] = (s === 'settings') ? [] : (snap[s] || []);
        settingsSnap[s] = (s === 'settings') ? (snap.settings || []) : [];
      });
      return remoteBackend.load(clinicalSnap)
        .then(function () { return localBackend.load(settingsSnap); })
        .then(function () {
          CN.bus.emit('data', { action: 'restore' });
          return true;
        });
    },

    wipe() {
      var tasks = [localBackend.wipe()];
      if (remoteBackend) tasks.push(remoteBackend.wipe());
      return Promise.all(tasks).then(function () {
        CN.bus.emit('data', { action: 'wipe' });
        return true;
      });
    },

    /* ------------------------------------------------------- backend mode --- */
    /**
     * Load backend configuration and connect automatically when a session and
     * a clinic membership are already present. Failure is never fatal: the app
     * stays on local storage and Settings reports why.
     */
    initBackend() {
      if (!CN.backend) return Promise.resolve(false);
      CN.backend.loadConfig();
      if (!CN.backend.configured() || !CN.backend.hasSession()) return Promise.resolve(false);
      return CN.backend.clinic().then(function () {
        remoteBackend = CN.backend.createAdapter();
        CN.bus.emit('backend', { action: 'connected' });
        return true;
      }).catch(function (e) {
        if (window.console) {
          console.warn('[NutriClinic] server backend not connected:', e && e.message);
        }
        return false;
      });
    },

    isRemote() { return !!remoteBackend; },

    /** Use the server adapter for clinical data. Call after a successful sign-in. */
    enableRemote() {
      if (!CN.backend) return Promise.reject(new Error('The backend module is not loaded.'));
      remoteBackend = CN.backend.createAdapter();
      CN.bus.emit('backend', { action: 'connected' });
      return Promise.resolve(true);
    },

    disableRemote() {
      remoteBackend = null;
      CN.bus.emit('backend', { action: 'disconnected' });
      return Promise.resolve(true);
    },

    // Binary helpers. Exposed because backup integrity rests on them, and a
    // claim about binary handling is worth nothing unless it is testable.
    blobToDataUrl: blobToDataUrl,
    dataUrlToBlob: dataUrlToBlob,

    /* --------------------------------------------------------- demo seed --- */
    /**
     * Demonstration records. Deliberately fictitious and clearly labelled —
     * a clinic must never seed this into a working database (brief §19).
     */
    seedDemo() {
      var today = U.todayISO();
      function shift(days) {
        var d = new Date();
        d.setDate(d.getDate() + days);
        return d.toISOString().slice(0, 10);
      }

      var p1 = {
        id: 'pat_demo_1', code: 'NC-1001', name: 'Mona Abdelrahman', sex: 'female',
        dob: '1984-03-12', phone: '+20 100 000 0001', email: '', occupation: 'Teacher',
        registeredAt: shift(-84),
        emergency: { name: 'Ahmed S.', phone: '+20 100 000 0009', relation: 'Spouse' },
        conditions: ['Type 2 diabetes', 'Hypertension'],
        medications: 'Metformin 1000 mg twice daily; Amlodipine 5 mg once daily',
        supplements: 'Vitamin D 1000 IU daily',
        restrictions: [
          { kind: 'allergy', substance: 'peanut', severity: 'moderate', diagnosed: true },
          { kind: 'intolerance', substance: 'lactose', severity: 'mild', diagnosed: false }
        ],
        familyHistory: 'Father: type 2 diabetes.',
        surgeries: 'None.',
        giNotes: 'Occasional bloating after dairy.',
        notes: 'Motivated, prefers Egyptian home cooking. Works long hours.',
        pregnancy: 'Not applicable',
        lifestyle: {
          activity: 'light', exercise: 'Walks 20–30 min, 3× weekly', sleep: '6.5',
          smoking: 'Non-smoker', water: '1200', meals: '3',
          preferences: 'Mediterranean, Egyptian dishes', disliked: 'Liver, okra',
          cultural: 'Halal', budget: 'moderate', cooking: 'Limited time on weekdays',
          eatingHabits: 'Skips breakfast 2–3 days per week'
        },
        goal: 'weight_loss'
      };

      var p2 = {
        id: 'pat_demo_2', code: 'NC-1002', name: 'Youssef Kamal', sex: 'male',
        dob: '1976-11-02', phone: '+20 100 000 0002', email: '',
        occupation: 'Accountant', registeredAt: shift(-42),
        emergency: { name: 'Hana K.', phone: '+20 100 000 0010', relation: 'Sister' },
        conditions: ['Hyperlipidaemia'],
        medications: 'Atorvastatin 20 mg once daily at night',
        supplements: 'None', restrictions: [], familyHistory: 'Brother: myocardial infarction at 52.',
        surgeries: 'Appendectomy 2009.', giNotes: 'None.', notes: 'Sedentary desk role.',
        pregnancy: 'Not applicable',
        lifestyle: {
          activity: 'sedentary', exercise: 'None currently', sleep: '7', smoking: 'Ex-smoker (4 years)',
          water: '1000', meals: '2', preferences: 'Grilled meats, rice', disliked: 'Salads',
          cultural: 'Halal', budget: 'moderate', cooking: 'Spouse prepares meals',
          eatingHabits: 'Large evening meal, frequent restaurant lunches'
        },
        goal: 'therapeutic'
      };

      var p3 = {
        id: 'pat_demo_3', code: 'NC-1003', name: 'Salma Fathy', sex: 'female',
        dob: '1997-06-25', phone: '+20 100 000 0003', email: 'salma@example.com',
        occupation: 'Pharmacist', registeredAt: shift(-21),
        emergency: { name: 'Nour F.', phone: '+20 100 000 0011', relation: 'Sister' },
        conditions: [], medications: 'None', supplements: 'Iron, occasional',
        restrictions: [{ kind: 'preference', substance: 'red meat', severity: 'n/a', diagnosed: false }],
        familyHistory: 'Unremarkable.', surgeries: 'None.', giNotes: 'None.',
        notes: 'Runs 4× weekly. Underweight since adolescence; wants to gain lean mass.',
        pregnancy: 'Not applicable',
        lifestyle: {
          activity: 'very', exercise: 'Running 5 km, 4× weekly', sleep: '7.5', smoking: 'Non-smoker',
          water: '2200', meals: '3', preferences: 'Poultry, fish, dairy', disliked: 'Fried food',
          cultural: 'Halal', budget: 'comfortable', cooking: 'Cooks for herself',
          eatingHabits: 'Frequent but small meals'
        },
        goal: 'weight_gain'
      };

      var setup = [
        { patient: p1, h: 162, w0: 88.4, w1: 84.9, w2: 83.1, target: 72, waist: 98, hip: 108, fat: 38.2 },
        { patient: p2, h: 176, w0: 96.2, w1: 94.4, w2: 93.5, target: 84, waist: 104, hip: 104, fat: 27.4 },
        { patient: p3, h: 168, w0: 49.8, w1: 50.6, w2: 51.2, target: 57, waist: 64, hip: 90, fat: 18.6 }
      ];

      var writes = [];

      setup.forEach(function (s, i) {
        writes.push(store.put('patients', s.patient));
        // Three measurement points per patient.
        var points = [
          { d: shift(-84 + i * 3), w: s.w0, fat: s.fat, waist: s.waist },
          { d: shift(-42 + i * 3), w: s.w1, fat: U.round(s.fat - 1.1, 1), waist: s.waist - 2 },
          { d: shift(-14 + i * 3), w: s.w2, fat: U.round(s.fat - 1.9, 1), waist: s.waist - 3 }
        ];
        points.forEach(function (pt, j) {
          writes.push(store.put('measurements', {
            id: 'mea_demo_' + (i + 1) + '_' + j,
            patientId: s.patient.id,
            measuredAt: pt.d,
            heightCm: s.h,
            weightKg: pt.w,
            targetWeightKg: s.target,
            waistCm: pt.waist,
            hipCm: s.hip,
            bodyFatPct: pt.fat,
            muscleMassKg: U.round(pt.w * (1 - pt.fat / 100) * 0.52, 1),
            visceralFat: i === 0 ? 12 : (i === 1 ? 13 : 8),
            totalBodyWaterPct: U.round(48 + (i === 2 ? 4 : 0), 1),
            source: 'bioimpedance',
            deviceName: 'Clinic analyser',
            notes: j === 0 ? 'Baseline.' : ''
          }));
        });

        writes.push(store.put('followups', {
          id: 'fu_demo_' + (i + 1),
          patientId: s.patient.id,
          scheduledFor: shift(-14 + i * 3),
          attendedAt: shift(-14 + i * 3),
          adherence: i === 0 ? 'moderate' : 'high',
          appetiteChange: 'Stable',
          giSymptoms: i === 0 ? 'Mild bloating after dairy' : 'None',
          feedback: 'Sleep improved; finds the plan manageable.',
          observations: 'Continuing as planned.',
          nextAppointmentAt: shift(14),
          createdAt: new Date().toISOString()
        }));
      });

      // One laboratory panel for the diabetes patient, to exercise the lab view.
      writes.push(store.put('labs', {
        id: 'lab_demo_1', patientId: 'pat_demo_1', collectedOn: shift(-35),
        laboratoryName: 'Central laboratory', fasting: true,
        notes: 'Routine review.',
        results: [
          { analyte: 'Fasting glucose', value: 7.4, unit: 'mmol/L', refLow: 3.9, refHigh: 5.6 },
          { analyte: 'HbA1c', value: 7.1, unit: '%', refLow: 4.0, refHigh: 5.7 },
          { analyte: 'Total cholesterol', value: 5.4, unit: 'mmol/L', refLow: 0, refHigh: 5.2 },
          { analyte: 'LDL cholesterol', value: 3.3, unit: 'mmol/L', refLow: 0, refHigh: 3.0 },
          { analyte: 'HDL cholesterol', value: 1.2, unit: 'mmol/L', refLow: 1.0, refHigh: 2.0 },
          { analyte: 'Triglycerides', value: 1.9, unit: 'mmol/L', refLow: 0, refHigh: 1.7 },
          { analyte: 'Creatinine', value: 76, unit: 'µmol/L', refLow: 53, refHigh: 97 },
          { analyte: 'eGFR', value: 88, unit: 'mL/min/1.73m²', refLow: 90, refHigh: 120 },
          { analyte: 'TSH', value: 2.1, unit: 'mIU/L', refLow: 0.4, refHigh: 4.0 },
          { analyte: 'Vitamin D (25-OH)', value: 44, unit: 'nmol/L', refLow: 75, refHigh: 200 }
        ]
      }));

      writes.push(store.put('labs', {
        id: 'lab_demo_2', patientId: 'pat_demo_2', collectedOn: shift(-20),
        laboratoryName: 'Central laboratory', fasting: true,
        results: [
          { analyte: 'Total cholesterol', value: 6.1, unit: 'mmol/L', refLow: 0, refHigh: 5.2 },
          { analyte: 'LDL cholesterol', value: 4.1, unit: 'mmol/L', refLow: 0, refHigh: 3.0 },
          { analyte: 'HDL cholesterol', value: 0.9, unit: 'mmol/L', refLow: 1.0, refHigh: 2.0 },
          { analyte: 'Triglycerides', value: 2.6, unit: 'mmol/L', refLow: 0, refHigh: 1.7 },
          { analyte: 'Fasting glucose', value: 5.5, unit: 'mmol/L', refLow: 3.9, refHigh: 5.6 }
        ]
      }));

      return Promise.all(writes)
        .then(function () { return saveSettings({ seeded: true }); })
        .then(function () {
          CN.bus.emit('data', { action: 'seed' });
          return true;
        });
    }
  };

  CN.store = store;
})();
