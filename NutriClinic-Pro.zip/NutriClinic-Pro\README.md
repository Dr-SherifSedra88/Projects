# NutriClinic Pro — Clinical Nutrition & Patient Management Platform

A premium clinical nutrition workstation for a private clinic: electronic patient records, deterministic
energy calculations, therapeutic diet planning, smart food exchange, a patient-aware copilot, follow-up
management and A4 report output. Bilingual English / Arabic with full RTL support.

**Static, self-contained build.** No build step, no dependencies, no CDN, no external fonts — every
asset ships in-site, satisfying a strict CSP.

---

## ⚠️ Scope and limitations — read before using clinically

This application was **authored from scratch against the original 23-section brief**. It is honest
about what it does and does not do.

| | Status |
|---|---|
| All 13 modules, deterministic engine, persistence, plan generation, smart exchange, PDF output | **Delivered** |
| Bilingual EN/AR with RTL | **Delivered** |
| Local document attachments — lab and body-composition files (brief §4) | **Delivered** — held in the browser, downloadable back; excluded from backups |
| Blood pressure recording (brief §4) | **Delivered** — stored in the same append-only measurement history |
| Clinician-defined custom fields (brief §3) | **Delivered** — defined in Settings, no source change |
| Clinic reporting with search and filters (brief §18) | **Delivered** |
| Custom recipes — nutrition computed from ingredients and finished yield, selectable in the Plan Builder and in Smart Exchange (brief §12) | **Delivered** |
| Knowledge base — text, Markdown, CSV, TSV and JSON ingested, chunked and searchable (brief §11) | **Delivered** |
| Knowledge base — PDF, Word and Excel text extraction | **Not implemented** — the format is recognised, the file is kept for reference, and the interface states plainly that its text was not read. Needs a server-side indexer. |
| PostgreSQL, server API, authentication, RBAC, encryption at rest, audit log, backups (brief §§19, 21) | **Not implemented** |
| Live internet research with source attribution (brief §12) | **Not implemented** — and stated as such in the UI |
| LLM-backed Copilot (brief §9) | **Not implemented** — the shipped copilot is a rule-based interpreter that says so. A proxy adapter is wired and documented. |

**Clinical content is a synthesis, not a transcription.** The food table, the 20 approaches and the
clinical briefs were written from established nutrition science and standard reference values. They are
internally consistent and clinically sane, but they are **not** derived from the uploaded lecture PDFs —
those could not be read in the authoring environment. All of it lives in three `data-*.js` files, so
replacing it with your own material is mechanical.

**Do not put real patient data in it.** Storage is browser-local with no authentication and no audit
trail. See `docs/backend-and-security.md` for what closing that gap requires.

---

## Quick start

Three ways to run it, from simplest to most capable.

### 1. Just open it (no tools needed)

Double-click **`site/index.html`**. Everything works — dashboard, patients, calculations,
plans, recipes, copilot, reports. Records persist across reloads in browser storage.

*Limit:* browser storage is capped at a few megabytes here, so keep document attachments small.
If it fills up, the app tells you instead of losing the record silently.

### 2. Local server (recommended on this machine)

Double-click **`Start-NutriClinic.bat`** in the folder above `site/`. It starts a server, opens the
app, and uses IndexedDB — so records and documents are stored in full.

If Python is missing, the script says so and opens the app anyway.

*Port clash:* use `Start-NutriClinic.ps1`, which picks a free port automatically.

### 3. Network mode — phone, tablet, another computer

Double-click **`Start-NutriClinic-Mobile.bat`**. It serves the app to your whole network and prints
the exact `http://…` address to type on the other device.

```
http://192.168.1.x:8617/      ← the script prints your real address
```

Requirements and cautions:

- The other device must be on the **same network**.
- Windows will ask whether to let Python through the firewall — choose **Private networks** and Allow,
  or other devices cannot connect.
- **There is no login yet.** Anyone on that network can open the app. Use it on a network you trust,
  and stop the server (Ctrl+C) when you are done.
- **Each device keeps its own records.** Data lives in that device's browser storage, so a patient
  registered on your phone does **not** appear on your desktop. Only the server build (below) gives
  one shared record set.

### 4. A public link other devices can reach over the internet

This project cannot deploy itself — there is no deployment tool here, and I will not invent a URL.
But `site/` is a plain static folder with relative paths and no build step, so it can be dropped onto
any static host unchanged:

| Host | Steps |
|---|---|
| **Netlify Drop** | Go to `app.netlify.com/drop`, drag the **`site`** folder onto the page. You get an HTTPS link in seconds. |
| **Cloudflare Pages** | Create a project, choose "direct upload", upload the contents of `site/`. |
| **GitHub Pages** | Commit the contents of `site/` to a repo and enable Pages. |

`site/_headers` adds security headers on hosts that honour it (Netlify, Cloudflare Pages).

**Read this before hosting publicly:** a public link serves the *application*, not your data. Each
visitor's records live in their own browser, so nobody sees yours — and your devices still do not
share records with each other. A public URL makes the app reachable; it does not make the data
shared or secure. For that you need the server build described in `docs/`.

---

## Server backend — shared records, login and audit (optional)

The application runs fully without a server. Connecting one adds what a browser alone cannot
provide: **one shared record set across authorised devices, authentication, role-based access and a
server-side audit trail.**

It uses a plain Supabase project (PostgreSQL + Auth + private Storage). No SDK is loaded — the app
talks to Supabase's REST, Auth and Storage HTTP APIs with `fetch`, so the no-external-assets
constraint still holds.

### Exact steps — about ten minutes, and they need your account

I cannot create this for you: it requires your Supabase login. Everything on the application side is
already implemented and merged; only the project has to exist.

1. **Create the project.** `supabase.com` → New project. Choose a region close to the clinic and
   save the database password somewhere safe.
2. **Create the schema.** Open the SQL editor, paste the whole of `docs/supabase-schema.sql`, run it.
   It creates the tables, enables row-level security, adds the audit triggers, creates the private
   `clinical-documents` bucket and installs the onboarding functions.
3. **Decide on email confirmation.** Authentication → Providers → Email. With confirmation ON, a new
   user must click a link before signing in. Turning it OFF is faster for a single-clinic pilot but
   means unverified addresses can register.
4. **Copy two values.** Project Settings → API: the **Project URL** and the **anon / public** key.
5. **Put them in the app.** Either
   - copy `site/config.example.js` to `site/config.js` and fill in those two values (recommended for
     a deployment), or
   - open **Settings → Server backend** in the running app and paste them there (stored on that
     device only).
6. **Create the first account and clinic.** Settings → Server backend → enter an email and a secret →
   **Create account and clinic**. The first account becomes the clinic **owner**.
7. **Add colleagues.** Have each person register, then on the owner's device call the
   `add_clinic_member` function with their email and a role (`clinician`, `assistant` or `auditor`).
   Only an owner can add members, which keeps privilege escalation out of the clinical role.
8. **Verify.** Press **Test connection** — it performs a real request and reports the failure reason
   if anything is wrong, rather than showing a hopeful tick.

### What the security model actually guarantees

| Concern | How it is handled |
|---|---|
| Key exposure | Only the **anon** key ships. It is public by design and grants nothing without a signed-in clinic member. The **service_role** key bypasses every rule — it is never in this codebase, and must never be put in `config.js`. |
| Cross-clinic access | Every clinical table has RLS enabled and one policy: `clinic_id in (select my_clinics())`. A signed-in user sees only their own clinic's rows. |
| Self-promotion | Membership is writable only through `add_clinic_member`, which refuses any caller who is not an owner. |
| Documents | The storage bucket is **private**. Objects sit under `<clinic_id>/…` and are reached only via short-lived signed URLs. |
| Modification audit | Written by **trigger**, so a client cannot skip it. The clinical payload is deliberately not copied into the log — the entry records who changed which record when, without duplicating patient data into a second table. |
| Read audit | Recorded through an explicit RPC when a patient record is opened. **This is client-reported** and therefore weaker: see the honesty note below. |

**Read audit is not tamper-proof.** A client that never calls `log_access` leaves no read record. Write
audit cannot be bypassed; read audit can. If non-repudiable read auditing is a requirement, move data
access behind a server function instead of the REST client used here. The schema file says this too —
I would rather you know the limit than discover it in an inspection.

### Honest status

**Implemented in the application; not yet exercised against a live project.** The adapter, the
authentication flow, the signed-URL document path, the schema, the RLS policies and the audit
triggers are all written. What has never happened is a real round-trip, because that needs a Supabase
project and I cannot create one. Until you complete the steps above and test, the correct description
is *implemented and unverified*, not *working*.

### Settings stay local by design

Clinic identity, language, report template and defaults are device preferences and are **not** synced
when a backend is connected. Clinical records are. If you want the clinic name shared, that belongs in
the `clinics` table, not in device settings.

---

## Development quick start

No build step, no dependencies, no install.

```bash
# From this folder — recommended, so IndexedDB works
python -m http.server 8617 --bind 127.0.0.1
# then open http://127.0.0.1:8617/
```

Opening `index.html` directly via `file://` also works. Storage picks the best tier available:
**IndexedDB → localStorage → in-memory**. On `file://`, IndexedDB is typically blocked, so the app uses
localStorage and records **do** survive a reload; only the last tier is session-only, and Settings
states plainly which engine is active.

On first run you get a short clinic-identity setup, then an empty dashboard. Settings → *Load
demonstration data* adds three fictitious patients with measurements, labs, a plan and follow-ups.

---

## Project structure

```
site/                          ← the deployable site root
├── index.html                 App shell: mount points + ordered script tags
├── assets/favicon.svg
├── css/
│   ├── app.css                Design system and all screen styling
│   └── print.css              A4 report layout (media="print")
└── js/
    ├── core.js                Utilities, icon set, toasts, modal/drawer layer
    ├── i18n.js                Full EN/AR dictionary, RTL switching
    ├── data-foods.js          Egyptian food table, household portions, allergens
    ├── data-approaches.js     20 approaches, compatibility matrix, meal patterns
    ├── data-references.js     Clinical briefs + evidence hierarchy
    ├── store.js               IndexedDB with in-memory fallback, backup/restore, demo seed
    ├── engine.js              Deterministic BMR/TDEE/deficit/surplus/macros/safety/progress
    ├── charts.js              Dependency-free SVG charts
    ├── planner.js             Plan generation, editing, smart exchange, diff, templates
    ├── copilot.js             AR/EN intent interpreter, KB search, optional LLM adapter
    ├── pdf.js                 Report builder and print pipeline
    ├── views-core.js          Shared UI helpers · Dashboard · Patients · New Patient · Settings
    ├── views-clinical.js      Clinical Assessment · Energy Calculator · Body Composition
    ├── views-planning.js      Diet Plan Builder · Follow-Up · Reports
    ├── views-library.js       Food Database · Clinical References
    └── app.js                 Shell, routing, patient context, first-run, Copilot view

tests/engine-tests.html        QA page — MUST NOT ship with the site
docs/                          Server migration path and verification notes
deploy/                        Registry entry and deploy steps
```

Script load order in `index.html` is **load-bearing**: each module may depend only on those above it.

---

## The 13 modules

Dashboard · Patients · New Patient · Clinical Assessment · Energy Calculator · Body Composition ·
Diet Plan Builder · AI Nutrition Copilot · Follow-Up Management · Food Database · Clinical References ·
Reports & PDF · Settings

---

## The calculation engine is the spine

Every clinical number in the interface comes from `engine.js` or `planner.js`. Both are pure
functions — same input, same output, no I/O — which is what makes them testable and reproducible.

- **BMR** — Mifflin-St Jeor, Harris-Benedict (1919 and Roza 1984), plus device-reported and manual
  entry. A measured value is labelled as measured and never presented as an estimate.
- **TDEE** — activity factor applied to BMR, with the factor always displayed.
- **Target** — the deficit is applied to **TDEE, never to BMR**. A hard safety floor (1200 kcal
  female / 1500 kcal male) and a 30%-of-TDEE cap are enforced before any figure is shown.
- **Safety screen** — pregnancy, eating-disorder history, renal disease, type 1 diabetes, BMI under
  18.5 with a weight-loss goal, refeeding risk, and predicted loss above 1% of body weight per week
  all raise flags. Any `alert` sets *requires review*.
- **Reassessment** — proposes a revised target at follow-up and **never reduces calories for a short
  plateau alone**. Poor adherence, fluid shifts, medication changes and sub-three-week plateaus all
  hold the target steady. Every change requires clinician approval.
- **Approval is enforced** — a calorie target is stored with its approver; the Plan Builder refuses to
  generate anything without an approved target.

### Verify it yourself

Open `tests/engine-tests.html` in a browser. It runs ~90 assertions against hand-computed fixtures —
BMR for each equation, deficit clamping, the underweight and pregnancy safety paths, macro arithmetic,
exchange-portion maths, plan determinism, allergen exclusion, smart-exchange ranking, Arabic intent
parsing, and de-identification. It prints a pass/fail table.

> **Not yet executed.** The authoring environment had no browser and no shell, so this suite has never
> been run. It is the first thing to open. Treat any failure as a real defect.

---

## Design invariants

- **No green anywhere** — backgrounds, buttons, icons, charts, progress and status indicators
  included. `charts.js` cannot reach a green value; semantic states reuse navy (neutral/positive),
  gold (caution) and burgundy (alert).
- **Palette** — navy `#14213D`, burgundy `#800020`, soft gold `#C6A667`, light gray `#F4F5F7`,
  charcoal `#333333`, white.
- **System fonts only** — no external font may load.
- **History is appended, never overwritten** — measurements, lab panels, follow-ups and plan versions
  all accumulate. Plan edits create a new version and the previous one is preserved and diffable.
- **AI output is a draft** — nothing the copilot produces is applied without clinician approval.

---

## Smart food exchange

Select any item in a plan and press the swap button. Alternatives are matched on whichever objective
you choose (calories, protein, carbohydrate or fat), with portions recalculated to hit that objective,
ranked by similarity across all four macro dimensions.

Substitutions that are not nutritionally close are **labelled approximate** rather than presented as
equivalent. Foods excluded by an allergy are never offered. Composite dishes with unresolved
ingredient lists are flagged for verification.

---

## Persistence and data

- **IndexedDB** when served over http(s); **in-memory** automatically otherwise. The active engine is
  shown in Settings — it is never silently downgraded.
- **Backup** downloads a complete JSON snapshot, **including attachment file contents** encoded as
  base64, so a restore is byte-for-byte lossless. The envelope reports how many attachments travelled.
  **Restore** validates the envelope before writing anything, refuses a file from a newer schema, and
  accepts a version-1 backup by upgrading it in place.
- Deleting a patient removes their measurements, labs, assessments, plans, follow-ups, attachments and recipes.
- **Demo seeding must not run on a clinic holding real records.**

---

## Reports & PDF

PDF export is the **browser's print-to-PDF**, driven by `css/print.css`. A bundled renderer would need
a build step and would breach the no-external-assets constraint, so this is a deliberate choice, stated
in the interface rather than disguised.

Two modes: **branded** (clinic identity, logo, signature block) and **plain** (no clinic identity, for
externally branded stationery). Report includes patient summary, measurements with change, energy and
macronutrient targets, the full multi-day plan with household portions, clinical considerations and a
disclaimer. Meal rows are prevented from breaking across pages.

Page numbering is provided by the browser's print dialog rather than asserted by the stylesheet.

---

## Local verification

```powershell
# 1. Syntax-check every module
cd site
foreach ($f in (Get-ChildItem js/*.js).Name) { node --check "js/$f" }

# 2. Confirm no external references anywhere
Select-String -Path index.html,css/*.css,js/*.js -Pattern 'https?://'   # expect: only refs data URLs

# 3. Serve
python -m http.server 8617 --bind 127.0.0.1
```

Then browse the 13 modules, toggle EN ⇄ AR (layout must mirror), exercise a patient end to end, and
check the print preview.

---

## Deployment

Target contract: **nginx environment, `entryFile: index.html`, site root = `site/`**. The registry
entry to append is in `deploy/projects.entry.json`; the merge steps and validation are in
`deploy/APPLY-NOTES.md`.

Before deploying:

1. **Do not deploy `tests/`** — it is QA-only.
2. **Do not deploy `docs/` or `README.md`** — a static root will serve them, publishing your data model
   and security-gap analysis to anyone who requests those paths. Deploy the contents of `site/` only.
3. **Disable demo seeding** if the instance will ever hold real records.

---

## Modification guide

| To change | Edit |
|---|---|
| Foods, portions, allergens | `js/data-foods.js` |
| Approaches, compatibility rules, meal patterns | `js/data-approaches.js` |
| Clinical briefs and sources | `js/data-references.js` |
| Calculations (BMR, TDEE, macros, safety, reassessment) | `js/engine.js` — keep functions pure |
| Plan generation, exchange logic, recipe nutrition, diffing | `js/planner.js` |
| Interface strings | `js/i18n.js` — add to **both** EN and AR |
| Colours, layout, components | `css/app.css` — preserve the no-green invariant |
| Print/PDF layout | `css/print.css` and `js/pdf.js` |
| Copilot intents | `js/copilot.js` |
| Custom patient fields | Settings screen — **no code change required** |

Adding a module: create `js/<name>.js`, add a `<script>` tag **in dependency order**, register a route
in `ROUTES` in `app.js`, and add `CN.views.<name> = { title, render(host, ctx) }`.

---

## Outstanding work

- Run `tests/engine-tests.html` and fix anything it reports. **It has never been executed.**
- Replace the synthesised clinical content with the clinic's own reference material.
- Server build per brief §§19/21 — designed in `docs/database-schema.sql` and
  `docs/backend-and-security.md`, not built.
- Knowledge-base uploads with retrieval (brief §11). Text and CSV could be ingested client-side;
  PDF and DOCX cannot without a bundled parser, which the no-external-assets constraint rules out.
- Live research integration and a genuine LLM copilot behind a server-held key (brief §§9, 12).
- Attachments travel inside the backup as base64, so a backup grows by roughly a third of the
  attachment bytes. A server-backed deployment should move them to object storage.
- Knowledge-base PDF, Word and Excel ingestion requires a server-side indexer; the adapter contract
  is documented in `js/kb.js` and Settings.

---

## External integrations still requiring configuration

Nothing below is simulated. Each entry states what exists today and what a deployment must supply.

| Integration | Status in this build | What a deployment must provide |
|---|---|---|
| **External language model** | Proxy adapter wired (`js/copilot.js` → `callExternal`). Disabled by default; every response says whether a model was consulted. Sends **no credential**. | A server-side proxy URL in Settings. The proxy holds the API key and forwards a de-identified payload. Required contract: `POST` JSON `{instruction, patient, targets, followUpCount}` → `{text}`. |
| **Knowledge-base indexing for PDF / Word / Excel** | Formats recognised; files stored for reference; text explicitly not read and not searchable. | A server exposing `POST {base}/documents` (multipart → `{id,title,chunks}`), `GET {base}/search?q=` and `DELETE {base}/documents/{id}`. Set the base URL via `CN.kb.remote.setEndpoint()`. |
| **Live internet research** | Not implemented, and the interface says so. No claim of a search is ever made. | A search API reached through the same server-side proxy pattern, with source attribution returned alongside results. |
| **Clinical data backend** | None. Records live in the browser. | The full server build per brief §§19/21 — schema in `docs/database-schema.sql`, contract in `docs/backend-and-security.md`. |
| **PDF rendering** | Browser print-to-PDF. No external renderer. | Nothing, unless server-side PDF generation with embedded Arabic fonts is required — then a rendering service. |

**No credential belongs in this application.** `Settings → AI configuration` deliberately has no API
key field: in a browser-only build any key would be readable by whoever opens the page. That is why
the adapter is a proxy contract rather than a direct provider call.
