/* ==========================================================================
   NutriClinic Pro — copilot.js
   Intent interpretation in Arabic, English and mixed clinical instructions,
   and patient-aware responses.

   HONESTY CONTRACT (brief §9, §12):
     - This is a RULE-BASED interpreter running locally. It is a real
       implementation, not a simulation of one, and it says so: when the
       external-model adapter is off, every response states that no model was
       consulted.
     - It NEVER produces a clinical number. Energy and macronutrient values are
       read from the calculation engine output and the approved assessment.
     - It never claims to have searched the internet.
     - It never transmits patient identifiers; outbound payloads are built from
       a whitelist of de-identified clinical fields.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  /* --------------------------------------------------------- language ----- */
  var AR_RE = /[\u0600-\u06FF]/;
  function detectLang(text) {
    var s = String(text || '');
    var ar = (s.match(AR_RE) || []).length;
    var en = (s.match(/[A-Za-z]/g) || []).length;
    if (ar && en) return 'mixed';
    return ar ? 'ar' : 'en';
  }

  /* ------------------------------------------------------ approach terms --- */
  var APPROACH_TERMS = {
    mediterranean:       ['mediterranean', 'متوسطي', 'البحر المتوسط'],
    dash:                ['dash', 'داش'],
    low_carb:            ['low carb', 'low-carb', 'lowcarb', 'قليل الكربوهيدرات', 'منخفض الكارب', 'قليل النشويات'],
    low_gi:              ['low gi', 'low-gi', 'glycemic', 'glycaemic', 'جلايسيمي', 'مؤشر سكري'],
    ketogenic:           ['keto', 'ketogenic', 'كيتوني', 'كيتوجينيك'],
    intermittent_fasting:['intermittent fast', 'fasting', '16:8', '5:2', 'صيام', 'متقطع'],
    gluten_free:         ['gluten', 'coeliac', 'celiac', 'جلوتين', 'سيلياك'],
    dairy_free:          ['dairy free', 'dairy-free', 'milk free', 'خالي من الألبان', 'بدون ألبان', 'بدون حليب'],
    lactose_free:        ['lactose', 'لاكتوز'],
    low_sodium:          ['low sodium', 'low salt', 'sodium', 'صوديوم', 'قليل الملح', 'قليل الصوديوم'],
    high_protein:        ['high protein', 'protein', 'عالي البروتين', 'بروتين عالي', 'زيادة البروتين'],
    low_fat:             ['low fat', 'low-fat', 'قليل الدهون', 'منخفض الدهون'],
    calorie_controlled:  ['calorie controlled', 'calorie-controlled', 'محدد السعرات', 'تحديد السعرات'],
    vegetarian:          ['vegetarian', 'نباتي'],
    vegan:               ['vegan', 'نباتي صرف', 'نباتي تماما', 'نباتي تمامًا'],
    renal:               ['renal', 'kidney', 'كلى', 'كلوي'],
    diabetes_oriented:   ['diabetes', 'diabetic', 'سكري', 'السكري'],
    heart_healthy:       ['heart', 'cardiac', 'cardiovascular', 'قلب', 'قلبي'],
    weight_management:   ['weight management', 'weight loss', 'lose weight', 'إدارة الوزن', 'خفض الوزن', 'فقدان الوزن', 'إنقاص الوزن'],
    maintenance:         ['maintenance', 'maintain', 'صيانة', 'ثبات', 'الحفاظ على الوزن', 'المحافظة']
  };

  var EXCLUSION_TERMS = {
    gluten: ['gluten', 'جلوتين'],
    milk: ['milk', 'dairy', 'ألبان', 'حليب'],
    lactose: ['lactose', 'لاكتوز'],
    egg: ['egg', 'بيض'],
    peanut: ['peanut', 'فول سوداني'],
    treenut: ['tree nut', 'nuts', 'almond', 'walnut', 'مكسرات', 'لوز', 'عين جمل'],
    soy: ['soy', 'صويا'],
    fish: ['fish', 'seafood', 'سمك', 'أسماك'],
    shellfish: ['shellfish', 'shrimp', 'قشريات', 'جمبري'],
    sesame: ['sesame', 'tahini', 'سمسم', 'طحينة'],
    red_meat: ['red meat', 'beef', 'لحم أحمر', 'بقري'],
    sugar: ['sugar', 'sweets', 'سكر', 'حلويات']
  };

  var DURATION_WORDS = [
    { re: /\b(seven|7)[\s-]?day|week|أسبوع|سبعة أيام|٧ أيام/i, days: 7 },
    { re: /\b(three|3)[\s-]?day|ثلاثة أيام|٣ أيام/i, days: 3 },
    { re: /\b(fourteen|14)[\s-]?day|two weeks|أسبوعين|١٤ يوم/i, days: 14 },
    { re: /\b(ten|10)[\s-]?day|عشرة أيام/i, days: 10 },
    { re: /\b(single|one|1)[\s-]?day|يوم واحد/i, days: 1 }
  ];

  function findTerms(text, table) {
    var s = String(text || '').toLowerCase();
    var hits = [];
    Object.keys(table).forEach(function (key) {
      var terms = table[key];
      for (var i = 0; i < terms.length; i++) {
        if (s.indexOf(terms[i].toLowerCase()) !== -1) { hits.push(key); break; }
      }
    });
    return hits;
  }

  /* ------------------------------------------------------------ interpret -- */
  /**
   * interpret(text) -> { intent, params, understanding, lang }
   * Pure and synchronous; no I/O.
   */
  function interpret(text) {
    var s = String(text || '');
    var lower = s.toLowerCase();
    var lang = detectLang(s);
    var params = {};
    var understanding = [];

    var approachHits = findTerms(s, APPROACH_TERMS);
    var maintenance = approachHits.indexOf('maintenance') !== -1;
    approachHits = approachHits.filter(function (a) { return a !== 'maintenance'; });
    if (maintenance) approachHits.push('weight_management');

    // Duration
    for (var i = 0; i < DURATION_WORDS.length; i++) {
      if (DURATION_WORDS[i].re.test(s)) { params.durationDays = DURATION_WORDS[i].days; break; }
    }
    var numMatch = /(\d{1,2})\s*(?:day|أيام|يوم)/i.exec(s);
    if (numMatch) {
      var n = parseInt(numMatch[1], 10);
      if (n > 0 && n <= 28) params.durationDays = n;
    }

    // Exclusions — only when the phrasing asks for removal.
    var wantsExclusion = /exclude|remove|without|avoid|no\s+\w+\s|احذف|استبعد|بدون|خالي من|خال من|تجنب/i.test(s);
    var exclusionHits = findTerms(s, EXCLUSION_TERMS);
    if (exclusionHits.length && wantsExclusion) {
      params.exclusions = exclusionHits;
      approachHits = approachHits.filter(function (a) { return a !== 'dairy_free' && a !== 'lactose_free' && a !== 'gluten_free'; });
      if (exclusionHits.indexOf('gluten') !== -1) approachHits.push('gluten_free');
      if (exclusionHits.indexOf('milk') !== -1 || exclusionHits.indexOf('lactose') !== -1) approachHits.push('dairy_free');
    }

    if (approachHits.length) params.approachCodes = approachHits;

    // Budget / affordability
    if (/cheap|affordable|budget|economical|رخيص|اقتصادي|ميزانية|أسعار/i.test(s)) params.affordable = true;
    if (/egyptian|مصري|محلي/i.test(s)) params.egyptian = true;

    // Intent classification, most specific first.
    var intent = 'question';
    if (/replace|swap|substitute|instead of|استبدل|بديل|بدّل/i.test(s)) intent = 'swap';
    else if (/lighter|smaller|reduce portion|adjust portion|modify|change the plan|عدّل|خفيف|قلل الكمية|تعديل الخطة/i.test(s)) intent = 'modify_plan';
    else if (/keep the same|same structure|نفس الهيكل|نفس البنية|نفس التركيب/i.test(s)) intent = 'modify_plan';
    else if (/maintenance|maintain|صيانة|ثبات|الحفاظ/i.test(s)) intent = 'maintenance_plan';
    else if (/create|generate|make|build|plan for|diet for|أنشئ|اعمل|ولد|صمم|خطة|نظام/i.test(s)) intent = 'generate_plan';
    else if (/recalculate|adjust.*calorie|update.*target|أعد حساب|عدّل السعرات|حدّث الهدف/i.test(s)) intent = 'adjust_target';
    else if (/explain|why|what is|how much|ما هو|لماذا|اشرح|وضح|كم/i.test(s)) intent = 'question';

    if (approachHits.length && intent === 'question' &&
        /plan|diet|نظام|خطة/i.test(s)) intent = 'generate_plan';

    params.approachCodes = params.approachCodes || [];

    understanding.push((lang === 'ar' ? 'الهدف: ' : 'Goal: ') +
      (intent === 'generate_plan' ? (lang === 'ar' ? 'توليد خطة غذائية' : 'generate a diet plan')
        : intent === 'swap' ? (lang === 'ar' ? 'استبدال صنف' : 'substitute a food item')
        : intent === 'modify_plan' ? (lang === 'ar' ? 'تعديل الخطة الحالية' : 'modify the current plan')
        : intent === 'maintenance_plan' ? (lang === 'ar' ? 'خطة صيانة' : 'a maintenance plan')
        : intent === 'adjust_target' ? (lang === 'ar' ? 'مراجعة هدف الطاقة' : 'review the energy target')
        : (lang === 'ar' ? 'سؤال' : 'a question')));

    if (params.approachCodes.length) {
      understanding.push((lang === 'ar' ? 'الأنظمة: ' : 'Approaches: ') + params.approachCodes.map(function (c) {
        var a = CN.approaches.byCode(c);
        return a ? (lang === 'ar' ? a.nameAr : a.nameEn) : c;
      }).join(' + '));
    }
    if (params.durationDays) {
      understanding.push((lang === 'ar' ? 'المدة: ' : 'Duration: ') + params.durationDays + ' ' +
        (lang === 'ar' ? 'يوم' : (params.durationDays === 1 ? 'day' : 'days')));
    }
    if (params.exclusions && params.exclusions.length) {
      understanding.push((lang === 'ar' ? 'استبعاد: ' : 'Exclusions: ') +
        params.exclusions.map(function (e) { return CN.foods.allergenLabel(e, lang === 'ar' ? 'ar' : 'en'); }).join(', '));
    }
    if (params.affordable) understanding.push(lang === 'ar' ? 'تفضيل الأطعمة الاقتصادية' : 'Preference for affordable foods');

    return { intent: intent, params: params, understanding: understanding, lang: lang, confidence: approachHits.length || params.durationDays ? 'high' : 'low' };
  }

  /* --------------------------------------------------------- KB retrieval -- */
  function searchKB(query, codes) {
    var t = String(query || '').toLowerCase();
    var out = (CN.refs.all || []).filter(function (b) {
      if (codes && codes.length && (b.approaches || []).some(function (a) { return codes.indexOf(a) !== -1; })) return true;
      if (!t) return false;
      return b.titleEn.toLowerCase().indexOf(t) !== -1 ||
        b.summary.toLowerCase().indexOf(t) !== -1 ||
        (b.tags || []).some(function (tag) { return t.indexOf(tag) !== -1; });
    });
    return out.slice(0, 4);
  }

  /* ----------------------------------------------------- de-identified call */
  /**
   * Build an outbound payload containing no direct identifiers.
   * Returns null when a direct identifier would have to be included.
   */
  function deidentifiedPayload(text, ctx) {
    var p = (ctx && ctx.patient) || null;
    var age = p ? U.ageFrom(p.dob) : null;
    var payload = {
      instruction: text,
      patient: null
    };
    if (p) {
      payload.patient = {
        // Banded and generalised — never names, codes, dates or contact fields.
        ageBand: age === null ? null : (age < 18 ? '0-17' : age < 30 ? '18-29' : age < 45 ? '30-44' : age < 60 ? '45-59' : '60+'),
        sex: p.sex || null,
        goal: p.goal || null,
        conditionCount: (p.conditions || []).length,
        conditions: (p.conditions || []).slice(0, 6),
        restrictionCount: (p.restrictions || []).length
      };
    }
    // Refuse rather than leak: a name must never survive into the payload.
    if (p && p.name && JSON.stringify(payload).indexOf(p.name) !== -1) return null;

    // Approved targets and follow-up state carry no identifiers, so they can
    // travel and make the model's answer materially better.
    if (ctx && ctx.assessment && ctx.assessment.targetKcal) {
      var mac = ctx.assessment.macros || {};
      payload.targets = {
        kcal: ctx.assessment.targetKcal,
        proteinG: mac.proteinG || null,
        carbG: mac.carbG || null,
        fatG: mac.fatG || null
      };
    }
    if (ctx && ctx.followups && ctx.followups.length) {
      payload.followUpCount = ctx.followups.length;
      payload.latestAdherence = ctx.followups[0].adherence || null;
    }
    return payload;
  }

  function callExternal(text, ctx) {
    var s = ctx && ctx.settings;
    if (!s || !s.aiEnabled || !s.aiEndpoint) return Promise.resolve(null);

    // NO CREDENTIAL IS SENT. In a browser-only build an API key is readable by
    // anyone who opens the page, and brief §19 requires keys to live on the
    // server. The configured URL is therefore expected to be a proxy that holds
    // the key and forwards an already de-identified request.
    var payload = deidentifiedPayload(text, ctx);
    if (!payload) return Promise.resolve({ error: 'identifiers_present' });

    var headers = { 'Content-Type': 'application/json' };

    // ---------------------------------------------------------------------
    // The configured endpoint is expected to be our own server-side proxy
    // (see supabase/functions/copilot), which REQUIRES the caller's session
    // token so it can authenticate the clinician before calling the provider.
    //
    // That header cannot be written here: the workspace write guard rejects any
    // assignment whose name is "Authorization", treating it as a credential
    // literal, and I have been told not to work around that check. Add this
    // single line immediately below, reading the token the backend already
    // stores after sign-in:
    //
    //   headers['Authorization'] = 'Bearer ' + JSON.parse(
    //     localStorage.getItem('cn.backend.session') || 'null').access_token;
    //
    // Wrapped in try/catch if you prefer it to fail soft. Until it is added the
    // proxy answers 401 and the copilot reports "Not authenticated. Sign in
    // first." — a visible failure, not a silent one.
    // ---------------------------------------------------------------------

    return fetch(s.aiEndpoint, {
      method: 'POST',
      headers: headers,
      credentials: 'omit',
      body: JSON.stringify(payload)
    }).then(function (r) {
      // Read the body even on failure: the proxy explains WHY it refused, and a
      // bare status code would hide that explanation from the clinician.
      return r.text().then(function (raw) {
        var parsed = null;
        try { parsed = raw ? JSON.parse(raw) : null; } catch (e) { parsed = null; }
        if (!r.ok) {
          var msg = (parsed && (parsed.error || parsed.message)) || ('HTTP ' + r.status);
          var err = new Error(msg);
          err.status = r.status;
          throw err;
        }
        return parsed || {};
      });
    }).then(function (j) {
      return { text: j.text || j.reply || j.content || '' };
    }).catch(function (e) {
      return { error: e.message || 'request failed' };
    });
  }

  /* ------------------------------------------------------------- respond --- */
  /**
   * respond(text, ctx) -> Promise<result>
   * ctx: { patient, assessment (approved only), macros, plan (latest version),
   *        settings, history }
   */
  function respond(text, ctx) {
    ctx = ctx || {};
    var lang = detectLang(text);
    var isAr = lang === 'ar';
    var parsed = interpret(text);
    var blocks = [];
    var warnings = [];
    var draft = null;
    var refs = [];

    function p(t) { blocks.push({ kind: 'p', text: t }); }
    function ul(items) { blocks.push({ kind: 'ul', items: items }); }
    function notice(text, tone) { blocks.push({ kind: 'notice', tone: tone || 'info', text: text }); }

    /**
     * Close the response, waiting for the external-model attempt (if any) so
     * the envelope always states honestly which mode produced the content.
     */
    function finish() {
      return Promise.all([
        Promise.resolve(externalPromise),
        Promise.resolve(kbPromise)
      ]).then(function (pair) {
        var ext = pair[0];
        var kbHits = pair[1] || [];
        var mode = 'local';
        if (ext && ext.error === 'identifiers_present') {
          mode = 'blocked';
          notice(isAr
            ? 'أُلغي الاتصال بالنموذج الخارجي: كانت الحمولة ستحتوي معرّفًا مباشرًا.'
            : 'External model call aborted: the outbound payload would have contained a direct identifier.', 'alert');
        } else if (ext && ext.text) {
          mode = 'external';
          blocks.push({ kind: 'external', text: ext.text });
        } else if (ext && ext.error) {
          mode = 'external_failed';
          notice((isAr ? 'فشل الاتصال بالنموذج الخارجي: ' : 'External model call failed: ') + ext.error +
            (isAr ? ' — كل ما يلي نتج محليًا.' : ' — everything below was produced locally.'), 'warn');
        }
        if (mode === 'local') {
          // State plainly that no model was consulted.
          blocks.unshift({
            kind: 'notice', tone: 'info',
            text: isAr
              ? 'محول النموذج الخارجي معطّل. كل ما يلي نتج محليًا بتفسير قائم على القواعد — لم يُستخدم أي نموذج.'
              : 'The external model adapter is disabled. Everything below was produced locally by rule-based interpretation — no model was consulted.'
          });
        }
        if (kbHits.length) {
          blocks.push({
            kind: 'p',
            text: isAr ? 'من قاعدة المعرفة المحلية:' : 'From the local knowledge base:'
          });
          kbHits.forEach(function (h) {
            blocks.push({ kind: 'notice', tone: 'info', text: h.title + ' — ' + h.snippet });
          });
        }

        return {
          ok: true,
          intent: parsed.intent,
          params: parsed.params,
          understanding: parsed.understanding,
          lang: lang,
          blocks: blocks,
          warnings: warnings,
          draft: draft,
          refs: refs,
          mode: mode,
          requiresApproval: true
        };
      });
    }

    var patient = ctx.patient;
    var assessment = ctx.assessment;   // must be the approved one

    // --- context statement -------------------------------------------------
    if (!patient) {
      notice(isAr
        ? 'لم يتم اختيار مريض. اختر مريضًا أولًا، أو اطلب مني عرض معلومات عامة.'
        : 'No patient is selected. Choose a patient first, or ask me for general information.', 'warn');
    } else {
      var age = U.ageFrom(patient.dob);
      p((isAr ? 'سياق المريض المستخدم: ' : 'Patient context in use: ') +
        (isAr ? '' : patient.name + ' · ') +
        (age !== null ? age + (isAr ? ' سنة' : ' y') : (isAr ? 'العمر غير محدد' : 'age not recorded')) +
        (patient.conditions && patient.conditions.length ? ' · ' + patient.conditions.join(', ') : '') +
        (patient.goal ? ' · ' + CN.t('goal.' + patient.goal) : ''));
    }

    // --- follow-up history -------------------------------------------------
    var followups = ctx.followups || [];
    if (followups.length) {
      var lastFu = followups[0];
      p((isAr ? 'آخر متابعة: ' : 'Latest follow-up: ') +
        (lastFu.attendedAt ? U.fmtDate(lastFu.attendedAt) + ' · ' : '') +
        (isAr ? 'الالتزام ' : 'adherence ') +
        (lastFu.adherence ? CN.t('adh.' + lastFu.adherence) : '—') +
        ' · ' + followups.length + (isAr ? ' سجل متابعة' : ' record(s)'));
    } else {
      notice(isAr
        ? 'لا توجد متابعات مسجلة لهذا المريض بعد.'
        : 'No follow-up has been recorded for this patient yet.', 'info');
    }

    // --- external model, if enabled ---------------------------------------
    var externalPromise = callExternal(text, ctx);

    // Retrieval runs in parallel with the model attempt, against whatever the
    // knowledge base currently holds locally (plus the remote index if set).
    var kbPromise = (CN.kb && CN.kb.search)
      ? CN.kb.search(text, 4).catch(function () { return []; })
      : Promise.resolve([]);

    // --- intent handling ---------------------------------------------------
    if (parsed.intent === 'generate_plan') {
      var codes = parsed.params.approachCodes.slice();
      if (!codes.length) codes = ['mediterranean'];

      // Compatibility is evaluated before anything is generated.
      var compat = CN.approaches.evaluate(codes);
      p(isAr ? 'النظام المقترح: ' : 'Proposed approach: ');
      ul(codes.map(function (c) {
        var a = CN.approaches.byCode(c);
        return (a ? (isAr ? a.nameAr : a.nameEn) : c) + ' — ' + (a ? a.summary : '');
      }));

      if (!compat.ok) {
        notice((isAr ? 'تركيبة غير متوافقة: ' : 'Incompatible combination: ') +
          compat.pairs.filter(function (x) { return x.level === 'incompatible'; })
            .map(function (x) { return x.rationale; }).join(' '), 'alert');
        return finish();
      } else if (compat.level === 'caution') {
        notice(compat.pairs.filter(function (x) { return x.level === 'caution'; })
          .map(function (x) { return x.rationale; }).join(' '), 'warn');
      }

      // Contraindications that the selected approaches raise for this patient.
      var cis = CN.approaches.contraindicationsFor(codes);
      if (patient && cis.length) {
        var conditions = (patient.conditions || []).join(' ').toLowerCase();
        var relevant = cis.filter(function (ci) {
          var key = ci.condition.toLowerCase().split(' ')[0];
          return conditions.indexOf(key) !== -1;
        });
        relevant.forEach(function (ci) {
          notice((isAr ? 'تحذير إكلينيكي: ' : 'Clinical caution: ') + ci.rationale,
            ci.severity === 'absolute' ? 'alert' : 'warn');
        });
      }

      // Energy figures come only from an approved assessment.
      if (!assessment || !assessment.targetKcal) {
        notice(isAr
          ? 'لا يوجد هدف سعرات معتمد لهذا المريض. أستطيع وصف المتطلبات، لكن الأرقام تنتجها حاسبة الطاقة. احسب الهدف واعتمده أولًا، ثم اطلب مني توليد الخطة.'
          : 'There is no approved calorie target for this patient. I can describe requirements, but the calorie and macronutrient figures are produced by the calculation engine. Calculate and approve a target first, then ask me to generate the plan.', 'warn');
        refs = searchKB('', codes);
        return finish();
      }

      var macroProfile = CN.approaches.mergedMacros(codes) || { proteinPct: 20, carbPct: 45, fatPct: 35 };
      var limits = CN.approaches.mergedLimits(codes);
      var macros = CN.engine.macros({
        targetKcal: assessment.targetKcal,
        weightKg: assessment.weightKg,
        profile: macroProfile,
        method: limits.proteinPerKg ? 'hybrid' : 'percent',
        proteinPerKg: limits.proteinPerKg || 0.8,
        fiberMin: limits.fiberMin,
        sodiumMaxMg: limits.sodiumMaxMg
      });

      p(isAr ? 'الاحتياج اليومي (من محرك الحساب): ' : 'Daily requirements (from the calculation engine): ');
      ul([
        (isAr ? 'هدف السعرات: ' : 'Calorie target: ') + U.nf(assessment.targetKcal, 0) + ' kcal',
        (isAr ? 'بروتين: ' : 'Protein: ') + macros.proteinG + ' g (' + macros.proteinPerKg + ' g/kg)',
        (isAr ? 'كربوهيدرات: ' : 'Carbohydrate: ') + macros.carbG + ' g',
        (isAr ? 'دهون: ' : 'Fat: ') + macros.fatG + ' g',
        (isAr ? 'ألياف: ' : 'Fibre: ') + macros.fiberG + ' g' +
          (limits.sodiumMaxMg ? ' · ' + (isAr ? 'صوديوم: ' : 'sodium: ') + limits.sodiumMaxMg + ' mg' : '')
      ]);
      notice(isAr
        ? 'كل قيمة أعلاه صادرة من محرك الحساب، وليس من التفسير اللغوي.'
        : 'Every value above is produced by the calculation engine, not by language interpretation.', 'info');

      // Draft plan
      var exclusions = (parsed.params.exclusions || []).slice();
      var gen = CN.planner.generate({
        patient: patient,
        targetKcal: assessment.targetKcal,
        macros: macros,
        approachCodes: codes,
        durationDays: parsed.params.durationDays || 7,
        startDate: U.todayISO(),
        patternKey: limits.pattern || null,
        assessmentId: assessment.id,
        generatedBy: 'copilot_draft'
      });

      if (gen.ok) {
        draft = gen;
        p(isAr ? 'المسودة جاهزة: ' : 'Draft prepared: ');
        ul([
          gen.durationDays + (isAr ? ' يومًا' : ' days'),
          gen.days.reduce(function (a, d) { return a + d.meals.length; }, 0) + (isAr ? ' وجبة' : ' meals'),
          (isAr ? 'متوسط السعرات اليومي: ' : 'Average daily energy: ') +
            U.nf(U.mean(gen.days.map(function (d) { return d.totals.kcal; })), 0) + ' kcal'
        ].concat(gen.warnings));
        notice(isAr
          ? 'المسودة لا تُعتمد تلقائيًا. راجعها واعتمدها في منشئ الخطة الغذائية.'
          : 'The draft is not applied automatically. Review and approve it in the Diet Plan Builder.', 'warn');
      }

      var violations = patient ? CN.planner.restrictionViolations(gen, patient) : [];
      if (violations.length) {
        notice((isAr ? 'تعارض مع القيود: ' : 'Restriction conflict: ') +
          violations.map(function (v) { return v.food; }).join(', '), 'alert');
      } else if (patient) {
        notice(isAr ? 'لم يُدرج أي طعام مستبعد بقيود المريض.' : 'No food excluded by the patient\u2019s restrictions was included.', 'ok');
      }

      refs = searchKB('', codes);

    } else if (parsed.intent === 'swap') {
      p(isAr
        ? 'للاستبدال، افتح الخطة الغذائية واستخدم زر «استبدال ذكي» بجانب الصنف. تُرتَّب البدائل حسب التشابه الغذائي مع مراعاة قيود المريض، ويُوسم أي استبدال تقريبي بأنه غير مطابق.'
        : 'To substitute an item, open the diet plan and use the Smart replace button beside it. Alternatives are ranked by nutritional similarity, honouring the patient\u2019s restrictions, and any approximate match is labelled as such.');
      if (ctx.plan) {
        var firstItem = null, loc = null;
        ctx.plan.days.forEach(function (d) {
          d.meals.forEach(function (m, mi) {
            m.items.forEach(function (it) {
              if (!firstItem) { firstItem = it; loc = { day: d.dayIndex, meal: mi }; }
            });
          });
        });
        if (firstItem) {
          var opts = CN.planner.suggestSwaps(firstItem, { patient: patient, approachCodes: ctx.plan.approachCodes, limit: 3 });
          var food = CN.planner.resolveFood(firstItem.foodId);
          if (opts.length) {
            p((isAr ? 'مثال من الخطة الحالية — بدائل لـ ' : 'Example from the current plan — alternatives to ') +
              (food ? (isAr ? food.nameAr : food.nameEn) : firstItem.foodId) + ':');
            ul(opts.map(function (o) {
              return (isAr ? o.food.nameAr : o.food.nameEn) + ' · ' + o.grams + ' g · ' +
                o.nutrients.kcal + ' kcal' + (o.approximate ? (isAr ? ' (تقريبي)' : ' (approximate)') : '');
            }));
          }
        }
      }

    } else if (parsed.intent === 'modify_plan') {
      p(isAr
        ? 'تعديل الخطة يتم على نسخة جديدة، ويُحفظ الإصدار السابق. استخدم «تعديل الخطة السابقة» في المتابعة، ثم اضبط الكميات — وتتحدث كل الإجماليات تلقائيًا.'
        : 'Modifications create a new version; the previous one is preserved. Use Modify previous plan from Follow-Up, then adjust portions — all totals recalculate automatically.');
      if (ctx.plan) {
        p((isAr ? 'الخطة الحالية: الإصدار ' : 'Current plan: version ') + ctx.plan.versionNo +
          ' · ' + (isAr ? 'هدف ' : 'target ') + U.nf(ctx.plan.targetKcal, 0) + ' kcal' +
          ' · ' + ctx.plan.days.length + (isAr ? ' يومًا' : ' days'));
      }
      if (followups.length && followups[0].adherence) {
        p((isAr ? 'يُؤخذ الالتزام المسجل في الحسبان: ' : 'Recorded adherence is taken into account: ') +
          CN.t('adh.' + followups[0].adherence));
      }

    } else if (parsed.intent === 'maintenance_plan') {
      if (!assessment || !assessment.tdee) {
        notice(isAr
          ? 'لا يوجد تقييم طاقة محسوب. احسب الأيض الأساسي وإجمالي الاستهلاك أولًا؛ خطة الصيانة تُبنى على إجمالي الاستهلاك اليومي.'
          : 'No energy assessment exists yet. Calculate BMR and TDEE first; a maintenance plan is built on the total daily expenditure.', 'warn');
      } else {
        p((isAr ? 'خطة الصيانة: هدف ' : 'Maintenance plan: target ') + U.nf(assessment.tdee, 0) +
          (isAr ? ' سعرات يوميًا (إجمالي الاستهلاك).' : ' kcal/day (total daily expenditure).'));
        p(isAr
          ? 'يُعدَّل الهدف وفق اتجاه الوزن الفعلي في كل متابعة، لا يبقى ثابتًا.'
          : 'Adjust the target against the observed weight trend at each follow-up rather than holding it fixed.');
      }

    } else if (parsed.intent === 'adjust_target') {
      if (!assessment) {
        notice(isAr ? 'لا يوجد تقييم طاقة لعرضه.' : 'There is no energy assessment to review.', 'warn');
      } else {
        p((isAr ? 'الهدف الحالي: ' : 'Current target: ') + U.nf(assessment.targetKcal, 0) + ' kcal · ' +
          (isAr ? 'الأيض الأساسي ' : 'BMR ') + U.nf(assessment.bmr, 0) + ' · ' +
          (isAr ? 'إجمالي الاستهلاك ' : 'TDEE ') + U.nf(assessment.tdee, 0));
        p(isAr
          ? 'تُقترح أي مراجعة للهدف في شاشة المتابعة، حيث تُقارن بالوزن الفعلي، ويجب اعتمادها قبل تطبيقها.'
          : 'Any revision is proposed on the Follow-Up screen against measured weight, and requires your approval before it applies.');
      }

    } else {
      // Question — answer from the local knowledge base, never inventing facts.
      var kb = searchKB(text, []);
      if (kb.length) {
        p(isAr ? 'من قاعدة المعرفة الإكلينيكية:' : 'From the clinical knowledge base:');
        kb.forEach(function (b) {
          blocks.push({ kind: 'brief', brief: b });
        });
        refs = kb;
      } else {
        p(isAr
          ? 'لم أجد ملخصًا مطابقًا في قاعدة المعرفة. لا أخترع مراجع. جرّب مصطلحًا مثل «بروتين» أو «صوديوم» أو «سكري»، أو راجع شاشة المراجع الإكلينيكية.'
          : 'I found no matching brief in the knowledge base. I do not invent references. Try a term such as "protein", "sodium" or "diabetes", or browse the Clinical References screen.');
        notice(isAr
          ? 'هذا المساعد لا يبحث في الإنترنت. لم يُجرَ أي بحث خارجي.'
          : 'This assistant does not search the internet. No external research was performed.', 'info');
      }
    }

    return finish();
  }

  /* --------------------------------------------------------- examples ------ */
  function examples(lang) {
    if (lang === 'ar') {
      return [
        'ولّد خطة متوسطية لسبعة أيام لهذا المريض باستخدام العجز المحسوب',
        'أنشئ خطة منخفضة المؤشر الجلايسيمي لمريض سكري',
        'اجمع بين نظامي داش والمتوسطي',
        'استبعد كل منتجات الألبان والفول السوداني',
        'استبدل المكونات الغالية ببدائل مصرية اقتصادية',
        'عدّل الخطة السابقة وفق آخر متابعة',
        'أعد حساب هدف السعرات وفق آخر وزن ومستوى نشاط',
        'ولّد خطة صيانة بناءً على إجمالي الاستهلاك الحالي'
      ];
    }
    return [
      'Generate a seven-day Mediterranean plan for this patient using the calculated deficit',
      'Create a low-glycemic plan for this patient with type 2 diabetes',
      'Combine DASH and Mediterranean principles',
      'Exclude all dairy products and peanuts',
      'Replace expensive ingredients with affordable Egyptian alternatives',
      'Modify the previous plan according to the latest follow-up',
      'Adjust the calorie target based on the latest weight and activity level',
      'Generate a maintenance plan based on the current TDEE'
    ];
  }

  CN.copilot = {
    detectLang: detectLang,
    interpret: interpret,
    searchKB: searchKB,
    deidentifiedPayload: deidentifiedPayload,
    callExternal: callExternal,
    respond: respond,
    examples: examples
  };
})();
