/* ==========================================================================
   NutriClinic Pro — charts.js
   Dependency-free SVG charts. No charting library is loaded, per the strict
   CSP (no CDN, no external assets).

   PALETTE INVARIANT: series colours are drawn only from navy #14213D,
   soft gold #C6A667 and burgundy #800020. No green is reachable from this
   module — not for a series, a marker or a threshold band.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  var C = { navy: '#14213D', gold: '#C6A667', burgundy: '#800020', gray: '#6B7280', line: '#E2E5EA' };
  var SERIES = ['navy', 'gold', 'burgundy'];

  function esc(s) { return U.esc(s); }
  function attr(v) { return U.round(v, 2); }

  /** Pick a "nice" axis step so ticks land on readable values. */
  function niceStep(range, ticks) {
    var raw = range / Math.max(1, ticks);
    var mag = Math.pow(10, Math.floor(Math.log(raw) / Math.LN10));
    var norm = raw / mag;
    var step;
    if (norm <= 1) step = 1; else if (norm <= 2) step = 2;
    else if (norm <= 2.5) step = 2.5; else if (norm <= 5) step = 5; else step = 10;
    return step * mag;
  }

  function extent(values) {
    var vals = values.filter(function (v) { return typeof v === 'number' && isFinite(v); });
    if (!vals.length) return { lo: 0, hi: 1 };
    return { lo: Math.min.apply(null, vals), hi: Math.max.apply(null, vals) };
  }

  /* ----------------------------------------------------------------- line -- */
  /**
   * line({
   *   width, height, series: [{ name, color, points: [{ x, y }], dashed }],
   *   yTicks, xLabels: [..], yUnit, targetLines: [{ value, label }],
   *   yPadTop, yPadBottom, emptyText
   * })
   */
  function line(cfg) {
    cfg = cfg || {};
    var W = cfg.width || 680, H = cfg.height || 280;
    var pad = { l: 56, r: 18, t: 18, b: 38 };
    var series = (cfg.series || []).filter(function (s) { return s.points && s.points.length; });

    if (!series.length) {
      return '<div class="empty" style="padding:1.6rem">' + esc(cfg.emptyText || 'No data to plot') + '</div>';
    }

    var allY = [], allX = [];
    series.forEach(function (s) {
      s.points.forEach(function (p) {
        if (typeof p.y === 'number' && isFinite(p.y)) allY.push(p.y);
        allX.push(p.x);
      });
    });

    var ex = extent(allY);
    var span = Math.max(0.0001, ex.hi - ex.lo);
    var padTop = ex.hi + (cfg.yPadTop === undefined ? span * 0.12 : cfg.yPadTop);
    var padBot = ex.lo - (cfg.yPadBottom === undefined ? span * 0.12 : cfg.yPadBottom);
    var step = niceStep(padTop - padBot, cfg.yTicks || 4);
    var yLo = Math.floor(padBot / step) * step;
    var yHi = Math.ceil(padTop / step) * step;
    if (yHi === yLo) yHi = yLo + step;

    var n = Math.max.apply(null, series.map(function (s) { return s.points.length; }));
    var xAt = function (i) {
      if (n === 1) return pad.l + (W - pad.l - pad.r) / 2;
      return pad.l + (i / (n - 1)) * (W - pad.l - pad.r);
    };
    var yAt = function (v) {
      return pad.t + (1 - (v - yLo) / (yHi - yLo)) * (H - pad.t - pad.b);
    };

    var out = ['<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" preserveAspectRatio="xMidYMid meet">'];

    // horizontal gridlines + y labels
    for (var v = yLo; v <= yHi + 1e-9; v += step) {
      var yy = attr(yAt(v));
      out.push('<line class="grid-line" x1="' + pad.l + '" y1="' + yy + '" x2="' + (W - pad.r) + '" y2="' + yy + '"/>');
      out.push('<text class="axis-label" x="' + (pad.l - 8) + '" y="' + (yAt(v) + 4) +
        '" text-anchor="end">' + esc(U.nf(v, step < 1 ? 1 : 0)) + '</text>');
    }

    // target / threshold lines
    (cfg.targetLines || []).forEach(function (tl) {
      if (typeof tl.value !== 'number') return;
      var ty = yAt(tl.value);
      if (ty < pad.t || ty > H - pad.b) return;
      out.push('<line class="target-line" x1="' + pad.l + '" y1="' + attr(ty) + '" x2="' + (W - pad.r) + '" y2="' + attr(ty) + '"/>');
      if (tl.label) {
        out.push('<text class="axis-label" x="' + (W - pad.r) + '" y="' + attr(ty - 5) +
          '" text-anchor="end">' + esc(tl.label) + '</text>');
      }
    });

    // series
    series.forEach(function (s, si) {
      var tone = s.color || SERIES[si % SERIES.length];
      var pts = s.points.filter(function (p) { return typeof p.y === 'number' && isFinite(p.y); });
      if (!pts.length) return;

      var d = pts.map(function (p, i) { return (i ? 'L' : 'M') + attr(xAt(i)) + ' ' + attr(yAt(p.y)); }).join(' ');
      out.push('<path class="series-line' + (s.dashed || si === 1 ? ' alt' : '') + '" d="' + d +
        '"' + (tone === 'burgundy' ? ' style="stroke:#800020"' : '') + '/>');

      pts.forEach(function (p, i) {
        out.push('<circle class="point' + (si === 1 ? ' alt' : '') + '" cx="' + attr(xAt(i)) + '" cy="' +
          attr(yAt(p.y)) + '" r="3.4"><title>' + esc(p.tip || (p.y + ' ' + (cfg.yUnit || ''))) + '</title></circle>');
      });
    });

    // x labels
    var labels = cfg.xLabels || [];
    labels.forEach(function (lb, i) {
      if (!lb) return;
      out.push('<text class="axis-label" x="' + attr(xAt(i)) + '" y="' + (H - 14) +
        '" text-anchor="middle">' + esc(lb) + '</text>');
    });

    out.push('</svg>');
    return out.join('');
  }

  /* ------------------------------------------------------------------ bars -- */
  /**
   * bar({ width, height, bars: [{ label, value, tone, tip }], yUnit,
   *       target: number, emptyText })
   * tone: 'navy' | 'gold' | 'alert'  (never green)
   */
  function bar(cfg) {
    cfg = cfg || {};
    var W = cfg.width || 680, H = cfg.height || 260;
    var pad = { l: 56, r: 18, t: 18, b: 46 };
    var bars = cfg.bars || [];
    if (!bars.length) {
      return '<div class="empty" style="padding:1.6rem">' + esc(cfg.emptyText || 'No data to plot') + '</div>';
    }

    var vals = bars.map(function (b) { return Number(b.value) || 0; });
    var hi = Math.max.apply(null, vals.concat([cfg.target || 0]));
    var step = niceStep(hi || 1, 4);
    var yHi = Math.ceil((hi || 1) * 1.1 / step) * step;
    var yAt = function (v) { return pad.t + (1 - v / yHi) * (H - pad.t - pad.b); };

    var innerW = W - pad.l - pad.r;
    var slot = innerW / bars.length;
    var bw = Math.max(4, Math.min(cfg.maxBarWidth || 64, slot * 0.62));

    var out = ['<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" preserveAspectRatio="xMidYMid meet">'];

    for (var v = 0; v <= yHi + 1e-9; v += step) {
      out.push('<line class="grid-line" x1="' + pad.l + '" y1="' + attr(yAt(v)) + '" x2="' + (W - pad.r) +
        '" y2="' + attr(yAt(v)) + '"/>');
      out.push('<text class="axis-label" x="' + (pad.l - 8) + '" y="' + attr(yAt(v) + 4) +
        '" text-anchor="end">' + esc(U.nf(v, 0)) + '</text>');
    }

    bars.forEach(function (b, i) {
      var cx = pad.l + slot * (i + 0.5);
      var hgt = Math.max(0, yAt(0) - yAt(Number(b.value) || 0));
      var cls = b.tone === 'alert' ? 'bar-rect alert' : (b.tone === 'gold' ? 'bar-rect alt' : 'bar-rect');
      out.push('<rect class="' + cls + '" x="' + attr(cx - bw / 2) + '" y="' + attr(yAt(Number(b.value) || 0)) +
        '" width="' + attr(bw) + '" height="' + attr(hgt) + '" rx="3"><title>' +
        esc(b.tip || (b.label + ': ' + (b.value === null || b.value === undefined ? '—' : b.value) + ' ' + (cfg.yUnit || ''))) +
        '</title></rect>');
      // Value above the bar when there is room.
      if (b.showValue !== false && bw >= 20) {
        out.push('<text class="axis-label" x="' + attr(cx) + '" y="' + attr(yAt(Number(b.value) || 0) - 6) +
          '" text-anchor="middle">' + esc(U.nf(Number(b.value) || 0, 0)) + '</text>');
      }
      // x label, wrapped to two lines
      var parts = String(b.label || '').split(/\s+/);
      var l1 = parts.slice(0, Math.ceil(parts.length / 2)).join(' ');
      var l2 = parts.slice(Math.ceil(parts.length / 2)).join(' ');
      out.push('<text class="axis-label" x="' + attr(cx) + '" y="' + (H - 26) +
        '" text-anchor="middle">' + esc(l1) + '</text>');
      if (l2) {
        out.push('<text class="axis-label" x="' + attr(cx) + '" y="' + (H - 13) +
          '" text-anchor="middle">' + esc(l2) + '</text>');
      }
    });

    out.push('</svg>');
    return out.join('');
  }

  /* ----------------------------------------------------------------- donut -- */
  /**
   * donut({ size, segments: [{ label, value, tone }], centerLabel, centerValue })
   */
  function donut(cfg) {
    cfg = cfg || {};
    var size = cfg.size || 200;
    var segs = (cfg.segments || []).filter(function (s) { return Number(s.value) > 0; });
    if (!segs.length) {
      return '<div class="empty" style="padding:1.6rem">' + esc(cfg.emptyText || 'No data to plot') + '</div>';
    }

    var total = U.sum(segs.map(function (s) { return Number(s.value); }));
    var R = size / 2, r = R * 0.62, cx = R, cy = R;
    var angle = -Math.PI / 2;

    var out = ['<svg class="chart" viewBox="0 0 ' + size + ' ' + size + '" width="' + size +
      '" height="' + size + '" role="img">'];

    segs.forEach(function (s, i) {
      var frac = Number(s.value) / total;
      var a2 = angle + frac * Math.PI * 2;
      var large = frac > 0.5 ? 1 : 0;
      var x1 = cx + R * Math.cos(angle), y1 = cy + R * Math.sin(angle);
      var x2 = cx + R * Math.cos(a2), y2 = cy + R * Math.sin(a2);
      var x3 = cx + r * Math.cos(a2), y3 = cy + r * Math.sin(a2);
      var x4 = cx + r * Math.cos(angle), y4 = cy + r * Math.sin(angle);
      var tone = s.tone || SERIES[i % SERIES.length];
      var fill = C[tone] || C.navy;

      // A full circle cannot be expressed as an arc; draw it as two halves.
      if (frac >= 0.9999) {
        out.push('<circle class="donut-seg" cx="' + cx + '" cy="' + cy + '" r="' + ((R + r) / 2) +
          '" fill="none" stroke="' + fill + '" stroke-width="' + (R - r) + '"><title>' + esc(s.label) + '</title></circle>');
      } else {
        out.push('<path class="donut-seg" fill="' + fill + '" d="M' + attr(x1) + ' ' + attr(y1) +
          ' A' + R + ' ' + R + ' 0 ' + large + ' 1 ' + attr(x2) + ' ' + attr(y2) +
          ' L' + attr(x3) + ' ' + attr(y3) +
          ' A' + r + ' ' + r + ' 0 ' + large + ' 0 ' + attr(x4) + ' ' + attr(y4) + ' Z">' +
          '<title>' + esc(s.label + ': ' + s.value) + '</title></path>');
      }
      angle = a2;
    });

    if (cfg.centerValue !== undefined) {
      out.push('<text x="' + cx + '" y="' + (cy - 2) + '" text-anchor="middle" ' +
        'style="font:600 20px var(--sans);fill:#14213D">' + esc(cfg.centerValue) + '</text>');
    }
    if (cfg.centerLabel) {
      out.push('<text x="' + cx + '" y="' + (cy + 16) + '" text-anchor="middle" ' +
        'style="font:400 11px var(--sans);fill:#6B7280">' + esc(cfg.centerLabel) + '</text>');
    }

    out.push('</svg>');
    return out.join('');
  }

  /* -------------------------------------------------------------- sparkline -- */
  function sparkline(values, opts) {
    opts = opts || {};
    var vals = (values || []).filter(function (v) { return typeof v === 'number' && isFinite(v); });
    if (vals.length < 2) return '';
    var W = opts.width || 120, H = opts.height || 32;
    var ex = extent(vals);
    var span = Math.max(0.0001, ex.hi - ex.lo);
    var d = vals.map(function (v, i) {
      var x = (i / (vals.length - 1)) * (W - 4) + 2;
      var y = H - 3 - ((v - ex.lo) / span) * (H - 6);
      return (i ? 'L' : 'M') + attr(x) + ' ' + attr(y);
    }).join(' ');
    var stroke = C[opts.tone || 'navy'] || C.navy;
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="' + W + '" height="' + H +
      '" aria-hidden="true"><path d="' + d + '" fill="none" stroke="' + stroke +
      '" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round"/></svg>';
  }

  /** Horizontal progress bar, palette-locked. */
  function barHtml(fraction, tone) {
    var f = U.clamp(Number(fraction) || 0, 0, 1);
    var cls = tone === 'alert' ? 'bar alert' : (tone === 'gold' ? 'bar gold' : 'bar');
    return '<div class="' + cls + '" role="progressbar" aria-valuenow="' + Math.round(f * 100) +
      '" aria-valuemin="0" aria-valuemax="100"><i style="width:' + U.round(f * 100, 1) + '%"></i></div>';
  }

  /** Legend markup matching the series colours. */
  function legend(entries) {
    return '<div class="legend">' + (entries || []).map(function (e) {
      return '<span><i class="' + (e.tone || 'navy') + '"></i>' + esc(e.label) + '</span>';
    }).join('') + '</div>';
  }

  CN.charts = {
    colors: C,
    series: SERIES,
    line: line,
    bar: bar,
    donut: donut,
    sparkline: sparkline,
    barHtml: barHtml,
    legend: legend
  };
})();
