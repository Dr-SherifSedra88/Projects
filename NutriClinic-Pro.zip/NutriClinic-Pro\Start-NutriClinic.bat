@echo off
setlocal EnableExtensions
title NutriClinic Pro
cd /d "%~dp0"

set "PORT=8617"
set "SITE=%~dp0site"
set "PY="

rem Prefer the Python launcher, then python on PATH.
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)

if not exist "%SITE%\index.html" (
  echo.
  echo   Could not find site\index.html next to this script.
  echo   Keep Start-NutriClinic.bat inside the NutriClinic-Pro folder.
  echo.
  pause
  exit /b 1
)

if not defined PY goto :nopython

echo.
echo   NutriClinic Pro
echo   Serving %SITE%
echo   Open: http://127.0.0.1:%PORT%/
echo.
echo   Storage: IndexedDB - records and documents are kept in full.
echo   Close this window to stop the server.
echo.

start "" "http://127.0.0.1:%PORT%/"
%PY% -m http.server %PORT% --bind 127.0.0.1 --directory "%SITE%"

echo.
echo   Server stopped.
pause
exit /b 0

:nopython
echo.
echo   Python was not found, so the local server cannot be started.
echo.
echo   You can still use NutriClinic Pro right now:
echo.
echo     1. Open this file in your browser:   site\index.html
echo     2. Everything works - dashboard, patients, calculations,
echo        diet plans, recipes, copilot, reports.
echo.
echo   One difference: without the server, records are kept in
echo   browser storage, which has a size limit, so keep document
echo   attachments small. Your records still survive a reload.
echo.
echo   To get unrestricted storage later, install Python from
echo   https://www.python.org/downloads/  and run this script again.
echo.
start "" "%SITE%\index.html"
pause
exit /b 0
