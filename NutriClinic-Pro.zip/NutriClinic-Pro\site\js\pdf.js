/* ==========================================================================
   NutriClinic Pro — pdf.js
   Report construction and the print pipeline.

   PDF export is the browser's own print-to-PDF. No external rendering library
   is loaded — that would violate the strict CSP, and a bundled renderer would
   need a build step. The application therefore builds a print-ready A4
   document into #print-root and invokes window.print(); css/print.css carries
   the layout. This is stated plainly in the interface rather than presented
   as a bespoke PDF engine.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  var BRAND_MARK =
    '<svg class="rpt-logo" viewBox="0 0 64 64" aria-hidden="true">' +
    '<rect width="64" height="64" rx="14" fill="#14213D"/>' +
    '<path d="M14 42h10l6-16 6 22 5-14h9" fill="none" stroke="#C6A667" stroke-width="4" ' +
    'stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function n(v, dp) { return U.nf(v, dp); }
  function esc(v) { return U.esc(v); }

  /** Household-portion string for a gram weight, where one is available. */
  function portionText(food, grams, lang) {
    if (!food) return '';
    var h = CN.foods.household(food, grams);
    if (!h) return '';
    return lang === 'ar' ? h.labelAr : h.labelEn;
  }

  /** Resolve a food or a clinic recipe by id, through the planner's index. */
  function foodFor(id) {
    return CN.planner.resolveFood ? CN.planner.resolveFood(id) : CN.foods.byId(id);
  }

  /* ------------------------------------------------------------- sections -- */
  function head(settings, mode, lang) {
    if (mode === 'plain') {
      return '<header class="rpt-head"><div class="brand">' +
        '<h1>' + esc(settings.reportHeading || (lang === 'ar' ? 'خطة غذائية' : 'Diet Plan')) + '</h1>' +
        '<div class="sub">' + esc(U.fmtDate(U.todayISO())) + '</div>' +
        '</div></header>';
    }
    var contact = [settings.clinicPhone, settings.clinicEmail, settings.clinicAddress]
      .filter(Boolean).map(esc).join(' · ');
    return '<header class="rpt-head"><div class="brand">' +
      '<h1>' + esc(settings.clinicName || 'NutriClinic Pro') + '</h1>' +
      '<div class="sub">' +
        esc([settings.physicianName, settings.physicianTitle].filter(Boolean).join(' · ')) +
        (contact ? '<br>' + contact : '') +
      '</div></div>' + BRAND_MARK + '</header>';
  }

  function metaBlock(patient, lang) {
    var age = U.ageFrom(patient.dob);
    var sexLabel = patient.sex ? CN.t('sex.' + patient.sex) : '—';
    function cell(k, v) {
      return '<div><div class="k">' + esc(k) + '</div><div class="v">' + esc(v) + '</div></div>';
    }
    return '<div class="rpt-meta">' +
      cell(lang === 'ar' ? 'المريض' : 'Patient', patient.name || '—') +
      cell(lang === 'ar' ? 'رقم المريض' : 'Patient ID', patient.code || '—') +
      cell(lang === 'ar' ? 'العمر' : 'Age', age === null ? '—' : age + ' ' + (lang === 'ar' ? 'سنة' : 'years')) +
      cell(lang === 'ar' ? 'النوع' : 'Sex', sexLabel) +
      cell(lang === 'ar' ? 'تاريخ التقرير' : 'Report date', U.fmtDate(U.todayISO())) +
      cell(lang === 'ar' ? 'الهاتف' : 'Phone', patient.phone || '—') +
      cell(lang === 'ar' ? 'الهدف' : 'Goal', patient.goal ? CN.t('goal.' + patient.goal) : '—') +
      cell(lang === 'ar' ? 'الطبيب' : 'Clinician', (CN.pdfSettings && CN.pdfSettings.physicianName) || '—') +
      '</div>';
  }

  function measurementsTable(measurements, lang) {
    var pts = (measurements || []).slice().sort(function (a, b) {
      return String(a.measuredAt).localeCompare(String(b.measuredAt));
    });
    if (!pts.length) return '';
    var first = pts[0], last = pts[pts.length - 1];
    var h = last.heightCm || first.heightCm;
    var rows = [
      [lang === 'ar' ? 'الوزن' : 'Weight', first.weightKg, last.weightKg, 'kg'],
      [lang === 'ar' ? 'الطول' : 'Height', h, h, 'cm'],
      [lang === 'ar' ? 'كتلة الجسم' : 'BMI', CN.engine.bmi(h, first.weightKg), CN.engine.bmi(h, last.weightKg), ''],
      [lang === 'ar' ? 'محيط الخصر' : 'Waist', first.waistCm, last.waistCm, 'cm'],
      [lang === 'ar' ? 'نسبة الدهون' : 'Body fat', first.bodyFatPct, last.bodyFatPct, '%'],
      // Blood pressure is recorded alongside the measurements taken at the visit.
      [lang === 'ar' ? 'ضغط الدم' : 'Blood pressure',
        (first.systolic && first.diastolic) ? first.systolic + '/' + first.diastolic : null,
        (last.systolic && last.diastolic) ? last.systolic + '/' + last.diastolic : null, 'mmHg']
    ].filter(function (r) {
      return (r[1] !== undefined && r[1] !== null) || (r[2] !== undefined && r[2] !== null);
    });

    function fmtCell(v) {
      if (v === null || v === undefined) return '—';
      return typeof v === 'number' ? n(v, 1) : String(v);
    }

    return '<h2>' + esc(lang === 'ar' ? 'القياسات' : 'Measurements') + '</h2>' +
      '<table><thead><tr><th>' + esc(lang === 'ar' ? 'المقياس' : 'Measure') + '</th>' +
      '<th class="num">' + esc(U.fmtDate(first.measuredAt)) + '</th>' +
      '<th class="num">' + esc(U.fmtDate(last.measuredAt)) + '</th>' +
      '<th class="num">' + esc(lang === 'ar' ? 'التغير' : 'Change') + '</th></tr></thead><tbody>' +
      rows.map(function (r) {
        var a = r[1], b = r[2];
        var d = (typeof a === 'number' && typeof b === 'number') ? U.round(b - a, 1) : null;
        return '<tr><td>' + esc(r[0]) + '</td><td class="num">' + fmtCell(a) +
          (a === null || a === undefined ? '' : ' ' + r[3]) +
          '</td><td class="num">' + fmtCell(b) +
          (b === null || b === undefined ? '' : ' ' + r[3]) +
          '</td><td class="num">' + (d === null ? '—' : (d > 0 ? '+' : '') + n(d, 1)) + '</td></tr>';
      }).join('') + '</tbody></table>';
  }

  function energyTable(assessment, macros, lang) {
    if (!assessment) return '';
    var rows = [
      [lang === 'ar' ? 'معدل الأيض الأساسي' : 'Basal metabolic rate', n(assessment.bmr, 0) + ' kcal',
        assessment.bmrFormulaLabel || ''],
      [lang === 'ar' ? 'إجمالي الاستهلاك' : 'Total daily expenditure', n(assessment.tdee, 0) + ' kcal',
        (lang === 'ar' ? 'معامل النشاط ' : 'factor ') + n(assessment.activityFactor, 2)],
      [lang === 'ar' ? 'العجز/الفائض' : 'Deficit / surplus',
        (assessment.deltaKcal > 0 ? '+' : '') + n(assessment.deltaKcal, 0) + ' kcal', ''],
      [lang === 'ar' ? 'هدف السعرات' : 'Daily energy target', n(assessment.targetKcal, 0) + ' kcal',
        assessment.approvedAt ? (lang === 'ar' ? 'معتمد' : 'approved') : (lang === 'ar' ? 'غير معتمد' : 'not approved')]
    ];
    var out = '<h2>' + esc(lang === 'ar' ? 'أهداف الطاقة' : 'Energy targets') + '</h2>' +
      '<table><thead><tr><th>' + esc(lang === 'ar' ? 'البند' : 'Item') + '</th><th class="num">' +
      esc(lang === 'ar' ? 'القيمة' : 'Value') + '</th><th>' + esc(lang === 'ar' ? 'ملاحظة' : 'Note') +
      '</th></tr></thead><tbody>' +
      rows.map(function (r) {
        return '<tr><td>' + esc(r[0]) + '</td><td class="num">' + esc(r[1]) + '</td><td>' + esc(r[2]) + '</td></tr>';
      }).join('') + '</tbody></table>';

    if (macros) {
      out += '<h3>' + esc(lang === 'ar' ? 'العناصر الكبرى' : 'Macronutrients') + '</h3>' +
        '<table><thead><tr><th>' + esc(lang === 'ar' ? 'العنصر' : 'Nutrient') + '</th>' +
        '<th class="num">' + esc(lang === 'ar' ? 'الجرامات' : 'Grams') + '</th>' +
        '<th class="num">' + esc(lang === 'ar' ? 'النسبة' : 'Share') + '</th></tr></thead><tbody>' +
        '<tr><td>' + esc(lang === 'ar' ? 'بروتين' : 'Protein') + '</td><td class="num">' + n(macros.proteinG, 0) +
          ' g</td><td class="num">' + n(macros.proteinPct, 0) + '%</td></tr>' +
        '<tr><td>' + esc(lang === 'ar' ? 'كربوهيدرات' : 'Carbohydrate') + '</td><td class="num">' + n(macros.carbG, 0) +
          ' g</td><td class="num">' + n(macros.carbPct, 0) + '%</td></tr>' +
        '<tr><td>' + esc(lang === 'ar' ? 'دهون' : 'Fat') + '</td><td class="num">' + n(macros.fatG, 0) +
          ' g</td><td class="num">' + n(macros.fatPct, 0) + '%</td></tr>' +
        '<tr><td>' + esc(lang === 'ar' ? 'ألياف' : 'Fibre') + '</td><td class="num">' + n(macros.fiberG, 0) +
          ' g</td><td class="num">—</td></tr>' +
        (macros.sodiumMaxMg ? '<tr><td>' + esc(lang === 'ar' ? 'الحد الأقصى للصوديوم' : 'Sodium ceiling') +
          '</td><td class="num">' + n(macros.sodiumMaxMg, 0) + ' mg</td><td class="num">—</td></tr>' : '') +
        '</tbody></table>';
    }
    return out;
  }

  function planTable(version, lang, showNutrients) {
    if (!version || !version.days) return '';
    var out = '<h2>' + esc(lang === 'ar' ? 'الخطة الغذائية' : 'Diet plan') + '</h2>';

    if (version.approachCodes && version.approachCodes.length) {
      out += '<p><strong>' + esc(lang === 'ar' ? 'الأنظمة' : 'Approaches') + ':</strong> ' +
        esc(version.approachCodes.map(function (c) {
          var a = CN.approaches.byCode(c);
          return a ? (lang === 'ar' ? a.nameAr : a.nameEn) : c;
        }).join(' · ')) + '</p>';
    }

    version.days.forEach(function (day) {
      out += '<h3>' + esc((lang === 'ar' ? 'اليوم ' : 'Day ') + (day.dayIndex + 1)) +
        (day.date ? ' — ' + esc(U.fmtDate(day.date)) : '') +
        (showNutrients ? ' · ' + n(day.totals.kcal, 0) + ' kcal' : '') + '</h3>';

      day.meals.forEach(function (meal) {
        out += '<div class="meal"><h3>' + esc(lang === 'ar' ? (meal.labelAr || meal.labelEn) : meal.labelEn);
        if (meal.time) out += ' <span style="font-weight:400;color:#6B7280">' + esc(meal.time) + '</span>';
        out += '</h3>';

        if (showNutrients) {
          out += '<table><thead><tr><th>' + esc(lang === 'ar' ? 'الصنف' : 'Food') + '</th>' +
            '<th class="num">' + esc(lang === 'ar' ? 'الكمية' : 'Amount') + '</th>' +
            '<th class="num">' + esc(lang === 'ar' ? 'ك.ح' : 'kcal') + '</th>' +
            '<th class="num">' + esc(lang === 'ar' ? 'بروتين' : 'P') + '</th>' +
            '<th class="num">' + esc(lang === 'ar' ? 'كارب' : 'C') + '</th>' +
            '<th class="num">' + esc(lang === 'ar' ? 'دهون' : 'F') + '</th></tr></thead><tbody>';
        } else {
          out += '<table><tbody>';
        }

        meal.items.forEach(function (it) {
          var food = CN.planner.resolveFood(it.foodId);
          var name = CN.planner.itemName(it, lang);
          var portion = portionText(food, it.grams, lang);
          var amount = it.grams + ' g' + (portion ? ' (' + portion + ')' : '');
          var recipeMark = it.isRecipe
            ? ' <em style="color:#14213D">(' + esc(CN.t('rc.title')) + ')</em>' : '';
          if (showNutrients) {
            out += '<tr><td>' + esc(name) + recipeMark +
              (it.needsVerify ? ' <em style="color:#800020">(' + esc(lang === 'ar' ? 'يتطلب تحققًا' : 'verify') + ')</em>' : '') +
              '</td><td class="num">' + esc(amount) + '</td>' +
              '<td class="num">' + n(it.kcal, 0) + '</td><td class="num">' + n(it.protein, 1) + '</td>' +
              '<td class="num">' + n(it.carb, 1) + '</td><td class="num">' + n(it.fat, 1) + '</td></tr>';
          } else {
            out += '<tr><td>' + esc(name) + '</td><td class="num">' + esc(amount) + '</td></tr>';
          }
        });
        out += '</tbody></table>';

        if (showNutrients) {
          out += '<div class="totals"><span>' + esc(lang === 'ar' ? 'إجمالي الوجبة' : 'Meal total') +
            ': <b>' + n(meal.totals.kcal, 0) + ' kcal</b></span>' +
            '<span>P <b>' + n(meal.totals.protein, 1) + ' g</b></span>' +
            '<span>C <b>' + n(meal.totals.carb, 1) + ' g</b></span>' +
            '<span>F <b>' + n(meal.totals.fat, 1) + ' g</b></span></div>';
        }
        if (meal.instructions) {
          out += '<p style="font-size:9pt;color:#6B7280;margin:4pt 0 0">' + esc(meal.instructions) + '</p>';
        }
        out += '</div>';
      });
    });

    return out;
  }

  function notices(assessment, version, lang) {
    var out = '';
    var flags = (assessment && assessment.flags) || [];
    if (flags.length) {
      out += '<h2>' + esc(lang === 'ar' ? 'اعتبارات إكلينيكية' : 'Clinical considerations') + '</h2>';
      flags.forEach(function (f) {
        out += '<div class="notice">' + esc(lang === 'ar' ? (f.ar || f.en) : f.en) + '</div>';
      });
    }
    if (version && version.warnings && version.warnings.length) {
      out += '<h2>' + esc(lang === 'ar' ? 'ملاحظات على الخطة' : 'Plan notes') + '</h2>';
      version.warnings.forEach(function (w) { out += '<div class="notice">' + esc(w) + '</div>'; });
    }
    return out;
  }

  /* --------------------------------------------------------------- build --- */
  /**
   * buildReport({ patient, measurements, assessment, macros, plan, settings, mode })
   * `mode` is 'branded' or 'plain'. Returns an HTML string for #print-root.
   */
  function buildReport(ctx) {
    ctx = ctx || {};
    var lang = (CN.i18n && CN.i18n.lang === 'ar') ? 'ar' : 'en';
    var settings = ctx.settings || {};
    var mode = ctx.mode || settings.reportMode || 'branded';
    var showNutrients = ctx.showNutrients === undefined ? settings.reportShowNutrients !== false : !!ctx.showNutrients;
    var showSignature = ctx.showSignature === undefined ? settings.reportShowSignature !== false : !!ctx.showSignature;
    var patient = ctx.patient || {};

    // Editable template tokens: accent colour and a type scale. A single inline
    // font-size rescales the whole report because css/print.css is em-based.
    var accent = ctx.accent || settings.reportAccent || '#14213D';
    var scale = Number(ctx.fontScale || settings.reportFontScale) || 1;
    var articleStyle = ' style="--rpt-accent:' + accent + ';font-size:' +
      U.round(10.5 * scale, 1) + 'pt"';

    CN.pdfSettings = settings;

    var body = '';
    body += '<h2>' + esc(lang === 'ar' ? 'ملخص المريض' : 'Patient summary') + '</h2>' +
      '<table><tbody>' +
      '<tr><td>' + esc(lang === 'ar' ? 'الاسم' : 'Name') + '</td><td>' + esc(patient.name || '—') + '</td></tr>' +
      '<tr><td>' + esc(lang === 'ar' ? 'رقم المريض' : 'Patient ID') + '</td><td>' + esc(patient.code || '—') + '</td></tr>' +
      (patient.conditions && patient.conditions.length
        ? '<tr><td>' + esc(lang === 'ar' ? 'الأمراض' : 'Conditions') + '</td><td>' + esc(patient.conditions.join(' · ')) + '</td></tr>' : '') +
      (patient.restrictions && patient.restrictions.length
        ? '<tr><td>' + esc(lang === 'ar' ? 'القيود الغذائية' : 'Dietary restrictions') + '</td><td>' +
          esc(patient.restrictions.map(function (r) {
            return CN.foods.allergenLabel(r.substance, lang) + ' (' + CN.t('rest.' + r.kind) + ')';
          }).join(' · ')) + '</td></tr>' : '') +
      (patient.medications ? '<tr><td>' + esc(lang === 'ar' ? 'الأدوية' : 'Medications') + '</td><td>' +
        esc(patient.medications) + '</td></tr>' : '') +
      '</tbody></table>';

    body += measurementsTable(ctx.measurements, lang);
    body += energyTable(ctx.assessment, ctx.macros, lang);
    body += planTable(ctx.plan, lang, showNutrients);
    body += notices(ctx.assessment, ctx.plan, lang);

    var sig = '';
    if (showSignature) {
      sig = '<div class="sig">' +
        '<div class="line">' + esc(settings.physicianName || (lang === 'ar' ? 'الطبيب المعالج' : 'Treating clinician')) + '</div>' +
        '<div class="line">' + esc(lang === 'ar' ? 'التاريخ' : 'Date') + '</div>' +
        '</div>';
    }

    return '<article class="rpt' + (mode === 'plain' ? ' plain' : '') + '"' + articleStyle + '>' +
      head(settings, mode, lang) +
      metaBlock(patient, lang) +
      body +
      '<div class="notice">' + esc(CN.t('rp.disclaimer')) + '</div>' +
      sig +
      '<footer class="rpt-foot"><span>' +
        esc(mode === 'plain' ? '' : (settings.clinicName || 'NutriClinic Pro')) +
      '</span><span>' + esc(U.fmtDate(U.todayISO())) + '</span></footer>' +
      '</article>';
  }

  /* ---------------------------------------------------------------- print -- */
  function printHtml(html) {
    var root = document.getElementById('print-root');
    if (!root) return;
    root.innerHTML = html;
    root.removeAttribute('aria-hidden');

    var cleanup = function () {
      root.innerHTML = '';
      root.setAttribute('aria-hidden', 'true');
      window.removeEventListener('afterprint', cleanup);
    };
    window.addEventListener('afterprint', cleanup);
    // Some browsers never fire afterprint; do not leave stale content forever.
    setTimeout(function () {
      window.print();
      setTimeout(cleanup, 1500);
    }, 60);
  }

  /** Render a report from a context object. */
  function print(ctx) {
    printHtml(buildReport(ctx));
  }

  /** Modal preview with a print action. */
  function preview(ctx) {
    var html = buildReport(ctx);
    CN.modal({
      title: CN.t('rp.previewBtn'),
      wide: true,
      body: '<div style="background:#F4F5F7;padding:1rem;border-radius:8px;max-height:66vh;overflow:auto">' +
        '<div style="background:#fff;padding:14mm;box-shadow:0 1px 4px rgba(20,33,61,.14);' +
        'max-width:210mm;margin:0 auto">' + html + '</div></div>' +
        '<p class="muted" style="margin-top:.6rem;font-size:.82rem">' + esc(CN.t('rp.previewHint')) + '</p>',
      actions: [
        { label: CN.t('common.close'), kind: 'ghost' },
        { label: CN.t('rp.printBtn'), kind: 'primary', onClick() { printHtml(html); } }
      ]
    });
  }

  CN.pdf = {
    buildReport: buildReport,
    print: print,
    preview: preview,
    printHtml: printHtml,
    portionText: portionText
  };
})();
