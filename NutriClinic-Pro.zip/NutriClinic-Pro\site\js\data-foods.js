/* ==========================================================================
   NutriClinic Pro — data-foods.js
   Food composition table with Egyptian household portions.

   Nutrients are per 100 g edible portion. Values are reference-class figures
   drawn from standard composition tables (USDA-class and regional Egyptian
   food-composition data). They are suitable for planning; they are NOT a
   laboratory analysis of any specific product.

   `needsVerify` marks composite dishes whose ingredient list is not fully
   resolved. Those foods are surfaced with a verification warning and should
   not be treated as allergen-safe (brief §8).
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};

  /* Household measures. Every portion carries its own gram assumption, as the
     brief requires: no household measure may exist without a documented
     serving-size assumption. */
  var MEASURE_AR = {
    g: 'جرام', ml: 'مل', cup: 'كوب', tbsp: 'ملعقة كبيرة', tsp: 'ملعقة صغيرة',
    piece: 'قطعة', slice: 'شريحة', loaf: 'رغيف', half_loaf: 'نصف رغيف',
    small: 'صغير', medium: 'وسط', large: 'كبير', bowl: 'طبق', plate: 'طبق',
    glass: 'كأس', handful: 'حفنة', can: 'علبة', packet: 'عبوة'
  };

  var CATEGORY_AR = {
    bread: 'خبز', grains: 'حبوب ونشويات', vegetables: 'خضروات', fruits: 'فواكه',
    legumes: 'بقوليات', dairy: 'ألبان ومنتجاتها', eggs: 'بيض', meat: 'لحوم',
    poultry: 'دواجن', fish: 'أسماك', nuts: 'مكسرات وبذور', fats: 'زيوت ودهون',
    sweets: 'حلويات', beverages: 'مشروبات', dishes: 'أطباق مركبة', condiments: 'إضافات'
  };

  var ALLERGENS = [
    ['gluten', 'Gluten', 'جلوتين'], ['milk', 'Milk', 'لبن'], ['lactose', 'Lactose', 'لاكتوز'],
    ['egg', 'Egg', 'بيض'], ['peanut', 'Peanut', 'فول سوداني'], ['treenut', 'Tree nuts', 'مكسرات'],
    ['soy', 'Soy', 'صويا'], ['fish', 'Fish', 'أسماك'], ['shellfish', 'Shellfish', 'قشريات'],
    ['sesame', 'Sesame', 'سمسم'], ['sulfite', 'Sulfites', 'كبريتيت'], ['mustard', 'Mustard', 'خردل'],
    ['celery', 'Celery', 'كرفس']
  ];

  /* ---------------------------------------------------------------------------
     Columns:
       id, nameEn, nameAr, category,
       kcal, protein, carb, fat, fiber, sugar, sodium(mg), allergens[],
       portions[ [measure, grams, labelEn] ], flags
     --------------------------------------------------------------------------- */
  var RAW = [
    /* ---------------------------------------------------------------- breads */
    ['baladi_bread', 'Baladi bread (whole wheat)', 'خبز بلدي', 'bread', 264, 8.6, 52.0, 1.4, 6.5, 1.8, 480, ['gluten'],
      [['loaf', 90, 'One loaf'], ['half_loaf', 45, 'Half loaf'], ['g', 100, 'Weighed']]],
    ['baladi_bread_white', 'Baladi bread (white flour)', 'خبز بلدي أبيض', 'bread', 275, 8.0, 56.0, 1.2, 2.4, 2.4, 520, ['gluten'],
      [['loaf', 90, 'One loaf'], ['half_loaf', 45, 'Half loaf']]],
    ['fino_bread', 'Fino bread', 'خبز فينو', 'bread', 285, 8.8, 55.0, 2.6, 2.6, 3.5, 540, ['gluten'],
      [['piece', 60, 'One roll'], ['half_loaf', 30, 'Half roll']]],
    ['toast_bread', 'Toast / sliced bread', 'خبز توست', 'bread', 270, 8.5, 51.0, 3.2, 2.7, 4.0, 480, ['gluten'],
      [['slice', 28, 'One slice']]],
    ['pita_white', 'Pita bread (white)', 'خبز عيش أبيض', 'bread', 275, 8.4, 55.0, 1.3, 2.3, 2.0, 500, ['gluten'],
      [['loaf', 85, 'One loaf'], ['half_loaf', 42, 'Half loaf']]],
    ['shami_bread', 'Shami bread', 'خبز شامي', 'bread', 269, 8.4, 53.5, 1.6, 4.0, 2.0, 470, ['gluten'],
      [['loaf', 95, 'One loaf']]],

    /* ---------------------------------------------------------------- grains */
    ['rice_white', 'White rice, cooked', 'أرز أبيض مطبوخ', 'grains', 130, 2.7, 28.2, 0.3, 0.4, 0.1, 1, [],
      [['cup', 158, 'One cup'], ['bowl', 200, 'One bowl'], ['tbsp', 12, 'One tablespoon']]],
    ['rice_brown', 'Brown rice, cooked', 'أرز بني مطبوخ', 'grains', 123, 2.7, 25.6, 1.0, 1.6, 0.2, 4, [],
      [['cup', 158, 'One cup'], ['bowl', 200, 'One bowl']]],
    ['pasta_cooked', 'Pasta, cooked', 'مكرونة مطبوخة', 'grains', 158, 5.8, 30.9, 0.9, 1.8, 0.6, 6, ['gluten'],
      [['cup', 140, 'One cup'], ['bowl', 220, 'One bowl']]],
    ['vermicelli', 'Vermicelli, cooked', 'شعرية مطبوخة', 'grains', 156, 5.6, 30.5, 0.9, 1.6, 0.6, 6, ['gluten'],
      [['cup', 140, 'One cup']]],
    ['bulgur', 'Bulgur, cooked', 'برغل مطبوخ', 'grains', 83, 3.1, 18.6, 0.2, 4.5, 0.1, 5, ['gluten'],
      [['cup', 182, 'One cup']]],
    ['couscous', 'Couscous, cooked', 'كسكسي مطبوخ', 'grains', 112, 3.8, 23.2, 0.2, 1.4, 0.1, 5, ['gluten'],
      [['cup', 157, 'One cup']]],
    ['oats', 'Oats, dry', 'شوفان جاف', 'grains', 389, 16.9, 66.3, 6.9, 10.6, 1.0, 2, ['gluten'],
      [['tbsp', 10, 'One tablespoon'], ['cup', 81, 'One cup']]],
    ['freekeh', 'Freekeh, cooked', 'فريك مطبوخ', 'grains', 118, 4.6, 24.0, 0.7, 4.2, 0.2, 6, ['gluten'],
      [['cup', 165, 'One cup']]],
    ['corn_sweet', 'Sweet corn', 'ذرة حلوة', 'grains', 86, 3.2, 19.0, 1.2, 2.7, 3.2, 15, [],
      [['cup', 145, 'One cup'], ['piece', 90, 'One cob']]],
    ['potato_boiled', 'Potato, boiled', 'بطاطس مسلوقة', 'grains', 87, 2.0, 20.1, 0.1, 1.8, 0.9, 5, [],
      [['medium', 150, 'One medium'], ['small', 100, 'One small']]],
    ['potato_fried', 'Potato, fried', 'بطاطس مقلية', 'grains', 312, 3.4, 42.0, 14.5, 3.8, 0.3, 210, [],
      [['medium', 150, 'One medium serving'], ['handful', 60, 'Small handful']]],
    ['sweet_potato', 'Sweet potato, baked', 'بطاطا مشوية', 'grains', 90, 2.0, 20.7, 0.2, 3.3, 6.5, 36, [],
      [['medium', 130, 'One medium']]],
    ['taro', 'Taro (qolqas), cooked', 'قلقاس مسلوق', 'grains', 112, 1.5, 26.5, 0.2, 4.1, 0.4, 12, [],
      [['cup', 132, 'One cup']]],

    /* ------------------------------------------------------------ vegetables */
    ['tomato', 'Tomato', 'طماطم', 'vegetables', 18, 0.9, 3.9, 0.2, 1.2, 2.6, 5, [],
      [['medium', 123, 'One medium'], ['slice', 20, 'One slice']]],
    ['cucumber', 'Cucumber', 'خيار', 'vegetables', 15, 0.7, 3.6, 0.1, 0.5, 1.7, 2, [],
      [['medium', 150, 'One medium'], ['cup', 120, 'Chopped cup']]],
    ['lettuce', 'Lettuce, romaine', 'خس', 'vegetables', 17, 1.2, 3.3, 0.3, 2.1, 1.2, 8, [],
      [['cup', 47, 'Shredded cup'], ['handful', 40, 'One handful']]],
    ['carrot', 'Carrot', 'جزر', 'vegetables', 41, 0.9, 9.6, 0.2, 2.8, 4.7, 69, [],
      [['medium', 61, 'One medium'], ['cup', 128, 'Sliced cup']]],
    ['zucchini', 'Zucchini (kousa)', 'كوسة', 'vegetables', 17, 1.2, 3.1, 0.3, 1.0, 2.5, 8, [],
      [['medium', 180, 'One medium'], ['cup', 124, 'Sliced cup']]],
    ['eggplant', 'Eggplant', 'باذنجان', 'vegetables', 25, 1.0, 5.9, 0.2, 3.0, 3.5, 2, [],
      [['medium', 250, 'One medium'], ['cup', 82, 'Cubed cup']]],
    ['okra', 'Okra (bamia)', 'بامية', 'vegetables', 33, 1.9, 7.5, 0.2, 3.2, 1.5, 7, [],
      [['cup', 100, 'One cup']]],
    ['spinach', 'Spinach', 'سبانخ', 'vegetables', 23, 2.9, 3.6, 0.4, 2.2, 0.4, 79, [],
      [['cup', 30, 'Raw cup'], ['bowl', 180, 'Cooked bowl']]],
    ['molokhia_raw', 'Jew\'s mallow (molokhia), leaves', 'ملوخية', 'vegetables', 42, 4.8, 5.6, 0.6, 3.1, 0.9, 21, [],
      [['cup', 60, 'Chopped cup']]],
    ['cabbage', 'Cabbage', 'كرنب', 'vegetables', 25, 1.3, 5.8, 0.1, 2.5, 3.2, 18, [],
      [['cup', 89, 'Shredded cup']]],
    ['cauliflower', 'Cauliflower', 'قرنبيط', 'vegetables', 25, 1.9, 5.0, 0.3, 2.0, 1.9, 30, [],
      [['cup', 107, 'One cup']]],
    ['broccoli', 'Broccoli', 'بروكلي', 'vegetables', 34, 2.8, 6.6, 0.4, 2.6, 1.7, 33, [],
      [['cup', 91, 'One cup']]],
    ['green_beans', 'Green beans', 'فاصوليا خضراء', 'vegetables', 31, 1.8, 7.0, 0.1, 3.4, 3.3, 6, [],
      [['cup', 100, 'One cup']]],
    ['peas_green', 'Green peas', 'بسلة خضراء', 'vegetables', 81, 5.4, 14.5, 0.4, 5.7, 5.7, 5, [],
      [['cup', 145, 'One cup']]],
    ['onion', 'Onion', 'بصل', 'vegetables', 40, 1.1, 9.3, 0.1, 1.7, 4.2, 4, [],
      [['medium', 110, 'One medium'], ['cup', 160, 'Chopped cup']]],
    ['garlic', 'Garlic', 'ثوم', 'vegetables', 149, 6.4, 33.1, 0.5, 2.1, 1.0, 17, [],
      [['piece', 3, 'One clove'], ['tsp', 3, 'One teaspoon']]],
    ['pepper_green', 'Green bell pepper', 'فلفل أخضر', 'vegetables', 20, 0.9, 4.6, 0.2, 1.7, 2.4, 3, [],
      [['medium', 119, 'One medium']]],
    ['pepper_red', 'Red bell pepper', 'فلفل أحمر', 'vegetables', 31, 1.0, 6.0, 0.3, 2.1, 4.2, 4, [],
      [['medium', 119, 'One medium']]],
    ['mushroom', 'Mushrooms', 'مشروم', 'vegetables', 22, 3.1, 3.3, 0.3, 1.0, 2.0, 5, [],
      [['cup', 70, 'Sliced cup']]],
    ['beetroot', 'Beetroot', 'بنجر', 'vegetables', 43, 1.6, 9.6, 0.2, 2.8, 6.8, 78, [],
      [['cup', 136, 'One cup']]],
    ['turnip', 'Turnip', 'لفت', 'vegetables', 28, 0.9, 6.4, 0.1, 1.8, 3.8, 67, [],
      [['cup', 130, 'One cup']]],
    ['radish', 'Radish', 'فجل', 'vegetables', 16, 0.7, 3.4, 0.1, 1.6, 1.9, 39, [],
      [['cup', 116, 'One cup']]],
    ['pumpkin', 'Pumpkin', 'قرع', 'vegetables', 26, 1.0, 6.5, 0.1, 0.5, 2.8, 1, [],
      [['cup', 116, 'One cup']]],
    ['artichoke', 'Artichoke', 'خرشوف', 'vegetables', 47, 3.3, 10.5, 0.2, 5.4, 1.0, 94, [],
      [['medium', 128, 'One medium']]],

    /* ---------------------------------------------------------------- fruits */
    ['date_medjool', 'Dates, medjool', 'تمر مجدول', 'fruits', 277, 1.8, 75.0, 0.2, 6.7, 66.5, 1, [],
      [['piece', 24, 'One date'], ['handful', 72, 'Three dates']]],
    ['date_dry', 'Dates, dried', 'تمر جاف', 'fruits', 282, 2.5, 75.0, 0.4, 8.0, 63.4, 2, [],
      [['piece', 8, 'One date'], ['tbsp', 12, 'One tablespoon']]],
    ['banana', 'Banana', 'موز', 'fruits', 89, 1.1, 22.8, 0.3, 2.6, 12.2, 1, [],
      [['medium', 118, 'One medium'], ['small', 90, 'One small']]],
    ['apple', 'Apple', 'تفاح', 'fruits', 52, 0.3, 13.8, 0.2, 2.4, 10.4, 1, [],
      [['medium', 182, 'One medium'], ['small', 130, 'One small']]],
    ['orange', 'Orange', 'برتقال', 'fruits', 47, 0.9, 11.8, 0.1, 2.4, 9.4, 0, [],
      [['medium', 131, 'One medium'], ['glass', 248, 'One glass juice']]],
    ['mandarin', 'Mandarin', 'يوسفي', 'fruits', 53, 0.8, 13.3, 0.3, 1.8, 10.6, 2, [],
      [['medium', 88, 'One medium']]],
    ['mango', 'Mango', 'مانجو', 'fruits', 60, 0.8, 15.0, 0.4, 1.6, 13.7, 1, [],
      [['medium', 200, 'One medium'], ['cup', 165, 'Sliced cup']]],
    ['watermelon', 'Watermelon', 'بطيخ', 'fruits', 30, 0.6, 7.6, 0.2, 0.4, 6.2, 1, [],
      [['slice', 280, 'One slice'], ['cup', 152, 'Diced cup']]],
    ['melon', 'Melon (canteloupe)', 'شمام', 'fruits', 34, 0.8, 8.2, 0.2, 0.9, 7.9, 16, [],
      [['slice', 160, 'One slice'], ['cup', 160, 'Diced cup']]],
    ['grapes', 'Grapes', 'عنب', 'fruits', 69, 0.7, 18.1, 0.2, 0.9, 15.5, 2, [],
      [['cup', 151, 'One cup'], ['handful', 80, 'One handful']]],
    ['strawberry', 'Strawberry', 'فراولة', 'fruits', 32, 0.7, 7.7, 0.3, 2.0, 4.9, 1, [],
      [['cup', 152, 'One cup']]],
    ['guava', 'Guava', 'جوافة', 'fruits', 68, 2.6, 14.3, 1.0, 5.4, 8.9, 2, [],
      [['medium', 55, 'One medium']]],
    ['fig_fresh', 'Figs, fresh', 'تين طازج', 'fruits', 74, 0.8, 19.2, 0.3, 2.9, 16.3, 1, [],
      [['medium', 50, 'One fig']]],
    ['pomegranate', 'Pomegranate', 'رمان', 'fruits', 83, 1.7, 18.7, 1.2, 4.0, 13.7, 3, [],
      [['medium', 154, 'One medium'], ['cup', 174, 'One cup arils']]],
    ['peach', 'Peach', 'خوخ', 'fruits', 39, 0.9, 9.5, 0.3, 1.5, 8.4, 0, [],
      [['medium', 150, 'One medium']]],
    ['pear', 'Pear', 'كمثرى', 'fruits', 57, 0.4, 15.2, 0.1, 3.1, 9.8, 1, [],
      [['medium', 178, 'One medium']]],
    ['apricot_dry', 'Apricots, dried', 'مشمش مجفف', 'fruits', 241, 3.4, 62.6, 0.5, 7.3, 53.4, 10, ['sulfite'],
      [['piece', 8, 'One piece'], ['handful', 40, 'Five pieces']]],
    ['raisins', 'Raisins', 'زبيب', 'fruits', 299, 3.1, 79.2, 0.5, 3.7, 59.2, 11, ['sulfite'],
      [['tbsp', 9, 'One tablespoon'], ['handful', 40, 'One handful']]],
    ['lemon', 'Lemon', 'ليمون', 'fruits', 29, 1.1, 9.3, 0.3, 2.8, 2.5, 2, [],
      [['medium', 58, 'One lemon'], ['tbsp', 15, 'One tablespoon juice']]],
    ['avocado', 'Avocado', 'أفوكادو', 'fruits', 160, 2.0, 8.5, 14.7, 6.7, 0.7, 7, [],
      [['medium', 150, 'One medium'], ['half', 75, 'Half']]],

    /* -------------------------------------------------------------- legumes */
    ['foul_medames', 'Fava beans (foul medames), cooked', 'فول مدمس', 'legumes', 110, 7.6, 19.7, 0.4, 5.4, 1.8, 5, [],
      [['cup', 170, 'One cup'], ['bowl', 200, 'One bowl']]],
    ['taameya', 'Taameya (Egyptian falafel)', 'طعمية', 'legumes', 333, 13.3, 31.8, 17.8, 7.0, 2.0, 400, [],
      [['piece', 25, 'One piece'], ['handful', 100, 'Four pieces']], 'needsVerify'],
    ['lentils_cooked', 'Lentils, cooked', 'عدس مطبوخ', 'legumes', 116, 9.0, 20.1, 0.4, 7.9, 1.8, 2, [],
      [['cup', 198, 'One cup'], ['bowl', 220, 'One bowl']]],
    ['chickpeas_cooked', 'Chickpeas, cooked', 'حمص مطبوخ', 'legumes', 164, 8.9, 27.4, 2.6, 7.6, 4.8, 7, [],
      [['cup', 164, 'One cup']]],
    ['kidney_beans', 'Kidney beans, cooked', 'فاصوليا حمراء', 'legumes', 127, 8.7, 22.8, 0.5, 6.4, 0.3, 1, [],
      [['cup', 177, 'One cup']]],
    ['white_beans', 'White beans, cooked', 'فاصوليا بيضاء', 'legumes', 139, 9.7, 25.1, 0.5, 6.3, 0.3, 6, [],
      [['cup', 179, 'One cup']]],
    ['lupin', 'Lupin beans (termes)', 'ترمس', 'legumes', 119, 15.6, 9.9, 2.9, 2.8, 0.5, 240, [],
      [['cup', 166, 'One cup'], ['handful', 40, 'One handful']]],
    ['soybeans', 'Soybeans, cooked', 'فول الصويا', 'legumes', 173, 16.6, 9.9, 9.0, 6.0, 3.0, 1, ['soy'],
      [['cup', 172, 'One cup']]],

    /* ---------------------------------------------------------------- dairy */
    ['milk_full', 'Milk, full fat', 'لبن كامل الدسم', 'dairy', 61, 3.2, 4.8, 3.3, 0, 5.1, 43, ['milk', 'lactose'],
      [['glass', 240, 'One glass'], ['cup', 244, 'One cup']]],
    ['milk_skim', 'Milk, skimmed', 'لبن منزوع الدسم', 'dairy', 34, 3.4, 5.0, 0.1, 0, 5.1, 42, ['milk', 'lactose'],
      [['glass', 240, 'One glass']]],
    ['yoghurt_plain', 'Yoghurt, plain', 'زبادي طبيعي', 'dairy', 61, 3.5, 4.7, 3.3, 0, 4.7, 46, ['milk', 'lactose'],
      [['cup', 245, 'One cup'], ['tbsp', 15, 'One tablespoon']]],
    ['yoghurt_low', 'Yoghurt, low fat', 'زبادي قليل الدسم', 'dairy', 46, 4.0, 6.1, 0.9, 0, 6.0, 50, ['milk', 'lactose'],
      [['cup', 245, 'One cup']]],
    ['rayeb', 'Rayeb (fermented milk)', 'لبن رايب', 'dairy', 60, 3.3, 4.9, 3.2, 0, 4.9, 44, ['milk', 'lactose'],
      [['glass', 240, 'One glass']]],
    ['cheese_white', 'White cheese (baramili)', 'جبنة بيضاء', 'dairy', 264, 14.5, 2.2, 22.0, 0, 1.0, 1200, ['milk', 'lactose'],
      [['slice', 30, 'One slice'], ['tbsp', 20, 'One tablespoon']]],
    ['cheese_roumi', 'Roumi cheese', 'جبنة رومي', 'dairy', 380, 25.0, 3.0, 30.0, 0, 1.5, 1400, ['milk', 'lactose'],
      [['slice', 25, 'One slice']]],
    ['cheese_cottage', 'Cottage cheese', 'جبنة قريش', 'dairy', 98, 11.1, 3.4, 4.3, 0, 2.7, 364, ['milk', 'lactose'],
      [['cup', 210, 'One cup'], ['tbsp', 30, 'One tablespoon']]],
    ['cheese_cheddar', 'Cheddar cheese', 'جبنة شيدر', 'dairy', 403, 24.9, 1.3, 33.1, 0, 0.5, 621, ['milk', 'lactose'],
      [['slice', 28, 'One slice']]],
    ['cream_double', 'Cream, double', 'كريمة', 'dairy', 340, 2.1, 2.8, 36.1, 0, 2.8, 38, ['milk', 'lactose'],
      [['tbsp', 15, 'One tablespoon']]],
    ['butter', 'Butter', 'زبدة', 'fats', 717, 0.9, 0.1, 81.1, 0, 0.1, 11, ['milk'],
      [['tbsp', 14, 'One tablespoon'], ['tsp', 5, 'One teaspoon']]],
    ['ghee', 'Ghee (samna)', 'سمنة', 'fats', 876, 0.3, 0.0, 99.5, 0, 0, 2, ['milk'],
      [['tbsp', 13, 'One tablespoon']]],

    /* ----------------------------------------------------------------- eggs */
    ['egg_boiled', 'Egg, boiled', 'بيض مسلوق', 'eggs', 155, 12.6, 1.1, 10.6, 0, 1.1, 124, ['egg'],
      [['piece', 50, 'One egg'], ['large', 60, 'One large egg']]],
    ['egg_white', 'Egg white', 'بياض بيض', 'eggs', 52, 10.9, 0.7, 0.2, 0, 0.7, 166, ['egg'],
      [['piece', 33, 'One white']]],
    ['egg_yolk', 'Egg yolk', 'صفار بيض', 'eggs', 322, 15.9, 3.6, 26.5, 0, 0.6, 48, ['egg'],
      [['piece', 17, 'One yolk']]],
    ['egg_fried', 'Egg, fried', 'بيض مقلي', 'eggs', 196, 13.6, 0.8, 15.0, 0, 0.4, 207, ['egg'],
      [['piece', 55, 'One egg']]],

    /* ----------------------------------------------------------------- meat */
    ['beef_lean', 'Beef, lean, cooked', 'لحم بقري قليل الدهن', 'meat', 250, 26.0, 0.0, 15.0, 0, 0, 72, [],
      [['piece', 100, 'One serving'], ['cup', 140, 'Diced cup']]],
    ['beef_fatty', 'Beef, fatty cuts, cooked', 'لحم بقري عالي الدهن', 'meat', 320, 22.0, 0.0, 25.0, 0, 0, 70, [],
      [['piece', 100, 'One serving']]],
    ['kofta', 'Kofta (minced meat)', 'كفتة', 'meat', 282, 17.5, 4.0, 21.8, 0.5, 1.0, 480, [],
      [['piece', 60, 'One piece'], ['handful', 120, 'Two pieces']], 'needsVerify'],
    ['lamb', 'Lamb, cooked', 'لحم ضأن', 'meat', 294, 24.5, 0.0, 21.0, 0, 0, 72, [],
      [['piece', 100, 'One serving']]],
    ['liver_beef', 'Beef liver, cooked', 'كبدة بقري', 'meat', 191, 29.0, 5.1, 5.3, 0, 0, 76, [],
      [['piece', 80, 'One serving']]],
    ['chicken_liver', 'Chicken liver, cooked', 'كبدة فراخ', 'poultry', 167, 24.5, 0.9, 6.5, 0, 0, 71, [],
      [['piece', 80, 'One serving']]],
    ['beef_sausage', 'Beef sausage', 'سجق', 'meat', 300, 14.0, 3.0, 25.5, 0, 1.2, 900, ['mustard'],
      [['piece', 40, 'One piece']], 'needsVerify'],
    ['shawerma', 'Shawerma (meat)', 'شاورما', 'meat', 240, 18.0, 8.0, 15.0, 1.0, 1.5, 700, ['gluten'],
      [['piece', 180, 'One sandwich']], 'needsVerify'],
    ['kebab', 'Kebab (grilled)', 'كباب', 'meat', 260, 20.0, 2.0, 19.0, 0.4, 0.8, 420, [],
      [['piece', 70, 'One skewer']], 'needsVerify'],

    /* -------------------------------------------------------------- poultry */
    ['chicken_breast', 'Chicken breast, skinless, cooked', 'صدور فراخ بدون جلد', 'poultry', 165, 31.0, 0, 3.6, 0, 0, 74, [],
      [['piece', 120, 'One breast'], ['cup', 140, 'Diced cup']]],
    ['chicken_thigh', 'Chicken thigh, skinless, cooked', 'وراك فراخ بدون جلد', 'poultry', 209, 26.0, 0, 10.9, 0, 0, 88, [],
      [['piece', 110, 'One thigh']]],
    ['chicken_skin', 'Chicken with skin, roasted', 'فراخ بالجلد مشوية', 'poultry', 239, 27.0, 0, 14.0, 0, 0, 82, [],
      [['quarter', 220, 'One quarter']]],
    ['turkey_breast', 'Turkey breast, cooked', 'صدور ديك رومي', 'poultry', 135, 30.0, 0, 1.0, 0, 0, 63, [],
      [['piece', 120, 'One serving']]],
    ['duck', 'Duck, roasted', 'بط مشوي', 'poultry', 337, 19.0, 0, 28.4, 0, 0, 59, [],
      [['piece', 150, 'One serving']]],

    /* ----------------------------------------------------------------- fish */
    ['tilapia', 'Tilapia (bolti), cooked', 'سمك بلطي', 'fish', 128, 26.2, 0, 2.7, 0, 0, 56, ['fish'],
      [['fillet', 120, 'One fillet'], ['piece', 150, 'One serving']]],
    ['bouri', 'Mullet (bouri), cooked', 'سمك بوري', 'fish', 150, 22.0, 0, 6.5, 0, 0, 65, ['fish'],
      [['piece', 150, 'One serving']]],
    ['salmon', 'Salmon, cooked', 'سلمون', 'fish', 208, 22.5, 0, 13.4, 0, 0, 59, ['fish'],
      [['fillet', 154, 'One fillet']]],
    ['tuna_canned', 'Tuna, canned in water', 'تونة معلبة بالماء', 'fish', 116, 25.5, 0, 0.8, 0, 0, 320, ['fish'],
      [['can', 142, 'One can drained'], ['tbsp', 30, 'One tablespoon']]],
    ['sardines', 'Sardines, canned', 'سردين معلبة', 'fish', 208, 24.6, 0, 11.5, 0, 0, 505, ['fish'],
      [['can', 92, 'One can']]],
    ['shrimp', 'Shrimp, cooked', 'جمبري', 'fish', 99, 24.0, 0.2, 0.3, 0, 0, 111, ['shellfish'],
      [['piece', 15, 'One shrimp'], ['cup', 145, 'One cup']]],
    ['fish_smoked', 'Smoked herring (ringa)', 'رنجة مدخنة', 'fish', 217, 24.6, 0, 12.4, 0, 0, 1200, ['fish'],
      [['piece', 90, 'One serving']]],

    /* ---------------------------------------------------------- nuts & seeds */
    ['almonds', 'Almonds', 'لوز', 'nuts', 579, 21.2, 21.6, 49.9, 12.5, 4.4, 1, ['treenut'],
      [['handful', 28, 'One handful'], ['tbsp', 9, 'One tablespoon']]],
    ['walnuts', 'Walnuts', 'عين جمل', 'nuts', 654, 15.2, 13.7, 65.2, 6.7, 2.6, 2, ['treenut'],
      [['handful', 28, 'One handful'], ['tbsp', 8, 'One tablespoon']]],
    ['cashews', 'Cashews', 'كاجو', 'nuts', 553, 18.2, 30.2, 43.9, 3.3, 5.9, 12, ['treenut'],
      [['handful', 28, 'One handful']]],
    ['pistachios', 'Pistachios', 'فستق', 'nuts', 560, 20.2, 27.2, 45.3, 10.6, 7.7, 1, ['treenut'],
      [['handful', 28, 'One handful']]],
    ['hazelnuts', 'Hazelnuts', 'بندق', 'nuts', 628, 15.0, 16.7, 60.8, 9.7, 4.3, 0, ['treenut'],
      [['handful', 28, 'One handful']]],
    ['peanuts', 'Peanuts', 'فول سوداني', 'nuts', 567, 25.8, 16.1, 49.2, 8.5, 4.7, 18, ['peanut'],
      [['handful', 28, 'One handful'], ['tbsp', 9, 'One tablespoon']]],
    ['peanut_butter', 'Peanut butter', 'زبدة فول سوداني', 'nuts', 588, 25.1, 20.0, 50.4, 6.0, 9.2, 429, ['peanut'],
      [['tbsp', 16, 'One tablespoon']]],
    ['sunflower_seeds', 'Sunflower seeds', 'لب عباد الشمس', 'nuts', 584, 20.8, 20.0, 51.5, 8.6, 2.6, 9, [],
      [['handful', 30, 'One handful'], ['tbsp', 10, 'One tablespoon']]],
    ['pumpkin_seeds', 'Pumpkin seeds', 'لب قرع', 'nuts', 559, 30.2, 10.7, 49.1, 6.0, 1.4, 7, [],
      [['handful', 30, 'One handful'], ['tbsp', 10, 'One tablespoon']]],
    ['sesame', 'Sesame seeds', 'سمسم', 'nuts', 573, 17.7, 23.4, 49.7, 11.8, 0.3, 11, ['sesame'],
      [['tbsp', 9, 'One tablespoon']]],
    ['tahini', 'Tahini (sesame paste)', 'طحينة', 'condiments', 595, 17.0, 21.2, 53.8, 9.3, 0.5, 115, ['sesame'],
      [['tbsp', 15, 'One tablespoon']]],

    /* ----------------------------------------------------------------- fats */
    ['olive_oil', 'Olive oil', 'زيت زيتون', 'fats', 884, 0, 0, 100.0, 0, 0, 2, [],
      [['tbsp', 13.5, 'One tablespoon'], ['tsp', 4.5, 'One teaspoon']]],
    ['sunflower_oil', 'Sunflower oil', 'زيت عباد الشمس', 'fats', 884, 0, 0, 100.0, 0, 0, 0, [],
      [['tbsp', 13.5, 'One tablespoon']]],
    ['corn_oil', 'Corn oil', 'زيت ذرة', 'fats', 884, 0, 0, 100.0, 0, 0, 0, [],
      [['tbsp', 13.5, 'One tablespoon']]],
    ['mayonnaise', 'Mayonnaise', 'مايونيز', 'condiments', 680, 1.0, 0.6, 75.0, 0, 0.6, 635, ['egg', 'mustard'],
      [['tbsp', 14, 'One tablespoon']]],

    /* --------------------------------------------------------------- sweets */
    ['sugar_white', 'Sugar, white', 'سكر أبيض', 'sweets', 387, 0, 100.0, 0, 0, 100.0, 1, [],
      [['tsp', 4, 'One teaspoon'], ['tbsp', 12, 'One tablespoon']]],
    ['honey', 'Honey', 'عسل نحل', 'sweets', 304, 0.3, 82.4, 0, 0.2, 82.1, 4, [],
      [['tbsp', 21, 'One tablespoon'], ['tsp', 7, 'One teaspoon']]],
    ['molasses', 'Molasses (asal aswad)', 'عسل أسود', 'sweets', 290, 0, 74.7, 0.1, 0, 74.7, 37, [],
      [['tbsp', 20, 'One tablespoon']]],
    ['halva_plain', 'Halva (plain)', 'حلاوة طحينية', 'sweets', 469, 12.5, 54.0, 22.0, 4.0, 50.0, 200, ['sesame'],
      [['piece', 30, 'One piece'], ['tbsp', 20, 'One tablespoon']], 'needsVerify'],
    ['basbousa', 'Basbousa', 'بسبوسة', 'sweets', 385, 5.5, 58.0, 14.5, 1.5, 35.0, 190, ['gluten', 'milk'],
      [['piece', 60, 'One piece']], 'needsVerify'],
    ['konafa', 'Konafa', 'كنافة', 'sweets', 400, 7.0, 55.0, 17.0, 1.2, 32.0, 180, ['gluten', 'milk', 'treenut'],
      [['piece', 80, 'One piece']], 'needsVerify'],
    ['baklava', 'Baklava', 'بقلاوة', 'sweets', 428, 6.5, 50.0, 22.5, 2.0, 28.0, 165, ['gluten', 'treenut', 'milk'],
      [['piece', 40, 'One piece']], 'needsVerify'],
    ['rice_pudding', 'Rice pudding', 'مهلبية', 'sweets', 130, 3.2, 22.0, 3.4, 0.2, 14.0, 60, ['milk'],
      [['cup', 200, 'One cup']], 'needsVerify'],
    ['chocolate_dark', 'Dark chocolate (70%)', 'شوكولاتة داكنة', 'sweets', 598, 7.8, 45.9, 42.6, 10.9, 24.0, 20, ['milk', 'soy'],
      [['piece', 10, 'One square'], ['handful', 30, 'Three squares']]],
    ['chocolate_milk', 'Milk chocolate', 'شوكولاتة بالحليب', 'sweets', 535, 7.7, 59.4, 29.7, 3.4, 51.5, 79, ['milk', 'soy'],
      [['piece', 10, 'One square']]],
    ['jam', 'Jam', 'مربى', 'sweets', 278, 0.4, 68.9, 0.1, 1.1, 48.5, 32, [],
      [['tbsp', 20, 'One tablespoon']]],
    ['ice_cream', 'Ice cream, vanilla', 'آيس كريم', 'sweets', 207, 3.5, 24.0, 11.0, 0.7, 21.2, 80, ['milk', 'egg'],
      [['cup', 132, 'One cup'], ['piece', 65, 'One scoop']]],

    /* ------------------------------------------------------------ beverages */
    ['water', 'Water', 'ماء', 'beverages', 0, 0, 0, 0, 0, 0, 0, [],
      [['glass', 240, 'One glass'], ['cup', 240, 'One cup']]],
    ['tea_unsweetened', 'Tea, unsweetened', 'شاي بدون سكر', 'beverages', 1, 0, 0.2, 0, 0, 0, 3, [],
      [['cup', 240, 'One cup']]],
    ['coffee_black', 'Coffee, black', 'قهوة سادة', 'beverages', 2, 0.3, 0, 0, 0, 0, 5, [],
      [['cup', 240, 'One cup']]],
    ['juice_orange', 'Orange juice', 'عصير برتقال', 'beverages', 45, 0.7, 10.4, 0.2, 0.2, 8.4, 1, [],
      [['glass', 248, 'One glass']]],
    ['karkadeh', 'Hibiscus tea (karkadeh)', 'كركديه', 'beverages', 12, 0.1, 2.9, 0, 0.2, 2.0, 2, [],
      [['glass', 240, 'One glass']]],
    ['sugarcane_juice', 'Sugarcane juice', 'عصير قصب', 'beverages', 58, 0.2, 14.5, 0.1, 0.1, 13.5, 5, [],
      [['glass', 240, 'One glass']]],
    ['soda', 'Soft drink, cola', 'مشروب غازي', 'beverages', 42, 0, 10.6, 0, 0, 10.6, 4, [],
      [['can', 330, 'One can'], ['glass', 240, 'One glass']]],
    ['beer', 'Beer', 'بيرة', 'beverages', 43, 0.5, 3.6, 0, 0, 0.1, 4, ['gluten'],
      [['can', 355, 'One can']]],
    ['wine_red', 'Wine, red', 'نبيذ أحمر', 'beverages', 85, 0.1, 2.6, 0, 0, 0.6, 4, ['sulfite'],
      [['glass', 147, 'One glass']]],

    /* -------------------------------------------------- traditional dishes */
    ['koshari', 'Koshari', 'كشري', 'dishes', 180, 6.0, 31.0, 4.0, 3.5, 1.5, 420, ['gluten'],
      [['plate', 350, 'One plate'], ['cup', 200, 'One cup']], 'needsVerify'],
    ['molokhia_stew', 'Molokhia stew', 'شوربة ملوخية', 'dishes', 85, 4.5, 6.0, 4.6, 2.0, 1.0, 380, [],
      [['bowl', 250, 'One bowl']], 'needsVerify'],
    ['mahshi', 'Mahshi (stuffed vegetables)', 'محشي', 'dishes', 145, 3.6, 22.0, 4.8, 2.4, 3.0, 350, [],
      [['piece', 90, 'One piece'], ['plate', 300, 'One plate']], 'needsVerify'],
    ['fatta', 'Fatta', 'فتة', 'dishes', 250, 12.0, 22.0, 13.0, 2.5, 2.0, 480, [],
      [['plate', 350, 'One plate']], 'needsVerify'],
    ['mesaqaa', 'Mesaqaa (eggplant bake)', 'مسقعة', 'dishes', 160, 4.0, 14.0, 10.0, 3.5, 4.5, 400, [],
      [['plate', 300, 'One plate']], 'needsVerify'],
    ['hamam_mahshi', 'Stuffed pigeon', 'حمام محشي', 'dishes', 235, 22.0, 8.0, 13.0, 1.2, 1.0, 480, [],
      [['piece', 220, 'One bird']], 'needsVerify'],
    ['roqaq', 'Roqaq (meat pastry)', 'رقاق', 'dishes', 270, 11.0, 26.0, 13.5, 1.8, 2.0, 520, ['gluten'],
      [['piece', 120, 'One piece']], 'needsVerify'],
    ['lentil_soup', 'Lentil soup', 'شوربة عدس', 'dishes', 90, 5.0, 14.0, 1.6, 3.5, 1.5, 380, [],
      [['bowl', 250, 'One bowl']], 'needsVerify'],
    ['vegetable_soup', 'Vegetable soup', 'شوربة خضار', 'dishes', 45, 1.8, 7.0, 1.2, 1.5, 2.5, 420, [],
      [['bowl', 250, 'One bowl']], 'needsVerify'],
    ['chicken_soup', 'Chicken soup', 'شوربة فراخ', 'dishes', 55, 3.5, 4.0, 2.4, 0.4, 1.0, 450, [],
      [['bowl', 250, 'One bowl']]],
    ['baba_ghanoush', 'Baba ghanoush', 'بابا غنوج', 'dishes', 130, 2.5, 8.5, 9.5, 3.5, 4.0, 320, ['sesame'],
      [['tbsp', 30, 'One tablespoon'], ['plate', 150, 'One serving']], 'needsVerify'],
    ['hummus', 'Hummus', 'حمص بالطحينة', 'dishes', 177, 5.5, 14.5, 11.0, 4.0, 0.5, 380, ['sesame'],
      [['tbsp', 30, 'One tablespoon'], ['plate', 150, 'One serving']], 'needsVerify'],
    ['grape_leaves', 'Stuffed grape leaves', 'محشي ورق عنب', 'dishes', 150, 3.0, 21.0, 6.0, 2.5, 2.0, 420, [],
      [['piece', 30, 'One piece']], 'needsVerify'],

    /* ------------------------------------------------------------ condiments */
    ['tomato_paste', 'Tomato paste', 'صلصة طماطم', 'condiments', 82, 4.3, 18.9, 0.5, 4.1, 12.2, 59, [],
      [['tbsp', 16, 'One tablespoon']]],
    ['ketchup', 'Ketchup', 'كاتشب', 'condiments', 101, 1.0, 25.8, 0.1, 0.3, 22.8, 907, [],
      [['tbsp', 17, 'One tablespoon']]],
    ['vinegar', 'Vinegar', 'خل', 'condiments', 18, 0, 0.9, 0, 0, 0.4, 5, ['sulfite'],
      [['tbsp', 15, 'One tablespoon']]],
    ['soy_sauce', 'Soy sauce', 'صويا صوص', 'condiments', 53, 8.1, 4.9, 0.6, 0.8, 0.4, 5493, ['soy', 'gluten'],
      [['tbsp', 18, 'One tablespoon']]],
    ['olives_black', 'Olives, black', 'زيتون أسود', 'condiments', 115, 0.8, 6.3, 10.7, 3.2, 0, 735, [],
      [['piece', 4, 'One olive'], ['handful', 40, 'Ten olives']]],
    ['olives_green', 'Olives, green', 'زيتون أخضر', 'condiments', 145, 1.0, 3.8, 15.3, 3.3, 0.5, 1556, [],
      [['piece', 4, 'One olive'], ['tbsp', 35, 'One tablespoon']]],
    ['pickles', 'Pickled cucumbers', 'مخلل', 'condiments', 11, 0.5, 2.3, 0.2, 1.2, 1.0, 1200, [],
      [['piece', 30, 'One piece']]],
    ['hot_sauce', 'Hot chilli sauce', 'شطة', 'condiments', 30, 1.0, 5.0, 0.5, 1.5, 3.0, 1800, [],
      [['tsp', 5, 'One teaspoon']]],
    ['black_pepper', 'Black pepper', 'فلفل أسود', 'condiments', 251, 10.4, 63.9, 3.3, 25.3, 0.6, 20, [],
      [['tsp', 2, 'One teaspoon']]],
    ['cumin', 'Cumin', 'كمون', 'condiments', 375, 17.8, 44.2, 22.3, 10.5, 2.3, 168, [],
      [['tsp', 2, 'One teaspoon']]],
    ['coriander', 'Coriander, ground', 'كزبرة', 'condiments', 298, 12.4, 55.0, 17.8, 41.9, 0, 35, [],
      [['tsp', 2, 'One teaspoon']]],
    ['cinnamon', 'Cinnamon', 'قرفة', 'condiments', 247, 4.0, 80.6, 1.2, 53.1, 2.2, 10, [],
      [['tsp', 3, 'One teaspoon']]]
  ];

  /* ------------------------------------------------------------- build items */
  var byId = {};

  var items = RAW.map(function (r) {
    var f = {
      id: r[0],
      nameEn: r[1],
      nameAr: r[2],
      category: r[3],
      categoryAr: CATEGORY_AR[r[3]] || r[3],
      kcal: r[4],
      protein: r[5],
      carb: r[6],
      fat: r[7],
      fiber: r[8],
      sugar: r[9],
      sodium: r[10],
      allergens: r[11] || [],
      isEgyptian: true,
      needsVerify: r[13] === 'needsVerify',
      source: 'Reference composition tables (USDA-class + Egyptian regional data)',
      portions: (r[12] || []).map(function (p) {
        return {
          measure: p[0],
          measureAr: MEASURE_AR[p[0]] || p[0],
          grams: p[1],
          labelEn: p[2],
          assumptionNote: 'Assumed ' + p[1] + ' g for one ' + String(p[2] || p[0]).toLowerCase() + '.'
        };
      })
    };
    // Every food is weighable in grams, always.
    f.portions.push({
      measure: 'g', measureAr: MEASURE_AR.g, grams: 100,
      labelEn: 'Weighed (100 g)', assumptionNote: 'Grams are the reference basis.'
    });
    byId[f.id] = f;
    return f;
  });

  /* ------------------------------------------------ derived / helper access */
  /** Grams of `food` that supply `kcal` — the 100-kcal exchange portion. */
  function gramsForKcal(food, kcal) {
    if (!food || !food.kcal) return null;
    return CN.util.round((kcal || 100) * 100 / food.kcal, 1);
  }

  /** Nutrients contained in an arbitrary gram weight. */
  function nutrientsFor(food, grams) {
    var k = (Number(grams) || 0) / 100;
    return {
      kcal: CN.util.round(food.kcal * k, 1),
      protein: CN.util.round(food.protein * k, 1),
      carb: CN.util.round(food.carb * k, 1),
      fat: CN.util.round(food.fat * k, 1),
      fiber: CN.util.round(food.fiber * k, 1),
      sodium: CN.util.round(food.sodium * k, 1)
    };
  }

  /** Fractional quantity of a household measure, e.g. 1.5 cups. */
  function household(food, grams) {
    if (!food || !food.portions || !food.portions.length) return null;
    var best = null;
    food.portions.forEach(function (p) {
      if (p.measure === 'g') return;
      var qty = grams / p.grams;
      // Prefer a human-scale fraction (>= 0.5) of a familiar measure.
      if (qty >= 0.5 && (!best || qty < best.qty)) best = { portion: p, qty: CN.util.round(qty, 1) };
    });
    if (!best) return null;
    return {
      measure: best.portion.measure,
      measureAr: best.portion.measureAr,
      qty: best.qty,
      labelEn: best.qty + ' × ' + best.portion.labelEn,
      labelAr: best.qty + ' × ' + best.portion.measureAr
    };
  }

  /** Does any allergen on the food intersect the exclusion list? */
  function conflicts(food, exclusions) {
    if (!food || !exclusions || !exclusions.length) return [];
    var ex = exclusions.map(function (e) { return String(e).toLowerCase(); });
    return (food.allergens || []).filter(function (a) { return ex.indexOf(a) !== -1; });
  }

  function matchesQuery(food, q) {
    if (!q) return true;
    var s = q.trim().toLowerCase();
    if (!s) return true;
    return food.nameEn.toLowerCase().indexOf(s) !== -1 ||
      (food.nameAr || '').indexOf(q.trim()) !== -1 ||
      food.category.indexOf(s) !== -1 ||
      food.id.indexOf(s) !== -1;
  }

  CN.foods = {
    items: items,
    all: items,
    allergens: ALLERGENS,
    categories: Object.keys(CATEGORY_AR).map(function (k) {
      return { key: k, en: k.charAt(0).toUpperCase() + k.slice(1), ar: CATEGORY_AR[k] };
    }),
    categoryLabel(key) { return CATEGORY_AR[key] || key; },
    allergenLabel(key, lang) {
      for (var i = 0; i < ALLERGENS.length; i++) {
        if (ALLERGENS[i][0] === key) return lang === 'ar' ? ALLERGENS[i][2] : ALLERGENS[i][1];
      }
      return key;
    },
    byId(id) { return byId[id] || null; },
    search(q, opts) {
      opts = opts || {};
      var out = items.filter(function (f) {
        if (opts.category && f.category !== opts.category) return false;
        if (opts.egyptianOnly && !f.isEgyptian) return false;
        if (opts.excludeAllergens && conflicts(f, opts.excludeAllergens).length) return false;
        return matchesQuery(f, q);
      });
      var key = (CN.i18n && CN.i18n.lang === 'ar') ? 'nameAr' : 'nameEn';
      return out.sort(function (a, b) {
        return String(a[key] || '').localeCompare(String(b[key] || ''), CN.i18n && CN.i18n.lang === 'ar' ? 'ar' : 'en');
      });
    },
    gramsForKcal: gramsForKcal,
    nutrientsFor: nutrientsFor,
    household: household,
    conflicts: conflicts,
    count: items.length
  };
})();
