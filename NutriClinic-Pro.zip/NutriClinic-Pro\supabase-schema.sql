-- ============================================================================
--  NutriClinic Pro — Supabase / PostgreSQL backend schema  (HARDENED)
--  WHAT THIS FILE DOES NOT COVER
--    * Storage object policies. Those need a signed-in HTTP client, because
--      storage.objects is written through the Storage API rather than by SQL.
--      Verify manually: sign in, upload a document, then open its object URL in
--      a private window — it must be denied.
--    * Session expiry and token refresh. Verify by shortening the JWT expiry in
--      Authentication → Settings, then leaving a tab idle.
--    * The application's own read paths. See docs/TEST-AND-DEPLOY.md §4 for
--      which reads are audited and which are not.
-- ============================================================================
--  HOW TO RUN
--    New project: paste this whole file into the Supabase SQL editor and run it.
--    Existing project: read section 12 first — there is a documented migration
--    path, and this file is written so that re-running it is safe.
--
--  This script contains NO statement that deletes rows or drops tables.
--  Section 1 lists every destructive-looking statement and states exactly what
--  it replaces. Nothing here can lose clinical data.
--
--  ---------------------------------------------------------------------------
--  SECURITY MODEL
--  ---------------------------------------------------------------------------
--  The application ships with the Supabase ANON key, which is public by design.
--  It grants nothing on its own: every table below has RLS enabled and no policy
--  admits an anonymous request.
--
--  The service_role key BYPASSES every policy here. It must never appear in
--  config.js, in the repository, or anywhere a browser can read. It belongs on a
--  server, in a migration script, or in the dashboard — nowhere else.
--
--  Roles, and what each may do:
--
--    owner      read + write every clinical table + delete + manage membership
--    clinician  read + write every clinical table + delete clinical records
--               (but NOT delete a whole patient record, and NOT manage members)
--    assistant  read everything; write day-to-day records (measurements, labs,
--               follow-ups, attachments, recipes, knowledge base, registration)
--               but NOT assessments or plans — those encode clinical decisions
--    auditor    READ ONLY. Cannot insert, update or delete anything, anywhere.
--
--  Ownership is always resolved as "this clinic", never as "some clinic this
--  user belongs to". A user in two clinics therefore cannot act in one using
--  authority from the other. See section 3.
-- ============================================================================


-- ============================================================================
--  SECTION 1 — Destructive operations: the complete inventory
-- ============================================================================
--
--  These are the ONLY statements in this file that remove anything. Each is
--  idempotent and each is scoped to objects this file created.
--
--  | Statement                              | What it removes                          | Data at risk |
--  |----------------------------------------|------------------------------------------|--------------|
--  | drop policy if exists <t>_read         | the SELECT policy on table <t>            | none         |
--  | drop policy if exists <t>_insert       | the INSERT policy on <t>                  | none         |
--  | drop policy if exists <t>_update       | the UPDATE policy on <t>                  | none         |
--  | drop policy if exists <t>_delete       | the DELETE policy on <t>                  | none         |
--  | drop policy if exists <t>_clinic_rw    | **the revision-1 blanket policy on <t>**  | none         |
--  | drop trigger if exists <t>_audit       | the audit trigger on <t>                  | none         |
--  | drop trigger if exists <t>_touch       | the updated_at trigger on <t>             | none         |
--  | drop policy if exists <name> on storage.objects | a storage policy                | none         |
--  | drop function if exists public.my_role() | revision-1 helper that returned an      | none         |
--  |                                        | unscoped role — deleted deliberately      |              |
--
--  What this script does NOT do:
--    - no drop table, anywhere
--    - no delete from, anywhere
--    - no truncate, anywhere
--    - no update of existing clinical rows
--
--  WHY THE `_clinic_rw` POLICY MUST BE DROPPED
--    PostgreSQL combines multiple permissive policies for the same command with
--    OR. Revision 1 granted every command through one blanket policy. If it were
--    left in place, the new least-privilege policies would be OR-ed with it and
--    would therefore grant nothing new — an auditor would still be able to write.
--    Dropping it is not optional; it is the whole point of this revision.
--
--  REPEATABILITY
--    - `create table if not exists`, `create index if not exists`
--    - `create or replace function`
--    - `drop policy/trigger if exists` immediately before `create policy/trigger`
--    - the storage bucket insert uses `on conflict (id) do nothing`
--    Running it twice produces the same result. Running it on a database with
--    data leaves the data untouched.
--
--  MIGRATION FOR AN EXISTING PROJECT — see section 12.
-- ============================================================================


-- ============================================================================
--  SECTION 2 — Extensions
-- ============================================================================
create extension if not exists pgcrypto;


-- ============================================================================
--  SECTION 3 — Tables: clinics and membership
-- ============================================================================
create table if not exists public.clinics (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  created_at  timestamptz not null default now()
);

do $$
begin
  if not exists (select 1 from pg_type where typname = 'member_role') then
    create type public.member_role as enum ('owner', 'clinician', 'assistant', 'auditor');
  end if;
end $$;

create table if not exists public.clinic_members (
  clinic_id   uuid not null references public.clinics(id) on delete cascade,
  user_id     uuid not null references auth.users(id) on delete cascade,
  role        public.member_role not null default 'clinician',
  created_at  timestamptz not null default now(),
  primary key (clinic_id, user_id)
);

create index if not exists clinic_members_user_idx on public.clinic_members (user_id);

alter table public.clinics enable row level security;
alter table public.clinic_members enable row level security;


-- ============================================================================
--  SECTION 4 — Capability helpers
--
--  Every helper below takes a clinic id and answers a question about THE
--  CALLER IN THAT CLINIC. None of them answers "what is this user's role
--  somewhere", which was the revision-1 defect: a single role selected with
--  `limit 1` and no ordering is nondeterministic for a user in two clinics, and
--  a policy that does not reference the row it guards can be satisfied using
--  authority from an unrelated clinic.
--
--  All are SECURITY DEFINER because they read clinic_members, which the caller
--  may not be able to read directly (and doing so through a policy on
--  clinic_members would recurse). All set an explicit search_path.
-- ============================================================================

create or replace function public.my_clinics()
returns setof uuid
language sql stable security definer set search_path = public, pg_temp as $fn$
  select clinic_id from public.clinic_members where user_id = auth.uid();
$fn$;

create or replace function public.my_owned_clinics()
returns setof uuid
language sql stable security definer set search_path = public, pg_temp as $fn$
  select clinic_id from public.clinic_members
  where user_id = auth.uid() and role = 'owner';
$fn$;

create or replace function public.my_role_in(target_clinic uuid)
returns public.member_role
language sql stable security definer set search_path = public, pg_temp as $fn$
  select role from public.clinic_members
  where user_id = auth.uid() and clinic_id = target_clinic;
$fn$;

create or replace function public.is_member_of(target_clinic uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $fn$
  select exists (
    select 1 from public.clinic_members
    where user_id = auth.uid() and clinic_id = target_clinic
  );
$fn$;

-- Any member, including an auditor. Read access.
create or replace function public.can_read(target_clinic uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $fn$
  select public.is_member_of(target_clinic);
$fn$;

-- Day-to-day records. Excludes auditors by construction.
create or replace function public.can_write_clinical(target_clinic uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $fn$
  select coalesce(
    public.my_role_in(target_clinic) in ('owner', 'clinician', 'assistant'),
    false
  );
$fn$;

-- Clinical decisions: assessments and diet plans. Assistants prepare drafts in
-- the interface but do not commit a decision, so they are excluded here.
create or replace function public.can_write_decisions(target_clinic uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $fn$
  select coalesce(
    public.my_role_in(target_clinic) in ('owner', 'clinician'),
    false
  );
$fn$;

-- Administrative authority: membership, and removing a whole patient record.
create or replace function public.can_manage(target_clinic uuid)
returns boolean
language sql stable security definer set search_path = public, pg_temp as $fn$
  select coalesce(public.my_role_in(target_clinic) = 'owner', false);
$fn$;

-- Casts a text to uuid without raising. Used inside storage policies, where an
-- unparseable path segment must DENY rather than abort the whole evaluation.
create or replace function public.safe_uuid(t text)
returns uuid
language plpgsql immutable as $fn$
begin
  return t::uuid;
exception when others then
  return null;
end
$fn$;


-- ============================================================================
--  SECTION 5 — Policies: clinics and membership
-- ============================================================================
-- Fail closed if an unfamiliar policy remains on a managed table. PostgreSQL
-- ORs permissive policies, so an unrecognized policy could defeat the rules
-- below. Review or explicitly migrate it before rerunning this script.
do $policy_check$
declare
  p record;
  allowed boolean;
begin
  for p in
    select tablename, policyname from pg_policies
    where schemaname = 'public'
      and tablename in ('clinics', 'clinic_members')
  loop
    allowed := case
      when p.tablename = 'clinics' then p.policyname = 'clinics_member_read'
      when p.tablename = 'clinic_members' then p.policyname = any(array[
        'members_self_read', 'members_owner_write', 'members_owner_insert', 'members_owner_delete'
      ])
      when p.tablename = 'audit_log' then p.policyname = any(array['audit_clinic_read', 'audit_no_write'])
      else p.policyname = any(array[
        p.tablename || '_read', p.tablename || '_insert',
        p.tablename || '_update', p.tablename || '_delete', p.tablename || '_clinic_rw'
      ])
    end;
    if not allowed then
      raise exception 'Unrecognized existing policy %.%; review it before applying hardened policies',
        p.tablename, p.policyname;
    end if;
  end loop;
end
$policy_check$;

drop policy if exists clinics_member_read on public.clinics;
create policy clinics_member_read on public.clinics
  for select to authenticated
  using (public.can_read(id));

drop policy if exists members_self_read on public.clinic_members;
create policy members_self_read on public.clinic_members
  for select to authenticated
  using (user_id = auth.uid() or public.can_read(clinic_id));

-- Membership can be UPDATED only by an owner of that exact clinic.
-- Self-promotion is impossible: the WITH CHECK re-evaluates ownership for the
-- row's own clinic after the change, so a non-owner can never satisfy it.
drop policy if exists members_owner_write on public.clinic_members;
create policy members_owner_write on public.clinic_members
  for update to authenticated
  using (public.can_manage(clinic_id))
  with check (public.can_manage(clinic_id));

-- Deliberately absent: INSERT and DELETE policies for clinic_members. With no
-- policy, both commands are denied for every client role. Membership changes
-- happen only through the RPCs in section 8, which enforce ownership explicitly.
drop policy if exists members_owner_insert on public.clinic_members;
drop policy if exists members_owner_delete on public.clinic_members;


-- ============================================================================
--  SECTION 6 — Clinical entity tables and their role-aware policies
-- ============================================================================
do $mig$
declare
  t text;
  tables text[] := array[
    'patients', 'measurements', 'labs', 'assessments', 'plans',
    'followups', 'attachments', 'recipes', 'kb'
  ];
begin
  foreach t in array tables loop
    execute format($ddl$
      create table if not exists public.%1$s (
        id            text primary key,
        clinic_id     uuid not null references public.clinics(id) on delete cascade,
        patient_id    text,
        storage_path  text,
        data          jsonb not null default '{}'::jsonb,
        created_at    timestamptz not null default now(),
        updated_at    timestamptz not null default now()
      );
      alter table public.%1$s enable row level security;
      create index if not exists %1$s_clinic_idx  on public.%1$s (clinic_id);
      create index if not exists %1$s_patient_idx on public.%1$s (patient_id);
    $ddl$, t);
  end loop;
end
$mig$;

-- Check the clinical tables after creation and before replacing their policies.
do $policy_check$
declare p record;
begin
  for p in
    select tablename, policyname from pg_policies
    where schemaname = 'public'
      and tablename in ('patients', 'measurements', 'labs', 'assessments', 'plans',
                        'followups', 'attachments', 'recipes', 'kb')
  loop
    if p.policyname <> all(array[
      p.tablename || '_read', p.tablename || '_insert', p.tablename || '_update',
      p.tablename || '_delete', p.tablename || '_clinic_rw'
    ]) then
      raise exception 'Unrecognized existing policy %.%; review it before applying hardened policies',
        p.tablename, p.policyname;
    end if;
  end loop;
end
$policy_check$;

-- ---------------------------------------------------------------------------
-- Per-table write class.
--
--   'decisions' — assessments and plans. Encode a clinical decision.
--                 Owner and clinician only.
--   'records'   — day-to-day clinical data. Owner, clinician and assistant.
--
-- Delete class:
--   'owner'     — removing a whole patient record is an administrative act.
--   'decision'  — owner and clinician; correcting a data-entry error is a
--                 clinical act. Assistants and auditors cannot delete anything.
-- ---------------------------------------------------------------------------
do $pol$
declare
  cfg text[][] := array[
    array['patients',     'records',   'owner'],
    array['measurements', 'records',   'decision'],
    array['labs',         'records',   'decision'],
    array['followups',    'records',   'decision'],
    array['attachments',  'records',   'decision'],
    array['recipes',      'records',   'decision'],
    array['kb',           'records',   'decision'],
    array['assessments',  'decisions', 'decision'],
    array['plans',        'decisions', 'decision']
  ];
  i int;
  t text;
  write_class text;
  del_class text;
  write_expr text;
  del_expr text;
begin
  for i in 1 .. array_length(cfg, 1) loop
    t := cfg[i][1];
    write_class := cfg[i][2];
    del_class := cfg[i][3];

    write_expr := case write_class
                    when 'decisions' then 'public.can_write_decisions(clinic_id)'
                    else 'public.can_write_clinical(clinic_id)'
                  end;
    del_expr := case del_class
                  when 'owner' then 'public.can_manage(clinic_id)'
                  else 'public.can_write_decisions(clinic_id)'
                end;

    -- Remove the revision-1 blanket policy. Without this the new policies are
    -- OR-ed with it and an auditor could still write. See section 1.
    execute format('drop policy if exists %1$s_clinic_rw on public.%1$s', t);

    -- READ: any member of the clinic, auditor included.
    execute format('drop policy if exists %1$s_read on public.%1$s', t);
    execute format(
      'create policy %1$s_read on public.%1$s for select to authenticated
         using (public.can_read(clinic_id))', t);

    -- INSERT
    execute format('drop policy if exists %1$s_insert on public.%1$s', t);
    execute format(
      'create policy %1$s_insert on public.%1$s for insert to authenticated
         with check (%2$s)', t, write_expr);

    -- UPDATE
    execute format('drop policy if exists %1$s_update on public.%1$s', t);
    execute format(
      'create policy %1$s_update on public.%1$s for update to authenticated
         using (%2$s) with check (%2$s)', t, write_expr);

    -- DELETE
    execute format('drop policy if exists %1$s_delete on public.%1$s', t);
    execute format(
      'create policy %1$s_delete on public.%1$s for delete to authenticated
         using (%2$s)', t, del_expr);
  end loop;
end
$pol$;

-- No UPDATE policy is narrowed to specific columns, so a client could in
-- principle rewrite `clinic_id` to move a row into another clinic. The WITH
-- CHECK prevents that: the new clinic_id must also satisfy the same capability,
-- and the caller has no authority in the target clinic. A row therefore cannot
-- be reassigned out of its own clinic by a client.


-- ============================================================================
--  SECTION 7 — Audit log and triggers
-- ============================================================================
create table if not exists public.audit_log (
  id          bigserial primary key,
  clinic_id   uuid,
  user_id     uuid,
  action      text not null,
  entity      text not null,
  entity_id   text,
  patient_id  text,
  detail      jsonb,
  at          timestamptz not null default now()
);

create index if not exists audit_clinic_idx  on public.audit_log (clinic_id, at desc);
create index if not exists audit_patient_idx on public.audit_log (patient_id, at desc);

alter table public.audit_log enable row level security;

do $policy_check$
declare p record;
begin
  for p in
    select policyname from pg_policies
    where schemaname = 'public' and tablename = 'audit_log'
  loop
    if p.policyname <> all(array['audit_clinic_read', 'audit_no_write']) then
      raise exception 'Unrecognized existing audit_log policy %; review it before applying hardened policies',
        p.policyname;
    end if;
  end loop;
end
$policy_check$;

-- Read-only, and only for members of the clinic. There is deliberately no
-- INSERT policy: entries are written by the trigger below, which runs as the
-- function owner. A client cannot forge or amend an audit entry.
drop policy if exists audit_clinic_read on public.audit_log;
create policy audit_clinic_read on public.audit_log
  for select to authenticated
  using (public.can_read(clinic_id));

drop policy if exists audit_no_write on public.audit_log;

create or replace function public.audit_trigger()
returns trigger
language plpgsql security definer set search_path = public, pg_temp as $fn$
declare
  row_clinic uuid;
  row_patient text;
  row_id text;
begin
  if tg_op = 'DELETE' then
    row_clinic := old.clinic_id; row_patient := old.patient_id; row_id := old.id;
  else
    row_clinic := new.clinic_id; row_patient := new.patient_id; row_id := new.id;
  end if;

  insert into public.audit_log (clinic_id, user_id, action, entity, entity_id, patient_id, detail)
  values (
    row_clinic, auth.uid(), lower(tg_op), tg_table_name, row_id, row_patient,
    case when tg_op = 'DELETE' then null
         else jsonb_build_object('updated_at', to_jsonb(new) -> 'updated_at') end
  );
  if tg_op = 'DELETE' then
    return old;
  else
    return new;
  end if;
end
$fn$;

create or replace function public.touch_updated_at()
returns trigger
language plpgsql set search_path = public, pg_temp as $fn$
begin
  new.updated_at := now();
  return new;
end
$fn$;

do $trg$
declare
  t text;
  tables text[] := array[
    'patients', 'measurements', 'labs', 'assessments', 'plans',
    'followups', 'attachments', 'recipes', 'kb'
  ];
begin
  foreach t in array tables loop
    execute format('drop trigger if exists %1$s_audit on public.%1$s', t);
    execute format(
      'create trigger %1$s_audit after insert or update or delete on public.%1$s
         for each row execute function public.audit_trigger()', t);

    execute format('drop trigger if exists %1$s_touch on public.%1$s', t);
    execute format(
      'create trigger %1$s_touch before update on public.%1$s
         for each row execute function public.touch_updated_at()', t);
  end loop;
end
$trg$;

-- Note on `to_jsonb(new) -> 'updated_at'`: the clinical payload is deliberately
-- NOT copied into the log. The entry records who changed which record when,
-- which is what an audit needs, without duplicating patient data into a second
-- table with different retention rules.


-- ============================================================================
--  SECTION 8 — Private document storage
-- ============================================================================
insert into storage.buckets (id, name, public)
values ('clinical-documents', 'clinical-documents', false)
on conflict (id) do nothing;

-- Path layout: <clinic_id>/<patient_id>/<attachment_id>-<filename>
-- Membership of the clinic in the first segment is the entire check.
-- safe_uuid() denies an unparseable segment instead of raising.
--
-- WRITE policies require can_write_clinical; an auditor cannot upload or remove
-- a document. Read is open to any member, as it is for the tables themselves.

drop policy if exists "clinical documents read" on storage.objects;
create policy "clinical documents read" on storage.objects
  for select to authenticated
  using (
    bucket_id = 'clinical-documents'
    and public.can_read(public.safe_uuid((storage.foldername(name))[1]))
  );

drop policy if exists "clinical documents insert" on storage.objects;
create policy "clinical documents insert" on storage.objects
  for insert to authenticated
  with check (
    bucket_id = 'clinical-documents'
    and public.can_write_clinical(public.safe_uuid((storage.foldername(name))[1]))
  );

drop policy if exists "clinical documents update" on storage.objects;
create policy "clinical documents update" on storage.objects
  for update to authenticated
  using (
    bucket_id = 'clinical-documents'
    and public.can_write_clinical(public.safe_uuid((storage.foldername(name))[1]))
  );

drop policy if exists "clinical documents delete" on storage.objects;
create policy "clinical documents delete" on storage.objects
  for delete to authenticated
  using (
    bucket_id = 'clinical-documents'
    and public.can_write_decisions(public.safe_uuid((storage.foldername(name))[1]))
  );

-- Superseded revision-1 policy names, removed so they cannot OR their way past
-- the policies above.
drop policy if exists "clinic members read documents" on storage.objects;
drop policy if exists "clinic members upload documents" on storage.objects;
drop policy if exists "clinic members replace documents" on storage.objects;
drop policy if exists "clinic members delete documents" on storage.objects;


-- ============================================================================
--  SECTION 9 — Onboarding and membership RPCs
-- ============================================================================

-- Creates the caller's FIRST clinic and makes them its owner. Additional
-- clinics are joined by invitation, never created ad hoc.
create or replace function public.bootstrap_clinic(clinic_name text)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $fn$
declare
  new_id uuid;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;
  if exists (select 1 from public.clinic_members where user_id = auth.uid()) then
    raise exception 'This account already belongs to a clinic';
  end if;

  insert into public.clinics (name)
  values (coalesce(nullif(btrim(clinic_name), ''), 'My Clinic'))
  returning id into new_id;

  insert into public.clinic_members (clinic_id, user_id, role)
  values (new_id, auth.uid(), 'owner');

  return new_id;
end
$fn$;

-- ---------------------------------------------------------------------------
-- COMPATIBILITY OVERLOAD — do not remove
--
-- The shipped client calls this function with only an email and a role. That
-- form cannot be made safe by itself, because "which clinic?" would have to be
-- guessed. Rather than leave a broken caller (which would make invitations fail
-- with 'A clinic id is required'), this overload answers the question safely:
--
--   * owns exactly one clinic → acts on it
--   * owns none               → refuses
--   * owns more than one       → REFUSES, and says which form to use
--
-- So the ambiguous case can never be resolved arbitrarily. It is refused.
-- ---------------------------------------------------------------------------
create or replace function public.add_clinic_member(
  member_email text,
  member_role text default 'clinician'
)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $fn$
declare
  owned uuid[];
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select array_agg(clinic_id) into owned
  from public.clinic_members
  where user_id = auth.uid() and role = 'owner';

  if owned is null or array_length(owned, 1) = 0 then
    raise exception 'Only a clinic owner may add members';
  end if;

  if array_length(owned, 1) > 1 then
    raise exception
      'This account owns more than one clinic. Call add_clinic_member with an explicit target_clinic_id.';
  end if;

  return public.add_clinic_member(owned[1], member_email, member_role);
end
$fn$;

-- Adds or re-roles a member of ONE EXPLICIT CLINIC.
--
-- The caller must own target_clinic_id. There is no `limit 1`, no implicit
-- "the caller's clinic", and no way to act on a clinic the caller does not own.
create or replace function public.add_clinic_member(
  target_clinic_id uuid,
  member_email text,
  member_role text default 'clinician'
)
returns uuid
language plpgsql security definer set search_path = public, pg_temp as $fn$
declare
  target_user uuid;
  wanted public.member_role;
  owners_left int;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if target_clinic_id is null then
    raise exception 'A clinic id is required';
  end if;

  -- Explicit ownership check against the named clinic, not "any owned clinic".
  if not exists (
    select 1 from public.clinic_members
    where clinic_id = target_clinic_id
      and user_id = auth.uid()
      and role = 'owner'
  ) then
    raise exception 'Only an owner of this clinic may change its membership';
  end if;

  if not exists (select 1 from public.clinics where id = target_clinic_id) then
    raise exception 'No such clinic';
  end if;

  select id into target_user
  from auth.users
  where lower(email) = lower(btrim(member_email))
  limit 1;

  if target_user is null then
    raise exception 'No registered account matches that email address';
  end if;

  wanted := coalesce(nullif(btrim(member_role), ''), 'clinician')::public.member_role;

  -- Never leave a clinic without an owner.
  if wanted <> 'owner' then
    select count(*) into owners_left
    from public.clinic_members
    where clinic_id = target_clinic_id and role = 'owner' and user_id <> target_user;
    if owners_left = 0 then
      raise exception 'Refused: that would leave the clinic with no owner';
    end if;
  end if;

  insert into public.clinic_members (clinic_id, user_id, role)
  values (target_clinic_id, target_user, wanted)
  on conflict (clinic_id, user_id) do update set role = excluded.role;

  return target_user;
end
$fn$;

-- Removes a member from ONE EXPLICIT CLINIC. Owner only, and refuses to remove
-- the last owner.
create or replace function public.remove_clinic_member(
  target_clinic_id uuid,
  member_email text
)
returns boolean
language plpgsql security definer set search_path = public, pg_temp as $fn$
declare
  target_user uuid;
  owners_left int;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if not exists (
    select 1 from public.clinic_members
    where clinic_id = target_clinic_id
      and user_id = auth.uid()
      and role = 'owner'
  ) then
    raise exception 'Only an owner of this clinic may change its membership';
  end if;

  select id into target_user
  from auth.users
  where lower(email) = lower(btrim(member_email))
  limit 1;

  if target_user is null then
    raise exception 'No registered account matches that email address';
  end if;

  select count(*) into owners_left
  from public.clinic_members
  where clinic_id = target_clinic_id and role = 'owner' and user_id <> target_user;

  if owners_left = 0 then
    raise exception 'Refused: that would leave the clinic with no owner';
  end if;

  delete from public.clinic_members
  where clinic_id = target_clinic_id and user_id = target_user;

  return true;
end
$fn$;

-- Lists the clinics the caller belongs to, with role. Used by the client to let
-- a multi-clinic user choose, instead of guessing one.
create or replace function public.my_memberships()
returns table (clinic_id uuid, clinic_name text, role public.member_role)
language sql stable security definer set search_path = public, pg_temp as $fn$
  select m.clinic_id, c.name, m.role
  from public.clinic_members m
  join public.clinics c on c.id = m.clinic_id
  where m.user_id = auth.uid()
  order by c.name;
$fn$;

-- Guaranteed-audited read of one patient record.
--
-- PostgreSQL has no SELECT trigger, so a plain REST select cannot be audited at
-- all. Reading through this function makes the read and its audit entry a single
-- server-side transaction: if the row comes back, the entry exists.
create or replace function public.patient_read(p_id text)
returns jsonb
language plpgsql security definer set search_path = public, pg_temp as $fn$
declare
  target_clinic uuid;
  payload jsonb;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  select p.clinic_id, to_jsonb(p)
    into target_clinic, payload
  from public.patients p
  where p.id = p_id
    and p.clinic_id in (select public.my_clinics());

  if target_clinic is null then
    -- Not found, or not the caller's clinic. Indistinguishable by design: a
    -- distinguishable response would confirm the existence of another clinic's
    -- record.
    return null;
  end if;

  insert into public.audit_log (clinic_id, user_id, action, entity, entity_id, patient_id)
  values (target_clinic, auth.uid(), 'read', 'patients', p_id, p_id);

  return payload;
end
$fn$;

-- Best-effort read logging for paths that cannot use patient_read().
-- The patient must belong to one of the caller's clinics, so a client cannot
-- write arbitrary entries into the trail.
create or replace function public.log_access(entity text, entity_id text, patient_id text)
returns void
language plpgsql security definer set search_path = public, pg_temp as $fn$
declare
  c uuid;
begin
  if auth.uid() is null or patient_id is null then
    return;
  end if;

  select p.clinic_id into c
  from public.patients p
  where p.id = patient_id
    and p.clinic_id in (select public.my_clinics());

  if c is null then
    return;
  end if;

  insert into public.audit_log (clinic_id, user_id, action, entity, entity_id, patient_id)
  values (c, auth.uid(), 'read', entity, entity_id, patient_id);
end
$fn$;


-- ============================================================================
--  SECTION 10 — Privileges: revoke the default, grant the minimum
--
--  New functions in PostgreSQL are EXECUTABLE BY PUBLIC unless revoked. An
--  anon-key holder is `anon`; without these revokes every function above would
--  be callable without signing in. The helpers are SECURITY DEFINER, so that
--  would be a serious hole: `patient_read` in particular would return data if a
--  policy were ever mis-scoped.
--
--  Grants are limited to `authenticated`. `anon` gets nothing.
-- ============================================================================

do $priv$
declare
  fn text;
  -- Functions the signed-in client must be able to call or that RLS policies
  -- must be able to evaluate.
  client_fns text[] := array[
    'public.my_clinics()',
    'public.my_owned_clinics()',
    'public.my_role_in(uuid)',
    'public.is_member_of(uuid)',
    'public.can_read(uuid)',
    'public.can_write_clinical(uuid)',
    'public.can_write_decisions(uuid)',
    'public.can_manage(uuid)',
    'public.safe_uuid(text)',
    'public.my_memberships()',
    'public.patient_read(text)',
    'public.log_access(text, text, text)',
    'public.bootstrap_clinic(text)',
    'public.add_clinic_member(uuid, text, text)',
    'public.add_clinic_member(text, text)',
    'public.remove_clinic_member(uuid, text)'
  ];
  -- Trigger functions. Invoked by the trigger machinery, never by a client.
  trigger_fns text[] := array[
    'public.audit_trigger()',
    'public.touch_updated_at()'
  ];
begin
  foreach fn in array client_fns loop
    execute format('revoke all on function %s from public', fn);
    execute format('revoke all on function %s from anon', fn);
    execute format('grant execute on function %s to authenticated', fn);
  end loop;

  foreach fn in array trigger_fns loop
    execute format('revoke all on function %s from public', fn);
    execute format('revoke all on function %s from anon', fn);
    execute format('revoke all on function %s from authenticated', fn);
    -- Trigger invocation is governed by trigger creation, not the caller's
    -- EXECUTE privilege, so clients do not need a direct grant.
  end loop;
end
$priv$;

-- Remove residual object-level grants on the objects managed by this script.
-- RLS does not replace SQL privileges: a role needs both a table grant and a
-- permitting policy. The audit sequence is used only inside the definer trigger.
revoke all on public.clinics, public.clinic_members, public.patients,
  public.measurements, public.labs, public.assessments, public.plans,
  public.followups, public.attachments, public.recipes, public.kb, public.audit_log
  from public, anon, authenticated;
do $sequence_privileges$
begin
  if to_regclass('public.audit_log_id_seq') is not null then
    execute 'revoke all on sequence public.audit_log_id_seq from public, anon, authenticated';
  end if;
end
$sequence_privileges$;
grant usage on schema public to authenticated;
grant select on public.clinics, public.clinic_members, public.audit_log to authenticated;
grant update on public.clinic_members to authenticated;
grant select, insert, update, delete on public.patients, public.measurements,
  public.labs, public.assessments, public.plans, public.followups,
  public.attachments, public.recipes, public.kb to authenticated;
revoke all on schema public from anon;

-- Superseded revision-1 helper. It returned an unscoped role and must not
-- survive, because a policy using it can be satisfied using authority from an
-- unrelated clinic.
drop function if exists public.my_role();


-- ============================================================================
--  SECTION 11 — Verification
--
--  Run these after the script. Expected results are stated; anything else means
--  the hardening did not apply.
-- ============================================================================

-- 11.1 Every public table must have RLS enabled. EXPECT: zero rows.
--      A row here is a table that is readable by anyone holding the anon key.
--
--   select c.relname
--   from pg_class c
--   join pg_namespace n on n.oid = c.relnamespace
--   where n.nspname = 'public'
--     and c.relkind = 'r'
--     and c.relrowsecurity = false;

-- 11.2 The revision-1 blanket policy must be gone. EXPECT: zero rows.
--
--   select tablename, policyname from pg_policies
--   where schemaname = 'public' and policyname like '%_clinic_rw';

-- 11.3 Every clinical table must have all four command policies. EXPECT: 36 rows
--      (9 tables x 4 commands), with no gaps in the pattern.
--
--   select tablename, cmd from pg_policies
--   where schemaname = 'public'
--     and tablename in ('patients','measurements','labs','assessments','plans',
--                       'followups','attachments','recipes','kb')
--   order by tablename, cmd;

-- 11.4 No function executable by anon. EXPECT: zero rows.
--
--   select p.proname
--   from pg_proc p join pg_namespace n on n.oid = p.pronamespace
--   where n.nspname = 'public'
--     and has_function_privilege('anon', p.oid, 'execute');

-- 11.5 No table grant to anon. EXPECT: zero rows.
--
--   select table_name, privilege_type
--   from information_schema.role_table_grants
--   where grantee = 'anon' and table_schema = 'public';

-- 11.6 The private bucket must be private. EXPECT: public = false.
--
--   select id, public from storage.buckets where id = 'clinical-documents';

-- For behavioural tests — every role, and cross-clinic isolation — run
--   docs/supabase-security-tests.sql
-- which asserts each expectation and rolls itself back.


-- ============================================================================
--  SECTION 12 — Migration for an EXISTING project
-- ============================================================================
--
--  This file is safe to re-run: it creates nothing twice, drops only policies,
--  triggers and one superseded function, and never touches a row. On a project
--  already carrying clinical data the recommended sequence is:
--
--   1. BACK UP FIRST. Supabase dashboard → Database → Backups. Do not rely on
--      this script being reversible; RLS changes are not data changes, but a
--      backup is the only way to undo a mistake.
--
--   2. Read section 1. The only removals are policies, triggers and the
--      revision-1 `my_role()` function. No table and no row is dropped.
--
--   3. Run the script in a TRANSACTION first, and roll it back, to see it apply
--      cleanly against your real schema:
--
--        begin;
--        -- paste the contents of this file here, from section 2 onward
--        rollback;
--
--      A failure inside will abort the transaction and leave nothing changed.
--
--   4. Then run it for real.
--
--   5. Run section 11's verification queries. 11.1 and 11.2 must both return
--      zero rows — those two catch the most damaging outcomes: a table without
--      RLS, and the old blanket policy still granting an auditor write access.
--
--   6. Run docs/supabase-security-tests.sql to prove the role behaviour.
--
--   7. Existing rows are unaffected, BUT note the access change: if the project
--      previously relied on the blanket policy, an auditor or assistant who
--      could write before will now receive a policy violation. That is the
--      intended outcome, and it will be visible as a 403/42501 error rather
--      than silent data loss.
--
--  ROLLING BACK
--    RLS policy changes are reversible by restoring the previous policy
--    definitions; there is no data to restore. If you need the revision-1
--    behaviour back, replace the four per-command policies on a table with a
--    single policy:
--
--      drop policy if exists patients_read on public.patients;
--      -- ... for each of _read/_insert/_update/_delete ...
--      create policy patients_clinic_rw on public.patients for all to authenticated
--        using (clinic_id in (select public.my_clinics()))
--        with check (clinic_id in (select public.my_clinics()));
--
--    That restores the revision-1 behaviour, including its weakness. It is
--    documented here so the choice is explicit, not so it is recommended.


-- ============================================================================
--  SECTION 13 — Known limits, stated plainly
-- ============================================================================
--
--  * service_role and the table owner bypass RLS by design. This schema does not
--    use FORCE ROW LEVEL SECURITY, because forcing it would also restrict
--    administrative operations performed from the dashboard. Anyone holding the
--    service_role key can read and write everything; that key must never leave
--    the server.
--
--  * Read auditing is guaranteed only for the patient_read() path. Lists and
--    searches are ordinary REST selects and are not audited (see
--    docs/TEST-AND-DEPLOY.md §4). Closing that gap means routing all reads
--    through server functions.
--
--  * bootstrap_clinic() checks then inserts without a lock, so two simultaneous
--    first requests from the same new account could in principle create two
--    clinics. Low likelihood, and recoverable by an administrator.
--
--  * add_clinic_member() and remove_clinic_member() reveal whether an email
--    address has a registered account. Only owners can call them.
--
--  * Deleting a clinic cascades to its members and clinical rows. Storage
--    objects are NOT removed by that cascade — clear the bucket path separately.
--
--  * An owner can grant themselves nothing they do not already have, but an
--    owner CAN promote another member to owner. That is intended; it is the
--    escape hatch when the original owner leaves.
-- ============================================================================
