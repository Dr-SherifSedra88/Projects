# Supabase Hardening — Revision 2 change list

**Date:** 2026-10-16
**Applies to:** `docs/supabase-schema.sql` (revision 2), superseding revision 1.

---

## 0. What to execute, and in what order

| Step | Action |
|---|---|
| 1 | **Back up first.** Supabase → Database → Backups. RLS changes are not data changes, but a backup is the only way to undo a mistake. |
| 2 | Run `docs/supabase-schema.sql` in the SQL editor. It is safe to re-run and touches no data. |
| 3 | Run the verification queries in **section 11** of that file. Queries 11.1 and 11.2 must both return **zero rows**. |
| 4 | Run `docs/supabase-security-tests.sql`. It asserts every role and cross-clinic isolation, then rolls itself back. |
| 5 | Only then test the application against the backend. |

**Nothing in the schema file deletes rows or drops tables.** The complete inventory of
destructive-looking statements is in section 1 of that file; every one of them removes a policy, a
trigger, or one superseded function.

---

## 1. Destructive operations — the exact list

| Statement | Removes | Data at risk |
|---|---|---|
| `drop policy if exists <t>_read / _insert / _update / _delete` | the four per-command policies on table `<t>` | none |
| `drop policy if exists <t>_clinic_rw` | **the revision-1 blanket policy** | none |
| `drop policy if exists members_owner_insert / _delete` | policies that never existed | none |
| `drop trigger if exists <t>_audit / _touch` | two triggers, immediately recreated | none |
| `drop policy if exists "clinical documents …"` | 4 storage policies, immediately recreated | none |
| `drop policy if exists "clinic members … documents"` | 4 superseded revision-1 storage policies | none |
| `drop function if exists public.my_role()` | the revision-1 helper that returned an unscoped role | none |

**Why the blanket policy must be dropped:** PostgreSQL OR-combines multiple permissive policies for
the same command. Leaving `_clinic_rw` in place would OR with the new least-privilege policies and
grant everything to everyone — an auditor would still be able to write. Dropping it is the whole
point of this revision, not a side effect.

**Repeatability:** `create table if not exists`, `create index if not exists`,
`create or replace function`, `drop … if exists` before every `create`, and the storage bucket insert
uses `on conflict do nothing`. Re-running produces an identical result.

**Migration for an existing project:** section 12 of the schema file documents the sequence — back up,
read section 1, rehearse inside `begin; … rollback;`, then run for real, then verify. It also states
the one behavioural change to expect: a role that could write under revision 1 will now receive a
policy violation (SQLSTATE 42501), which is the intended outcome and is loud rather than silent.

---

## 2. Roles — explicit least privilege

Every capability helper is **clinic-scoped**. `my_role_in(clinic_id)` answers "what is this caller in
*this* clinic", never "what is this caller somewhere".

| Capability | owner | clinician | assistant | auditor |
|---|---|---|---|---|
| Read clinical tables | yes | yes | yes | **yes** |
| Insert/update day-to-day records (measurements, labs, follow-ups, attachments, recipes, knowledge base) | yes | yes | **yes** | **no** |
| Insert/update patients (registration) | yes | yes | yes | **no** |
| Insert/update assessments and plans (clinical decisions) | yes | yes | **no** | **no** |
| Delete a clinical record | yes | yes | **no** | **no** |
| Delete a whole patient record | **yes** | **no** | **no** | **no** |
| Change membership | **yes** | **no** | **no** | **no** |
| Upload / replace a document | yes | yes | yes | **no** |
| Delete a document | yes | yes | **no** | **no** |
| Read the audit log | yes | yes | yes | yes |
| Write an audit entry | trigger only | trigger only | trigger only | trigger only |

Implemented as four policies per table (`_read`, `_insert`, `_update`, `_delete`) created from a
per-table configuration table, so the intended authority for each table is readable in one place
rather than inferred from a dozen files.

An auditor therefore cannot insert, update or delete **anything**, in any table, including
attachments and storage objects.

---

## 3. Membership — the `LIMIT 1` defect

**The defect.** Revision 1's membership policy was `using (public.my_role() = 'owner')`, where
`my_role()` was `select role from clinic_members where user_id = auth.uid() limit 1`. There was no
ordering and no reference to the row being guarded. For a user in two clinics the result was
nondeterministic, and an owner of clinic B who merely *belonged* to clinic A could modify clinic A's
membership rows — including promoting themselves.

**The fix, in three parts.**

1. `my_role()` is deleted outright, with a comment explaining why a scalar role helper must not
   return. `my_owned_clinics()` returns a **set**.
2. The policy is now row-scoped: `using (clinic_id in (select public.my_owned_clinics()))`.
3. `add_clinic_member` and `remove_clinic_member` take an **explicit `target_clinic_id`** and verify
   the caller owns **that exact clinic**. Omitting the id is an error, not a guess.

**The last-owner guard.** Neither function will demote or remove the final owner of a clinic, which
would otherwise leave records nobody can administer.

**The compatibility overload.** The shipped client calls the two-argument form
(`member_email`, `member_role`). Changing the signature would have broken invitations with
*"A clinic id is required"*. A second overload keeps that call working and answers the ambiguous
question safely:

| Caller owns | Outcome |
|---|---|
| exactly one clinic | acts on it |
| none | refuses |
| **more than one** | **refuses, and names the explicit form to use** |

So the ambiguous case can never be resolved arbitrarily — it is refused.

**Client side — and here I must be straight.** `site/js/backend.js` still contains
`rest('clinic_members?select=clinic_id,role&limit=1')`. That is the same arbitrary-choice flaw on the
client. **I could not fix it: the workspace write guard blocks every write to that file**, on a false
positive it reports as a credential-shaped literal named `token`. The file contains no credential —
only Supabase's own field names (`access_token`, `refresh_token`) and a `SESSION_KEY` constant. The
guard's own guidance is to tell you rather than work around it, so I have not renamed anything to slip
past it. The exact replacement is in §7 below for you to paste, and three protections limit the
exposure in the meantime:

- `bootstrap_clinic` creates a **first** clinic only, refusing an account that already belongs to one.
- The two-argument `add_clinic_member` **refuses** when the caller owns several clinics.
- Every RPC and policy is clinic-explicit, so a wrong pick can only mean "the wrong one of *your own*
  clinics" — never another clinic's data.

The practical consequence: through the current client, an account cannot end up in two clinics at all,
so `limit=1` is unambiguous. It becomes a real problem only if someone is added to a second clinic
directly through SQL or the dashboard — which is why the patch in §7 should be applied before
multi-clinic use.

---

## 4. `SECURITY DEFINER` functions — privileges, ownership, search path

| Function | Definer? | `search_path` pinned | EXECUTE granted to |
|---|---|---|---|
| `my_clinics`, `my_owned_clinics`, `my_role_in`, `is_member_of` | yes | `public, pg_temp` | `authenticated` |
| `can_read`, `can_write_clinical`, `can_write_decisions`, `can_manage` | yes | `public, pg_temp` | `authenticated` |
| `safe_uuid` | no (plain immutable) | n/a | `authenticated` |
| `my_memberships`, `patient_read`, `log_access` | yes | `public, pg_temp` | `authenticated` |
| `bootstrap_clinic`, `add_clinic_member` (both forms), `remove_clinic_member` | yes | `public, pg_temp` | `authenticated` |
| `audit_trigger`, `touch_updated_at` | definer / plain | `public, pg_temp` | see note |

**Default privileges revoked.** Every function above is revoked from `PUBLIC` and from `anon`, then
granted only to `authenticated`. Without this, PostgreSQL's default `EXECUTE TO PUBLIC` would let an
anonymous request call `patient_read` — a `SECURITY DEFINER` function that bypasses RLS. That was a
genuine hole in revision 1 and is the single most important change in this file.

`revoke all on schema public from anon` is also applied.

**Trigger functions — a deliberate, flagged choice.** `audit_trigger` and `touch_updated_at` keep
`EXECUTE` for `authenticated`. PostgreSQL does not re-check `EXECUTE` when a trigger fires, and a
function returning `trigger` cannot be called directly, so withholding it would add no safety — but
since I cannot execute this script, I left it rather than change it blind. After verifying that writes
still audit correctly you can tighten it:

```sql
revoke all on function public.audit_trigger() from authenticated;
revoke all on function public.touch_updated_at() from authenticated;
```

**Ownership.** All objects should be owned by `postgres` (the role the SQL editor runs as). If any
function is owned by an application role, that role can redefine it. Verify with:

```sql
select p.proname, pg_get_userbyid(p.proowner) as owner
from pg_proc p join pg_namespace n on n.oid = p.pronamespace
where n.nspname = 'public' and p.proname in ('patient_read','my_clinics','can_read');
```

Expected owner: `postgres`.

---

## 5. RLS coverage

| Object | RLS | Policies |
|---|---|---|
| `clinics` | enabled | select (members) |
| `clinic_members` | enabled | select (self or members), update (owner of that clinic). **No insert, no delete** — denied outright; membership changes only via RPC |
| `patients`, `measurements`, `labs`, `assessments`, `plans`, `followups`, `attachments`, `recipes`, `kb` | enabled | 4 each (read/insert/update/delete), role-aware |
| `audit_log` | enabled | select only. **No insert policy** — entries come from the trigger, so a client cannot forge one |
| `storage.objects` (bucket `clinical-documents`) | bucket is private | read (any member), insert/update (can_write_clinical), delete (can_write_decisions) |

**Clinic A cannot reach clinic B**, by four separate mechanisms: the `using` clause on every read, the
`with check` on every write, the storage path prefix check, and the `SECURITY DEFINER` helpers being
clinic-explicit. `patient_read` returns `null` for a foreign patient — indistinguishable from "not
found", so it does not confirm the existence of another clinic's record either.

**Row reassignment is blocked.** No policy narrows the columns an UPDATE may change, so a client could
try to rewrite `clinic_id`. The `with check` clause re-evaluates the capability for the *new* value,
and the caller has no authority in the target clinic, so the update is refused.

**What is *not* protected, by design:** `service_role` and the table owner bypass RLS. This schema
does not use `FORCE ROW LEVEL SECURITY`, because forcing it would also restrict dashboard
administration. Anyone holding the `service_role` key reads and writes everything. That key must never
leave the server.

---

## 6. Read paths — which reads are audited, and which are not

PostgreSQL has **no SELECT trigger**, so a read cannot be audited by the database. Auditing requires
wrapping the read in a function. Starting from that constraint, here is the complete inventory:

| # | Read path | Location | Audited? |
|---|---|---|---|
| 1 | Opening a patient record (`patient_read` RPC) | `app.js` → `setPatient` | **YES — server-guaranteed** |
| 2 | Restoring the last patient on page load | `app.js` → `restorePatient` | **No** |
| 3 | Patient picker list | `app.js` → `openPatientPicker` | **No** |
| 4 | Dashboard patient list and counts | `views-core.js` (Dashboard) | **No** |
| 5 | Patients module list and search | `views-core.js` (Patients) | **No** |
| 6 | Patient edit form load | `views-core.js` → `openEditor` | **No** |
| 7 | Next-patient-code computation | `views-core.js` (New patient save) | **No** |
| 8 | All clinical reads by patient — measurements, labs, assessments, plans, follow-ups | `store.byPatient(...)` across the clinical, planning and library views | **No** |

**So: exactly one read path is guaranteed, and eight are not.** Path 1 covers the moment a clinician
opens a record, which is the event an inspection most often asks about. Paths 3–8 are lists and
lookups; auditing each would flood the log with thousands of aggregate reads.

**To close the gap** you would route *all* clinical reads through server functions — one per entity, or
a single `clinic_read(entity, filters)` — so no data can be fetched outside an audited path. That is a
deliberate architectural step with a real cost (an RPC per list view). If non-repudiable read auditing
is an inspection requirement, it is the correct answer, and it is worth doing before go-live rather
than retrofitting.

**Already non-repudiable:** every INSERT, UPDATE and DELETE on the nine clinical tables is logged by
database trigger. The audit table has no INSERT policy, so clients cannot forge or amend entries.

---

## 7. The client patch I could not apply

Paste this into `site/js/backend.js`, replacing the existing `clinic()` function (around line 225) and
the `inviteMember` function (around line 245). Add the constant next to `SESSION_KEY`.

```js
// Add beside SESSION_KEY:
var CLINIC_CHOICE_KEY = 'cn.backend.clinicId';

// Replace the existing clinic() with:
function clinic() {
  if (clinicCache) return Promise.resolve(clinicCache);
  return rpc('my_memberships', {}).then(function (rows) {
    var list = rows || [];
    if (!list.length) {
      var e = new Error('This account is not a member of a clinic yet.');
      e.code = 'no_clinic';
      throw e;
    }
    var chosen = null;
    try { chosen = localStorage.getItem(CLINIC_CHOICE_KEY); } catch (err) { /* ignore */ }
    var match = chosen ? list.filter(function (m) { return m.clinic_id === chosen; })[0] : null;
    if (!match && list.length === 1) match = list[0];
    if (!match) {
      var e2 = new Error('Choose which clinic to work in — this account belongs to ' +
        list.length + ' clinics.');
      e2.code = 'clinic_choice_required';
      e2.memberships = list;
      throw e2;
    }
    clinicCache = { id: match.clinic_id, role: match.role,
                    name: match.clinic_name, memberships: list };
    var s = loadSession();
    if (s && s.role !== clinicCache.role) { s.role = clinicCache.role; session = s; saveSession(); }
    return clinicCache;
  });
}

// Replace the existing inviteMember() with:
function inviteMember(clinicId, email, role) {
  return rpc('add_clinic_member', {
    target_clinic_id: clinicId,
    member_email: email,
    member_role: role || 'clinician'
  });
}
```

Also add `memberships: memberships,` and `chooseClinic: chooseClinic,` to the `CN.backend` export
object, and add a clinic picker to Settings → Server backend that appears when
`clinic_choice_required` is raised.

**Why this is not applied:** the write guard rejects every edit to `backend.js` as a suspected
credential (`token`). The file holds none. Per the guard's own instruction I am reporting it rather
than renaming identifiers to evade the check. If you would rather I apply it, either approve the write
or tell me to move that function into a separate file.

---

## 8. Security tests

`docs/supabase-security-tests.sql` — run in the SQL editor. It:

- creates two synthetic clinics, five synthetic users and a patient in each clinic;
- impersonates each role by setting `request.jwt.claims`, exactly as the API layer does;
- asserts read visibility, write authority, silent-update refusal, insert refusal, membership
  refusal, cross-clinic invisibility, `patient_read` returning `null` for a foreign patient, that a
  refused read writes no audit entry, that the last owner cannot be demoted, and that `anon` gets
  nothing;
- **rolls itself back**, so no synthetic user, clinic or patient survives.

A refused UPDATE or DELETE returns **zero rows** rather than raising — RLS does not error when the
`using` clause simply hides rows, because an error would leak their existence. The tests therefore
assert both shapes: an exception where one is expected, an unchanged row count where the refusal is
silent. Reading the results depends on knowing that.

Expected output: a series of `PASS` notices ending in `ALL SECURITY TESTS PASSED`.

**Not covered by that file** (needs an HTTP client, not SQL): storage object policies, session expiry
and token refresh. Manual procedures for both are in `docs/TEST-AND-DEPLOY.md` §3.

---

## 9. Residual risks — stated, not hidden

| # | Risk | Status |
|---|---|---|
| 1 | Client picks a clinic with `limit=1` | **Open.** Mitigated to "wrong one of your own clinics" by server-side refusals; patch in §7 |
| 2 | Eight read paths are unaudited | **Open by design.** Fix is to route all reads through functions; see §6 |
| 3 | `service_role` bypasses all policies | **By design.** Never ship that key |
| 4 | `bootstrap_clinic` can race with itself, creating two clinics for one account | **Accepted, low.** Add a unique constraint if it matters |
| 5 | Membership RPCs reveal whether an email has an account | **Accepted.** Owner-only |
| 6 | `add_clinic_member`'s two-argument form is retained | **Deliberate**, so the shipped client keeps working. Remove it once the client passes an explicit clinic |
| 7 | Deleting a clinic cascades to rows but not to storage objects | **Documented** |
| 8 | No-execute environment: none of this has been run | **Open.** §0 is the order to run it |

**Not production-ready** until §0 steps 3, 4 and 5 have run and their results recorded.
