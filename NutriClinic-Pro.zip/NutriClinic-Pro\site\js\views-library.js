/* ==========================================================================
   NutriClinic Pro — views-library.js
   Food Database and Clinical References.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;
  var ui = CN.ui;

  var fdState = { q: '', category: '', egyptian: false, exchange: false, open: null };

  /* ========================================================== FOOD DATABASE  */
  var Foods = {
    title: 'nav.foods',

    render(host, ctx) {
      host.innerHTML = ui.pageHead('fd.title', 'fd.subtitle');

      var cats = [{ value: '', label: CN.t('common.all') }].concat(
        CN.foods.categories.map(function (c) {
          return { value: c.key, label: CN.i18n.lang === 'ar' ? c.ar : c.en };
        }));

      host.innerHTML += '<div class="card"><div class="row mb1">' +
        '<input type="search" id="fd-q" placeholder="' + U.esc(CN.t('fd.search')) +
          '" value="' + U.esc(fdState.q) + '" style="max-width:360px"/>' +
        '<select id="fd-cat" style="max-width:190px">' + CN.options(cats, fdState.category) + '</select>' +
        '<label class="check" style="margin:0"><input type="checkbox" id="fd-eg"' +
          (fdState.egyptian ? ' checked' : '') + '/> <span>' + U.esc(CN.t('fd.egyptian')) + '</span></label>' +
        '<label class="check" style="margin:0"><input type="checkbox" id="fd-ex"' +
          (fdState.exchange ? ' checked' : '') + '/> <span>' + U.esc(CN.t('fd.exchange')) + '</span></label>' +
        '<div class="grow"></div><span class="muted" id="fd-count"></span></div>' +
        '<div id="fd-table"></div></div>';

      function draw() {
        var rows = CN.foods.search(fdState.q, {
          category: fdState.category || null,
          egyptianOnly: fdState.egyptian
        });
        var countEl = U.$('#fd-count');
        if (countEl) countEl.textContent = CN.t('fd.count', { n: rows.length });

        var wrap = U.$('#fd-table');
        if (!wrap) return;
        if (!rows.length) { wrap.innerHTML = CN.empty(CN.t('fd.none'), CN.t('fd.noneMsg')); return; }

        var lang = CN.i18n.lang;
        var head = fdState.exchange
          ? '<th>' + U.esc(CN.t('fd.title')) + '</th><th class="num">' + U.esc(CN.t('fd.exchange')) +
            '</th><th class="num">' + U.esc(CN.t('fd.protein')) + '</th><th class="num">' +
            U.esc(CN.t('fd.carb')) + '</th><th class="num">' + U.esc(CN.t('fd.fat')) + '</th><th></th>'
          : '<th>' + U.esc(CN.t('fd.title')) + '</th><th>' + U.esc(CN.t('fd.category')) +
            '</th><th class="num">' + U.esc(CN.t('fd.kcal100')) + '</th><th class="num">' +
            U.esc(CN.t('fd.protein')) + '</th><th class="num">' + U.esc(CN.t('fd.carb')) +
            '</th><th class="num">' + U.esc(CN.t('fd.fat')) + '</th><th class="num">' +
            U.esc(CN.t('fd.fiber')) + '</th><th class="num">' + U.esc(CN.t('fd.sodium')) +
            '</th><th>' + U.esc(CN.t('fd.allergens')) + '</th><th></th>';

        wrap.innerHTML = '<div class="table-wrap"><table class="tbl compact"><thead><tr>' + head +
          '</tr></thead><tbody>' +
          rows.map(function (f) {
            var name = lang === 'ar' ? (f.nameAr || f.nameEn) : f.nameEn;
            var alt = lang === 'ar' ? f.nameEn : (f.nameAr || '');
            var exGrams = CN.foods.gramsForKcal(f, 100);
            var ex = CN.foods.nutrientsFor(f, exGrams);

            var cells = fdState.exchange
              ? '<td><strong>' + U.esc(name) + '</strong>' +
                  (f.needsVerify ? ' <span class="chip gold" style="font-size:.68rem">' +
                    U.esc(CN.t('fd.verify')) + '</span>' : '') + '</td>' +
                '<td class="num">' + U.nf(exGrams, 0) + ' g</td>' +
                '<td class="num">' + U.nf(ex.protein, 1) + ' g</td>' +
                '<td class="num">' + U.nf(ex.carb, 1) + ' g</td>' +
                '<td class="num">' + U.nf(ex.fat, 1) + ' g</td>'
              : '<td><strong>' + U.esc(name) + '</strong>' +
                  (alt ? '<div class="muted" style="font-size:.76rem">' + U.esc(alt) + '</div>' : '') +
                  (f.needsVerify ? ' <span class="chip gold" style="font-size:.68rem">' +
                    U.esc(CN.t('fd.verify')) + '</span>' : '') + '</td>' +
                '<td>' + U.esc(CN.foods.categoryLabel(f.category)) + '</td>' +
                '<td class="num">' + U.nf(f.kcal, 0) + '</td>' +
                '<td class="num">' + U.nf(f.protein, 1) + '</td>' +
                '<td class="num">' + U.nf(f.carb, 1) + '</td>' +
                '<td class="num">' + U.nf(f.fat, 1) + '</td>' +
                '<td class="num">' + U.nf(f.fiber, 1) + '</td>' +
                '<td class="num">' + U.nf(f.sodium, 0) + '</td>' +
                '<td>' + (f.allergens.length
                  ? '<div class="chip-row">' + f.allergens.map(function (a) {
                      return '<span class="chip" style="font-size:.7rem">' +
                        U.esc(CN.foods.allergenLabel(a, lang)) + '</span>';
                    }).join('') + '</div>'
                  : '<span class="muted">—</span>') + '</td>';

            var detail = '';
            if (fdState.open === f.id) {
              detail = '<tr><td colspan="' + (fdState.exchange ? 6 : 10) + '" style="background:#F8FAFD">' +
                '<div class="grid cols-2"><div>' +
                '<h4>' + U.esc(CN.t('fd.portions')) + '</h4>' +
                '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
                '<th>' + U.esc(CN.t('fd.measure')) + '</th><th class="num">' + U.esc(CN.t('fd.grams')) +
                '</th><th>' + U.esc(CN.t('fd.assumption')) + '</th></tr></thead><tbody>' +
                f.portions.map(function (p) {
                  return '<tr><td>' + U.esc(lang === 'ar' ? (p.measureAr || p.measure) : p.measure) +
                    '</td><td class="num">' + U.nf(p.grams, 0) + ' g</td>' +
                    '<td class="muted" style="font-size:.78rem">' + U.esc(p.assumptionNote) + '</td></tr>';
                }).join('') + '</tbody></table></div></div>' +
                '<div><h4>' + U.esc(CN.t('fd.exchange')) + '</h4>' +
                '<p>' + U.nf(exGrams, 0) + ' g = <strong>100 kcal</strong></p>' +
                U.kv([
                  { k: CN.t('fd.protein'), v: U.nf(ex.protein, 1) + ' g' },
                  { k: CN.t('fd.carb'), v: U.nf(ex.carb, 1) + ' g' },
                  { k: CN.t('fd.fat'), v: U.nf(ex.fat, 1) + ' g' },
                  { k: CN.t('fd.source'), v: f.source }
                ]) + '</div></div></td></tr>';
            }

            return '<tr class="row-click" data-open="' + U.esc(f.id) + '">' + cells +
              '<td class="right">' + CN.icon(fdState.open === f.id ? 'chevron-down' : 'chevron-right', 13) +
              '</td></tr>' + detail;
          }).join('') + '</tbody></table></div>';
      }

      U.on(host, 'input', '#fd-q', U.debounce(function (e, el) { fdState.q = el.value; draw(); }, 180));
      U.on(host, 'change', '#fd-cat', function (e, el) { fdState.category = el.value; draw(); });
      U.on(host, 'change', '#fd-eg', function (e, el) { fdState.egyptian = el.checked; draw(); });
      U.on(host, 'change', '#fd-ex', function (e, el) { fdState.exchange = el.checked; draw(); });
      U.on(host, 'click', '[data-open]', function (e, el) {
        var id = el.getAttribute('data-open');
        fdState.open = (fdState.open === id) ? null : id;
        draw();
      });

      draw();

      /* ------------------------------------------------ §12 custom recipes --
         Nutrition is derived from the ingredient list, the quantities and the
         finished yield. Nothing is entered by hand, so the figure cannot
         silently disagree with the ingredients. */
      host.innerHTML += '<section class="card"><div class="card-head">' +
        '<h3>' + U.esc(CN.t('rc.title')) + '</h3><div class="grow"></div>' +
        '<button class="btn btn-sm" id="rc-new">' + CN.icon('plus', 14) + ' ' +
          U.esc(CN.t('rc.new')) + '</button></div>' +
        '<div id="rc-list"><span class="muted">' + U.esc(CN.t('boot.loading')) + '</span></div>' +
        '</section>';

      function drawRecipes() {
        CN.store.all('recipes').then(function (recipes) {
          var el = U.$('#rc-list');
          if (!el) return;
          if (!recipes.length) {
            el.innerHTML = CN.empty(CN.t('rc.none'), CN.t('rc.noneMsg'),
              '<button class="btn btn-primary" data-rc-new="1">' + U.esc(CN.t('rc.new')) +
              '</button>');
            return;
          }
          el.innerHTML = '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
            '<th>' + U.esc(CN.t('rc.name')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('rc.servings')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('rc.perServing')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('fd.protein')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('fd.carb')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('fd.fat')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('rc.servingG')) + '</th>' +
            '<th></th></tr></thead><tbody>' +
            recipes.map(function (r) {
              var n = CN.planner.recipeNutrition(r);
              var lang = CN.i18n.lang;
              return '<tr><td><strong>' + U.esc(lang === 'ar'
                  ? (r.nameAr || r.nameEn) : r.nameEn) + '</strong>' +
                '<div class="muted" style="font-size:.75rem">' +
                  (r.items || []).length + ' ' + U.esc(CN.t('rc.ingredients')) +
                  (n.missingFoodIds.length ? ' · ' + U.esc(CN.t('fd.verify')) : '') + '</div></td>' +
                '<td class="num">' + U.nf(n.servings, 1) + '</td>' +
                '<td class="num"><strong>' + U.nf(n.perServing.kcal, 0) + '</strong></td>' +
                '<td class="num">' + U.nf(n.perServing.protein, 1) + '</td>' +
                '<td class="num">' + U.nf(n.perServing.carb, 1) + '</td>' +
                '<td class="num">' + U.nf(n.perServing.fat, 1) + '</td>' +
                '<td class="num">' + (n.servingG ? U.nf(n.servingG, 0) + ' g' : '—') + '</td>' +
                '<td class="right nowrap">' +
                  '<button class="btn btn-xs" data-rc-edit="' + U.esc(r.id) + '">' +
                    CN.icon('pencil', 12) + '</button> ' +
                  '<button class="btn btn-xs" data-rc-del="' + U.esc(r.id) + '">' +
                    CN.icon('trash', 12) + '</button></td></tr>';
            }).join('') + '</tbody></table></div>' +
            '<p class="muted" style="font-size:.78rem;margin:.5rem 0 0">' +
              U.esc(CN.t('rc.yieldHint')) + '</p>';
        });
      }

      drawRecipes();

      U.on(host, 'click', '#rc-new, [data-rc-new]', function () { openRecipeEditor(null); });
      U.on(host, 'click', '[data-rc-edit]', function (e, el) {
        CN.store.get('recipes', el.getAttribute('data-rc-edit')).then(function (r) {
          openRecipeEditor(r);
        });
      });
      U.on(host, 'click', '[data-rc-del]', function (e, el) {
        CN.confirm({ title: CN.t('rc.deleteTitle'), message: CN.t('common.irreversible'),
          confirmLabel: CN.t('common.yesDelete') }).then(function (ok) {
          if (!ok) return;
          CN.store.del('recipes', el.getAttribute('data-rc-del')).then(function () {
            CN.toast(CN.t('common.saved'));
            drawRecipes();
          });
        });
      });

      // Re-draw after the editor closes, so the list reflects the saved recipe.
      CN.bus.on('recipe-saved', drawRecipes);
    }
  };

  /* ====================================================== CLINICAL REFERENCES */
  var Refs = {
    title: 'nav.references',

    render(host, ctx) {
      host.innerHTML = ui.pageHead('rf.title', 'rf.subtitle');

      var html = '';

      // Evidence hierarchy — patient-specific always outranks published sources.
      html += ui.card('rf.hierarchy',
        '<ol style="margin:0 0 .3rem 1.2rem;font-size:.88rem">' +
        CN.refs.hierarchy.map(function (h) {
          return '<li><strong>' + U.esc(h.tier) + '.</strong> ' +
            U.esc(CN.i18n.lang === 'ar' ? h.ar : h.en) +
            (h.note ? ' <span class="muted">— ' + U.esc(h.note) + '</span>' : '') + '</li>';
        }).join('') + '</ol>' +
        ui.notice(CN.t('rf.conflictNote'), 'info'));

      html += '<div class="card"><div class="row mb1">' +
        '<input type="search" id="rf-q" placeholder="' + U.esc(CN.t('rf.search')) +
          '" style="max-width:380px"/>' +
        '<div class="grow"></div>' +
        '<span class="muted">' + CN.refs.count + ' ' + U.esc(CN.t('common.rows')) + ' · ' +
          CN.refs.sourceCount() + ' ' + U.esc(CN.t('rf.source')) + '</span></div>' +
        '<div id="rf-list"></div></div>';

      html += ui.card('rf.external', ui.notice(CN.refs.externalNote, 'warn'));

      /* ------------------------------------------------- §11 knowledge base --
         Formats that can genuinely be parsed in a static build are indexed and
         searchable now. Formats that cannot say so explicitly, and the file is
         kept for reference instead of being quietly accepted. */
      html += '<section class="card" id="kb-card"><div class="card-head">' +
        '<h3>' + U.esc(CN.t('kb.title')) + '</h3><div class="grow"></div>' +
        '<span class="muted" id="kb-stats"></span></div>' +
        '<p class="muted" style="font-size:.85rem">' + U.esc(CN.t('kb.hint')) + '</p>' +
        '<div class="row tight mb1">' +
          '<label class="btn btn-sm" style="display:inline-flex;cursor:pointer">' +
            CN.icon('upload', 15) + ' ' + U.esc(CN.t('kb.add')) +
            '<input type="file" id="kb-file" style="display:none" accept="' +
              CN.kb.supportedExtensions().map(function (e) { return '.' + e; }).join(',') +
              ',' + CN.kb.deferredExtensions().map(function (e) { return '.' + e; }).join(',') +
              '"/></label>' +
          '<span class="chip">' + U.esc(CN.t('kb.indexed')) + ': ' +
            U.esc(CN.kb.supportedExtensions().join(' ')) + '</span>' +
          '<span class="chip gold">' + U.esc(CN.t('kb.needsServer')) + ': ' +
            U.esc(CN.kb.deferredExtensions().join(' ')) + '</span>' +
        '</div>' +
        '<div class="row tight mb1">' +
          '<input type="search" id="kb-q" placeholder="' + U.esc(CN.t('common.search')) +
            '" style="max-width:320px"/>' +
          '<div class="grow"></div>' +
          '<span class="muted" style="font-size:.8rem">' +
            U.esc(CN.kb.remote.configured() ? CN.t('kb.remoteOn') : CN.t('kb.remoteOff')) +
          '</span>' +
        '</div>' +
        '<div id="kb-results"></div>' +
        '<div id="kb-list"></div></section>';

      host.innerHTML += html;

      function drawKb() {
        CN.kb.stats().then(function (st) {
          var el = U.$('#kb-stats');
          if (el) el.textContent = st.documents + ' · ' + st.chunks + ' ' + CN.t('kb.passages');
        });
        CN.kb.list().then(function (docs) {
          var el = U.$('#kb-list');
          if (!el) return;
          if (!docs.length) return;
          el.innerHTML = '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
            '<th>' + U.esc(CN.t('common.name')) + '</th>' +
            '<th>' + U.esc(CN.t('common.date')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('kb.passages')) + '</th><th></th></tr></thead><tbody>' +
            docs.map(function (d) {
              return '<tr><td>' + CN.icon('file-text', 13) + ' ' + U.esc(d.title) + '</td>' +
                '<td>' + U.esc(U.fmtDate(d.addedAt)) + '</td>' +
                '<td class="num">' + U.nf(d.chunks, 0) + '</td>' +
                '<td class="right"><button class="btn btn-xs" data-kb-del="' + U.esc(d.id) + '">' +
                CN.icon('trash', 12) + '</button></td></tr>';
            }).join('') + '</tbody></table></div>';
        });
      }
      drawKb();

      function drawKbResults(q) {
        var el = U.$('#kb-results');
        if (!el) return;
        if (!q || !q.trim()) { el.innerHTML = ''; return; }
        CN.kb.search(q, 8).then(function (hits) {
          if (!hits.length) {
            el.innerHTML = '<p class="muted" style="font-size:.85rem">' +
              U.esc(CN.t('rf.none')) + '</p>';
            return;
          }
          el.innerHTML = hits.map(function (h) {
            return '<div class="notice info"><strong>' + U.esc(h.title) +
              (h.source === 'remote' ? ' · ' + U.esc(CN.t('kb.remote')) : '') +
              '</strong><br>' + U.esc(h.snippet) + '</div>';
          }).join('');
        });
      }

      U.on(host, 'input', '#kb-q', U.debounce(function (e, el) { drawKbResults(el.value); }, 200));

      U.on(host, 'change', '#kb-file', function (e, el) {
        var file = (el.files || [])[0];
        if (!file) return;
        CN.kb.ingest(file).then(function (res) {
          el.value = '';
          if (res.status === 'ingested') {
            CN.toast(CN.t('kb.ingested'));
            drawKb();
          } else if (res.status === 'deferred') {
            // Keep the document, and state plainly that its text was not read.
            CN.store.put('attachments', {
              id: U.uid('att'), patientId: null, kind: 'kb_reference',
              filename: file.name, mime: file.type || '', byteSize: file.size,
              blob: file, createdAt: new Date().toISOString()
            }).then(function () {
              CN.toast(CN.t('kb.deferredNote'), 'warn', 9000);
            });
          } else {
            CN.toast(res.reason, 'alert', 6000);
          }
        });
      });

      U.on(host, 'click', '[data-kb-del]', function (e, el) {
        CN.confirm({ title: CN.t('kb.removeTitle'), message: CN.t('common.irreversible'),
          confirmLabel: CN.t('common.yesDelete') }).then(function (ok) {
          if (!ok) return;
          CN.kb.remove(el.getAttribute('data-kb-del')).then(function () {
            CN.toast(CN.t('kb.removed'));
            drawKb();
          });
        });
      });

      function draw(q) {
        var rows = CN.refs.search(q);
        var el = U.$('#rf-list');
        var lang = CN.i18n.lang;
        if (!rows.length) { el.innerHTML = CN.empty(CN.t('rf.none'), CN.t('rf.noneMsg')); return; }

        el.innerHTML = rows.map(function (b) {
          return '<details style="border-bottom:1px solid var(--gray-line);padding:.7rem 0">' +
            '<summary style="cursor:pointer;font-weight:600;color:var(--navy)">' +
              U.esc(lang === 'ar' ? (b.titleAr || b.titleEn) : b.titleEn) +
              ' <span class="chip" style="font-size:.7rem">' +
              U.esc(CN.refs.tierLabel(b.tier, lang).split(' ').slice(0, 3).join(' ')) + '</span>' +
            '</summary>' +
            '<div style="padding:.6rem 0 .2rem 0">' +
              '<p style="font-size:.88rem">' + U.esc(b.summary) + '</p>' +
              '<h4 style="font-size:.86rem">' + U.esc(CN.t('common.details')) + '</h4>' +
              '<ul style="margin:.2rem 0 .8rem 1.1rem;font-size:.86rem">' +
                b.keyPoints.map(function (k) { return '<li>' + U.esc(k) + '</li>'; }).join('') +
              '</ul>' +
              (b.cautions && b.cautions.length
                ? '<h4 style="font-size:.86rem">' + U.esc(CN.t('cp.warnings')) + '</h4>' +
                  b.cautions.map(function (c) { return ui.notice(c, 'warn'); }).join('')
                : '') +
              (b.sources && b.sources.length
                ? '<h4 style="font-size:.86rem">' + U.esc(CN.t('rf.source')) + '</h4>' +
                  '<ul style="margin:.2rem 0 0 1.1rem;font-size:.84rem">' +
                  b.sources.map(function (s) {
                    // Inert by design: nothing is fetched until the user clicks.
                    return '<li><a href="' + U.esc(s.url) + '" target="_blank" rel="noopener noreferrer external">' +
                      U.esc(s.org) + ' — ' + U.esc(s.title) + '</a> ' +
                      '<span class="chip" style="font-size:.68rem">' +
                      U.esc(CN.i18n.lang === 'ar' ? 'غير مُتحقق منه' : 'not verified') + '</span></li>';
                  }).join('') + '</ul>'
                : '') +
              (b.approaches && b.approaches.length
                ? '<div class="chip-row" style="margin-top:.6rem">' + b.approaches.map(function (a) {
                    var ap = CN.approaches.byCode(a);
                    return ap ? ui.tag(lang === 'ar' ? ap.nameAr : ap.nameEn) : '';
                  }).join('') + '</div>'
                : '') +
            '</div></details>';
        }).join('');
      }

      U.on(host, 'input', '#rf-q', U.debounce(function (e, el) { draw(el.value); }, 180));
      draw('');
    }
  };

  /* -------------------------------------------------------- recipe editor --- */
  /**
   * Create or edit a recipe. Per-ingredient energy updates as you type, and the
   * whole-recipe and per-serving figures are derived from the ingredient list,
   * the servings and the finished yield — never typed in by hand.
   */
  function openRecipeEditor(existing) {
    var isNew = !existing;
    var model = {
      id: existing ? existing.id : null,
      nameEn: existing ? existing.nameEn : '',
      servings: existing ? existing.servings : 4,
      yieldG: existing ? existing.yieldG : '',
      method: existing ? existing.method : '',
      items: (existing && existing.items)
        ? existing.items.map(function (i) { return { foodId: i.foodId, grams: i.grams }; })
        : [{ foodId: '', grams: 100 }]
    };

    var allFoods = CN.foods.items.slice().sort(function (a, b) {
      return a.nameEn.localeCompare(b.nameEn);
    });

    function foodOptions(sel) {
      return '<option value="">—</option>' + allFoods.map(function (f) {
        return '<option value="' + U.esc(f.id) + '"' + (f.id === sel ? ' selected' : '') + '>' +
          U.esc(f.nameEn) + '</option>';
      }).join('');
    }

    function rowsHtml() {
      return model.items.map(function (it, i) {
        return '<tr data-ri="' + i + '">' +
          '<td><select data-f="foodId" style="min-width:200px">' + foodOptions(it.foodId) +
            '</select></td>' +
          '<td><input type="number" step="5" data-f="grams" value="' + U.esc(it.grams) +
            '" style="width:90px"/></td>' +
          '<td class="num" data-cell-kcal="' + i + '"></td>' +
          '<td class="right"><button type="button" class="btn btn-xs" data-rc-row-del="' + i +
            '">' + CN.icon('x', 12) + '</button></td></tr>';
      }).join('');
    }

    function harvest(node) {
      U.$$('#rc-rows tr', node).forEach(function (tr) {
        var i = Number(tr.getAttribute('data-ri'));
        if (!model.items[i]) return;
        U.$$('[data-f]', tr).forEach(function (inp) {
          var f = inp.getAttribute('data-f');
          model.items[i][f] = (f === 'grams') ? U.parseNum(inp.value) : inp.value;
        });
      });
    }

    function refresh(node) {
      model.items.forEach(function (it, i) {
        var cell = U.$('[data-cell-kcal="' + i + '"]', node);
        if (!cell) return;
        var n = CN.planner.ingredientNutrition(it.foodId, it.grams);
        cell.textContent = n ? U.nf(n.kcal, 0) + ' kcal' : '—';
      });

      var n = CN.planner.recipeNutrition(model);
      var out = U.$('#rc-nutrition', node);
      if (!out) return;
      out.innerHTML = '<div class="grid cols-3 mb1">' +
        '<div class="stat accent"><div class="stat-label">' + U.esc(CN.t('rc.perServing')) +
          '</div><div class="stat-value">' + U.nf(n.perServing.kcal, 0) + ' <small>kcal</small></div>' +
          '<div class="stat-foot">' + (n.servingG
            ? U.nf(n.servingG, 0) + ' g' : U.esc(CN.t('common.notSet'))) + '</div></div>' +
        '<div class="stat"><div class="stat-label">' + U.esc(CN.t('rc.total')) +
          '</div><div class="stat-value">' + U.nf(n.total.kcal, 0) + ' <small>kcal</small></div>' +
          '<div class="stat-foot">' + U.nf(n.servings, 1) + ' × ' + U.esc(CN.t('rc.servings')) +
          '</div></div>' +
        '<div class="stat"><div class="stat-label">' + U.esc(CN.t('en.macro')) +
          '</div><div class="stat-value" style="font-size:1rem">P ' + U.nf(n.perServing.protein, 1) +
          ' · C ' + U.nf(n.perServing.carb, 1) + ' · F ' + U.nf(n.perServing.fat, 1) + '</div>' +
          '<div class="stat-foot">' + U.esc(CN.t('rc.perServing')) + '</div></div></div>' +
        (n.missingFoodIds.length ? ui.notice(CN.t('fd.verify'), 'warn') : '');
    }

    var body = '<div class="inline-fields">' +
      '<div class="field"><label for="rc-name">' + U.esc(CN.t('rc.name')) + ' *</label>' +
        '<input id="rc-name" type="text" value="' + U.esc(model.nameEn) + '"/></div>' +
      '<div class="field"><label for="rc-servings">' + U.esc(CN.t('rc.servings')) + '</label>' +
        '<input id="rc-servings" type="number" min="1" step="1" value="' +
        U.esc(model.servings) + '"/></div>' +
      '<div class="field"><label for="rc-yield">' + U.esc(CN.t('rc.yield')) + ' (g)</label>' +
        '<input id="rc-yield" type="number" step="10" value="' + U.esc(model.yieldG) + '"/></div>' +
      '</div>' +
      '<div class="field"><label>' + U.esc(CN.t('rc.ingredients')) + '</label>' +
        '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
        '<th>' + U.esc(CN.t('fd.title')) + '</th><th>' + U.esc(CN.t('fd.grams')) + '</th>' +
        '<th class="num">' + U.esc(CN.t('common.kcal')) + '</th><th></th></tr></thead>' +
        '<tbody id="rc-rows">' + rowsHtml() + '</tbody></table></div>' +
        '<button type="button" class="btn btn-sm" id="rc-add-row" style="margin-top:.5rem">' +
          CN.icon('plus', 14) + ' ' + U.esc(CN.t('rc.addIngredient')) + '</button></div>' +
      '<div id="rc-nutrition"></div>' +
      '<div class="field"><label for="rc-method">' + U.esc(CN.t('rc.method')) + '</label>' +
        '<textarea id="rc-method">' + U.esc(model.method) + '</textarea></div>';

    var ref = CN.modal({
      title: isNew ? CN.t('rc.new') : CN.t('rc.name'),
      wide: true, body: body,
      actions: [
        { label: CN.t('common.cancel'), kind: 'ghost' },
        { label: CN.t('common.save'), kind: 'primary', close: false,
          onClick(node) {
            harvest(node);
            var name = (U.$('#rc-name', node).value || '').trim();
            if (!name) { CN.toast(CN.t('common.noData'), 'warn'); return false; }
            var items = model.items.filter(function (i) { return i.foodId && i.grams > 0; });
            if (!items.length) { CN.toast(CN.t('rc.needIngredients'), 'warn'); return false; }

            CN.store.put('recipes', {
              id: model.id || U.uid('rcp'),
              nameEn: name,
              servings: U.parseNum(U.$('#rc-servings', node).value) || 1,
              yieldG: U.parseNum(U.$('#rc-yield', node).value) || null,
              method: U.$('#rc-method', node).value,
              items: items,
              createdAt: (existing && existing.createdAt) || new Date().toISOString()
            }).then(function () {
              CN.toast(CN.t('rc.saved'));
              CN.bus.emit('recipe-saved');
              ref.close();
            });
            return false;
          } }
      ]
    });

    function redrawRows(node) {
      U.$('#rc-rows', node).innerHTML = rowsHtml();
      refresh(node);
    }

    U.on(ref.node, 'input', '#rc-rows input, #rc-rows select, #rc-servings, #rc-yield',
      U.debounce(function () {
        harvest(ref.node);
        model.servings = U.parseNum(U.$('#rc-servings', ref.node).value) || 1;
        model.yieldG = U.parseNum(U.$('#rc-yield', ref.node).value) || 0;
        refresh(ref.node);
      }, 150));

    U.on(ref.node, 'click', '#rc-add-row', function () {
      harvest(ref.node);
      model.items.push({ foodId: '', grams: 100 });
      redrawRows(ref.node);
    });

    U.on(ref.node, 'click', '[data-rc-row-del]', function (e, el) {
      harvest(ref.node);
      if (model.items.length <= 1) return;
      model.items.splice(Number(el.getAttribute('data-rc-row-del')), 1);
      redrawRows(ref.node);
    });

    refresh(ref.node);
  }

  CN.views = CN.views || {};
  CN.views.foods = Foods;
  CN.views.references = Refs;
})();
