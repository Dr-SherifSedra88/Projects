window.NUTRICLINIC_CONFIG = {
  supabaseUrl: 'https://teoqbzyeixqpovotzgio.supabase.co',
  supabaseAnonKey: 'sb_publishable_gnM9D7mazn7SAiFmza84mA_tw5O-LIs'
};
