/* ==========================================================================
   NutriClinic Pro — data-approaches.js
   The 20 therapeutic approaches, their pairwise compatibility, meal-share
   patterns and reusable plan templates.

   Macro profiles are conventional starting points for each pattern. They are
   defaults, not prescriptions: the clinician approves or overrides every
   target before a plan may be generated.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};

  /* Meal-share patterns: fractions of the daily target across eating occasions. */
  var PATTERNS = {
    '3_meals':          { key: '3_meals', meals: 3, snacks: 0, shares: [0.30, 0.40, 0.30] },
    '3_meals_1_snack':  { key: '3_meals_1_snack', meals: 3, snacks: 1, shares: [0.28, 0.10, 0.34, 0.28] },
    '3_meals_2_snacks': { key: '3_meals_2_snacks', meals: 3, snacks: 2, shares: [0.25, 0.10, 0.33, 0.10, 0.22] },
    '2_meals_if':       { key: '2_meals_if', meals: 2, snacks: 0, shares: [0.45, 0.55] },
    '3_meals_if':       { key: '3_meals_if', meals: 3, snacks: 0, shares: [0.35, 0.35, 0.30] },
    '4_meals':          { key: '4_meals', meals: 4, snacks: 0, shares: [0.25, 0.25, 0.30, 0.20] }
  };

  var MEAL_LABELS = {
    0: { en: 'Breakfast', ar: 'الإفطار' },
    1: { en: 'Morning snack', ar: 'سناك الصباح' },
    2: { en: 'Lunch', ar: 'الغداء' },
    3: { en: 'Afternoon snack', ar: 'سناك العصر' },
    4: { en: 'Dinner', ar: 'العشاء' }
  };

  /** Occasion labels are positional; snacks always follow the meal they trail. */
  function mealLabelsFor(pattern) {
    if (pattern.key === '2_meals_if') {
      return [{ en: 'First meal', ar: 'الوجبة الأولى' }, { en: 'Second meal', ar: 'الوجبة الثانية' }];
    }
    if (pattern.key === '3_meals_if') {
      return [{ en: 'First meal', ar: 'الوجبة الأولى' },
              { en: 'Second meal', ar: 'الوجبة الثانية' },
              { en: 'Third meal', ar: 'الوجبة الثالثة' }];
    }
    var seq = [];
    seq.push(MEAL_LABELS[0]);
    if (pattern.snacks >= 1) seq.push(MEAL_LABELS[1]);
    seq.push(MEAL_LABELS[2]);
    if (pattern.snacks >= 2) seq.push(MEAL_LABELS[3]);
    seq.push(MEAL_LABELS[4]);
    return seq.slice(0, pattern.shares.length);
  }

  /* ---------------------------------------------------------------------------
     The 20 approaches.

     macros        : default distribution, % of energy (protein/carb/fat)
     proteinPerKg  : when the approach governs protein by body weight instead
     sodiumMaxMg   : upper bound where the approach restricts sodium
     requires      : dietary exclusions the approach itself imposes
     contraindications: [{condition, severity: absolute|relative|caution, rationale}]
     --------------------------------------------------------------------------- */
  var APPROACHES = [
    {
      code: 'mediterranean', nameEn: 'Mediterranean Diet', nameAr: 'النظام المتوسطي',
      group: 'pattern', evidence: 'clinical_guideline',
      summary: 'Olive oil as the principal fat, abundant vegetables, legumes, whole grains, fish and nuts; limited red meat and processed foods.',
      macros: { proteinPct: 18, carbPct: 50, fatPct: 32 }, fiberMin: 25,
      guidelines: [
        'Olive oil as the main added fat; nuts and seeds most days.',
        'Fish two or more times weekly; red meat a few times monthly.',
        'Legumes at least three times weekly as a protein source.',
        'Whole grains in preference to refined; fruit as the default dessert.'
      ],
      cautions: ['Energy density is high — portion control still governs weight outcomes.'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['mediterranean_pattern', 'cardiometabolic_risk']
    },
    {
      code: 'dash', nameEn: 'DASH Diet', nameAr: 'نظام داش',
      group: 'pattern', evidence: 'clinical_guideline',
      summary: 'Blood-pressure-lowering pattern: rich in vegetables, fruit, whole grains and low-fat dairy, with sodium restriction.',
      macros: { proteinPct: 18, carbPct: 55, fatPct: 27 }, sodiumMaxMg: 2300, fiberMin: 30,
      guidelines: [
        'Four to five servings of vegetables and the same of fruit daily.',
        'Low-fat dairy two to three servings daily.',
        'Sodium reduced in steps toward 1500 mg where tolerated.',
        'Limit sweets and added sugars to fewer than five servings weekly.'
      ],
      cautions: ['Potassium load is high — review in renal impairment and on potassium-sparing diuretics.'],
      contraindications: [
        { condition: 'Chronic kidney disease with hyperkalaemia', severity: 'absolute',
          rationale: 'The DASH pattern is potassium-dense and may be unsafe when potassium is already elevated.' }
      ],
      pattern: '3_meals_2_snacks', refs: ['dash_sodium', 'hypertension']
    },
    {
      code: 'low_carb', nameEn: 'Low-Carbohydrate Diet', nameAr: 'نظام قليل الكربوهيدرات',
      group: 'macro', evidence: 'clinical_guideline',
      summary: 'Carbohydrate reduced to roughly 25% of energy, with fat and protein raised to compensate.',
      macros: { proteinPct: 30, carbPct: 25, fatPct: 45 }, fiberMin: 25,
      guidelines: [
        'Remove refined starches and free sugars first; keep fibre-rich vegetables.',
        'Maintain adequate fibre — low-carb is not low-vegetable.',
        'Review lipid profile 8–12 weeks after initiation.'
      ],
      cautions: ['Monitor for constipation, headache and transient electrolyte shifts in the first weeks.'],
      contraindications: [
        { condition: 'Pregnancy or lactation', severity: 'relative',
          rationale: 'Restricted carbohydrate in pregnancy requires specialist supervision.' },
        { condition: 'Type 1 diabetes', severity: 'relative',
          rationale: 'Requires close insulin adjustment and specialist review.' }
      ],
      pattern: '3_meals_1_snack', refs: ['carbohydrate_load', 'low_carb']
    },
    {
      code: 'low_gi', nameEn: 'Low-Glycemic-Index Diet', nameAr: 'نظام منخفض المؤشر الجلايسيمي',
      group: 'pattern', evidence: 'clinical_guideline',
      summary: 'Prioritises foods that raise blood glucose slowly, with attention to both glycemic index and glycemic load.',
      macros: { proteinPct: 20, carbPct: 45, fatPct: 35 }, fiberMin: 30,
      guidelines: [
        'Choose intact whole grains, legumes and most vegetables and fruit.',
        'Pair carbohydrate with protein or fat to blunt the glucose response.',
        'Glycemic load matters more than index alone — portion size counts.'
      ],
      cautions: ['Low-GI does not by itself imply low calorie; both still require attention.'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['glycemic_index', 'diabetes_t2']
    },
    {
      code: 'ketogenic', nameEn: 'Ketogenic Diet', nameAr: 'النظام الكيتوني',
      group: 'macro', evidence: 'clinical_guideline',
      summary: 'Very low carbohydrate (typically under 50 g/day) with high fat, inducing nutritional ketosis.',
      macros: { proteinPct: 25, carbPct: 5, fatPct: 70 }, fiberMin: 25,
      guidelines: [
        'Carbohydrate generally below 50 g/day, individualised to the patient.',
        'Protein set to requirement, not in excess — excess protein blunts ketosis.',
        'Adequate fluid and electrolytes: sodium, potassium and magnesium.',
        'Fibre must be actively maintained from low-carbohydrate vegetables.'
      ],
      cautions: [
        'Monitor for "keto flu", constipation, dyslipidaemia and nephrolithiasis risk.',
        'Not a first-line pattern for most patients; requires a defined review point.'
      ],
      contraindications: [
        { condition: 'Type 1 diabetes', severity: 'absolute',
          rationale: 'Risk of euglycaemic diabetic ketoacidosis without specialist supervision.' },
        { condition: 'Pancreatic insufficiency', severity: 'absolute',
          rationale: 'High fat load cannot be safely tolerated.' },
        { condition: 'Chronic kidney disease', severity: 'relative',
          rationale: 'High protein and acid load may accelerate decline.' },
        { condition: 'Eating disorder history', severity: 'absolute',
          rationale: 'Highly restrictive patterns are contraindicated.' },
        { condition: 'Pregnancy or lactation', severity: 'absolute',
          rationale: 'Not appropriate for the nutritional demands of pregnancy.' }
      ],
      pattern: '3_meals', refs: ['ketogenic_diet']
    },
    {
      code: 'intermittent_fasting', nameEn: 'Intermittent Fasting', nameAr: 'الصيام المتقطع',
      group: 'timing', evidence: 'clinical_guideline',
      summary: 'Energy intake confined to defined windows, most commonly 16:8 or 5:2, rather than changing the composition of the diet.',
      macros: { proteinPct: 20, carbPct: 45, fatPct: 35 }, fiberMin: 25,
      guidelines: [
        'Agree the fasting window explicitly and record it in the plan.',
        'Energy and protein targets are unchanged — only their timing moves.',
        'Water, and unsweetened tea or coffee, are permitted in the fasting window.'
      ],
      cautions: [
        'Plans must be explicit that this is not an energy-restriction method by itself.',
        'Watch for over-eating in the eating window, and for headaches and irritability early on.'
      ],
      contraindications: [
        { condition: 'Type 1 diabetes', severity: 'absolute',
          rationale: 'Hypoglycaemia risk without intensive specialist management.' },
        { condition: 'Type 2 diabetes on insulin or sulfonylureas', severity: 'relative',
          rationale: 'Requires medication review and glucose monitoring before starting.' },
        { condition: 'Pregnancy or lactation', severity: 'absolute',
          rationale: 'Fasting is inappropriate at these life stages.' },
        { condition: 'Eating disorder history', severity: 'absolute',
          rationale: 'Fasting windows can reinforce restrictive behaviour.' },
        { condition: 'Underweight or malnutrition', severity: 'absolute',
          rationale: 'Conflicts with the goal of increasing intake.' }
      ],
      pattern: '2_meals_if', refs: ['intermittent_fasting']
    },
    {
      code: 'gluten_free', nameEn: 'Gluten-Free Diet', nameAr: 'نظام خالٍ من الجلوتين',
      group: 'exclusion', evidence: 'clinical_guideline',
      summary: 'Strict exclusion of wheat, barley, rye and their derivatives. Required in coeliac disease and wheat allergy.',
      macros: { proteinPct: 18, carbPct: 50, fatPct: 32 }, fiberMin: 25,
      requires: ['gluten'],
      guidelines: [
        'Exclude wheat, barley and rye, including in sauces and processed foods.',
        'Replace lost fibre with gluten-free whole grains, legumes and vegetables.',
        'In coeliac disease adherence must be strict and lifelong, not partial.'
      ],
      cautions: [
        'Gluten-free substitute products are frequently lower in fibre and higher in refined starch.',
        'Cross-contamination must be addressed in preparation, not only in ingredients.'
      ],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['coeliac_disease']
    },
    {
      code: 'dairy_free', nameEn: 'Dairy-Free Diet', nameAr: 'نظام خالٍ من الألبان',
      group: 'exclusion', evidence: 'clinical_guideline',
      summary: 'Excludes all mammalian milk and its derivatives, as required in milk allergy.',
      macros: { proteinPct: 18, carbPct: 50, fatPct: 32 },
      requires: ['milk', 'lactose'],
      guidelines: [
        'Exclude milk, cheese, butter, ghee, cream and milk-containing baked goods.',
        'Replace calcium from fortified plant milks, calcium-set tofu, sardines or supplements.',
        'Review the label of every composite product — milk solids appear widely.'
      ],
      cautions: ['Calcium and riboflavin intakes must be actively assessed, not assumed.'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['cow_milk_allergy']
    },
    {
      code: 'lactose_free', nameEn: 'Lactose-Free Diet', nameAr: 'نظام خالٍ من اللاكتوز',
      group: 'exclusion', evidence: 'clinical_guideline',
      summary: 'Reduces or excludes lactose rather than all dairy, suited to lactose intolerance rather than milk allergy.',
      macros: { proteinPct: 18, carbPct: 50, fatPct: 32 },
      requires: ['lactose'],
      guidelines: [
        'Lactose-free milk, hard aged cheeses and lactose-reduced yoghurt are usually tolerated.',
        'Test individual tolerance — thresholds vary widely between patients.',
        'This is not the same diet as dairy-free; do not conflate the two.'
      ],
      cautions: ['Distinguish intolerance (dose-dependent) from allergy (immune-mediated, absolute).'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['lactose_intolerance']
    },
    {
      code: 'low_sodium', nameEn: 'Low-Sodium Diet', nameAr: 'نظام قليل الصوديوم',
      group: 'nutrient', evidence: 'clinical_guideline',
      summary: 'Sodium reduced, typically to 1500–2300 mg/day, for hypertension, heart failure and renal disease.',
      macros: { proteinPct: 18, carbPct: 52, fatPct: 30 }, sodiumMaxMg: 1500,
      guidelines: [
        'Target 1500–2300 mg sodium daily depending on indication.',
        'The largest contributors are bread, cheese, processed meats and pickles — not the salt shaker.',
        'Replace salt with herbs, spices, lemon and vinegar.'
      ],
      cautions: ['Sudden large reductions may be poorly tolerated; step down gradually.'],
      contraindications: [
        { condition: 'Hyponatraemia', severity: 'relative',
          rationale: 'Sodium restriction may be inappropriate when serum sodium is already low.' }
      ],
      pattern: '3_meals_1_snack', refs: ['dash_sodium', 'heart_failure']
    },
    {
      code: 'high_protein', nameEn: 'High-Protein Diet', nameAr: 'نظام عالي البروتين',
      group: 'macro', evidence: 'clinical_guideline',
      summary: 'Protein raised to 1.5–2.0 g/kg, typically for satiety, muscle preservation during weight loss, or sarcopenia.',
      macros: { proteinPct: 35, carbPct: 35, fatPct: 30 }, proteinPerKg: 1.6,
      guidelines: [
        'Set protein by body weight, not as a percentage of energy.',
        'Distribute protein across meals rather than concentrating it at one.',
        'Ensure adequate fluid and fibre alongside the higher protein load.'
      ],
      cautions: ['Long-term renal effects of sustained high protein in healthy adults remain debated; review renal function periodically.'],
      contraindications: [
        { condition: 'Chronic kidney disease without dialysis', severity: 'absolute',
          rationale: 'Protein is restricted in non-dialysed chronic kidney disease.' },
        { condition: 'Severe hepatic impairment', severity: 'absolute',
          rationale: 'Protein load may precipitate encephalopathy.' },
        { condition: 'Inborn errors of protein metabolism', severity: 'absolute',
          rationale: 'Contraindicated by the underlying metabolic defect.' }
      ],
      pattern: '3_meals_2_snacks', refs: ['protein_requirement', 'sarcopenia']
    },
    {
      code: 'low_fat', nameEn: 'Low-Fat Diet', nameAr: 'نظام قليل الدهون',
      group: 'macro', evidence: 'clinical_guideline',
      summary: 'Fat reduced to roughly 20–25% of energy, chiefly by cutting saturated and trans fat.',
      macros: { proteinPct: 19, carbPct: 58, fatPct: 23 }, fiberMin: 28,
      guidelines: [
        'Reduce saturated fat below 7% of energy where cardiovascular risk is high.',
        'Use grilling, baking and steaming rather than frying.',
        'Replace fat energy with fibre-rich carbohydrate, not refined starch.'
      ],
      cautions: ['Very low fat intakes can impair absorption of fat-soluble vitamins; monitor if prolonged.'],
      contraindications: [
        { condition: 'Fat malabsorption or pancreatic insufficiency', severity: 'relative',
          rationale: 'Requires specialist dietetic input rather than a generic low-fat template.' }
      ],
      pattern: '3_meals_1_snack', refs: ['lipid_lowering']
    },
    {
      code: 'calorie_controlled', nameEn: 'Calorie-Controlled Diet', nameAr: 'نظام محدد السعرات',
      group: 'energy', evidence: 'clinical_guideline',
      summary: 'Energy intake fixed at a clinician-approved target, with macronutrients distributed conventionally.',
      macros: { proteinPct: 20, carbPct: 45, fatPct: 35 }, fiberMin: 25,
      guidelines: [
        'The target comes from the calculation engine, never from an estimate.',
        'Weigh and record intake for the first two weeks to calibrate the patient.',
        'Review at every follow-up against observed weight trend.'
      ],
      cautions: ['Energy targets are estimates and must be adjusted against measured response.'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['energy_balance']
    },
    {
      code: 'vegetarian', nameEn: 'Vegetarian Diet', nameAr: 'نظام نباتي',
      group: 'pattern', evidence: 'clinical_guideline',
      summary: 'Excludes meat and fish; includes dairy and eggs where the patient accepts them.',
      macros: { proteinPct: 16, carbPct: 52, fatPct: 32 }, fiberMin: 30,
      guidelines: [
        'Combine plant proteins across the day to cover essential amino acids.',
        'Attend to vitamin B12, iron, zinc, iodine and omega-3.',
        'Legumes are the workhorse — plan them into most days.'
      ],
      cautions: ['Iron from plant sources is less bioavailable; pair with vitamin C.'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['plant_based_patterns', 'micronutrients']
    },
    {
      code: 'vegan', nameEn: 'Vegan Diet', nameAr: 'نظام نباتي صرف',
      group: 'pattern', evidence: 'clinical_guideline',
      summary: 'Excludes all animal-derived foods. Requires deliberate planning for B12, calcium, iron and omega-3.',
      macros: { proteinPct: 15, carbPct: 55, fatPct: 30 }, fiberMin: 32,
      requires: ['milk', 'lactose', 'egg', 'fish', 'shellfish'],
      guidelines: [
        'Vitamin B12 supplementation is mandatory, not optional.',
        'Ensure calcium from fortified sources or supplements.',
        'Include a reliable omega-3 source: flax, chia, walnuts or algal oil.'
      ],
      cautions: ['Protein quality requires attention, particularly in older adults and athletes.'],
      contraindications: [
        { condition: 'Infants and young children', severity: 'relative',
          rationale: 'Requires specialist paediatric dietetic supervision.' }
      ],
      pattern: '3_meals_1_snack', refs: ['plant_based_patterns', 'b12']
    },
    {
      code: 'renal', nameEn: 'Renal-Specific Nutrition Plan', nameAr: 'خطة تغذية الكلى',
      group: 'clinical', evidence: 'clinical_guideline',
      summary: 'Individualised protein, sodium, potassium, phosphate and fluid targets according to renal function and dialysis status.',
      macros: { proteinPct: 15, carbPct: 55, fatPct: 30 }, proteinPerKg: 0.8,
      sodiumMaxMg: 2000,
      guidelines: [
        'Protein 0.6–0.8 g/kg in non-dialysed disease; higher on dialysis.',
        'Restrict potassium and phosphate according to measured serum levels, not by routine.',
        'Fluid restriction only where clinically indicated.'
      ],
      cautions: [
        'Potassium and phosphate limits must be driven by laboratory results.',
        'Undue protein restriction risks malnutrition — the balance needs active management.'
      ],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['renal_nutrition', 'ckd']
    },
    {
      code: 'diabetes_oriented', nameEn: 'Diabetes-Oriented Nutrition Plan', nameAr: 'خطة تغذية السكري',
      group: 'clinical', evidence: 'clinical_guideline',
      summary: 'Carbohydrate quantity, quality and distribution managed to support glycaemic control.',
      macros: { proteinPct: 20, carbPct: 42, fatPct: 38 }, fiberMin: 30,
      guidelines: [
        'Distribute carbohydrate evenly across meals rather than concentrating it.',
        'Prefer low-glycemic-index carbohydrate sources.',
        'Align carbohydrate intake with medication timing, particularly insulin.'
      ],
      cautions: [
        'Hypoglycaemia risk rises with tighter carbohydrate control on insulin or sulfonylureas.',
        'Individual glycaemic response varies — encourage self-monitoring where available.'
      ],
      contraindications: [],
      pattern: '3_meals_2_snacks', refs: ['diabetes_t2', 'glycemic_index']
    },
    {
      code: 'heart_healthy', nameEn: 'Heart-Healthy Diet', nameAr: 'نظام صحي للقلب',
      group: 'clinical', evidence: 'clinical_guideline',
      summary: 'Cardioprotective pattern: unsaturated fat in place of saturated, high fibre, sodium restricted.',
      macros: { proteinPct: 18, carbPct: 52, fatPct: 30 }, fiberMin: 30, sodiumMaxMg: 2000,
      guidelines: [
        'Replace saturated with unsaturated fat rather than simply reducing total fat.',
        'Two servings of oily fish weekly where accepted.',
        'Soluble fibre from oats, barley and legumes to support lipid lowering.'
      ],
      cautions: ['Review with anticoagulant therapy — vitamin K intake from leafy greens should be consistent rather than avoided.'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['lipid_lowering', 'cardiometabolic_risk']
    },
    {
      code: 'weight_management', nameEn: 'Weight Management Diet', nameAr: 'نظام إدارة الوزن',
      group: 'energy', evidence: 'clinical_guideline',
      summary: 'Structured energy control with a protein-forward distribution to protect lean mass, for loss, gain or maintenance.',
      macros: { proteinPct: 25, carbPct: 40, fatPct: 35 }, proteinPerKg: 1.4,
      guidelines: [
        'Anchor the plan to the approved energy target for the stated goal.',
        'Highest protein share at the meal following resistance exercise where relevant.',
        'Plan for the maintenance phase from the outset, not as an afterthought.'
      ],
      cautions: ['Aggressive deficits accelerate lean-mass loss; review body composition, not weight alone.'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: ['energy_balance', 'protein_requirement']
    },
    {
      code: 'custom', nameEn: 'Custom Therapeutic Diet', nameAr: 'نظام علاجي مخصص',
      group: 'clinical', evidence: 'patient_specific',
      summary: 'A clinician-defined pattern for presentations the standard approaches do not fit.',
      macros: null,
      guidelines: [
        'Document the clinical reasoning for the pattern in the patient record.',
        'Set every target explicitly — no defaults are applied to a custom pattern.'
      ],
      cautions: ['Targets are entirely clinician-supplied and are not validated by the engine.'],
      contraindications: [],
      pattern: '3_meals_1_snack', refs: []
    }
  ];

  /* --------------------------------------------------- compatibility matrix
     Unlisted pairs default to compatible. Only genuine structural conflicts,
     or combinations needing explicit caution, are enumerated.               */
  var PAIR_RULES = {
    'dash|ketogenic':      ['incompatible', 'DASH mandates generous whole grains, fruit and legumes; that carbohydrate load is incompatible with ketosis.'],
    'ketogenic|low_carb':  ['redundant', 'Ketogenic is a stricter form of low-carbohydrate; combining them adds nothing.'],
    'ketogenic|low_fat':   ['incompatible', 'Fat cannot simultaneously be 70% and 23% of energy.'],
    'ketogenic|vegan':     ['caution', 'Sustaining ketosis on a fully plant-based pattern is possible but strongly constrained in practice.'],
    'ketogenic|vegetarian':['caution', 'Achievable with eggs and dairy, but food variety narrows sharply.'],
    'dash|low_carb':       ['caution', 'DASH assumes roughly 55% carbohydrate; a low-carbohydrate variant departs from the tested DASH protocol.'],
    'high_protein|renal':  ['incompatible', 'Renal plans restrict protein; a high-protein plan contradicts that directly.'],
    'intermittent_fasting|diabetes_oriented': ['caution', 'Fasting windows on insulin or sulfonylureas increase hypoglycaemia risk and require medication review.'],
    'vegan|vegetarian':    ['redundant', 'Vegan is a strict subset of vegetarian; apply vegan alone.'],
    'dairy_free|lactose_free': ['redundant', 'Dairy-free already excludes lactose; the lactose-free constraint adds nothing.'],
    'gluten_free|low_gi':  ['compatible', 'Both are carbohydrate-quality constraints and reinforce each other.'],
    'dash|low_sodium':     ['redundant', 'DASH already includes sodium restriction; set the stricter sodium bound once.'],
    'gluten_free|dairy_free': ['compatible', 'Two independent exclusion sets; both apply without conflict.'],
    'low_fat|mediterranean': ['caution', 'Mediterranean patterns are fat-generous; a low-fat version departs from the tested pattern.'],
    'ketogenic|high_protein': ['caution', 'Excess protein blunts ketosis; protein must be set to requirement, not maximised.'],
    'intermittent_fasting|underweight': ['incompatible', 'Fasting conflicts with a weight-gain objective.'],
    'high_protein|chronic_kidney_disease': ['incompatible', 'Protein is restricted in non-dialysed chronic kidney disease.']
  };

  /** Evaluate a combination. Returns {level, pairs:[{a,b,rationale}], ok}. */
  function evaluate(codes) {
    var list = (codes || []).slice();
    var pairs = [], level = 'compatible';
    var RANK = { compatible: 0, redundant: 1, caution: 2, incompatible: 3 };

    for (var i = 0; i < list.length; i++) {
      for (var j = i + 1; j < list.length; j++) {
        var a = list[i], b = list[j];
        var rule = PAIR_RULES[a + '|' + b] || PAIR_RULES[b + '|' + a];
        var lv = rule ? rule[0] : 'compatible';
        var why = rule ? rule[1] : 'No structural conflict between these two patterns.';
        pairs.push({ a: a, b: b, level: lv, rationale: why });
        if (RANK[lv] > RANK[level]) level = lv;
      }
    }
    return { level: level, pairs: pairs, ok: level !== 'incompatible' };
  }

  /** Union of every exclusion the selected approaches themselves impose. */
  function requiredExclusions(codes) {
    var out = [];
    (codes || []).forEach(function (c) {
      var a = byCode(c);
      (a && a.requires ? a.requires : []).forEach(function (r) {
        if (out.indexOf(r) === -1) out.push(r);
      });
    });
    return out;
  }

  /** Every contraindication raised by the selected approaches. */
  function contraindicationsFor(codes) {
    var out = [];
    (codes || []).forEach(function (c) {
      var a = byCode(c);
      (a && a.contraindications ? a.contraindications : []).forEach(function (ci) {
        out.push({ approach: c, condition: ci.condition, severity: ci.severity, rationale: ci.rationale });
      });
    });
    return out;
  }

  var byCodeMap = {};
  APPROACHES.forEach(function (a) { byCodeMap[a.code] = a; });
  function byCode(code) { return byCodeMap[code] || null; }

  /** Merge macro profiles of several approaches by averaging, then normalising. */
  function mergedMacros(codes) {
    var ms = (codes || []).map(function (c) { var a = byCode(c); return a && a.macros; })
      .filter(Boolean);
    if (!ms.length) return null;
    var p = 0, c2 = 0, f = 0;
    ms.forEach(function (m) { p += m.proteinPct; c2 += m.carbPct; f += m.fatPct; });
    p /= ms.length; c2 /= ms.length; f /= ms.length;
    var total = p + c2 + f;
    if (!total) return null;
    // Normalise to 100 and round, then correct any rounding drift on fat.
    var rp = CN.util.round(p * 100 / total, 1);
    var rc = CN.util.round(c2 * 100 / total, 1);
    var rf = CN.util.round(100 - rp - rc, 1);
    return { proteinPct: rp, carbPct: rc, fatPct: rf };
  }

  /** Tightest sodium ceiling and highest fibre floor across the selection. */
  function mergedLimits(codes) {
    var sodium = null, fiber = null, perKg = null, pattern = null;
    (codes || []).forEach(function (c) {
      var a = byCode(c);
      if (!a) return;
      if (a.sodiumMaxMg) sodium = sodium === null ? a.sodiumMaxMg : Math.min(sodium, a.sodiumMaxMg);
      if (a.fiberMin) fiber = fiber === null ? a.fiberMin : Math.max(fiber, a.fiberMin);
      if (a.proteinPerKg && perKg === null) perKg = a.proteinPerKg;
      if (a.pattern && pattern === null) pattern = a.pattern;
    });
    return { sodiumMaxMg: sodium, fiberMin: fiber, proteinPerKg: perKg, pattern: pattern };
  }

  /* --------------------------------------------------------------- templates */
  var TEMPLATES = [
    { id: 'tpl_med_loss', nameEn: 'Mediterranean Weight Loss Template', nameAr: 'قالب المتوسطي لخفض الوزن',
      approaches: ['mediterranean', 'weight_management'], duration: 7 },
    { id: 'tpl_dash', nameEn: 'DASH Diet Template', nameAr: 'قالب نظام داش',
      approaches: ['dash'], duration: 7 },
    { id: 'tpl_dm_lowgi', nameEn: 'Diabetes Low-Glycemic Template', nameAr: 'قالب السكري منخفض الجلايسيمي',
      approaches: ['diabetes_oriented', 'low_gi'], duration: 7 },
    { id: 'tpl_high_protein', nameEn: 'High-Protein Template', nameAr: 'قالب عالي البروتين',
      approaches: ['high_protein', 'weight_management'], duration: 7 },
    { id: 'tpl_maintenance', nameEn: 'Maintenance Diet Template', nameAr: 'قالب الحفاظ على الوزن',
      approaches: ['mediterranean', 'calorie_controlled'], duration: 7 },
    { id: 'tpl_renal', nameEn: 'Renal Template', nameAr: 'قالب الكلى',
      approaches: ['renal', 'low_sodium'], duration: 7 },
    { id: 'tpl_vegan', nameEn: 'Plant-Based Template', nameAr: 'قالب نباتي',
      approaches: ['vegan'], duration: 7 },
    { id: 'tpl_low_carb', nameEn: 'Low-Carbohydrate Template', nameAr: 'قالب قليل الكربوهيدرات',
      approaches: ['low_carb'], duration: 7 }
  ];

  /* Food-group composition per eating occasion, used by the plan generator.
     Shares are relative weights within the occasion. */
  var OCCASION_RECIPES = {
    breakfast: [
      { slot: 'protein', share: 0.30, cats: ['eggs', 'dairy', 'legumes'] },
      { slot: 'starch', share: 0.40, cats: ['bread', 'grains'] },
      { slot: 'vegetable', share: 0.15, cats: ['vegetables'] },
      { slot: 'fat', share: 0.10, cats: ['fats', 'nuts'] },
      { slot: 'fruit', share: 0.05, cats: ['fruits'] }
    ],
    lunch: [
      { slot: 'protein', share: 0.35, cats: ['poultry', 'meat', 'fish', 'legumes'] },
      { slot: 'starch', share: 0.30, cats: ['grains'] },
      { slot: 'vegetable', share: 0.25, cats: ['vegetables'] },
      { slot: 'fat', share: 0.10, cats: ['fats'] }
    ],
    dinner: [
      { slot: 'protein', share: 0.35, cats: ['fish', 'poultry', 'legumes', 'dairy'] },
      { slot: 'starch', share: 0.25, cats: ['bread', 'grains'] },
      { slot: 'vegetable', share: 0.28, cats: ['vegetables'] },
      { slot: 'fat', share: 0.12, cats: ['fats'] }
    ],
    snack: [
      { slot: 'fruit', share: 0.50, cats: ['fruits'] },
      { slot: 'protein', share: 0.35, cats: ['dairy', 'nuts'] },
      { slot: 'fat', share: 0.15, cats: ['nuts'] }
    ]
  };

  CN.approaches = {
    all: APPROACHES,
    byCode: byCode,
    patterns: PATTERNS,
    mealLabelsFor: mealLabelsFor,
    templates: TEMPLATES,
    occasionRecipes: OCCASION_RECIPES,
    evaluate: evaluate,
    mergedMacros: mergedMacros,
    mergedLimits: mergedLimits,
    requiredExclusions: requiredExclusions,
    contraindicationsFor: contraindicationsFor,
    /** Does this occasion index read as a snack? Used for labelling only. */
    isSnackIndex(pattern, i) {
      if (!pattern) return false;
      if (pattern.snacks === 1) return i === 1;
      if (pattern.snacks === 2) return i === 1 || i === 3;
      return false;
    },
    /** Which occasion recipe applies to index `i` of a pattern. */
    occasionFor(pattern, i) {
      if (CN.approaches.isSnackIndex(pattern, i)) return 'snack';
      if (pattern.key === '2_meals_if') return i === 0 ? 'lunch' : 'dinner';
      if (i === 0) return 'breakfast';
      return (i === pattern.shares.length - 1) ? 'dinner' : 'lunch';
    }
  };
})();
