/* ==========================================================================
   NutriClinic Pro — data-references.js
   Clinical briefs, the evidence hierarchy, and external source pointers.

   HONESTY RULE (brief §12, "never fabricate references"):
   The URLs below are each organisation's canonical entry point. They have NOT
   been fetched or version-checked in this build, so `verified` is false and no
   access date is claimed. The interface states this plainly rather than
   implying a citation that was never opened. Confirm the current version
   before quoting any of these in a clinical document.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};

  /* Ordered evidence hierarchy. Patient-specific information always outranks
     every published source (brief §11). */
  var HIERARCHY = [
    { tier: 1, key: 'patient_specific',
      en: 'Patient-specific clinical information and clinician restrictions',
      ar: 'معلومات المريض الخاصة والقيود التي حددها الطبيب',
      note: 'Highest priority. Overrides every published source below.' },
    { tier: 2, key: 'clinical_guideline',
      en: 'Current authoritative clinical guidelines',
      ar: 'الإرشادات الإكلينيكية المعتمدة الحالية' },
    { tier: 3, key: 'food_database',
      en: 'Validated food composition databases',
      ar: 'قواعد بيانات التركيب الغذائي الموثوقة' },
    { tier: 4, key: 'clinician_upload',
      en: 'Clinician-uploaded reference material',
      ar: 'المواد المرجعية التي رفعها الطبيب',
      note: 'Is not automatically authoritative — checked against tiers 1–3.' },
    { tier: 5, key: 'web_source',
      en: 'Other reliable scientific sources',
      ar: 'مصادر علمية موثوقة أخرى' }
  ];

  function src(org, title, url) {
    return { org: org, title: title, url: url, verified: false };
  }

  var BRIEFS = [
    {
      id: 'energy_balance', titleEn: 'Energy balance and weight regulation', titleAr: 'توازن الطاقة وتنظيم الوزن',
      tier: 2, tags: ['energy', 'obesity', 'weight'],
      summary: 'Body weight changes when energy intake diverges from expenditure over time. The relationship is real but not linear: adaptive thermogenesis, adherence drift and fluid shifts all modulate the observed response, which is why a fixed deficit rarely produces exactly the predicted loss rate.',
      keyPoints: [
        'Estimate requirements from TDEE, never by subtracting from BMR.',
        'A 500 kcal/day deficit predicts roughly 0.5 kg/week, but measured loss commonly lags the prediction.',
        'Recalculate against observed trend at every follow-up rather than holding the original estimate.',
        'A short plateau is not by itself evidence that the target is wrong.'
      ],
      cautions: ['Very large deficits accelerate lean-mass loss and are rarely justified outside supervised programmes.'],
      approaches: ['calorie_controlled', 'weight_management'],
      sources: [
        src('WHO', 'Obesity and overweight — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/obesity-and-overweight'),
        src('NIH / NIDDK', 'Body weight and energy balance', 'https://www.niddk.nih.gov/')
      ]
    },
    {
      id: 'protein_requirement', titleEn: 'Protein requirements', titleAr: 'الاحتياجات من البروتين',
      tier: 2, tags: ['protein', 'macronutrient'],
      summary: 'The adult requirement is approximately 0.8 g/kg/day for sedentary healthy adults, rising with age, illness, injury and physical training. During energy restriction, higher intakes protect lean mass. Protein should be set in grams per kilogram of body weight rather than as a fixed percentage of energy.',
      keyPoints: [
        '0.8 g/kg/day baseline; 1.0–1.2 g/kg for older adults.',
        '1.2–1.6 g/kg during intentional weight loss to preserve lean mass.',
        'Up to 1.6–2.2 g/kg for athletes, distributed across the day.',
        'Restrict protein in non-dialysed chronic kidney disease — do not apply general targets.'
      ],
      cautions: ['Renal and hepatic impairment require condition-specific protein targets, not standard ones.'],
      approaches: ['high_protein', 'weight_management', 'sarcopenia'],
      sources: [
        src('WHO / FAO', 'Protein and amino acid requirements', 'https://www.who.int/publications'),
        src('ESPEN', 'Clinical nutrition guidelines', 'https://www.espen.org/guidelines-home/espen-guidelines')
      ]
    },
    {
      id: 'carbohydrate_load', titleEn: 'Carbohydrate quantity and quality', titleAr: 'كمية الكربوهيدرات وجودتها',
      tier: 2, tags: ['carbohydrate', 'macronutrient'],
      summary: 'Both the amount and the type of carbohydrate influence glycaemic and cardiometabolic outcomes. Quality — fibre content, whole-grain structure, degree of processing — carries independent effects beyond total quantity.',
      keyPoints: [
        'Fibre target 25–30 g/day for most adults.',
        'Replace refined starches with intact whole grains, legumes and vegetables.',
        'Very low intakes (under 50 g/day) are a distinct therapeutic intervention with their own review requirements.'
      ],
      cautions: ['Low-carbohydrate plans must still maintain fibre and micronutrient adequacy.'],
      approaches: ['low_carb', 'low_gi', 'diabetes_oriented'],
      sources: [src('WHO', 'Healthy diet — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/healthy-diet')]
    },
    {
      id: 'glycemic_index', titleEn: 'Glycemic index and glycemic load', titleAr: 'المؤشر والحمل الجلايسيمي',
      tier: 2, tags: ['carbohydrate', 'diabetes'],
      summary: 'Glycemic index ranks carbohydrate foods by postprandial glucose response; glycemic load multiplies that by the carbohydrate actually consumed. Load is the more useful clinical quantity because portion size is part of the calculation.',
      keyPoints: [
        'Use glycemic load rather than index alone when advising portions.',
        'Combine carbohydrate with protein or fat to blunt the glucose excursion.',
        'Individual response varies substantially — self-monitoring where available is more informative than tables.'
      ],
      cautions: ['Low-glycemic-index foods are not automatically low-calorie.'],
      approaches: ['low_gi', 'diabetes_oriented'],
      sources: [src('ADA', 'Standards of Care in Diabetes', 'https://diabetes.org/')]
    },
    {
      id: 'lipid_lowering', titleEn: 'Lipid lowering through diet', titleAr: 'خفض الدهون بالغذاء',
      tier: 2, tags: ['lipids', 'cardiovascular'],
      summary: 'Replacing saturated with unsaturated fat lowers LDL cholesterol. Soluble fibre and plant stanols add modest further reductions. The substitution matters more than the absolute reduction in total fat.',
      keyPoints: [
        'Saturated fat below 7% of energy where cardiovascular risk is elevated.',
        'Soluble fibre from oats, barley and legumes — around 5–10 g/day for lipid benefit.',
        'Oily fish twice weekly where accepted.',
        'Avoid trans fats entirely.'
      ],
      cautions: ['Do not simply reduce total fat; replace the saturated fraction.'],
      approaches: ['heart_healthy', 'low_fat', 'mediterranean'],
      sources: [src('AHA', 'Dietary guidance to improve cardiovascular health', 'https://www.heart.org/')]
    },
    {
      id: 'dash_sodium', titleEn: 'DASH pattern and sodium reduction', titleAr: 'نظام داش وخفض الصوديوم',
      tier: 2, tags: ['hypertension', 'sodium'],
      summary: 'The DASH eating pattern lowers blood pressure, with a graded additional benefit as sodium is reduced. The combination of the pattern with low sodium produces the largest effect observed in controlled feeding studies.',
      keyPoints: [
        'Sodium reduction steps of roughly 1000 mg/day are better tolerated than abrupt change.',
        'Target 1500–2300 mg/day depending on indication and tolerance.',
        'Processed bread, cheese and cured meats — not table salt — dominate intake.',
        'Potassium-rich foods contribute to the blood-pressure benefit where renal function permits.'
      ],
      cautions: ['Review potassium load in renal impairment and with potassium-sparing diuretics.'],
      approaches: ['dash', 'low_sodium', 'hypertension'],
      sources: [src('NIH / NHLBI', 'DASH Eating Plan', 'https://www.nhlbi.nih.gov/education/dash-eating-plan')]
    },
    {
      id: 'mediterranean_pattern', titleEn: 'Mediterranean dietary pattern', titleAr: 'النمط الغذائي المتوسطي',
      tier: 2, tags: ['pattern', 'cardiovascular'],
      summary: 'A pattern characterised by olive oil as principal fat, high vegetable and legume intake, whole grains, fish and nuts, with limited red meat and processed food. Associated with reduced cardiovascular events in primary and secondary prevention settings.',
      keyPoints: [
        'Olive oil as the main added fat.',
        'Legumes as a routine protein source, not an occasional one.',
        'Fish twice or more weekly; red meat a few times monthly.',
        'Whole grains in preference to refined.'
      ],
      cautions: ['Energy density is high — the pattern does not by itself produce weight loss.'],
      approaches: ['mediterranean', 'heart_healthy'],
      sources: [src('WHO', 'Healthy diet — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/healthy-diet')]
    },
    {
      id: 'diabetes_t2', titleEn: 'Type 2 diabetes: nutrition approach', titleAr: 'السكري من النوع الثاني: المقاربة الغذائية',
      tier: 2, tags: ['diabetes'],
      summary: 'Nutrition therapy is foundational in type 2 diabetes. Weight reduction where overweight, carbohydrate quality and distribution, and adequate fibre all improve glycaemic control. No single macronutrient distribution is universally superior.',
      keyPoints: [
        'Distribute carbohydrate evenly across meals.',
        'Prefer low-glycemic-index sources.',
        'Weight loss of 5–10% where indicated improves glycaemia materially.',
        'Align carbohydrate intake with medication timing.'
      ],
      cautions: ['Hypoglycaemia risk rises with insulin or sulfonylureas when intake is reduced or redistributed.'],
      approaches: ['diabetes_oriented', 'low_gi', 'weight_management'],
      sources: [
        src('ADA', 'Standards of Care in Diabetes', 'https://diabetes.org/'),
        src('WHO', 'Diabetes — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/diabetes')
      ]
    },
    {
      id: 'diabetes_t1', titleEn: 'Type 1 diabetes: carbohydrate awareness', titleAr: 'السكري من النوع الأول: إدراك الكربوهيدرات',
      tier: 2, tags: ['diabetes', 'safety'],
      summary: 'In type 1 diabetes, carbohydrate quantity and timing must be coordinated with insulin. Carbohydrate counting supports glycaemic control, but dietary change requires insulin regimen adjustment by the diabetes team.',
      keyPoints: [
        'Nutritional changes require concomitant insulin adjustment.',
        'Carbohydrate counting is a tool, not a diet — it does not by itself dictate composition.',
        'Exercise requires carbohydrate and insulin planning.'
      ],
      cautions: [
        'Do not initiate a ketogenic or fasting plan without specialist diabetes supervision — risk of euglycaemic ketoacidosis and severe hypoglycaemia.'
      ],
      approaches: [],
      sources: [src('ADA', 'Standards of Care in Diabetes', 'https://diabetes.org/')]
    },
    {
      id: 'ckd', titleEn: 'Chronic kidney disease: protein and electrolytes', titleAr: 'مرض الكلى المزمن: البروتين والإلكتروليتات',
      tier: 2, tags: ['renal', 'safety'],
      summary: 'Non-dialysed chronic kidney disease typically requires protein restriction to 0.6–0.8 g/kg/day, with potassium and phosphate limits driven by measured serum levels rather than applied routinely. Undue restriction risks protein-energy malnutrition.',
      keyPoints: [
        'Protein 0.6–0.8 g/kg/day in non-dialysed disease; higher on dialysis.',
        'Potassium and phosphate limits follow laboratory values.',
        'Sodium restriction is usually indicated.',
        'Energy intake must remain adequate — restriction is not the goal in itself.'
      ],
      cautions: ['A high-protein plan is contraindicated. Refer for specialist renal dietetic input.'],
      approaches: ['renal', 'low_sodium'],
      sources: [src('NIH / NIDDK', 'Chronic kidney disease', 'https://www.niddk.nih.gov/')]
    },
    {
      id: 'hypertension', titleEn: 'Hypertension: dietary management', titleAr: 'ارتفاع ضغط الدم: الإدارة الغذائية',
      tier: 2, tags: ['hypertension', 'cardiovascular'],
      summary: 'Sodium reduction, the DASH pattern, weight loss where overweight, moderation of alcohol, and adequate potassium from food all lower blood pressure. Effects are additive across interventions.',
      keyPoints: [
        'Sodium reduction is the single most effective dietary lever.',
        'Weight loss of 1 kg associates with roughly 1 mmHg systolic reduction.',
        'Potassium-rich foods help where renal function permits.',
        'Dietary effects complement, and do not replace, pharmacological treatment.'
      ],
      cautions: ['Do not present dietary change as a reason to stop antihypertensive medication.'],
      approaches: ['dash', 'low_sodium', 'hypertension'],
      sources: [
        src('WHO', 'Salt reduction — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/salt-reduction'),
        src('AHA', 'High blood pressure', 'https://www.heart.org/')
      ]
    },
    {
      id: 'coeliac_disease', titleEn: 'Coeliac disease and gluten exclusion', titleAr: 'مرض السيلياك واستبعاد الجلوتين',
      tier: 2, tags: ['gluten', 'gastrointestinal'],
      summary: 'Coeliac disease requires strict, lifelong exclusion of wheat, barley and rye. Even small amounts sustain mucosal inflammation. Oats require certification as uncontaminated. Adherence is assessed clinically and serologically.',
      keyPoints: [
        'Total exclusion — not reduction.',
        'Oats only if certified gluten-free.',
        'Cross-contamination in preparation matters as much as ingredients.',
        'Substitute fibre deliberately; gluten-free products are often fibre-poor.'
      ],
      cautions: ['Do not commence a gluten-free diet before diagnostic testing is complete — it invalidates the result.'],
      approaches: ['gluten_free'],
      sources: [src('WHO', 'Healthy diet — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/healthy-diet')]
    },
    {
      id: 'lactose_intolerance', titleEn: 'Lactose intolerance', titleAr: 'عدم تحمل اللاكتوز',
      tier: 2, tags: ['dairy', 'gastrointestinal'],
      summary: 'Lactose intolerance is a dose-dependent deficiency of lactase, distinct from cow\u2019s milk allergy. Most affected people tolerate small amounts, lactose-free milk and hard aged cheeses. It is not an immune reaction and does not carry allergy risk.',
      keyPoints: [
        'Dose-dependent — total exclusion is rarely necessary.',
        'Hard cheeses are low in lactose; fermented products are often tolerated.',
        'Lactose-free milk is nutritionally equivalent to regular milk.',
        'Distinguish carefully from milk allergy.'
      ],
      cautions: ['Restricting dairy unnecessarily risks inadequate calcium intake.'],
      approaches: ['lactose_free'],
      sources: [src('NIH', 'Lactose intolerance', 'https://www.niddk.nih.gov/')]
    },
    {
      id: 'cow_milk_allergy', titleEn: 'Cow\u2019s milk allergy', titleAr: 'حساسية حليب البقر',
      tier: 2, tags: ['dairy', 'allergy', 'safety'],
      summary: 'An immune-mediated reaction requiring exclusion of all mammalian milk protein, including in baked goods where the reaction is severe. This is fundamentally different from lactose intolerance and must never be conflated with it.',
      keyPoints: [
        'Excludes all milk protein, including milk solids in composite products.',
        'Calcium and riboflavin must be replaced deliberately.',
        'Adrenaline auto-injector provision is a medical decision, not a dietary one.'
      ],
      cautions: ['A dietary plan must never include an allergen the patient has a diagnosed allergy to (brief §8).'],
      approaches: ['dairy_free'],
      sources: [src('WHO', 'Food safety and allergens', 'https://www.who.int/health-topics/food-safety')]
    },
    {
      id: 'ketogenic_diet', titleEn: 'Ketogenic diet: indications and monitoring', titleAr: 'النظام الكيتوني: دواعيه والمتابعة',
      tier: 2, tags: ['ketogenic', 'safety'],
      summary: 'A very low carbohydrate, high fat pattern inducing nutritional ketosis. Established in drug-resistant epilepsy; used with varying evidence in obesity and type 2 diabetes. Requires defined monitoring and a review point.',
      keyPoints: [
        'Carbohydrate generally below 50 g/day.',
        'Protein at requirement — excess blunts ketosis.',
        'Monitor electrolytes, renal function and lipid profile.',
        'Maintain fibre from low-carbohydrate vegetables.'
      ],
      cautions: [
        'Absolute contraindications include type 1 diabetes, pancreatic insufficiency, eating disorder history and pregnancy.',
        'Constipation, dyslipidaemia and nephrolithiasis risk require active surveillance.'
      ],
      approaches: ['ketogenic'],
      sources: [src('ESPEN', 'Clinical nutrition guidelines', 'https://www.espen.org/guidelines-home/espen-guidelines')]
    },
    {
      id: 'intermittent_fasting', titleEn: 'Intermittent fasting', titleAr: 'الصيام المتقطع',
      tier: 2, tags: ['fasting', 'energy'],
      summary: 'Confining intake to defined windows (commonly 16:8) or to lower-intake days (5:2). Weight outcomes are broadly comparable to continuous energy restriction when total intake matches. The mechanism is timing, not a metabolic advantage.',
      keyPoints: [
        'Energy and protein targets are unchanged — only timing moves.',
        'Adherence is often better than continuous restriction for some patients.',
        'Not suitable in pregnancy, lactation, underweight or eating-disorder history.'
      ],
      cautions: ['Requires medication review when insulin or sulfonylureas are prescribed.'],
      approaches: ['intermittent_fasting'],
      sources: [src('WHO', 'Healthy diet — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/healthy-diet')]
    },
    {
      id: 'low_carb', titleEn: 'Low-carbohydrate diets', titleAr: 'الأنظمة قليلة الكربوهيدرات',
      tier: 2, tags: ['carbohydrate'],
      summary: 'Reducing carbohydrate to roughly 25% of energy or below. Produces comparable or slightly greater short-term weight loss than low-fat diets; differences narrow at 12 months. Lipid and renal parameters require monitoring.',
      keyPoints: [
        'Greater early weight loss is largely water and glycogen.',
        'Review lipid profile at 8–12 weeks.',
        'Fibre and micronutrient adequacy require deliberate planning.'
      ],
      cautions: ['Requires individual assessment in pregnancy, type 1 diabetes and renal impairment.'],
      approaches: ['low_carb'],
      sources: [src('ESPEN', 'Clinical nutrition guidelines', 'https://www.espen.org/guidelines-home/espen-guidelines')]
    },
    {
      id: 'plant_based_patterns', titleEn: 'Vegetarian and vegan patterns', titleAr: 'الأنظمة النباتية',
      tier: 2, tags: ['pattern', 'micronutrient'],
      summary: 'Well-planned plant-based patterns are nutritionally adequate and associate with lower cardiovascular risk. Adequacy depends on deliberate attention to B12, calcium, iron, zinc, iodine and omega-3, particularly in vegan diets.',
      keyPoints: [
        'Vitamin B12 supplementation is mandatory in vegan diets.',
        'Plant iron is less bioavailable — pair with vitamin C.',
        'Combine plant proteins across the day.',
        'Include a reliable omega-3 source: flax, chia, walnuts or algal oil.'
      ],
      cautions: ['Infants, young children and pregnancy require specialist dietetic supervision.'],
      approaches: ['vegetarian', 'vegan'],
      sources: [src('WHO', 'Healthy diet — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/healthy-diet')]
    },
    {
      id: 'b12', titleEn: 'Vitamin B12', titleAr: 'فيتامين ب١٢',
      tier: 2, tags: ['micronutrient'],
      summary: 'B12 is found naturally almost exclusively in animal-derived foods. Deficiency causes megaloblastic anaemia and irreversible neurological damage if prolonged. Vegan diets, metformin therapy, bariatric surgery and older age all raise risk.',
      keyPoints: [
        'Supplementation, not diet alone, is required in vegan diets.',
        'Fortified foods and supplements are equivalent options.',
        'Serum B12, and where indicated methylmalonic acid, guide assessment.'
      ],
      cautions: ['Neurological damage from untreated deficiency may be irreversible.'],
      approaches: ['vegan'],
      sources: [src('NIH / ODS', 'Vitamin B12 — fact sheet for health professionals', 'https://ods.od.nih.gov/factsheets/')]
    },
    {
      id: 'micronutrients', titleEn: 'Micronutrient adequacy in energy restriction', titleAr: 'كفاية العناصر الدقيقة في تقييد الطاقة',
      tier: 2, tags: ['micronutrient'],
      summary: 'As energy intake falls, the risk of inadequate micronutrient intake rises unless food choices are deliberately nutrient-dense. Intakes below roughly 1200 kcal/day rarely meet requirements from food alone.',
      keyPoints: [
        'Below 1200 kcal/day, food alone seldom meets micronutrient requirements.',
        'Prioritise nutrient-dense foods over energy-dense ones.',
        'Consider targeted supplementation where a deficit is identified, not routinely.'
      ],
      cautions: ['Do not prescribe broad-spectrum supplementation as a substitute for dietary quality.'],
      approaches: ['calorie_controlled'],
      sources: [src('NIH / ODS', 'Micronutrient fact sheets', 'https://ods.od.nih.gov/factsheets/')]
    },
    {
      id: 'sarcopenia', titleEn: 'Sarcopenia and older adults', titleAr: 'ضمور العضلات وكبار السن',
      tier: 2, tags: ['ageing', 'protein'],
      summary: 'Muscle mass declines with age, accelerated by inactivity and inadequate protein. Countermeasures are resistance exercise plus protein of 1.0–1.2 g/kg/day, distributed across meals rather than concentrated.',
      keyPoints: [
        'Protein 1.0–1.2 g/kg/day for healthy older adults.',
        'Distribute across meals — roughly 25–30 g per occasion.',
        'Resistance training is required for protein to translate into muscle.',
        'Assess vitamin D status.'
      ],
      cautions: ['Energy restriction in older adults risks accelerating muscle loss — assess body composition, not weight alone.'],
      approaches: ['high_protein', 'weight_management'],
      sources: [src('ESPEN', 'Clinical nutrition guidelines', 'https://www.espen.org/guidelines-home/espen-guidelines')]
    },
    {
      id: 'heart_failure', titleEn: 'Heart failure: sodium and fluid', titleAr: 'هبوط القلب: الصوديوم والسوائل',
      tier: 2, tags: ['cardiovascular', 'sodium', 'fluid'],
      summary: 'Sodium restriction supports volume management in heart failure. Routine fluid restriction is reserved for patients with hyponatraemia or persistent congestion despite diuretic therapy rather than applied universally.',
      keyPoints: [
        'Sodium target commonly 2000–3000 mg/day; individualise.',
        'Routine fluid restriction is not universal.',
        'Monitor weight daily as an early marker of congestion.',
        'Review potassium with diuretic therapy.'
      ],
      cautions: ['Over-restriction of both sodium and fluid can be harmful; individualise rather than applying a fixed rule.'],
      approaches: ['low_sodium', 'heart_healthy'],
      sources: [src('AHA', 'Heart failure', 'https://www.heart.org/')]
    },
    {
      id: 'cardiometabolic_risk', titleEn: 'Cardiometabolic risk reduction', titleAr: 'خفض المخاطر القلبية الأيضية',
      tier: 2, tags: ['cardiovascular', 'diabetes'],
      summary: 'Dietary patterns rather than isolated nutrients drive cardiometabolic outcomes. Mediterranean and DASH patterns both reduce risk. Weight reduction, fibre adequacy, sodium reduction and replacement of saturated fat act independently and additively.',
      keyPoints: [
        'Whole dietary pattern matters more than any single nutrient.',
        'Weight reduction of 5–10% where overweight produces broad metabolic benefit.',
        'Fibre 25–30 g/day and sodium under 2300 mg/day are the two most actionable single targets.'
      ],
      cautions: ['Present dietary change as complementary to prescribed pharmacological therapy.'],
      approaches: ['mediterranean', 'dash', 'heart_healthy'],
      sources: [src('AHA', 'Dietary guidance to improve cardiovascular health', 'https://www.heart.org/')]
    },
    {
      id: 'eating_disorders', titleEn: 'Eating disorder screening and safety', titleAr: 'تحري اضطرابات الأكل والسلامة',
      tier: 2, tags: ['safety', 'mental-health'],
      summary: 'Weight-focused interventions can precipitate or aggravate disordered eating. Restrictive patterns, fasting windows and calorie counting all carry risk in vulnerable patients. Screening precedes any restrictive prescription.',
      keyPoints: [
        'Screen before initiating any restrictive plan.',
        'Restrictive patterns and fasting windows are contraindicated where an eating disorder is present or suspected.',
        'Weight-neutral approaches are preferable where risk is identified.',
        'Referral to specialist mental health support takes precedence over dietary planning.'
      ],
      cautions: ['This is a safety-critical screen, not a routine question.'],
      approaches: [],
      sources: [src('NIH', 'Eating disorders', 'https://www.nimh.nih.gov/health/topics/eating-disorders')]
    },
    {
      id: 'pregnancy_lactation', titleEn: 'Pregnancy and lactation', titleAr: 'الحمل والرضاعة',
      tier: 2, tags: ['pregnancy', 'safety'],
      summary: 'Energy and nutrient requirements rise during pregnancy and lactation, and weight reduction is not appropriate. Fasting patterns, ketogenic diets and aggressive deficits are contraindicated. Folic acid, iron, iodine and vitamin D require attention.',
      keyPoints: [
        'Energy restriction for weight loss is not appropriate in pregnancy.',
        'Folic acid, iodine, iron and vitamin D require deliberate provision.',
        'Fasting and ketogenic patterns are contraindicated.',
        'Postpartum weight management begins after lactation is established or concluded.'
      ],
      cautions: ['Any restrictive dietary pattern during pregnancy requires specialist obstetric dietetic supervision.'],
      approaches: [],
      sources: [src('WHO', 'Healthy diet — fact sheet', 'https://www.who.int/news-room/fact-sheets/detail/healthy-diet')]
    },
    {
      id: 'refeeding', titleEn: 'Refeeding syndrome risk', titleAr: 'خطر متلازمة إعادة التغذية',
      tier: 2, tags: ['safety', 'malnutrition'],
      summary: 'Reintroducing nutrition in a severely malnourished patient can cause dangerous electrolyte shifts, particularly hypophosphataemia. Risk assessment precedes feeding, and feeding advances cautiously with electrolyte monitoring.',
      keyPoints: [
        'Assess risk before feeding: low BMI, minimal recent intake, significant unintentional loss, low baseline electrolytes.',
        'Start at reduced energy and advance over several days.',
        'Monitor phosphate, potassium and magnesium closely.',
        'Thiamine supplementation is given before feeding in at-risk patients.'
      ],
      cautions: ['This is a medical emergency risk — do not initiate aggressive feeding in a high-risk patient without monitoring in place.'],
      approaches: [],
      sources: [src('ESPEN', 'Clinical nutrition guidelines', 'https://www.espen.org/guidelines-home/espen-guidelines')]
    }
  ];

  var byId = {};
  BRIEFS.forEach(function (b) { byId[b.id] = b; });

  /** Briefs linked to any of the given approach codes. */
  function forApproaches(codes) {
    var set = (codes || []);
    return BRIEFS.filter(function (b) {
      return (b.approaches || []).some(function (a) { return set.indexOf(a) !== -1; });
    });
  }

  var EXTERNAL_NOTE =
    'These organisations\u2019 canonical pages are listed for reference. They were not fetched ' +
    'or version-checked when this build was produced, so no access date is asserted. Confirm the ' +
    'current version before citing one in a clinical document.';

  CN.refs = {
    all: BRIEFS,
    hierarchy: HIERARCHY,
    byId(id) { return byId[id] || null; },
    externalNote: EXTERNAL_NOTE,
    tierLabel(tier, lang) {
      for (var i = 0; i < HIERARCHY.length; i++) {
        if (HIERARCHY[i].tier === tier) return lang === 'ar' ? HIERARCHY[i].ar : HIERARCHY[i].en;
      }
      return 'Tier ' + tier;
    },
    forApproaches: forApproaches,
    search(q) {
      if (!q || !q.trim()) return BRIEFS;
      var s = q.trim().toLowerCase();
      return BRIEFS.filter(function (b) {
        return b.titleEn.toLowerCase().indexOf(s) !== -1 ||
          (b.titleAr || '').indexOf(q.trim()) !== -1 ||
          b.summary.toLowerCase().indexOf(s) !== -1 ||
          (b.tags || []).some(function (t) { return t.indexOf(s) !== -1; });
      });
    },
    count: BRIEFS.length,
    /** Total distinct external sources referenced. */
    sourceCount() {
      var seen = {};
      BRIEFS.forEach(function (b) {
        (b.sources || []).forEach(function (s) { seen[s.org + '|' + s.url] = 1; });
      });
      return Object.keys(seen).length;
    }
  };
})();
