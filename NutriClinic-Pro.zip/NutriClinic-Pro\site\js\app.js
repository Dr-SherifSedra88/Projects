/* ==========================================================================
   NutriClinic Pro — app.js
   Shell, routing, patient context, first-run setup, Copilot view.
   Loads last; may depend on every module above it.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;
  var ui = CN.ui;

  /* ------------------------------------------------------------- routing --- */
  var ROUTES = [
    { section: 'nav.sec.overview', items: [
      { name: 'dashboard', icon: 'grid', title: 'nav.dashboard' }
    ] },
    { section: 'nav.sec.clinical', items: [
      { name: 'patients', icon: 'users', title: 'nav.patients' },
      { name: 'newPatient', icon: 'user-plus', title: 'nav.newPatient' },
      { name: 'assessment', icon: 'clipboard', title: 'nav.assessment', needsPatient: true },
      { name: 'energy', icon: 'flame', title: 'nav.energy', needsPatient: true },
      { name: 'bodyComp', icon: 'activity', title: 'nav.bodyComp', needsPatient: true },
      { name: 'planner', icon: 'utensils', title: 'nav.planner', needsPatient: true },
      { name: 'copilot', icon: 'sparkles', title: 'nav.copilot', needsPatient: true },
      { name: 'followup', icon: 'calendar', title: 'nav.followup', needsPatient: true }
    ] },
    { section: 'nav.sec.library', items: [
      { name: 'foods', icon: 'apple', title: 'nav.foods' },
      { name: 'references', icon: 'book', title: 'nav.references' },
      { name: 'reports', icon: 'file-text', title: 'nav.reports', needsPatient: true }
    ] },
    { section: 'nav.sec.system', items: [
      { name: 'settings', icon: 'sliders', title: 'nav.settings' }
    ] }
  ];

  var state = {
    route: 'dashboard',
    patientId: null,
    patient: null,
    busy: false
  };

  function findRoute(name) {
    var out = null;
    ROUTES.forEach(function (sec) {
      sec.items.forEach(function (it) { if (it.name === name) out = it; });
    });
    return out;
  }

  /* ------------------------------------------------------------- sidebar --- */
  function renderSidebar() {
    var el = U.$('#sidebar');
    if (!el) return;
    var html = '<div class="side-brand">' +
      '<svg viewBox="0 0 64 64" width="34" height="34" aria-hidden="true">' +
      '<rect width="64" height="64" rx="14" fill="#1D2E52"/>' +
      '<path d="M14 42h10l6-16 6 22 5-14h9" fill="none" stroke="#C6A667" stroke-width="4" ' +
      'stroke-linecap="round" stroke-linejoin="round"/></svg>' +
      '<div class="side-brand-txt"><strong>' + U.esc(CN.t('app.name')) + '</strong>' +
      '<span>' + U.esc(CN.t('app.tagline')) + '</span></div></div>' +
      '<nav class="side-nav">';

    ROUTES.forEach(function (sec) {
      html += '<div class="side-sec">' + U.esc(CN.t(sec.section)) + '</div>';
      sec.items.forEach(function (it) {
        html += '<button class="nav-item' + (state.route === it.name ? ' is-active' : '') +
          '" data-route="' + it.name + '">' + CN.icon(it.icon, 17) +
          '<span>' + U.esc(CN.t(it.title)) + '</span>' +
          (it.needsPatient && !state.patientId ? '<span class="nav-badge">·</span>' : '') +
          '</button>';
      });
    });

    html += '</nav>';
    el.innerHTML = html;
  }

  /* -------------------------------------------------------------- topbar --- */
  function renderTopbar() {
    var el = U.$('#topbar');
    if (!el) return;
    var route = findRoute(state.route) || { title: 'nav.dashboard' };
    var p = state.patient;

    el.innerHTML =
      '<button class="btn btn-ghost btn-icon nav-toggle" id="nav-toggle" aria-label="' +
        U.esc(CN.t('topbar.menu')) + '">' + CN.icon('menu', 18) + '</button>' +
      '<div class="topbar-title"><strong>' + U.esc(CN.t(route.title)) + '</strong>' +
        '<span>' + U.esc(CN.t('app.name')) + (p ? ' · ' + U.esc(p.name) : '') + '</span></div>' +
      '<div class="topbar-spacer"></div>' +
      (p
        ? '<button class="patient-pill" id="patient-pill" title="' + U.esc(CN.t('topbar.switch')) + '">' +
          CN.icon('users', 15) + '<span>' + U.esc(p.name) + '</span></button>'
        : '<span class="patient-pill is-empty">' + CN.icon('users', 15) + '<span>' +
          U.esc(CN.t('topbar.noPatient')) + '</span></span>') +
      '<button class="btn btn-ghost btn-sm" id="lang-toggle" title="' + U.esc(CN.t('common.language')) + '">' +
        (CN.i18n.lang === 'ar' ? 'EN' : 'ع') + '</button>';
  }

  /* ----------------------------------------------------------- patient list */
  function openPatientPicker() {
    CN.store.all('patients').then(function (patients) {
      if (!patients.length) {
        CN.toast(CN.t('dash.noPatientsMsg'), 'warn');
        CN.app.go('newPatient');
        return;
      }
      patients = U.sortBy(patients, 'name', 'asc');
      var body = '<div class="field"><input type="search" id="pp-q" placeholder="' +
        U.esc(CN.t('pat.search')) + '"/></div><div id="pp-list" class="scroll-y"></div>';

      var ref = CN.modal({
        title: CN.t('topbar.switch'), body: body,
        actions: [
          { label: CN.t('common.none'), kind: 'ghost', onClick() { CN.app.setPatient(null); } },
          { label: CN.t('common.close'), kind: 'ghost' }
        ]
      });

      function draw(q) {
        var s = (q || '').trim().toLowerCase();
        var rows = patients.filter(function (p) {
          return !s || (p.name || '').toLowerCase().indexOf(s) !== -1 ||
            (p.code || '').toLowerCase().indexOf(s) !== -1;
        });
        var el = U.$('#pp-list', ref.node);
        if (!rows.length) { el.innerHTML = CN.empty(CN.t('pat.none'), ''); return; }
        el.innerHTML = rows.map(function (p) {
          return '<button class="btn btn-block" style="justify-content:flex-start;margin-bottom:.4rem" ' +
            'data-pick="' + U.esc(p.id) + '">' + CN.icon('users', 15) +
            ' <strong>' + U.esc(p.name) + '</strong> <span class="muted">' +
            U.esc(p.code || '') + '</span></button>';
        }).join('');
      }
      draw('');

      U.on(ref.node, 'input', '#pp-q', U.debounce(function (e, el) { draw(el.value); }, 150));
      U.on(ref.node, 'click', '[data-pick]', function (e, el) {
        CN.app.setPatient(el.getAttribute('data-pick'));
        ref.close();
      });
    });
  }

  /* -------------------------------------------------------------- copilot -- */
  var chat = [];   // conversation blocks for the current session

  var CopilotView = {
    title: 'nav.copilot',
    render(host, ctx) {
      var patient = ctx.patient;
      if (!patient) { ui.needPatient(host); return; }

      Promise.all([
        CN.store.byPatient('assessments', patient.id),
        CN.store.byPatient('measurements', patient.id),
        CN.store.settings(),
        CN.planHelpers.loadPlan(patient.id),
        CN.store.byPatient('followups', patient.id),
        CN.store.all('recipes')
      ]).then(function (r) {
        var approved = ui.approvedAssessment(r[0], patient.id);
        var settings = r[2];
        var plan = CN.planHelpers.activeVersion(r[3]);
        var followups = U.sortBy(r[4] || [], 'attendedAt', 'desc');
        // Recipes are referenceable in whatever the copilot drafts.
        CN.planner.setRecipeIndex(r[5] || []);
        var displayName = patient.name.split(' ')[0];

        var html = ui.pageHead('cp.title', 'cp.subtitle');

        // Context banner: exactly what the copilot can see.
        html += ui.card('cp.context',
          '<div class="chip-row mb1">' +
            ui.tag(patient.name) +
            (patient.goal ? ui.tag(CN.t('goal.' + patient.goal)) : '') +
            (patient.conditions || []).slice(0, 4).map(function (c) { return ui.tag(c); }).join('') +
            (patient.restrictions || []).map(function (x) {
              return ui.tag(CN.foods.allergenLabel(x.substance, CN.i18n.lang), x.kind === 'allergy' ? 'alert' : '');
            }).join('') +
            (approved ? ui.tag(CN.t('en.target') + ' ' + U.nf(approved.targetKcal, 0) + ' kcal', 'navy')
              : ui.tag(CN.t('en.notApproved'), 'gold')) +
            (plan ? ui.tag(CN.t('pl.versions') + ' ' + plan.versionNo) : '') +
          '</div>' +
          ui.notice(CN.t('cp.externalOff'), 'info'));

        // Examples
        html += ui.card('cp.examples',
          '<div class="chip-row">' + CN.copilot.examples(CN.i18n.lang).map(function (ex, i) {
            return '<button class="btn btn-sm" data-example="' + i + '">' + U.esc(ex) + '</button>';
          }).join('') + '</div>');

        html += '<div class="card"><div id="cp-log" class="scroll-y" style="max-height:52vh;min-height:120px">' +
          (chat.length ? chat.map(renderBlocks).join('')
            : '<p class="muted">' + U.esc(CN.t('cp.placeholder')) + '</p>') +
          '</div>' +
          '<div class="row" style="margin-top:.8rem">' +
          '<input type="text" id="cp-input" placeholder="' + U.esc(CN.t('cp.placeholder')) + '"/>' +
          '<button class="btn btn-primary" id="cp-send">' + CN.icon('sparkles', 16) + ' ' +
            U.esc(CN.t('cp.send')) + '</button>' +
          '<button class="btn btn-ghost btn-sm" id="cp-clear">' + CN.icon('trash', 15) + '</button>' +
          '</div></div>';

        host.innerHTML += html;

        function renderBlocks(res) {
          if (!res || !res.blocks) return '';
          return res.blocks.map(function (b) {
            if (b.kind === 'p') return '<p>' + U.esc(b.text) + '</p>';
            if (b.kind === 'ul') {
              return '<ul style="margin:0 0 .7rem 1.1rem;font-size:.87rem">' +
                b.items.map(function (i) { return '<li>' + U.esc(i) + '</li>'; }).join('') + '</ul>';
            }
            if (b.kind === 'notice') return ui.notice(b.text, b.tone);
            if (b.kind === 'external') {
              return '<div class="notice info"><strong>External model:</strong><br>' +
                U.esc(b.text) + '</div>';
            }
            if (b.kind === 'brief') {
              var t = CN.i18n.lang === 'ar' ? (b.brief.titleAr || b.brief.titleEn) : b.brief.titleEn;
              return '<div class="notice info"><strong>' + U.esc(t) + '</strong><br>' +
                U.esc(b.brief.summary) + '</div>';
            }
            return '';
          }).join('');
        }

        function appendQuestion(text) {
          var log = U.$('#cp-log');
          if (!log) return;
          if (log.querySelector('.muted') && !chat.length) log.innerHTML = '';
          log.insertAdjacentHTML('beforeend',
            '<div class="notice" style="border-inline-start-color:#14213D"><strong>' +
            U.esc(CN.t('common.clinician')) + ':</strong> ' + U.esc(text) + '</div>');
          log.scrollTop = log.scrollHeight;
        }

        function send() {
          var input = U.$('#cp-input');
          var text = (input.value || '').trim();
          if (!text) return;
          appendQuestion(text);
          input.value = '';

          var log = U.$('#cp-log');
          var id = 'pend_' + Date.now();
          log.insertAdjacentHTML('beforeend', '<div id="' + id + '" class="muted">' +
            U.esc(CN.t('cp.thinking')) + '</div>');
          log.scrollTop = log.scrollHeight;

          CN.copilot.respond(text, {
            patient: patient,
            assessment: approved,
            macros: approved ? approved.macros : null,
            settings: settings,
            plan: plan,
            followups: followups,
            history: chat
          }).then(function (res) {
            var pend = U.$('#' + id);
            if (pend) pend.remove();

            chat.push({ q: text, res: res });

            var htmlOut = renderBlocks(res);
            // Offer to carry the draft into the builder.
            if (res.draft && res.draft.ok) {
              htmlOut += '<div class="btn-row"><button class="btn btn-primary btn-sm" id="cp-open-planner">' +
                U.esc(CN.t('cp.openPlanner')) + '</button></div>';
              CopilotView._pendingDraft = res.draft;
            }
            log.insertAdjacentHTML('beforeend', htmlOut);
            log.scrollTop = log.scrollHeight;

            U.on(log, 'click', '#cp-open-planner', function () {
              var draft = CopilotView._pendingDraft;
              if (!draft) return;
              draft.status = 'pending_approval';
              CN.planHelpers.saveVersion(patient.id, draft).then(function () {
                chat = [];
                CN.toast(CN.t('cp.draftReady'));
                CN.app.go('planner');
              });
            });
          });
        }

        U.on(host, 'click', '#cp-send', send);
        U.on(host, 'keydown', '#cp-input', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); send(); }
        });
        U.on(host, 'click', '[data-example]', function (e, el) {
          var list = CN.copilot.examples(CN.i18n.lang);
          var v = list[Number(el.getAttribute('data-example'))];
          if (v) { U.$('#cp-input').value = v; U.$('#cp-input').focus(); }
        });
        U.on(host, 'click', '#cp-clear', function () {
          chat = [];
          U.$('#cp-log').innerHTML = '<p class="muted">' + U.esc(CN.t('cp.placeholder')) + '</p>';
        });

        if (patient) {
          var greet = CN.i18n.lang === 'ar'
            ? 'اختر تعليمًا من الأمثلة أو اكتب تعليمًا إكلينيكيًا.'
            : 'Pick an example instruction, or type a clinical instruction.';
          var logEl = U.$('#cp-log');
          if (logEl && !chat.length) logEl.innerHTML = '<p class="muted">' + U.esc(greet) + '</p>';
        }
      });
    }
  };

  /* ---------------------------------------------------------- first run ---- */
  /**
   * The application ALWAYS opens on the Dashboard. Nothing is demanded of the
   * user up front — no setup wizard, no forced patient registration, no modal
   * blocking the interface. When the clinic identity is still unset the
   * Dashboard shows a dismissible prompt instead, and Settings holds the full
   * form for anyone who wants to complete it.
   *
   * This replaced a non-dismissable first-run modal, which meant a new user (or
   * anyone opening the link on a phone) met a form before ever seeing the app.
   */
  function needsClinicIdentity() {
    return CN.store.settings().then(function (s) {
      if (!s) return true;
      var name = String(s.clinicName || '').trim();
      return !name || name === 'NutriClinic Pro';
    });
  }

  /* ------------------------------------------------------------------ app -- */
  var app = {
    get patientId() { return state.patientId; },
    get patient() { return state.patient; },

    /**
     * Navigate to a module by name.
     * `focus` is an optional CSS selector to scroll to and highlight once the
     * view has rendered — used by the Dashboard's quick-access tiles to reach
     * a section that lives inside a larger module.
     */
    go(name, focus) {
      var r = findRoute(name);
      if (!r || r.needsPatient && !state.patientId) {
        if (r && r.needsPatient && !state.patientId) {
          ui.needPatient(U.$('#view'));
          openPatientPicker();
          return;
        }
      }
      state.route = name;
      state.focus = focus || null;
      try { localStorage.setItem('cn.route', name); } catch (e) { /* ignore */ }
      renderSidebar();
      renderTopbar();
      app.renderCurrent();
      app.applyFocus();
    },

    /**
     * Scroll to and briefly highlight a target.
     * Views render asynchronously, so this retries until the element appears
     * rather than silently doing nothing.
     */
    applyFocus() {
      var sel = state.focus;
      if (!sel) return;
      state.focus = null;
      var tries = 0;
      (function attempt() {
        var el = U.$(sel);
        if (el) {
          try { el.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
          catch (e) { el.scrollIntoView(); }
          el.style.transition = 'box-shadow .4s ease';
          el.style.boxShadow = '0 0 0 3px rgba(198,166,103,.6)';
          setTimeout(function () { el.style.boxShadow = ''; }, 1800);
          return;
        }
        if (++tries < 12) setTimeout(attempt, 120);
      })();
    },

    /** Re-render the active route, keeping scroll position where possible. */
    refresh() {
      var y = window.scrollY;
      app.renderCurrent();
      window.scrollTo(0, y);
    },

    renderCurrent() {
      var view = CN.views[state.route];
      var host = U.$('#view');
      if (!host) return;
      if (!view) { host.innerHTML = CN.empty('Module not found: ' + state.route, ''); return; }

      var ctx = { patient: state.patient, patientId: state.patientId };
      try {
        view.render(host, ctx);
      } catch (e) {
        host.innerHTML = ui.pageHead(view.title || state.route) +
          ui.notice('This screen failed to render: ' + (e && e.message ? e.message : e), 'alert');
        if (window.console) console.error(e);
      }
    },

    setPatient(id) {
      if (!id) {
        state.patientId = null;
        state.patient = null;
        try { localStorage.removeItem('cn.patientId'); } catch (e) { /* ignore */ }
        renderSidebar(); renderTopbar(); app.refresh();
        return Promise.resolve();
      }

      // In server mode the read goes through the audited function, so the access
      // and its audit entry are one transaction and cannot be separated by a
      // client. If that call fails the clinic still needs to work, so it falls
      // back to a plain read AND says so rather than failing quietly.
      var load;
      if (CN.store.isRemote() && CN.backend) {
        // Calls the security-definer function directly. The server returns the
        // whole row as jsonb ({ id, clinic_id, patient_id, storage_path, data }),
        // which is mapped here exactly as the REST adapter would map it.
        load = CN.backend.rpc('patient_read', { p_id: String(id) }).then(function (row) {
          if (!row) return null;
          var obj = Object.assign({}, row.data || {});
          obj.id = row.id;
          if (row.patient_id) obj.patientId = row.patient_id;
          if (row.storage_path) obj.storagePath = row.storage_path;
          if (row.created_at) obj.createdAt = obj.createdAt || row.created_at;
          return obj;
        }).catch(function (e) {
          if (window.console) {
            console.warn('[NutriClinic] audited read unavailable, falling back:', e && e.message);
          }
          CN.toast('Record opened without the audit log — ' +
            ((e && e.message) || 'server unavailable'), 'warn', 8000);
          return CN.store.get('patients', id);
        });
      } else {
        load = CN.store.get('patients', id);
      }

      return load.then(function (p) {
        if (!p) return;
        state.patientId = p.id;
        state.patient = p;
        try { localStorage.setItem('cn.patientId', p.id); } catch (e) { /* ignore */ }
        renderSidebar(); renderTopbar(); app.refresh();
      });
    },

    openPatient(id, route) {
      app.setPatient(id).then(function () {
        if (route) app.go(route);
      });
    },

    /** Restore the last patient if it still exists. */
    restorePatient() {
      var id = null;
      try { id = localStorage.getItem('cn.patientId'); } catch (e) { /* ignore */ }
      if (!id) return Promise.resolve();
      return CN.store.get('patients', id).then(function (p) {
        if (p) { state.patientId = p.id; state.patient = p; }
      });
    }
  };
  CN.app = app;
  CN.app.needsClinicIdentity = needsClinicIdentity;
  // Exported so the test harness can assert route coverage without a DOM.
  CN.app.ROUTES = ROUTES;
  CN.app.findRoute = findRoute;
  CN.views.copilot = CopilotView;

  /* ----------------------------------------------------------------- boot -- */
  function boot() {
    CN.i18n.restore();

    CN.store.ready().then(function () {
      // Connect the optional server backend before the first render, so the
      // Dashboard reflects shared records when a session already exists.
      return CN.store.initBackend();
    }).then(function () {
      return app.restorePatient();
    }).then(function () {
      var bootEl = U.$('#boot');
      if (bootEl) bootEl.remove();
      var appEl = U.$('#app');
      if (appEl) appEl.removeAttribute('hidden');

      var saved = null;
      try { saved = localStorage.getItem('cn.route'); } catch (e) { /* ignore */ }
      state.route = (saved && findRoute(saved)) ? saved : 'dashboard';

      renderSidebar();
      renderTopbar();
      app.renderCurrent();

      CN.bus.on('lang', function () {
        renderSidebar(); renderTopbar(); app.renderCurrent();
      });
      CN.bus.on('data', function () {
        renderSidebar(); renderTopbar();
      });

      /* --- failure visibility ------------------------------------------------
         Views call store.put() and mostly ignore the returned promise, so a
         failed save would otherwise be completely silent. Announcing failures
         centrally means a clinician can never believe a record was saved when
         it was not. */
      CN.bus.on('store-error', function (info) {
        var verb = info.action === 'read' ? 'read'
          : (info.action === 'delete' ? 'delete' : 'save');
        var why = (info.error && info.error.message) || 'unknown error';
        CN.toast('Could not ' + verb + ' in "' + info.store + '": ' + why, 'alert', 9000);
      });

      // Backstop for any rejection that is not routed through the store.
      window.addEventListener('unhandledrejection', function (ev) {
        var r = ev.reason;
        var msg = (r && r.message) ? r.message : String(r);
        if (window.console) console.error('[NutriClinic] unhandled rejection:', r);
        CN.toast('An operation failed: ' + msg, 'alert', 9000);
      });

      return null;
    }).catch(function (e) {
      var bootEl = U.$('#boot');
      if (bootEl) {
        bootEl.innerHTML = '<div class="boot-txt" style="color:#800020">' +
          U.esc('The application failed to start: ' + (e && e.message ? e.message : e)) + '</div>';
      }
      if (window.console) console.error(e);
    });
  }

  /* Delegated shell handlers — attached once, outside the re-rendered markup. */
  document.addEventListener('click', function (e) {
    var navBtn = e.target.closest('[data-route]');
    if (navBtn) {
      CN.app.go(navBtn.getAttribute('data-route'));
      var sb = U.$('#sidebar');
      if (sb) sb.classList.remove('is-open');
      document.body.classList.remove('nav-open');
      return;
    }
    if (e.target.closest('#nav-toggle')) {
      var sb2 = U.$('#sidebar');
      if (sb2) {
        sb2.classList.toggle('is-open');
        document.body.classList.toggle('nav-open', sb2.classList.contains('is-open'));
      }
      return;
    }
    // On a phone the sidebar is an overlay. Tapping the content behind it
    // should dismiss it, or there is no way back.
    if (e.target.closest('#view')) {
      var sbOpen = U.$('#sidebar');
      if (sbOpen && sbOpen.classList.contains('is-open')) {
        sbOpen.classList.remove('is-open');
        document.body.classList.remove('nav-open');
        return;
      }
    }
    if (e.target.closest('#patient-pill')) { openPatientPicker(); return; }
    if (e.target.closest('#lang-toggle')) {
      CN.i18n.setLang(CN.i18n.lang === 'ar' ? 'en' : 'ar');
      return;
    }
    // A click on the scrim behind the mobile sidebar closes it.
    if (e.target.classList && e.target.classList.contains('scrim')) {
      var sb3 = U.$('#sidebar');
      if (sb3) sb3.classList.remove('is-open');
      document.body.classList.remove('nav-open');
    }
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
