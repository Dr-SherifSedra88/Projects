/* ==========================================================================
   NutriClinic Pro — core.js
   Utilities, icon set, toasts, modal/drawer layer, confirmation dialogs.
   Loads first. Must not depend on any other module.
   ========================================================================== */
(function () {
  'use strict';
  var CN = (window.CN = window.CN || {});

  /* ------------------------------------------------------------------ util */
  var util = {
    $(sel, root) { return (root || document).querySelector(sel); },
    $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); },

    /** Escape untrusted text before it enters innerHTML. Always use this. */
    esc(v) {
      if (v === null || v === undefined) return '';
      return String(v)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    },

    uid(prefix) {
      return (prefix || 'id') + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    },

    /** Round half-away-from-zero to `dp` decimals; guards NaN/Infinity. */
    round(v, dp) {
      var f = Math.pow(10, dp || 0);
      var n = Number(v);
      if (!isFinite(n)) return null;
      return Math.round((n + (n >= 0 ? 1 : -1) * Number.EPSILON) * f) / f;
    },

    clamp(v, lo, hi) { return Math.min(hi, Math.max(lo, v)); },

    /** Coerce to number; returns null for blank/invalid input (never 0). */
    parseNum(v) {
      if (v === '' || v === null || v === undefined) return null;
      var n = Number(String(v).replace(/[^\d.\-]/g, ''));
      return isFinite(n) ? n : null;
    },

    nf(v, dp) {
      var n = Number(v);
      if (!isFinite(n)) return '—';
      return n.toLocaleString('en-US', {
        minimumFractionDigits: dp || 0, maximumFractionDigits: dp === undefined ? 0 : dp
      });
    },

    sum(arr) { return arr.reduce(function (a, b) { return a + (Number(b) || 0); }, 0); },
    mean(arr) { return arr.length ? util.sum(arr) / arr.length : null; },

    min(arr) { return arr.length ? Math.min.apply(null, arr) : null; },
    max(arr) { return arr.length ? Math.max.apply(null, arr) : null; },

    deepClone(o) { return o === undefined ? o : JSON.parse(JSON.stringify(o)); },

    range(n) { var a = []; for (var i = 0; i < n; i++) a.push(i); return a; },

    todayISO() { return new Date().toISOString().slice(0, 10); },

    /** Parse a YYYY-MM-DD string as a *local* date to avoid UTC drift. */
    parseDate(iso) {
      if (!iso) return null;
      var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso));
      if (!m) return null;
      return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
    },

    fmtDate(iso, opts) {
      var d = (iso instanceof Date) ? iso : util.parseDate(iso);
      if (!d || isNaN(d)) return '—';
      try {
        return d.toLocaleDateString((CN.i18n && CN.i18n.lang === 'ar') ? 'ar-EG' : 'en-GB',
          opts || { day: '2-digit', month: 'short', year: 'numeric' });
      } catch (e) { return d.toISOString().slice(0, 10); }
    },

    /** Whole years between dob and today. Null-safe. */
    ageFrom(dob) {
      var d = util.parseDate(dob);
      if (!d || isNaN(d)) return null;
      var t = new Date(), y = t.getFullYear() - d.getFullYear(), m = t.getMonth() - d.getMonth();
      if (m < 0 || (m === 0 && t.getDate() < d.getDate())) y--;
      return y >= 0 ? y : null;
    },

    /** Days between two dates (b - a), local-safe. */
    daysBetween(aISO, bISO) {
      var a = util.parseDate(aISO), b = util.parseDate(bISO);
      if (!a || !b) return null;
      return Math.round((b - a) / 86400000);
    },

    debounce(fn, ms) {
      var t;
      return function () {
        var args = arguments, self = this;
        clearTimeout(t);
        t = setTimeout(function () { fn.apply(self, args); }, ms === undefined ? 220 : ms);
      };
    },

    /** Delegated listener. Handler receives (event, matchedElement). */
    on(root, evt, sel, fn) {
      root.addEventListener(evt, function (e) {
        var t = e.target.closest ? e.target.closest(sel) : null;
        if (t && root.contains(t)) fn.call(t, e, t);
      });
    },

    /** Trigger a client-side file download of text content. */
    download(filename, text, mime) {
      var blob = new Blob([text], { type: mime || 'text/plain;charset=utf-8' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url; a.download = filename;
      document.body.appendChild(a); a.click();
      setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 0);
    },

    readFile(file) {
      return new Promise(function (res, rej) {
        var r = new FileReader();
        r.onload = function () { res(r.result); };
        r.onerror = function () { rej(r.error); };
        r.readAsText(file);
      });
    },

    sortBy(arr, key, dir) {
      var d = dir === 'desc' ? -1 : 1;
      return arr.slice().sort(function (a, b) {
        var x = a[key], y = b[key];
        if (typeof x === 'string' || typeof y === 'string') {
          x = String(x || '').toLowerCase(); y = String(y || '').toLowerCase();
        }
        if (x < y) return -1 * d;
        if (x > y) return 1 * d;
        return 0;
      });
    },

    groupBy(arr, fn) {
      return arr.reduce(function (acc, item) {
        var k = fn(item);
        (acc[k] = acc[k] || []).push(item);
        return acc;
      }, {});
    },

    /** "initial(s)" helper for avatar placeholders. */
    initials(name) {
      var parts = String(name || '').trim().split(/\s+/).filter(Boolean);
      if (!parts.length) return '?';
      return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : '')).toUpperCase();
    }
  };
  CN.util = util;

  /* --------------------------------------------------------------- i18n shim
     Real implementation lives in i18n.js, which loads after this file. This
     proxy keeps core working (and untranslated-safe) either way.            */
  CN.t = function (key, vars) {
    return (CN.i18n && typeof CN.i18n.t === 'function') ? CN.i18n.t(key, vars) : key;
  };

  /* ------------------------------------------------------------------- bus */
  var handlers = {};
  CN.bus = {
    on(evt, fn) { (handlers[evt] = handlers[evt] || []).push(fn); return function () { CN.bus.off(evt, fn); }; },
    off(evt, fn) { handlers[evt] = (handlers[evt] || []).filter(function (h) { return h !== fn; }); },
    emit(evt, data) { (handlers[evt] || []).slice().forEach(function (fn) { try { fn(data); } catch (e) { console.error(e); } }); }
  };

  /* ----------------------------------------------------------------- icons */
  var ICONS = {
    grid: '<path d="M3 3h7v8H3zM14 3h7v5h-7zM14 11h7v10h-7zM3 14h7v7H3z"/>',
    users: '<path d="M16 20v-1.5a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4V20"/><circle cx="9.5" cy="7" r="3.5"/><path d="M21 20v-1.5a4 4 0 0 0-3-3.87"/><path d="M16.5 3.6a4 4 0 0 1 0 7.75"/>',
    'user-plus': '<path d="M15 20v-1.5a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4V20"/><circle cx="8.5" cy="7" r="3.5"/><path d="M19 8v6M22 11h-6"/>',
    clipboard: '<path d="M9 4h6v3H9z"/><path d="M15 5.5h2a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V6.5a1 1 0 0 1 1-1h2"/><path d="M9 12h6M9 16h4"/>',
    flame: '<path d="M12 22c3.9 0 6-2.6 6-5.8 0-3.6-3-5.2-3-8.2 0-1.6.6-2.6.6-2.6S13 6 11 8.5 9 12 9 12s-.6-.8-1-2c-1 1.4-2 3-2 5.2C6 19.4 8.1 22 12 22z"/>',
    activity: '<path d="M3 12h4l3 8 4-16 3 8h4"/>',
    utensils: '<path d="M7 3v7a2 2 0 0 0 4 0V3"/><path d="M9 10v11"/><path d="M16 3c-1.7 0-3 1.3-3 3v5h3"/><path d="M16 11v10"/>',
    sparkles: '<path d="M12 3l1.6 4.4L18 9l-4.4 1.6L12 15l-1.6-4.4L6 9l4.4-1.6z"/><path d="M18 14.5l.7 1.9 1.8.6-1.8.7-.7 1.8-.8-1.8-1.7-.7 1.7-.6z"/>',
    calendar: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    apple: '<path d="M12 8c-2.5-2-6-1-6 3 0 4 3 8 6 8s6-4 6-8c0-4-3.5-5-6-3z"/><path d="M12 8V5"/><path d="M12 5c1 0 1.8-.6 2.2-1.5"/>',
    book: '<path d="M4 5a2 2 0 0 1 2-2h12v18H6a2 2 0 0 1-2-2z"/><path d="M8 3v18"/>',
    'file-text': '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13h6M9 17h4"/>',
    sliders: '<path d="M4 7h9M17 7h3M4 12h3M11 12h9M4 17h7M15 17h5"/><circle cx="15" cy="7" r="2"/><circle cx="9" cy="12" r="2"/><circle cx="13" cy="17" r="2"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M9 7V5h6v2"/><path d="M6 7l1 13h10l1-13"/>',
    pencil: '<path d="M4 20h4L20 8l-4-4L4 16z"/><path d="M14 6l4 4"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    'chevron-down': '<path d="M6 9l6 6 6-6"/>',
    'chevron-left': '<path d="M15 6l-6 6 6 6"/>',
    'chevron-right': '<path d="M9 6l6 6-6 6"/>',
    check: '<path d="M5 13l4 4L19 7"/>',
    alert: '<path d="M12 3l9 16H3z"/><path d="M12 9v5M12 17h.01"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 20h16"/>',
    printer: '<path d="M7 8V3h10v5"/><rect x="4" y="8" width="16" height="8" rx="2"/><path d="M7 14h10v7H7z"/>',
    swap: '<path d="M7 4v13M4 14l3 3 3-3"/><path d="M17 20V7M14 10l3-3 3 3"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    filter: '<path d="M3 5h18l-7 8v6l-4 2v-8z"/>',
    save: '<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h8V3"/><path d="M8 14h8v7H8z"/>',
    database: '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
    refresh: '<path d="M20 12a8 8 0 1 1-2.3-5.7"/><path d="M20 4v5h-5"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    target: '<circle cx="12" cy="12" r="8"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
    scale: '<path d="M12 4v16"/><path d="M6 8h12"/><path d="M6 8l-3 7h6zM18 8l-3 7h6z"/>',
    copy: '<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/>',
    upload: '<path d="M12 21V9M7 14l5-5 5 5"/><path d="M4 4h16"/>',
    lock: '<rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/>',
    shield: '<path d="M12 3l8 3v6c0 5-3.5 8.5-8 9.5C7.5 20.5 4 17 4 12V6z"/>',
    lightbulb: '<path d="M12 3a6 6 0 0 0-3.5 10.9c.5.4.8 1 .8 1.6V16h5.4v-.5c0-.6.3-1.2.8-1.6A6 6 0 0 0 12 3z"/><path d="M9.5 19h5M10.5 21.5h3"/>',
    list: '<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>',
    heart: '<path d="M12 20s-7-4.5-7-9.5A4.5 4.5 0 0 1 12 7a4.5 4.5 0 0 1 7 3.5C19 15.5 12 20 12 20z"/>',
    droplet: '<path d="M12 3s6 6.5 6 10.5a6 6 0 0 1-12 0C6 9.5 12 3 12 3z"/>',
    pill: '<path d="M14 4l6 6-10 10-6-6z"/><path d="M8 10l6 6"/>',
    flask: '<path d="M9 3h6v5l4 9a2 2 0 0 1-1.8 3H6.8A2 2 0 0 1 5 17l4-9z"/><path d="M7.5 14h9"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5z"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5L19 19M19 5l-1.5 1.5M6.5 17.5L5 19"/>',
    'arrow-up': '<path d="M12 19V5M6 11l6-6 6 6"/>',
    'arrow-down': '<path d="M12 5v14M6 13l6 6 6-6"/>',
    'log-out': '<path d="M15 4h3a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2h-3"/><path d="M10 8l-4 4 4 4M3 12h11"/>',
    eye: '<path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6-10-6-10-6z"/><circle cx="12" cy="12" r="2.5"/>',
    star: '<path d="M12 3l2.7 5.7 6.3.9-4.5 4.4 1 6.2-5.5-2.9-5.5 2.9 1-6.2L3 9.6l6.3-.9z"/>',
    dot: '<circle cx="12" cy="12" r="4"/>'
  };

  /** Render an inline SVG icon. All icons are stroke-based, size-agnostic. */
  CN.icon = function (name, size) {
    var body = ICONS[name] || ICONS.dot;
    var s = size || 18;
    return '<svg viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" ' +
      'stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" ' +
      'aria-hidden="true" focusable="false">' + body + '</svg>';
  };
  CN.icons = ICONS;

  /* ---------------------------------------------------------------- toasts */
  CN.toast = function (msg, type, ms) {
    var host = util.$('#toasts');
    if (!host) return;
    var el = document.createElement('div');
    el.className = 'toast ' + (type || 'ok');
    var ic = type === 'alert' ? 'alert' : (type === 'warn' ? 'alert' : 'check');
    el.innerHTML = CN.icon(ic, 16) + '<div>' + util.esc(msg) + '</div>';
    host.appendChild(el);
    setTimeout(function () {
      el.style.transition = 'opacity .2s ease';
      el.style.opacity = '0';
      setTimeout(function () { el.remove(); }, 220);
    }, ms || 3200);
  };

  /* ------------------------------------------------------------ layer host */
  var openLayers = [];

  function layerHost() { return util.$('#layer'); }

  function mount(node, opts) {
    var host = layerHost();
    if (!host) return;
    host.hidden = false;
    var scrim = document.createElement('div');
    scrim.className = 'scrim';
    scrim.addEventListener('click', function () {
      if (opts && opts.dismissable === false) return;
      closeTop();
    });
    host.appendChild(scrim);
    host.appendChild(node);
    document.body.style.overflow = 'hidden';
    openLayers.push({ node: node, scrim: scrim });

    // Focus the first meaningful control for keyboard users.
    setTimeout(function () {
      var focusable = node.querySelector(
        'input:not([type=hidden]),select,textarea,button:not(.js-close)');
      if (focusable) focusable.focus();
      else { node.setAttribute('tabindex', '-1'); node.focus(); }
    }, 20);

    return { node: node, scrim: scrim };
  }

  function closeTop() {
    var top = openLayers.pop();
    if (!top) return;
    top.node.remove();
    top.scrim.remove();
    if (!openLayers.length) {
      var host = layerHost();
      if (host) host.hidden = true;
      document.body.style.overflow = '';
    }
    var prev = openLayers[openLayers.length - 1];
    if (prev) prev.node.focus();
  }
  CN.closeLayer = function () { closeTop(); };

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && openLayers.length) closeTop();
  });

  /* ---------------------------------------------------------------- modal  */
  /**
   * CN.modal({ title, body, actions:[{label,kind,onClick,close}], wide, dismissable })
   * `body` is trusted HTML — escape any interpolated data with CN.util.esc.
   */
  CN.modal = function (o) {
    o = o || {};
    var node = document.createElement('div');
    node.className = 'modal' + (o.wide ? ' wide' : '');
    node.setAttribute('role', 'dialog');
    node.setAttribute('aria-modal', 'true');

    var html = '<div class="modal-head"><h3>' + util.esc(o.title || '') + '</h3>' +
      '<button type="button" class="btn btn-ghost btn-icon js-close" aria-label="' +
      util.esc(CN.t('common.close')) + '">' + CN.icon('x', 18) + '</button></div>';
    html += '<div class="modal-body">' + (o.body || '') + '</div>';

    var actions = o.actions || [{ label: CN.t('common.close'), kind: 'ghost' }];
    html += '<div class="modal-foot">';
    actions.forEach(function (a, i) {
      html += '<button type="button" class="btn btn-' + (a.kind || 'ghost') +
        '" data-act="' + i + '">' + util.esc(a.label) + '</button>';
    });
    html += '</div>';
    node.innerHTML = html;

    mount(node, o);

    node.addEventListener('click', function (e) {
      var closeBtn = e.target.closest('.js-close');
      if (closeBtn) { closeTop(); return; }
      var act = e.target.closest('[data-act]');
      if (!act) return;
      var a = actions[Number(act.getAttribute('data-act'))];
      var keep = a && a.onClick ? a.onClick(node) : undefined;
      if (a && a.close === false) return;
      if (keep === false) return;
      closeTop();
    });

    return { node: node, close: closeTop };
  };

  /* --------------------------------------------------------------- drawer  */
  /** CN.drawer({ title, body, footer, actions }) — side panel, RTL-aware. */
  CN.drawer = function (o) {
    o = o || {};
    var node = document.createElement('div');
    node.className = 'drawer';
    node.setAttribute('role', 'dialog');
    node.setAttribute('aria-modal', 'true');

    var html = '<div class="drawer-head"><h3>' + util.esc(o.title || '') + '</h3>' +
      '<button type="button" class="btn btn-ghost btn-icon js-close" aria-label="' +
      util.esc(CN.t('common.close')) + '">' + CN.icon('x', 18) + '</button></div>';
    html += '<div class="drawer-body">' + (o.body || '') + '</div>';
    var actions = o.actions || [];
    if (actions.length) {
      html += '<div class="drawer-foot">';
      actions.forEach(function (a, i) {
        html += '<button type="button" class="btn btn-' + (a.kind || 'ghost') +
          '" data-act="' + i + '">' + util.esc(a.label) + '</button>';
      });
      html += '</div>';
    }
    node.innerHTML = html;
    mount(node, o);

    node.addEventListener('click', function (e) {
      if (e.target.closest('.js-close')) { closeTop(); return; }
      var act = e.target.closest('[data-act]');
      if (!act) return;
      var a = actions[Number(act.getAttribute('data-act'))];
      var keep = a && a.onClick ? a.onClick(node) : undefined;
      if (a && a.close === false) return;
      if (keep === false) return;
      closeTop();
    });

    return { node: node, close: closeTop };
  };

  /* -------------------------------------------------------------- confirm  */
  /** CN.confirm({title, message, confirmLabel, kind}) -> Promise<boolean> */
  CN.confirm = function (o) {
    o = o || {};
    return new Promise(function (resolve) {
      var settled = false;
      var finish = function (v) { if (!settled) { settled = true; resolve(v); } };
      CN.modal({
        title: o.title || CN.t('common.confirm'),
        body: '<p>' + util.esc(o.message || '') + '</p>',
        actions: [
          { label: o.cancelLabel || CN.t('common.cancel'), kind: 'ghost',
            onClick() { finish(false); } },
          { label: o.confirmLabel || CN.t('common.confirm'), kind: o.kind || 'accent',
            onClick() { finish(true); } }
        ]
      });
      // Dismissing via scrim/Esc counts as a decline.
      var host = layerHost();
      var obs = new MutationObserver(function () {
        if (!openLayers.length) { finish(false); obs.disconnect(); }
      });
      obs.observe(host, { childList: true });
    });
  };

  /* -------------------------------------------------- small render helpers */
  /** Tabular <dl> from [{k,v}] pairs. */
  CN.kv = function (pairs) {
    return '<dl class="kv">' + pairs.map(function (p) {
      return '<dt>' + util.esc(p.k) + '</dt><dd>' + (p.raw ? p.v : util.esc(p.v)) + '</dd>';
    }).join('') + '</dl>';
  };

  /** Consistent empty-state block. */
  CN.empty = function (title, msg, actionsHtml) {
    return '<div class="empty">' + CN.icon('info', 26) +
      '<h4>' + util.esc(title) + '</h4>' +
      '<p>' + util.esc(msg || '') + '</p>' + (actionsHtml || '') + '</div>';
  };

  /** Select options from [{value,label}]. */
  CN.options = function (list, selected) {
    return list.map(function (o) {
      return '<option value="' + util.esc(o.value) + '"' +
        (String(o.value) === String(selected) ? ' selected' : '') + '>' +
        util.esc(o.label) + '</option>';
    }).join('');
  };
})();
