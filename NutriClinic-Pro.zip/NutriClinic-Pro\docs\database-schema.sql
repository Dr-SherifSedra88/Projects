-- ============================================================================
--  NutriClinic Pro — PostgreSQL schema (production server path)
-- ============================================================================
--
--  STATUS:  *** NOT IMPLEMENTED ***  DESIGN TARGET ONLY.
--
--  The delivered build is a static, single-clinician prototype whose only
--  datastore is browser IndexedDB. The original brief (§19) requires a
--  production database and states: "Do not rely on browser localStorage as the
--  primary database for clinical records"; §21 names PostgreSQL. Neither is
--  present in the delivered artifact.
--
--  This file is the migration target for that requirement. Nothing in this
--  repository executes it. Do not describe it as a shipped feature.
--
--  Design rules carried from the brief:
--    - History is preserved, never overwritten (append-only clinical facts).
--    - All clinical numbers are computed by deterministic application code and
--      stored alongside the inputs and the formula identity that produced them,
--      so any number is reproducible and auditable.
--    - Patient-specific information ranks above guideline above database above
--      uploaded material above general web sources (evidence hierarchy §11).
--    - De-identification is a first-class concern (§12, §19).
--
--  Target: PostgreSQL 15+.
-- ============================================================================

BEGIN;

CREATE SCHEMA IF NOT EXISTS nutriclinic;
SET search_path TO nutriclinic, public;

-- ---------------------------------------------------------------------------
-- Extensions
-- ---------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid(), digest()
CREATE EXTENSION IF NOT EXISTS citext;     -- case-insensitive email

-- ---------------------------------------------------------------------------
-- Enumerated types
-- ---------------------------------------------------------------------------
CREATE TYPE sex_t             AS ENUM ('female', 'male', 'other', 'undisclosed');
CREATE TYPE user_role_t       AS ENUM ('admin', 'clinician', 'assistant', 'reception', 'auditor');
CREATE TYPE restriction_kind_t AS ENUM ('allergy', 'intolerance', 'preference', 'religious', 'medical');
CREATE TYPE lab_flag_t        AS ENUM ('low', 'normal', 'high', 'critical', 'unknown');
CREATE TYPE plan_status_t     AS ENUM ('draft', 'pending_approval', 'approved', 'superseded', 'archived');
CREATE TYPE goal_t            AS ENUM ('weight_loss', 'maintenance', 'weight_gain', 'therapeutic');
CREATE TYPE formula_t         AS ENUM ('mifflin_st_jeor', 'harris_benedict', 'harris_benedict_revised', 'device_measured', 'manual');
CREATE TYPE evidence_tier_t   AS ENUM ('patient_specific', 'clinical_guideline', 'food_database', 'clinician_upload', 'web_source');
CREATE TYPE consent_kind_t    AS ENUM ('treatment', 'data_processing', 'research', 'imaging');

-- ---------------------------------------------------------------------------
-- Clinics, users, roles
-- ---------------------------------------------------------------------------
CREATE TABLE clinic (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name            text NOT NULL,
  logo_asset_id   uuid,                       -- -> asset(id)
  address         text,
  phone           text,
  email           citext,
  currency        text NOT NULL DEFAULT 'EGP',
  locale          text NOT NULL DEFAULT 'en' CHECK (locale IN ('en', 'ar')),
  settings        jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE app_user (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id       uuid NOT NULL REFERENCES clinic(id) ON DELETE RESTRICT,
  email           citext NOT NULL UNIQUE,
  full_name       text NOT NULL,
  professional_title text,
  role            user_role_t NOT NULL DEFAULT 'clinician',
  password_hash   text NOT NULL,              -- Argon2id; never a raw digest
  mfa_secret_enc  bytea,                      -- encrypted at rest
  is_active       boolean NOT NULL DEFAULT true,
  last_login_at   timestamptz,
  failed_attempts smallint NOT NULL DEFAULT 0,
  locked_until    timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON app_user (clinic_id, role) WHERE is_active;

-- Which clinician may see which patient. Absent row = no access.
CREATE TABLE patient_access (
  patient_id      uuid NOT NULL,
  user_id         uuid NOT NULL REFERENCES app_user(id) ON DELETE CASCADE,
  granted_by      uuid REFERENCES app_user(id),
  granted_at      timestamptz NOT NULL DEFAULT now(),
  revoked_at      timestamptz,
  PRIMARY KEY (patient_id, user_id)
);

-- ---------------------------------------------------------------------------
-- Patients — demographics
-- ---------------------------------------------------------------------------
CREATE TABLE patient (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id       uuid NOT NULL REFERENCES clinic(id) ON DELETE RESTRICT,
  patient_code    text NOT NULL,              -- human-facing unique Patient ID
  full_name       text NOT NULL,
  date_of_birth   date,
  sex             sex_t NOT NULL DEFAULT 'undisclosed',
  phone           text,
  email           citext,
  occupation      text,
  address         text,
  emergency_contact jsonb,                    -- {name, phone, relation}
  registered_at   timestamptz NOT NULL DEFAULT now(),
  is_active       boolean NOT NULL DEFAULT true,
  -- pseudo-identifier used for any external call; real identifiers never leave
  deid_token      uuid NOT NULL DEFAULT gen_random_uuid(),
  created_by      uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (clinic_id, patient_code)
);
CREATE INDEX ON patient (clinic_id, is_active);
CREATE INDEX ON patient (lower(full_name));   -- no pg_trgm dependency; swap for GIN if needed

-- Age is derived, never stored, so it cannot go stale.
CREATE OR REPLACE VIEW patient_v AS
SELECT p.*,
       date_part('year', age(current_date, p.date_of_birth))::int AS age_years
FROM patient p;

-- ---------------------------------------------------------------------------
-- Clinician-defined custom fields (brief §3: extensible without code changes)
-- ---------------------------------------------------------------------------
CREATE TABLE custom_field (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id       uuid NOT NULL REFERENCES clinic(id) ON DELETE CASCADE,
  key             text NOT NULL,
  label_en        text NOT NULL,
  label_ar        text,
  data_type       text NOT NULL CHECK (data_type IN ('text','number','date','boolean','select')),
  options         jsonb,
  applies_to      text NOT NULL DEFAULT 'patient' CHECK (applies_to IN ('patient','measurement','follow_up')),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (clinic_id, key)
);

CREATE TABLE custom_field_value (
  custom_field_id uuid NOT NULL REFERENCES custom_field(id) ON DELETE CASCADE,
  entity_id       uuid NOT NULL,
  value_text      text,
  value_number    numeric,
  value_date      date,
  value_boolean   boolean,
  PRIMARY KEY (custom_field_id, entity_id)
);

-- ---------------------------------------------------------------------------
-- Medical history — append-only clinical facts
-- ---------------------------------------------------------------------------
CREATE TABLE condition (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  label           text NOT NULL,              -- coded vocab can be layered later
  is_current      boolean NOT NULL DEFAULT true,
  onset_date      date,
  resolved_date   date,
  notes           text,
  recorded_by     uuid REFERENCES app_user(id),
  recorded_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON condition (patient_id, is_current);

CREATE TABLE medication (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  name            text NOT NULL,
  dose            text,
  frequency       text,
  started_at      date,
  stopped_at      date,
  is_current      boolean NOT NULL DEFAULT true,
  notes           text,
  recorded_by     uuid REFERENCES app_user(id),
  recorded_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON medication (patient_id, is_current);

CREATE TABLE supplement (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  name            text NOT NULL,
  dose            text,
  frequency       text,
  started_at      date,
  stopped_at      date,
  recorded_by     uuid REFERENCES app_user(id),
  recorded_at     timestamptz NOT NULL DEFAULT now()
);

-- Allergies, intolerances and preferences are distinguished, never conflated.
CREATE TABLE restriction (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  kind            restriction_kind_t NOT NULL,
  substance       text NOT NULL,              -- e.g. 'milk', 'gluten', 'peanut'
  severity        text,                       -- 'mild' | 'moderate' | 'severe' | 'anaphylaxis'
  is_diagnosed    boolean NOT NULL DEFAULT false,
  reaction        text,
  notes           text,
  recorded_by     uuid REFERENCES app_user(id),
  recorded_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON restriction (patient_id, kind);

CREATE TABLE lifestyle_assessment (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  assessment_date date NOT NULL DEFAULT current_date,
  activity_level  text,                       -- sedentary .. extremely_active
  exercise_freq   text,
  sleep_hours     numeric(4,1),
  smoking_status  text,
  water_intake_ml integer,
  meal_count      smallint,
  eating_habits   text,
  food_preferences text,
  disliked_foods  text,
  cultural_notes  text,
  food_budget     text,
  cooking_limits  text,
  recorded_by     uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON lifestyle_assessment (patient_id, assessment_date DESC);

-- ---------------------------------------------------------------------------
-- Anthropometry — one immutable row per measurement event
-- ---------------------------------------------------------------------------
CREATE TABLE measurement (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  measured_at     timestamptz NOT NULL DEFAULT now(),
  height_cm       numeric(5,1),
  weight_kg       numeric(6,2),
  target_weight_kg numeric(6,2),
  bmi             numeric(5,2),               -- stored for reference; recomputed by engine
  waist_cm        numeric(5,1),
  hip_cm          numeric(5,1),
  body_fat_pct    numeric(4,1),
  muscle_mass_kg  numeric(5,2),
  visceral_fat    numeric(5,1),
  total_body_water_pct numeric(4,1),
  source          text CHECK (source IN ('clinic_scale','bioimpedance','patient_reported','device')),
  device_name     text,
  notes           text,
  recorded_by     uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON measurement (patient_id, measured_at DESC);

-- ---------------------------------------------------------------------------
-- Laboratory results — units and reference ranges travel with each result
-- ---------------------------------------------------------------------------
CREATE TABLE lab_panel (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  collected_on    date NOT NULL,
  laboratory_name text,
  fasting         boolean,
  attachment_id   uuid,                       -- -> asset(id)
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON lab_panel (patient_id, collected_on DESC);

CREATE TABLE lab_result (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  panel_id        uuid NOT NULL REFERENCES lab_panel(id) ON DELETE CASCADE,
  analyte         text NOT NULL,              -- 'hba1c', 'ldl', 'egfr', 'tsh', 'vitamin_d', ...
  value_numeric   numeric,
  value_text      text,                       -- non-numeric results
  unit            text,
  ref_low         numeric,
  ref_high        numeric,
  ref_text        text,                       -- lab-specific ranges
  flag            lab_flag_t NOT NULL DEFAULT 'unknown',
  -- Deliberately NOT an interpretation. Brief §4: abnormal results must not be
  -- presented as confirmed diagnoses.
  clinician_note  text,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON lab_result (panel_id, analyte);

-- ---------------------------------------------------------------------------
-- Energy assessment — inputs and formula stored with every result
-- ---------------------------------------------------------------------------
CREATE TABLE energy_assessment (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  measurement_id  uuid REFERENCES measurement(id) ON DELETE SET NULL,
  assessed_at     timestamptz NOT NULL DEFAULT now(),
  formula         formula_t NOT NULL,
  formula_version text NOT NULL DEFAULT '1',
  bmr_kcal        numeric(7,2) NOT NULL,
  bmr_is_estimated boolean NOT NULL DEFAULT true,   -- false for device-reported (§5 step 1)
  activity_factor numeric(4,3) NOT NULL,
  activity_label  text,
  tdee_kcal       numeric(7,2) NOT NULL,
  goal            goal_t NOT NULL,
  suggested_delta_kcal integer,               -- negative = deficit, positive = surplus
  target_kcal     numeric(7,2),
  delta_rationale text,
  safety_flags    jsonb NOT NULL DEFAULT '[]'::jsonb,  -- e.g. pregnancy, CKD, eating disorder
  requires_review boolean NOT NULL DEFAULT false,
  approved_by     uuid REFERENCES app_user(id),        -- NULL until clinician approves
  approved_at     timestamptz,
  superseded_by   uuid REFERENCES energy_assessment(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  -- A target is only usable once a clinician has approved it.
  CONSTRAINT target_requires_approval
    CHECK (target_kcal IS NULL OR approved_by IS NOT NULL)
);
CREATE INDEX ON energy_assessment (patient_id, assessed_at DESC);

CREATE TABLE macro_target (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  energy_assessment_id uuid NOT NULL REFERENCES energy_assessment(id) ON DELETE CASCADE,
  protein_g       numeric(6,1),
  protein_per_kg  numeric(4,2),
  carb_g          numeric(6,1),
  carb_pct        numeric(4,1),
  fat_g           numeric(6,1),
  fat_pct         numeric(4,1),
  fiber_g         numeric(6,1),
  sodium_mg       numeric(7,1),
  fluid_ml        integer,
  method          text CHECK (method IN ('percent', 'per_kg', 'hybrid')),
  notes           text,
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Therapeutic approaches — the 20 from brief §7
-- ---------------------------------------------------------------------------
CREATE TABLE dietary_approach (
  code            text PRIMARY KEY,           -- 'mediterranean', 'dash', 'ketogenic', ...
  name_en         text NOT NULL,
  name_ar         text,
  description     text,
  evidence_tier   evidence_tier_t NOT NULL DEFAULT 'clinical_guideline',
  is_custom       boolean NOT NULL DEFAULT false,
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- Pairwise compatibility, so combinations can be validated (§7).
CREATE TABLE approach_compatibility (
  approach_a      text NOT NULL REFERENCES dietary_approach(code) ON DELETE CASCADE,
  approach_b      text NOT NULL REFERENCES dietary_approach(code) ON DELETE CASCADE,
  is_compatible   boolean NOT NULL,
  rationale       text NOT NULL,              -- why compatible / why not
  PRIMARY KEY (approach_a, approach_b),
  CHECK (approach_a < approach_b)             -- store each unordered pair once
);

-- Contraindications, checked before a plan may be generated (§7 safety).
CREATE TABLE approach_contraindication (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  approach_code   text NOT NULL REFERENCES dietary_approach(code) ON DELETE CASCADE,
  condition_label text NOT NULL,
  severity        text NOT NULL CHECK (severity IN ('absolute','relative','caution')),
  rationale       text NOT NULL
);

CREATE TABLE patient_approach (
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  approach_code   text NOT NULL REFERENCES dietary_approach(code) ON DELETE RESTRICT,
  selected_at     timestamptz NOT NULL DEFAULT now(),
  selected_by     uuid REFERENCES app_user(id),
  is_active       boolean NOT NULL DEFAULT true,
  PRIMARY KEY (patient_id, approach_code, selected_at)
);

-- ---------------------------------------------------------------------------
-- Food composition — bilingual, with Egyptian household portions (brief §13)
-- ---------------------------------------------------------------------------
CREATE TABLE food (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_en         text NOT NULL,
  name_ar         text,
  category        text,
  -- Nutrients are per 100 g; household portions carry their own gram weights.
  kcal_100g       numeric(7,2) NOT NULL,
  protein_100g    numeric(6,2),
  carb_100g       numeric(6,2),
  fat_100g        numeric(6,2),
  fiber_100g      numeric(6,2),
  sugar_100g      numeric(6,2),
  sodium_mg_100g  numeric(8,2),
  micros          jsonb NOT NULL DEFAULT '{}'::jsonb,
  -- Allergen tags drive hard exclusion in plan generation (§8).
  allergens       text[] NOT NULL DEFAULT '{}',
  is_egyptian     boolean NOT NULL DEFAULT false,
  data_source     text NOT NULL,              -- provenance is mandatory
  source_ref      text,
  -- Set when ingredient composition is incomplete (composite dishes, sauces):
  -- such foods are flagged for verification, never silently declared safe.
  needs_verification boolean NOT NULL DEFAULT false,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON food (name_en);
CREATE INDEX ON food USING gin (allergens);
CREATE INDEX ON food (is_egyptian) WHERE is_egyptian;

-- Household measures: tbsp, tsp, cup, piece, slice, loaf, half_loaf, g, ml.
-- Every household portion MUST document its gram assumption (brief §13).
CREATE TABLE food_portion (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  food_id         uuid NOT NULL REFERENCES food(id) ON DELETE CASCADE,
  measure         text NOT NULL,
  label_en        text NOT NULL,
  label_ar        text,
  grams           numeric(7,2) NOT NULL CHECK (grams > 0),
  assumption_note text NOT NULL,
  is_default      boolean NOT NULL DEFAULT false,
  UNIQUE (food_id, measure, grams)
);

CREATE TABLE recipe (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name_en         text NOT NULL,
  name_ar         text,
  servings        numeric(5,2),
  yield_g         numeric(7,2),
  method          text,
  notes           text,
  created_by      uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE recipe_item (
  recipe_id       uuid NOT NULL REFERENCES recipe(id) ON DELETE CASCADE,
  food_id         uuid NOT NULL REFERENCES food(id) ON DELETE RESTRICT,
  grams           numeric(7,2) NOT NULL,
  PRIMARY KEY (recipe_id, food_id)
);

-- ---------------------------------------------------------------------------
-- Diet plans — versioned, never mutated in place (brief §14, §16)
-- ---------------------------------------------------------------------------
CREATE TABLE plan (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  title           text,
  created_by      uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE plan_version (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_id         uuid NOT NULL REFERENCES plan(id) ON DELETE CASCADE,
  version_no      integer NOT NULL,
  status          plan_status_t NOT NULL DEFAULT 'draft',
  energy_assessment_id uuid REFERENCES energy_assessment(id) ON DELETE SET NULL,
  duration_days   smallint NOT NULL DEFAULT 7 CHECK (duration_days > 0),
  starts_on       date,
  -- Generation provenance: which approaches were combined, and the diff vs parent.
  approach_codes  text[] NOT NULL DEFAULT '{}',
  generated_by    text NOT NULL CHECK (generated_by IN ('engine','copilot_draft','clinician','template')),
  parent_version_id uuid REFERENCES plan_version(id),
  diff_summary    jsonb,
  notes           text,
  created_by      uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (plan_id, version_no)
);
CREATE INDEX ON plan_version (plan_id, version_no DESC);
CREATE INDEX ON plan_version (status) WHERE status IN ('draft','pending_approval');

CREATE TABLE plan_day (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_version_id uuid NOT NULL REFERENCES plan_version(id) ON DELETE CASCADE,
  day_index       smallint NOT NULL,
  total_kcal      numeric(7,2),
  total_protein_g numeric(6,1),
  total_carb_g    numeric(6,1),
  total_fat_g     numeric(6,1),
  total_fiber_g   numeric(6,1),
  UNIQUE (plan_version_id, day_index)
);

CREATE TABLE plan_meal (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_day_id     uuid NOT NULL REFERENCES plan_day(id) ON DELETE CASCADE,
  meal_index      smallint NOT NULL,
  label_en        text,
  label_ar        text,
  time_suggestion time,
  instructions    text,
  UNIQUE (plan_day_id, meal_index)
);

CREATE TABLE plan_item (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_meal_id    uuid NOT NULL REFERENCES plan_meal(id) ON DELETE CASCADE,
  item_index      smallint NOT NULL,
  food_id         uuid REFERENCES food(id) ON DELETE SET NULL,
  recipe_id       uuid REFERENCES recipe(id) ON DELETE SET NULL,
  free_text       text,                       -- for items not yet in the database
  grams           numeric(7,2),
  household_measure text,
  household_qty   numeric(6,2),
  kcal            numeric(7,2),
  protein_g       numeric(6,1),
  carb_g          numeric(6,1),
  fat_g           numeric(6,1),
  -- Approximate swaps must be labelled as such (brief §10).
  is_approximate_swap boolean NOT NULL DEFAULT false,
  swap_note       text,
  CHECK (food_id IS NOT NULL OR recipe_id IS NOT NULL OR free_text IS NOT NULL)
);
CREATE INDEX ON plan_item (plan_meal_id, item_index);

-- Clinician approval is an immutable event, not a status flip.
CREATE TABLE plan_approval (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  plan_version_id uuid NOT NULL REFERENCES plan_version(id) ON DELETE CASCADE,
  approved_by     uuid NOT NULL REFERENCES app_user(id),
  approved_at     timestamptz NOT NULL DEFAULT now(),
  decision        text NOT NULL CHECK (decision IN ('approved','rejected','changes_requested')),
  comment         text
);

CREATE TABLE plan_template (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id       uuid NOT NULL REFERENCES clinic(id) ON DELETE CASCADE,
  name            text NOT NULL,
  approach_codes  text[] NOT NULL DEFAULT '{}',
  structure       jsonb NOT NULL,             -- portable meal skeleton
  is_shared       boolean NOT NULL DEFAULT true,
  created_by      uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Follow-up
-- ---------------------------------------------------------------------------
CREATE TABLE follow_up (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  scheduled_for   timestamptz,
  attended_at     timestamptz,
  measurement_id  uuid REFERENCES measurement(id) ON DELETE SET NULL,
  adherence       text,
  appetite_change text,
  gi_symptoms     text,
  patient_feedback text,
  clinical_notes  text,
  medication_changes text,
  next_appointment_at timestamptz,
  recorded_by     uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON follow_up (patient_id, attended_at DESC);
CREATE INDEX ON follow_up (scheduled_for) WHERE attended_at IS NULL;

-- Reassessment proposals: shown side by side, applied only on approval (§15).
CREATE TABLE reassessment (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  follow_up_id    uuid REFERENCES follow_up(id) ON DELETE SET NULL,
  previous_target_kcal numeric(7,2),
  suggested_target_kcal numeric(7,2),
  rationale       text NOT NULL,
  contributing_factors jsonb NOT NULL DEFAULT '[]'::jsonb,  -- adherence, fluid, meds, plateau
  approved_by     uuid REFERENCES app_user(id),
  approved_at     timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- Knowledge base and evidence (brief §11)
-- ---------------------------------------------------------------------------
CREATE TABLE kb_document (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id       uuid NOT NULL REFERENCES clinic(id) ON DELETE CASCADE,
  title           text NOT NULL,
  asset_id        uuid,                       -- -> asset(id)
  mime_type       text,
  evidence_tier   evidence_tier_t NOT NULL DEFAULT 'clinician_upload',
  published_on    date,
  source_org      text,
  source_url      text,
  is_superseded   boolean NOT NULL DEFAULT false,
  superseded_by   uuid REFERENCES kb_document(id),
  notes           text,
  created_by      uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE kb_chunk (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id     uuid NOT NULL REFERENCES kb_document(id) ON DELETE CASCADE,
  chunk_index     integer NOT NULL,
  content         text NOT NULL,
  page_from       integer,
  page_to         integer,
  embedding       jsonb,                      -- or pgvector vector(1536) if available
  UNIQUE (document_id, chunk_index)
);

-- A recommendation must be traceable to its source (brief §11).
CREATE TABLE recommendation_citation (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_type    text NOT NULL,              -- 'plan_version','energy_assessment', ...
  subject_id      uuid NOT NULL,
  kb_document_id  uuid REFERENCES kb_document(id) ON DELETE SET NULL,
  evidence_tier   evidence_tier_t NOT NULL,
  quote           text,
  source_url      text,
  accessed_on     date,
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON recommendation_citation (subject_type, subject_id);

-- ---------------------------------------------------------------------------
-- Assets, consent, audit, privacy
-- ---------------------------------------------------------------------------
CREATE TABLE asset (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clinic_id       uuid NOT NULL REFERENCES clinic(id) ON DELETE CASCADE,
  patient_id      uuid REFERENCES patient(id) ON DELETE CASCADE,
  kind            text NOT NULL,              -- 'lab_report','body_comp','document','logo'
  filename        text NOT NULL,
  mime_type       text NOT NULL,
  byte_size       bigint NOT NULL,
  storage_key     text NOT NULL,              -- object-store key; never a public URL
  sha256          text NOT NULL,
  contains_phi    boolean NOT NULL DEFAULT true,
  uploaded_by     uuid REFERENCES app_user(id),
  created_at      timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON asset (patient_id, kind);

CREATE TABLE consent (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  kind            consent_kind_t NOT NULL,
  granted         boolean NOT NULL,
  granted_at      timestamptz NOT NULL DEFAULT now(),
  withdrawn_at    timestamptz,
  document_asset_id uuid REFERENCES asset(id),
  recorded_by     uuid REFERENCES app_user(id)
);

CREATE TABLE data_subject_request (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  patient_id      uuid NOT NULL REFERENCES patient(id) ON DELETE CASCADE,
  kind            text NOT NULL CHECK (kind IN ('export','deletion','rectification','restriction')),
  requested_at    timestamptz NOT NULL DEFAULT now(),
  fulfilled_at    timestamptz,
  handled_by      uuid REFERENCES app_user(id),
  outcome         text,
  notes           text
);

-- Append-only. UPDATE and DELETE are revoked from the application role.
CREATE TABLE audit_log (
  id              bigserial PRIMARY KEY,
  clinic_id       uuid NOT NULL,
  actor_user_id   uuid,
  actor_ip        inet,
  actor_agent     text,
  action          text NOT NULL,              -- 'read','create','update','delete','export','login'
  entity_type     text NOT NULL,
  entity_id       uuid,
  patient_id      uuid,
  before_state    jsonb,
  after_state     jsonb,
  occurred_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON audit_log (clinic_id, occurred_at DESC);
CREATE INDEX ON audit_log (patient_id, occurred_at DESC);
CREATE INDEX ON audit_log (actor_user_id, occurred_at DESC);

-- ---------------------------------------------------------------------------
-- Triggers
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION touch_updated_at() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;

CREATE TRIGGER clinic_touch      BEFORE UPDATE ON clinic      FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER app_user_touch    BEFORE UPDATE ON app_user    FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER patient_touch     BEFORE UPDATE ON patient     FOR EACH ROW EXECUTE FUNCTION touch_updated_at();
CREATE TRIGGER food_touch        BEFORE UPDATE ON food        FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- Clinical facts are append-only: block silent edits to recorded observations.
CREATE OR REPLACE FUNCTION block_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'Append-only table: % records cannot be % (record a new row instead)',
    TG_TABLE_NAME, lower(TG_OP);
END $$;

CREATE TRIGGER measurement_append_only
  BEFORE UPDATE OR DELETE ON measurement
  FOR EACH ROW EXECUTE FUNCTION block_mutation();

CREATE TRIGGER lab_result_append_only
  BEFORE UPDATE OR DELETE ON lab_result
  FOR EACH ROW EXECUTE FUNCTION block_mutation();

CREATE TRIGGER audit_log_append_only
  BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION block_mutation();

-- ---------------------------------------------------------------------------
-- Row-level security sketch
-- Application connects as nutriclinic_app; never as the owner.
-- ---------------------------------------------------------------------------
ALTER TABLE patient      ENABLE ROW LEVEL SECURITY;
ALTER TABLE measurement  ENABLE ROW LEVEL SECURITY;
ALTER TABLE lab_panel    ENABLE ROW LEVEL SECURITY;
ALTER TABLE lab_result   ENABLE ROW LEVEL SECURITY;
ALTER TABLE plan         ENABLE ROW LEVEL SECURITY;
ALTER TABLE plan_version ENABLE ROW LEVEL SECURITY;
ALTER TABLE kb_document  ENABLE ROW LEVEL SECURITY;

-- The request sets:  SET LOCAL app.current_user_id = '<uuid>';
CREATE POLICY patient_read ON patient FOR SELECT USING (
  clinic_id = current_setting('app.current_clinic_id', true)::uuid
  AND (
    EXISTS (SELECT 1 FROM patient_access pa
            WHERE pa.patient_id = patient.id
              AND pa.user_id = current_setting('app.current_user_id', true)::uuid
              AND pa.revoked_at IS NULL)
    OR EXISTS (SELECT 1 FROM app_user u
               WHERE u.id = current_setting('app.current_user_id', true)::uuid
                 AND u.role IN ('admin','auditor'))
  )
);

CREATE POLICY patient_write ON patient FOR UPDATE USING (
  EXISTS (SELECT 1 FROM patient_access pa
          WHERE pa.patient_id = patient.id
            AND pa.user_id = current_setting('app.current_user_id', true)::uuid
            AND pa.revoked_at IS NULL)
);

-- ---------------------------------------------------------------------------
-- Seed: the 20 therapeutic approaches from brief §7
-- ---------------------------------------------------------------------------
INSERT INTO dietary_approach (code, name_en, evidence_tier) VALUES
  ('mediterranean',        'Mediterranean Diet',              'clinical_guideline'),
  ('dash',                 'DASH Diet',                        'clinical_guideline'),
  ('low_carb',             'Low-Carbohydrate Diet',            'clinical_guideline'),
  ('low_gi',               'Low-Glycemic-Index Diet',          'clinical_guideline'),
  ('ketogenic',            'Ketogenic Diet',                   'clinical_guideline'),
  ('intermittent_fasting', 'Intermittent Fasting',             'clinical_guideline'),
  ('gluten_free',          'Gluten-Free Diet',                 'clinical_guideline'),
  ('dairy_free',           'Dairy-Free Diet',                  'clinical_guideline'),
  ('lactose_free',         'Lactose-Free Diet',                'clinical_guideline'),
  ('low_sodium',           'Low-Sodium Diet',                  'clinical_guideline'),
  ('high_protein',         'High-Protein Diet',                'clinical_guideline'),
  ('low_fat',              'Low-Fat Diet',                     'clinical_guideline'),
  ('calorie_controlled',   'Calorie-Controlled Diet',          'clinical_guideline'),
  ('vegetarian',           'Vegetarian Diet',                  'clinical_guideline'),
  ('vegan',                'Vegan Diet',                       'clinical_guideline'),
  ('renal',                'Renal-Specific Nutrition Plan',    'clinical_guideline'),
  ('diabetes_oriented',    'Diabetes-Oriented Nutrition Plan', 'clinical_guideline'),
  ('heart_healthy',        'Heart-Healthy Diet',               'clinical_guideline'),
  ('weight_management',    'Weight Management Diet',           'clinical_guideline'),
  ('custom',               'Custom Therapeutic Diet',          'patient_specific');

-- Example compatibility rows (brief §7). The full matrix lives in application data.
INSERT INTO approach_compatibility (approach_a, approach_b, is_compatible, rationale) VALUES
  ('dash','mediterranean',  true,  'Concordant emphasis on vegetables, whole grains, unsaturated fat.'),
  ('gluten_free','low_carb',true,  'No structural conflict; gluten avoidance is orthogonal to carbohydrate load.'),
  ('low_gi','mediterranean',true,  'Mediterranean patterns are inherently low-GI in practice.'),
  ('dairy_free','high_protein', true, 'Protein target is reachable from non-dairy sources.'),
  ('diabetes_oriented','heart_healthy', true, 'Both favour fibre, unsaturated fat and sodium restriction.'),
  ('ketogenic','vegan',      false, 'Sustaining ketosis on a vegan pattern is possible but strongly constrained.'),
  ('dash','ketogenic',       false, 'DASH mandates high whole-grain and fruit intake; incompatible with ketosis.');

COMMIT;

-- ============================================================================
--  Migration note
--
--  The prototype stores everything in browser IndexedDB. A migration means:
--    1. Stand up this schema plus the API in backend-and-security.md.
--    2. Export the prototype via Settings -> Backup (JSON).
--    3. Map that JSON onto these tables — the prototype's entity names line up
--       with the table names here by design, so the transform is mechanical.
--    4. Re-point the front end at the API; no clinical logic moves, because
--       engine.js and planner.js are pure functions and port unchanged.
--
--  Until all four steps are done, treat this file as a specification.
-- ============================================================================
