<#
  NutriClinic Pro — launcher with automatic port selection.

  Prefer Start-NutriClinic.bat for a one-click start. Use this script when you
  need a different port because 8617 is already taken, or you want the fallback
  behaviour to be explicit.

  Right-click > Run with PowerShell, or from a terminal:
      powershell -ExecutionPolicy Bypass -File .\Start-NutriClinic.ps1
#>

$ErrorActionPreference = 'Stop'

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$site = Join-Path $root 'site'
$index = Join-Path $site 'index.html'

if (-not (Test-Path $index)) {
  Write-Host ''
  Write-Host '  Could not find site\index.html next to this script.' -ForegroundColor Red
  Write-Host '  Keep this script inside the NutriClinic-Pro folder.'
  Write-Host ''
  Read-Host 'Press Enter to close'
  exit 1
}

# --- find a runtime -------------------------------------------------------
$python = $null
foreach ($candidate in @('python', 'py')) {
  if (Get-Command $candidate -ErrorAction SilentlyContinue) { $python = $candidate; break }
}

if (-not $python) {
  Write-Host ''
  Write-Host '  Python was not found, so the local server cannot be started.' -ForegroundColor Yellow
  Write-Host ''
  Write-Host '  NutriClinic Pro still works - opening it directly now.'
  Write-Host '  Records persist in browser storage, which has a size limit,'
  Write-Host '  so keep document attachments small.'
  Write-Host ''
  Start-Process $index
  Read-Host 'Press Enter to close'
  exit 0
}

# --- pick a free port ----------------------------------------------------
$port = 8617
$limit = 8640
while ($port -lt $limit) {
  $busy = $false
  try {
    $busy = [bool](Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue)
  } catch {
    # Cmdlet unavailable on this system; probe by attempting a bind instead.
    try {
      $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $port)
      $probe.Start(); $probe.Stop(); $busy = $false
    } catch { $busy = $true }
  }
  if (-not $busy) { break }
  $port++
}

if ($port -ge $limit) {
  Write-Host ''
  Write-Host "  Ports 8617-8639 all appear to be in use." -ForegroundColor Red
  Write-Host '  Close whatever is using them and try again.'
  Write-Host ''
  Read-Host 'Press Enter to close'
  exit 1
}

$url = "http://127.0.0.1:$port/"
Write-Host ''
Write-Host '  NutriClinic Pro' -ForegroundColor Cyan
Write-Host "  Open: $url"
Write-Host ''
Write-Host '  Storage: IndexedDB - records and documents are kept in full.'
Write-Host '  Press Ctrl+C to stop the server.'
Write-Host ''

Start-Process $url

try {
  & $python -m http.server $port --bind 127.0.0.1 --directory $site
} finally {
  Write-Host ''
  Write-Host '  Server stopped.'
  Read-Host 'Press Enter to close'
}
