/* ==========================================================================
   NutriClinic Pro — kb.js
   Knowledge base: document ingestion, chunking and retrieval.

   HONEST CAPABILITY BOUNDARY
   A static build with no bundled libraries can read TEXT formats and nothing
   else. So this module:

     - genuinely ingests .txt .md .csv .tsv .json (parsed here, searchable now);
     - recognises .pdf .docx .xlsx as reference documents, stores the file for
       the clinician's own use, and states plainly that its TEXT cannot be
       extracted without a backend — it does not pretend otherwise;
     - exposes a documented remote adapter so a server can supply extraction and
       retrieval later, with no change to callers.

   No upload control here is decorative: every accepted format either produces
   searchable text or says exactly why it could not.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  var MAX_TEXT_BYTES = 5 * 1024 * 1024;   // refuse to freeze the tab
  var CHUNK_CHARS = 1200;
  var CHUNK_OVERLAP = 120;

  /* -------------------------------------------------------- parser registry */
  /**
   * spec: { label, native: true, parse(file) -> Promise<string> }
   * A parser marked `native: false` is recognised but cannot run here; the
   * backend is expected to supply it.
   */
  var PARSERS = {
    txt:  { label: 'Plain text',  native: true,  parse: readAsText },
    md:   { label: 'Markdown',    native: true,  parse: readAsText },
    csv:  { label: 'CSV',         native: true,  parse: readAsText },
    tsv:  { label: 'Tab-separated', native: true, parse: readAsText },
    json: { label: 'JSON',        native: true,  parse: readAsJsonText },
    pdf:  { label: 'PDF',         native: false, needs: 'server-side text extraction' },
    docx: { label: 'Word document', native: false, needs: 'server-side text extraction' },
    xlsx: { label: 'Excel workbook', native: false, needs: 'server-side text extraction' }
  };

  function readAsText(file) {
    return U.readFile(file);
  }

  /** JSON is re-serialised readably so numeric tables stay searchable. */
  function readAsJsonText(file) {
    return U.readFile(file).then(function (txt) {
      try { return JSON.stringify(JSON.parse(txt), null, 1); }
      catch (e) { return txt; }   // not valid JSON: keep the literal text
    });
  }

  function extOf(name) {
    var m = /\.([a-z0-9]+)$/i.exec(String(name || ''));
    return m ? m[1].toLowerCase() : '';
  }

  function registerParser(ext, spec) {
    PARSERS[String(ext).toLowerCase().replace(/^\./, '')] = spec;
  }

  function supportedExtensions() {
    return Object.keys(PARSERS).filter(function (k) { return PARSERS[k].native; });
  }
  function deferredExtensions() {
    return Object.keys(PARSERS).filter(function (k) { return !PARSERS[k].native; });
  }
  function isSupported(name) {
    var p = PARSERS[extOf(name)];
    return !!(p && p.native);
  }

  /* ------------------------------------------------------------- chunking -- */
  /**
   * Split on paragraph boundaries, then hard-wrap anything still oversized.
   * Overlap keeps a sentence that straddles a boundary retrievable.
   */
  function chunkText(text) {
    var clean = String(text || '').replace(/\r\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
    if (!clean) return [];

    var parts = clean.split(/\n{2,}/);
    var chunks = [];
    var buf = '';

    function flush() {
      var t = buf.trim();
      if (t) chunks.push(t);
      buf = '';
    }

    parts.forEach(function (p) {
      if (p.length > CHUNK_CHARS) {
        flush();
        for (var i = 0; i < p.length; i += (CHUNK_CHARS - CHUNK_OVERLAP)) {
          chunks.push(p.slice(i, i + CHUNK_CHARS));
        }
        return;
      }
      if ((buf + '\n\n' + p).length > CHUNK_CHARS) flush();
      buf = buf ? (buf + '\n\n' + p) : p;
    });
    flush();

    return chunks.map(function (t, i) { return { i: i, text: t }; });
  }

  /* ------------------------------------------------------------ retrieval -- */
  function terms(q) {
    return String(q || '').toLowerCase().split(/[^\p{L}\p{N}]+/u)
      .filter(function (t) { return t.length > 1; });
  }

  function scoreChunk(text, ts) {
    var lower = text.toLowerCase();
    var score = 0;
    ts.forEach(function (t) {
      var idx = lower.indexOf(t);
      if (idx === -1) return;
      score += 1;
      // A second occurrence, or a match near the start, is a stronger signal.
      if (lower.indexOf(t, idx + 1) !== -1) score += 0.5;
      if (idx < 120) score += 0.25;
    });
    return score;
  }

  function snippet(text, ts) {
    var lower = text.toLowerCase();
    var at = -1;
    for (var i = 0; i < ts.length && at === -1; i++) at = lower.indexOf(ts[i]);
    if (at === -1) at = 0;
    var start = Math.max(0, at - 90);
    var s = text.slice(start, start + 300).replace(/\s+/g, ' ').trim();
    return (start > 0 ? '…' : '') + s + (start + 300 < text.length ? '…' : '');
  }

  /* ---------------------------------------------------------- remote layer -- */
  /**
   * Backend adapter contract. A server implementation should expose:
   *
   *   POST {base}/documents            multipart file  -> { id, title, chunks }
   *   GET  {base}/search?q=&limit=     -> [{ docId, title, snippet, page }]
   *   DELETE {base}/documents/{id}     -> 204
   *
   * Until a base URL is configured the local index is the only source, and the
   * interface says so.
   */
  var remote = {
    endpoint: null,
    setEndpoint(url) { remote.endpoint = url || null; return remote; },
    configured() { return !!remote.endpoint; },
    search(q, limit) {
      if (!remote.configured()) return Promise.resolve([]);
      return fetch(remote.endpoint.replace(/\/$/, '') + '/search?q=' +
          encodeURIComponent(q) + '&limit=' + (limit || 6),
          { credentials: 'omit' })
        .then(function (r) { return r.ok ? r.json() : []; })
        .catch(function () { return []; });   // offline: local results still stand
    }
  };

  /* ------------------------------------------------------------- ingestion - */
  /**
   * ingest(file) -> Promise of one of:
   *   { status:'ingested', doc }
   *   { status:'deferred', ext, needs, note }   recognised, not extractable here
   *   { status:'rejected', reason }
   */
  function ingest(file) {
    if (!file) return Promise.resolve({ status: 'rejected', reason: 'No file.' });
    var ext = extOf(file.name);
    var parser = PARSERS[ext];

    if (!parser) {
      return Promise.resolve({
        status: 'rejected',
        reason: 'Unrecognised file type "' + (ext || '?') +
          '". Supported here: ' + supportedExtensions().join(', ') + '.'
      });
    }

    if (!parser.native) {
      // Say precisely what is missing rather than appearing to succeed.
      return Promise.resolve({
        status: 'deferred', ext: ext, needs: parser.needs,
        note: parser.label + ' files can be stored for reference, but their text cannot be ' +
          'extracted in this build (' + parser.needs + ' is required). Configure the knowledge-base ' +
          'endpoint in Settings to have a server index them.'
      });
    }

    if (file.size > MAX_TEXT_BYTES) {
      return Promise.resolve({
        status: 'rejected',
        reason: 'File is larger than ' + Math.round(MAX_TEXT_BYTES / 1024 / 1024) +
          ' MB and was not indexed.'
      });
    }

    return parser.parse(file).then(function (text) {
      var chunks = chunkText(text);
      if (!chunks.length) {
        return { status: 'rejected', reason: 'No readable text was found in that file.' };
      }
      var doc = {
        id: U.uid('kbd'),
        title: file.name,
        ext: ext,
        mime: file.type || '',
        byteSize: file.size,
        addedAt: new Date().toISOString(),
        source: 'upload',
        chunks: chunks,
        textChars: String(text).length
      };
      return CN.store.put('kb', doc).then(function () {
        CN.bus.emit('kb', { action: 'ingest', id: doc.id });
        return { status: 'ingested', doc: doc };
      });
    }).catch(function (e) {
      return { status: 'rejected', reason: (e && e.message) || 'The file could not be read.' };
    });
  }

  /** Search the local index, merged with the remote adapter when configured. */
  function search(q, limit) {
    var ts = terms(q);
    var lim = limit || 8;

    var local = (!ts.length ? Promise.resolve([]) : CN.store.all('kb').then(function (docs) {
      var hits = [];
      docs.forEach(function (doc) {
        (doc.chunks || []).forEach(function (c) {
          var s = scoreChunk(c.text, ts);
          if (s > 0) {
            hits.push({
              docId: doc.id, title: doc.title, chunk: c.i,
              score: s, snippet: snippet(c.text, ts), source: 'local'
            });
          }
        });
      });
      return U.sortBy(hits, 'score', 'desc').slice(0, lim);
    }));

    return local.then(function (localHits) {
      return remote.search(q, lim).then(function (remoteHits) {
        var merged = localHits.concat((remoteHits || []).map(function (h) {
          return { docId: h.docId, title: h.title, snippet: h.snippet,
            source: 'remote', score: 1, page: h.page };
        }));
        return merged.slice(0, lim);
      });
    });
  }

  function list() {
    return CN.store.all('kb').then(function (docs) {
      return U.sortBy(docs, 'addedAt', 'desc').map(function (d) {
        return {
          id: d.id, title: d.title, ext: d.ext, byteSize: d.byteSize,
          addedAt: d.addedAt, chunks: (d.chunks || []).length,
          textChars: d.textChars || 0, source: d.source
        };
      });
    });
  }

  function remove(id) {
    return CN.store.del('kb', id).then(function () {
      CN.bus.emit('kb', { action: 'remove', id: id });
      return true;
    });
  }

  function stats() {
    return CN.store.all('kb').then(function (docs) {
      var chunks = 0, chars = 0;
      docs.forEach(function (d) {
        chunks += (d.chunks || []).length;
        chars += d.textChars || 0;
      });
      return { documents: docs.length, chunks: chunks, characters: chars };
    });
  }

  CN.kb = {
    parsers: PARSERS,
    registerParser: registerParser,
    supportedExtensions: supportedExtensions,
    deferredExtensions: deferredExtensions,
    isSupported: isSupported,
    extOf: extOf,
    chunkText: chunkText,
    ingest: ingest,
    search: search,
    list: list,
    remove: remove,
    stats: stats,
    remote: remote,
    MAX_TEXT_BYTES: MAX_TEXT_BYTES
  };
})();
