# Apply Notes — registry entry and final deploy steps

The registry update **triggers the preview upload**, so it is the last thing you do. Run the checks in
order; nothing here could be executed from the authoring session (no shell, and `projects/projects.json`
lives outside that sandbox).

---

## Order matters — do not skip ahead

| # | Step | Why it comes here |
|---|---|---|
| 1 | Restore the 19 missing source files into the site root | Nothing renders without them |
| 2 | Run the four local verification commands (README §Local verification) | Prove the build before it ships |
| 3 | **Delete `qa-smoke.html`** | It seeds browser profiles and must never ship |
| 4 | Confirm `README.md`, `docs/`, `deploy/` are excluded from the bundle | A static root would serve them publicly |
| 5 | Append the registry entry (below) | This is what triggers the preview upload |

---

## Step 3 — remove the QA page

```powershell
cd <siteRoot>
Remove-Item .\qa-smoke.html -Force -ErrorAction Stop
Test-Path .\qa-smoke.html        # expect: False
```

Also remove any leftover QA scaffolding that is not part of the app: `qa-smoke.js`, `qa-ui.js`,
`patch-qa.py`, `extract_pdfs2.py`, `extract_assets.py`. None of these are app code.

---

## Step 5 — append the registry entry

The object to append is in `deploy/projects.entry.json`. Target file: `projects/projects.json`, which
is a **top-level JSON array** — append to it, never replace it. Existing items and any
`deploymentResult` fields must survive untouched.

```powershell
# --- from the workspace root that contains projects\ ---

# 1. Back up first. If the append goes wrong you want the original back.
Copy-Item 'projects\projects.json' 'projects\projects.json.bak' -Force

# 2. Load both files
$registryPath = 'projects\projects.json'
$entryPath    = 'deploy\projects.entry.json'
$registry = Get-Content $registryPath -Raw | ConvertFrom-Json
$entry    = Get-Content $entryPath    -Raw | ConvertFrom-Json

# 3. Refuse to create a duplicate
if (@($registry) | Where-Object { $_.id -eq $entry.id }) {
  throw "Entry '$($entry.id)' already present - aborting so nothing is duplicated."
}

# 4. Preserve a real timestamp
$now = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
$entry.createdAt = $now
$entry.updatedAt = $now

# 5. Append and write
$updated = @($registry) + @($entry)
$updated | ConvertTo-Json -Depth 20 | Set-Content $registryPath -Encoding utf8
```

### Validate before trusting it

```powershell
$v = Get-Content 'projects\projects.json' -Raw | ConvertFrom-Json

# a) parses as a top-level array
if ($v -isnot [System.Array]) { throw 'Not an array' }

# b) expected total count (original items + 1)
$v.Count

# c) target id present exactly once
@($v | Where-Object { $_.id -eq 'website-8fb4f824e29ad0478ac0cbed' }).Count   # expect: 1

# d) no other project lost
Compare-Object `
  (@(Get-Content 'projects\projects.json.bak' -Raw | ConvertFrom-Json).id) `
  $v.id | Where-Object SideIndicator -eq '<='      # expect: nothing listed
```

If (a)–(d) all pass, the preview upload fires. If anything fails, restore and retry:

```powershell
Copy-Item 'projects\projects.json.bak' 'projects\projects.json' -Force
```

### Two caveats

- `ConvertTo-Json` reformats whitespace and escapes non-ASCII characters. That is harmless for a JSON
  parser, but if `projects.json` is under version control you will see a large diff. Read the diff or
  use a JSON-aware editor if you would rather keep formatting stable.
- `ConvertTo-Json` in Windows PowerShell 5.1 is depth-limited; `-Depth 20` is deliberate. Do not lower
  it, or nested `deployment` fields will be truncated to strings.

---

## After the upload

Confirm the preview actually serves the app — not a directory listing and not the QA page:

1. `/` returns the NutriClinic Pro shell, not an index of files.
2. `/qa-smoke.html` returns 404.
3. `/README.md` and `/docs/database-schema.sql` return 404 (if they do not, they are shipping publicly —
   exclude them from the bundle and re-upload).
4. The 13 modules load, the EN ⇄ AR toggle flips to RTL, and a patient record opens.

---

## Scope reminder

This deploys a **single-clinician local prototype**, not the server-backed clinical system the original
brief specifies in §§19 and 21. Do not put real patient data into it. The prototype stores everything
in the deploying browser's IndexedDB, with no authentication, no audit trail and no encryption at rest.
See `docs/backend-and-security.md` for what closing that gap requires.
