# Backend & Security — Design Target

> **STATUS: NOT IMPLEMENTED.** This document specifies the server-side architecture the original
> brief requires (§§19 and §21). **None of it exists in the delivered build.** The shipped artifact is
> a static, single-clinician prototype whose only datastore is browser IndexedDB, with no
> authentication, no server API, no audit trail and no encryption at rest.
>
> It is included because the brief demands it and because the prototype cannot be used for real
> patient data without it. Do not read it as documentation of shipped behaviour.

---

## 1. Why this exists — the gap in one table

| Brief requirement | Verbatim | Prototype today |
|---|---|---|
| §1 | "a real, scalable clinical management application, **NOT a static website**" | static site |
| §19 | "**Do not rely on browser localStorage as the primary database** for clinical records" | IndexedDB is the only store |
| §19 | secure authentication | none — anyone at the machine reads every record |
| §19 | role-based access control | none |
| §19 | encrypted communication | N/A (no server) |
| §19 | encryption at rest | none |
| §19 | audit logs | none |
| §19 | regular backups, data recovery | manual JSON export only |
| §19 | patient consent management | none |
| §19 | data export and deletion workflows | export only, no deletion workflow |
| §21 | server-side API, PostgreSQL | neither |
| §19 | "Keep AI API keys, search credentials, and database secrets on the server" | no server exists, so no keys exist |

**Risk statement:** in its current form the prototype has no mechanism to prevent unauthorised access
to patient records, cannot prove who changed what, and loses everything if browser storage is cleared.
That is tolerable for evaluation with fictitious data and unacceptable for clinical use.

---

## 2. Target architecture

```
Browser (app shell, deterministic engine)
        │  HTTPS only, HSTS, strict CSP
        ▼
API server (stateless, containerised)
   ├── AuthN/AuthZ      session + MFA, RBAC, per-patient grants
   ├── Domain services  patients, assessments, planning, follow-up
   ├── Calculation      engine.js / planner.js ported unchanged (pure functions)
   ├── AI service       LLM + RAG, server-held keys, de-identified payloads
   ├── Research service optional search API, source attribution, de-identified queries
   └── Audit service    append-only audit log
        │
        ├──▶ PostgreSQL 15+   (docs/database-schema.sql), encrypted at rest
        ├──▶ Object storage   lab reports / body-comp files, private buckets, signed URLs
        └──▶ Secret manager   LLM key, search key, DB creds — never in images or repos
```

**The calculation engine does not move to the server by necessity** — it is already deterministic and
pure, so it runs identically on either side. Keeping it client-side is acceptable and keeps the UI
responsive; if it moves, it ports unchanged. What must move is *persistence, identity and audit*.

---

## 3. API contract (REST, JSON, `/api/v1`)

All endpoints require an authenticated session. All responses are scoped by clinic and by per-patient
access grants enforced in the database through row-level security — never by client-side filtering.

### Auth

| Method | Path | Purpose |
|---|---|---|
| POST | `/auth/login` | Credentials → session cookie (`HttpOnly`, `Secure`, `SameSite=Strict`) |
| POST | `/auth/mfa/verify` | Second factor |
| POST | `/auth/logout` | Invalidate session server-side |
| POST | `/auth/password/reset` | Initiate reset |
| GET  | `/auth/session` | Current user, role, clinic, granted patient scope |

### Patients

| Method | Path | Purpose |
|---|---|---|
| GET | `/patients` | List + filter (name, code, registration date, category, follow-up status) |
| POST | `/patients` | Create; server assigns `patient_code` and `deid_token` |
| GET | `/patients/{id}` | Full record |
| PATCH | `/patients/{id}` | Update demographics (never clinical facts) |
| GET | `/patients/{id}/timeline` | Chronological clinical events |
| POST | `/patients/{id}/access` | Grant a clinician access (admin only) |

### Clinical data

| Method | Path | Purpose |
|---|---|---|
| POST/GET | `/patients/{id}/conditions` | Medical history (append-only) |
| POST/GET | `/patients/{id}/medications` | Medications (append-only) |
| POST/GET | `/patients/{id}/restrictions` | Allergies / intolerances / preferences |
| POST/GET | `/patients/{id}/lifestyle` | Lifestyle assessments |
| POST/GET | `/patients/{id}/measurements` | Anthropometry (append-only) |
| POST/GET | `/patients/{id}/labs` | Lab panels + results |
| POST | `/patients/{id}/assets` | Upload lab report / body-comp file (multipart) |

### Assessment and planning

| Method | Path | Purpose |
|---|---|---|
| POST | `/patients/{id}/energy-assessments` | Compute BMR/TDEE/target; returns flags |
| POST | `/energy-assessments/{id}/approve` | Clinician approval — **required before a target is usable** |
| GET | `/approaches` | The 20 approaches + compatibility matrix |
| POST | `/patients/{id}/plans` | Create plan |
| POST | `/plans/{id}/versions` | Generate/append a version from an approved target |
| POST | `/plan-versions/{id}/swap` | Smart exchange; returns recalculated totals + warnings |
| POST | `/plan-versions/{id}/approve` | Approval event |
| GET | `/plan-versions/{id}/diff?against={otherId}` | Version comparison |
| GET | `/plan-versions/{id}/export.pdf` | Branded or plain A4 PDF |

### Follow-up, copilot, knowledge base

| Method | Path | Purpose |
|---|---|---|
| POST/GET | `/patients/{id}/follow-ups` | Follow-up records |
| POST | `/follow-ups/{id}/reassess` | Propose new target; requires approval to apply |
| POST | `/copilot/interpret` | NL → structured intent (draft only) |
| POST | `/copilot/plan-draft` | Draft plan from intent; never auto-approved |
| POST/GET | `/kb/documents` | Knowledge-base uploads |
| GET | `/research/search` | External research (de-identified query only) |

### Non-negotiable API rules

1. **AI never returns the authoritative number.** `energy-assessments` computes in deterministic code;
   the copilot may *explain* a result but never produces it.
2. **No clinical fact is overwritten.** Corrections append new rows.
3. **Approval is an event**, recorded with actor and timestamp — not a boolean flip.
4. **Every write is audited** with before/after state.
5. **PDF export is audited** like any other disclosure.

---

## 4. Authentication and RBAC

**Authentication:** Argon2id password hashing; mandatory MFA for clinical roles; server-side sessions
with idle and absolute timeouts; account lockout after repeated failures; password reset via
single-use, short-lived tokens.

**Authorisation is two-layered:** a role grants a capability, and a per-patient grant
(`patient_access`) determines the records it applies to. A clinician with no grant on a patient sees
nothing, regardless of role.

| Capability | admin | clinician | assistant | reception | auditor |
|---|---|---|---|---|---|
| View patient list | clinic-wide | granted only | granted only | limited (name/contact) | granted only (read) |
| Read clinical record | ✅ | ✅ granted | ✅ granted | ❌ | ✅ read-only |
| Write clinical facts | ✅ | ✅ granted | ⚠️ draft only | ❌ | ❌ |
| Compute energy assessment | ✅ | ✅ | ✅ draft | ❌ | ❌ |
| **Approve** targets/plans | ✅ | ✅ | ❌ | ❌ | ❌ |
| Manage users & grants | ✅ | ❌ | ❌ | ❌ | ❌ |
| Export PDF | ✅ | ✅ granted | ❌ | ❌ | ❌ |
| View audit log | ✅ | own activity | ❌ | ❌ | ✅ |
| Delete data | ✅ (via DSR workflow) | ❌ | ❌ | ❌ | ❌ |

**Separation of duties:** the assistant may prepare drafts; only a clinician may approve. An auditor
can read everything and change nothing. Approval capability cannot be self-granted.

---

## 5. Encryption

| Layer | Requirement |
|---|---|
| In transit | TLS 1.2+ only, HSTS, secure cookies, no mixed content |
| At rest (database) | Volume-level encryption **plus** column encryption for national ID and contact details (`pgcrypto`) |
| At rest (objects) | Server-side encryption on private buckets; no public URLs ever |
| Field-level | Direct identifiers encrypted with keys held in the secret manager, not in the DB |
| Backups | Encrypted, and restorable only with separately held keys |
| Keys | Managed in a secret manager; rotation on a documented schedule; never in images, repos or logs |

---

## 6. Audit logging

Append-only, enforced at the database level (see `audit_log` in `docs/database-schema.sql`; UPDATE and
DELETE are blocked by trigger, and the application role holds no such grants).

Each entry records: clinic, actor, IP, user agent, action, entity type and id, patient id (where
applicable), before/after state, timestamp.

**Must be audited:** every read of a patient record, every write, every approval, every export, every
login and failed login, every permission change, every knowledge-base upload, and every external
research query. Audit records are never exposed to non-auditor roles and are retained per policy.

---

## 7. File upload security

- Allow-list by content type and extension; verify declared type against magic bytes.
- Size limits per file; reject archives.
- Store outside the web root in private object storage under random keys; serve only via
  short-lived signed URLs after an authorisation check.
- Scan for malware before the file becomes retrievable; quarantine on failure.
- Strip or ignore embedded scripts and macros.
- Never derive filenames from user input; never serve from a path built from user input.
- Record hash, uploader and purpose in `asset`.

**The prototype's render check exposed a live instance of this class of problem:** `qa-smoke.html`
sat in the site root and would have shipped, and a static nginx root will serve `README.md` and
`docs/` to anyone who asks. See README §Before you deploy.

---

## 8. Privacy, consent and regulatory

The brief requires support for applicable Egyptian personal-data protection requirements and other
relevant regulations, subject to legal and security review. This document is an engineering design,
**not legal advice** — a qualified review is required before clinical deployment.

Engineering provisions:

- **Consent** recorded per kind (treatment, data processing, research, imaging) with grant and
  withdrawal timestamps, and the signed document stored as an asset.
- **Data-subject requests** modelled explicitly (`export`, `deletion`, `rectification`,
  `restriction`) with audit trail and outcome.
- **Deletion** must be defined against the record-preservation duty — clinical retention rules may
  require pseudonymisation rather than erasure; this is a policy decision to be confirmed legally.
- **Right of access** produces a machine-readable export plus a human-readable summary.
- **Data minimisation:** the prototype's demo seeding must never run in a production instance.

### De-identification for outbound calls

The brief forbids transmitting identifiable patient information to public search engines, and §19
requires de-identified information for external research wherever possible.

- Every patient carries a `deid_token`; outbound payloads reference only that token.
- Outbound requests are built from a whitelist of clinical fields (age band, sex, BMI band, conditions,
  restrictions) — never names, IDs, phone numbers, emails, addresses or free-text notes.
- A filter runs on the assembled payload and rejects the request if any direct identifier pattern
  survives.
- External AI is optional and off by default; when disabled, the copilot runs in deterministic mode
  and states plainly that no live model was consulted.

---

## 9. AI and research services

| Concern | Requirement |
|---|---|
| Keys | Server-side only, from the secret manager (§19 forbids frontend keys) |
| Grounding | RAG over the knowledge base, ordered by the evidence hierarchy: patient-specific → guidelines → validated food databases → clinician uploads → web |
| Citations | Every substantive recommendation carries a source; **references are never fabricated** |
| Honesty | If research is unavailable, say so — never claim a search happened (brief §12) |
| Output status | Draft until a clinician approves; never auto-applied |
| Numerical output | Never authoritative — deterministic functions own all clinical arithmetic |
| Audit | Every external query logged, with the de-identified payload |
| Conflicts | Detect and surface conflicting or outdated sources rather than silently accepting an upload |

---

## 10. Transport hardening

- **CSP:** strict, no `unsafe-inline`; every asset served same-origin. The prototype already meets
  this constraint — no CDNs, no external fonts, no runtime third-party calls.
- HSTS, `X-Content-Type-Options: nosniff`, `Referrer-Policy: no-referrer`,
  `X-Frame-Options: DENY` / `frame-ancestors 'none'`.
- CSRF protection on state-changing requests (double-submit token or strict `SameSite`).
- Rate limiting on authentication, export and research endpoints.
- No directory listing; no source maps in production; no stack traces to clients.
- `README.md`, `docs/` and `deploy/` excluded from the served bundle.

---

## 11. Backups and recovery

- Automated encrypted backups on a defined schedule, with point-in-time recovery.
- Restore tested on a schedule — an untested backup is not a backup.
- Backups stored separately from primary credentials.
- Documented RPO/RTO agreed with the clinic.
- **Prototype today:** manual JSON export via Settings. No schedule, no verification, no encryption,
  no recovery test. Clearing browser storage destroys all records irrecoverably.

---

## 12. Threat model (abridged)

| Threat | Current prototype | Target mitigation |
|---|---|---|
| Shared workstation, unauthorised viewing | **Unmitigated** — no auth at all | AuthN + MFA + per-patient grants + RLS |
| Theft of device | **Unmitigated** — IndexedDB plaintext | Disk encryption, no local PHI, server-side access control |
| Silent record alteration | **Unmitigated** — no trail | Append-only facts + immutable audit log |
| Data loss | **Unmitigated** — clear storage = total loss | Managed backups with tested restore |
| Malicious upload | N/A | Type verification, AV scan, private storage, signed URLs |
| Key leakage | N/A (no keys) | Secret manager, server-only keys, rotation |
| PHI in outbound AI/search | Adapter off by default | De-identification filter, whitelist payloads, audit |
| Serving docs/metadata publicly | **Live risk** — `README.md`, `docs/`, `qa-smoke.html` in root | Exclude from bundle, delete QA page |

---

## 13. Migration path from the prototype

Ordered, and each step independently testable.

1. **Stand up** PostgreSQL (`docs/database-schema.sql`) and the API surface in §3.
2. **Translate** the engine: `engine.js` and `planner.js` are pure functions and port unchanged.
   Keep one implementation — do not fork the logic.
3. **Export** prototype data via `Settings → Backup` (JSON).
4. **Import** into the schema. The prototype's entity names align with the table names by design, so
   the mapping is mechanical; validate row counts and spot-check calculations before and after.
5. **Re-point** the front end at the API, replacing the IndexedDB adapter behind the same interface
   so views do not change.
6. **Add** auth, RBAC, audit, uploads and backups, then re-run the end-to-end workflow from patient
   registration through PDF export and follow-up reassessment — the acceptance test in brief §23.

Until step 6 passes, this document describes an intention, not a system.
