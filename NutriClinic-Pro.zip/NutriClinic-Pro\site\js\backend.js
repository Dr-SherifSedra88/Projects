/* ==========================================================================
   NutriClinic Pro — backend.js
   Optional server backend: Supabase (PostgreSQL + Auth + Object Storage).

   WHY THIS FILE EXISTS
   Browser storage cannot hold real clinical records safely: it has no login, no
   audit trail and no shared record set. This module supplies those, while
   leaving the local tier intact so the app still runs with no server at all.

   SECRETS POLICY (brief §19)
   Only the Supabase ANON key ever reaches this file. It is designed to be
   public — every table is protected by Row Level Security, so the key alone
   grants nothing. The service_role key bypasses RLS and must NEVER appear here,
   in config.js, or anywhere the browser can read. AI provider keys stay behind
   the proxy described in README.

   TRANSPORT
   Plain fetch against Supabase's REST, Auth and Storage HTTP APIs. No SDK
   script is loaded, so the strict no-external-assets CSP still holds.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  var BUCKET = 'clinical-documents';
  var SESSION_KEY = 'cn.backend.session';
  var CLINICAL_TABLES = ['patients', 'measurements', 'labs', 'assessments',
    'plans', 'followups', 'attachments', 'recipes', 'kb'];

  var cfg = { url: '', anonKey: '' };
  var session = null;
  var clinicCache = null;

  /* --------------------------------------------------------------- config -- */
  function loadConfig() {
    var w = window.NUTRICLINIC_CONFIG || {};
    cfg.url = String(w.supabaseUrl || '').trim().replace(/\/+$/, '');
    cfg.anonKey = String(w.supabaseAnonKey || '').trim();
    // A device-level override is allowed for the anon key only.
    try {
      var local = JSON.parse(localStorage.getItem('cn.backend.cfg') || 'null');
      if (local && local.url) cfg.url = String(local.url).replace(/\/+$/, '');
      if (local && local.anonKey) cfg.anonKey = String(local.anonKey);
    } catch (e) { /* ignore */ }
    return cfg;
  }

  /** Persist a device-level override for a deployment without config.js. */
  function saveConfig(url, anonKey) {
    cfg.url = String(url || '').trim().replace(/\/+$/, '');
    cfg.anonKey = String(anonKey || '').trim();
    try {
      localStorage.setItem('cn.backend.cfg', JSON.stringify({ url: cfg.url, anonKey: cfg.anonKey }));
    } catch (e) { /* ignore */ }
    return cfg;
  }

  function configured() { return !!(cfg.url && cfg.anonKey); }

  /* ---------------------------------------------------------------- session */
  function loadSession() {
    if (session) return session;
    try { session = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null'); }
    catch (e) { session = null; }
    return session;
  }

  function saveSession() {
    try {
      if (session) localStorage.setItem(SESSION_KEY, JSON.stringify(session));
      else localStorage.removeItem(SESSION_KEY);
    } catch (e) { /* ignore */ }
  }

  function hasSession() {
    var s = loadSession();
    return !!(s && s.access_token);
  }

  function currentUser() {
    var s = loadSession();
    return s ? (s.user || null) : null;
  }

  function currentRole() {
    var s = loadSession();
    return s ? (s.role || null) : null;
  }

  function normaliseSession(j) {
    if (!j || !j.access_token) return null;
    var prev = loadSession() || {};
    return {
      access_token: j.access_token,
      refresh_token: j.refresh_token || prev.refresh_token || null,
      // Refresh a minute early so a token never expires mid-request.
      expires_at: Date.now() + ((Number(j.expires_in) || 3600) * 1000) - 60000,
      user: j.user || prev.user || null,
      role: (j.user && j.user.role) || prev.role || null
    };
  }

  /* ------------------------------------------------------------ http layer - */
  function parse(r) {
    if (r.status === 204) return Promise.resolve(null);
    return r.text().then(function (t) {
      var j = null;
      if (t) { try { j = JSON.parse(t); } catch (e) { j = null; } }
      if (!r.ok) {
        var msg = (j && (j.error_description || j.msg || j.message || j.error || j.hint)) ||
          ('HTTP ' + r.status);
        var err = new Error(msg);
        err.status = r.status;
        err.body = j;
        throw err;
      }
      return j;
    });
  }

  function authHeaders(token, extra) {
    var h = { apikey: cfg.anonKey };
    if (token) h.Authorization = 'Bearer ' + token;
    return Object.assign(h, extra || {});
  }

  /** Access token, refreshed when close to expiry. */
  function token() {
    var s = loadSession();
    if (!s || !s.access_token) return Promise.reject(new Error('Not signed in.'));
    if (s.expires_at && Date.now() > s.expires_at && s.refresh_token) {
      return refresh().then(function (n) { return n.access_token; })
        .catch(function () { return s.access_token; });   // let the server refuse if stale
    }
    return Promise.resolve(s.access_token);
  }

  /* ------------------------------------------------------------------- auth */
  function signIn(email, password) {
    if (!configured()) return Promise.reject(new Error('No backend is configured.'));
    return fetch(cfg.url + '/auth/v1/token?grant_type=password', {
      method: 'POST',
      headers: authHeaders(null, { 'Content-Type': 'application/json' }),
      body: JSON.stringify({ email: email, password: password })
    }).then(parse).then(function (j) {
      session = normaliseSession(j);
      saveSession();
      clinicCache = null;
      CN.bus.emit('auth', { action: 'signin', user: session.user });
      return session.user;
    });
  }

  function signUp(email, password, clinicName) {
    if (!configured()) return Promise.reject(new Error('No backend is configured.'));
    return fetch(cfg.url + '/auth/v1/signup', {
      method: 'POST',
      headers: authHeaders(null, { 'Content-Type': 'application/json' }),
      body: JSON.stringify({ email: email, password: password })
    }).then(parse).then(function (j) {
      // With email confirmation enabled there is no session yet, and that is
      // reported honestly rather than looking like a failure.
      var s = j && j.access_token ? normaliseSession(j) : null;
      if (s) {
        session = s;
        saveSession();
        return bootstrapClinic(clinicName).then(function () {
          CN.bus.emit('auth', { action: 'signin', user: s.user });
          return { signedIn: true, user: s.user };
        });
      }
      return { signedIn: false, needsEmailConfirmation: true };
    });
  }

  function signOut() {
    var s = loadSession();
    var t = s && s.access_token;
    session = null;
    clinicCache = null;
    saveSession();
    CN.bus.emit('auth', { action: 'signout' });
    if (!t || !configured()) return Promise.resolve(true);
    return fetch(cfg.url + '/auth/v1/logout', { method: 'POST', headers: authHeaders(t) })
      .catch(function () { return null; })   // a local sign-out must always succeed
      .then(function () { return true; });
  }

  function refresh() {
    var s = loadSession();
    if (!s || !s.refresh_token) return Promise.reject(new Error('No refresh token available.'));
    return fetch(cfg.url + '/auth/v1/token?grant_type=refresh_token', {
      method: 'POST',
      headers: authHeaders(null, { 'Content-Type': 'application/json' }),
      body: JSON.stringify({ refresh_token: s.refresh_token })
    }).then(parse).then(function (j) {
      session = normaliseSession(j);
      saveSession();
      return session;
    });
  }

  /* -------------------------------------------------------------- rest/rpc - */
  function rest(path, opts) {
    opts = opts || {};
    return token().then(function (t) {
      var headers = authHeaders(t, { 'Content-Type': 'application/json' });
      if (opts.prefer) headers.Prefer = opts.prefer;
      return fetch(cfg.url + '/rest/v1/' + path, {
        method: opts.method || 'GET',
        headers: headers,
        body: opts.body === undefined ? undefined : JSON.stringify(opts.body)
      });
    }).then(parse);
  }

  function rpc(name, args) {
    return rest('rpc/' + name, { method: 'POST', body: args || {} });
  }

  /** Which clinic, and with what role, this account belongs to. */
  function clinic() {
    if (clinicCache) return Promise.resolve(clinicCache);
    return rest('clinic_members?select=clinic_id,role&limit=1').then(function (rows) {
      if (!rows || !rows.length) {
        var e = new Error('This account is not a member of a clinic yet.');
        e.code = 'no_clinic';
        throw e;
      }
      clinicCache = { id: rows[0].clinic_id, role: rows[0].role };
      var s = loadSession();
      if (s && s.role !== clinicCache.role) { s.role = clinicCache.role; session = s; saveSession(); }
      return clinicCache;
    });
  }

  function bootstrapClinic(name) {
    return rpc('bootstrap_clinic', { clinic_name: name || 'My Clinic' }).then(function () {
      clinicCache = null;
      return true;
    });
  }

  function inviteMember(email, role) {
    return rpc('add_clinic_member', { member_email: email, member_role: role || 'clinician' });
  }

  /* ---------------------------------------------------------------- storage */
  function uploadObject(path, blob, contentType) {
    return token().then(function (t) {
      return fetch(cfg.url + '/storage/v1/object/' + BUCKET + '/' + path, {
        method: 'POST',
        headers: authHeaders(t, {
          'Content-Type': contentType || 'application/octet-stream',
          'x-upsert': 'true'
        }),
        body: blob
      });
    }).then(parse).then(function () { return true; });
  }

  function signedUrl(path, seconds) {
    return token().then(function (t) {
      return fetch(cfg.url + '/storage/v1/object/sign/' + BUCKET + '/' + path, {
        method: 'POST',
        headers: authHeaders(t, { 'Content-Type': 'application/json' }),
        body: JSON.stringify({ expiresIn: seconds || 300 })
      });
    }).then(parse).then(function (j) {
      if (!j || !j.signedURL) throw new Error('The storage service did not return a signed URL.');
      return cfg.url + '/storage/v1' + j.signedURL;
    });
  }

  function removeObject(path) {
    return token().then(function (t) {
      return fetch(cfg.url + '/storage/v1/object/' + BUCKET + '/' + path, {
        method: 'DELETE', headers: authHeaders(t)
      });
    }).then(function () { return true; });
  }

  /* ------------------------------------------------------- remote adapter --- */
  function rowToObject(row) {
    var obj = Object.assign({}, row.data || {});
    obj.id = row.id;
    if (row.patient_id) obj.patientId = row.patient_id;
    if (row.storage_path) obj.storagePath = row.storage_path;
    if (row.created_at) obj.createdAt = obj.createdAt || row.created_at;
    return obj;
  }

  /**
   * Implements the same interface as the local storage tiers, so views are
   * unaware of which one is in use.
   */
  function RemoteAdapter() {
    return {
      name: 'supabase',

      all(table) {
        return clinic().then(function () { return rest(table + '?select=*'); })
          .then(function (rows) { return (rows || []).map(rowToObject); });
      },

      get(table, id) {
        return clinic()
          .then(function () { return rest(table + '?select=*&id=eq.' + encodeURIComponent(id)); })
          .then(function (rows) { return (rows && rows.length) ? rowToObject(rows[0]) : null; });
      },

      put(table, obj) {
        return clinic().then(function (c) {
          var payload = Object.assign({}, obj);
          var blob = payload.blob || null;
          var patientId = payload.patientId || null;
          var existingPath = payload.storagePath || null;
          delete payload.blob;
          delete payload.storagePath;

          var prep = Promise.resolve(existingPath);
          if (blob) {
            // Documents go to private object storage, never into the database
            // row and never into a public bucket.
            var safe = String(payload.filename || 'document')
              .replace(/[^A-Za-z0-9._-]+/g, '_').slice(0, 80);
            var path = c.id + '/' + (patientId || 'unassigned') + '/' + obj.id + '-' + safe;
            prep = uploadObject(path, blob, payload.mime).then(function () { return path; });
          }

          return prep.then(function (path) {
            return rest(table + '?on_conflict=id', {
              method: 'POST',
              prefer: 'resolution=merge-duplicates,return=minimal',
              body: {
                id: String(obj.id),
                clinic_id: c.id,
                patient_id: patientId,
                storage_path: path || null,
                data: payload,
                updated_at: new Date().toISOString()
              }
            });
          }).then(function () { return obj; });
        });
      },

      del(table, id) {
        return clinic()
          .then(function () { return rest(table + '?id=eq.' + encodeURIComponent(id), { method: 'DELETE' }); })
          .then(function () { return true; });
      },

      clear(table) {
        // RLS confines this to the signed-in clinic.
        return clinic()
          .then(function () { return rest(table + '?id=not.is.null', { method: 'DELETE' }); })
          .then(function () { return true; });
      },

      wipe() {
        return CLINICAL_TABLES.reduce(function (chain, t) {
          return chain.then(function () { return this.clear(t); }.bind(this));
        }.bind(this), Promise.resolve());
      },

      raw() {
        var out = {};
        return CLINICAL_TABLES.reduce(function (chain, t) {
          return chain.then(function () {
            return this.all(t).then(function (rows) { out[t] = rows; });
          }.bind(this));
        }.bind(this), Promise.resolve()).then(function () { return out; });
      },

      load(snapshot) {
        return CLINICAL_TABLES.reduce(function (chain, t) {
          return chain.then(function () {
            var rows = snapshot[t] || [];
            return rows.reduce(function (c2, row) {
              return c2.then(function () { return this.put(t, row); }.bind(this));
            }.bind(this), Promise.resolve());
          }.bind(this));
        }.bind(this), Promise.resolve()).then(function () { return true; });
      }
    };
  }

  /* --------------------------------------------------------------- probing - */
  /** A real round-trip, so "connected" means connected. */
  function testConnection() {
    if (!configured()) {
      return Promise.resolve({ ok: false, reason: 'No backend URL or anon key is set.' });
    }
    return rest('patients?select=id&limit=1').then(function () {
      return clinic().then(function (c) {
        return { ok: true, clinicId: c.id, role: c.role };
      }).catch(function (e) {
        if (e.code === 'no_clinic') {
          return { ok: true, signedIn: true, clinicId: null,
            reason: 'Signed in, but this account has no clinic yet.' };
        }
        throw e;
      });
    }).catch(function (e) {
      return { ok: false, reason: e.message || String(e), status: e.status || null };
    });
  }

  CN.backend = {
    TABLES: CLINICAL_TABLES,
    BUCKET: BUCKET,
    loadConfig: loadConfig,
    saveConfig: saveConfig,
    configured: configured,
    hasSession: hasSession,
    currentUser: currentUser,
    currentRole: currentRole,
    signIn: signIn,
    signUp: signUp,
    signOut: signOut,
    refresh: refresh,
    clinic: clinic,
    bootstrapClinic: bootstrapClinic,
    inviteMember: inviteMember,
    rest: rest,
    rpc: rpc,
    uploadObject: uploadObject,
    signedUrl: signedUrl,
    removeObject: removeObject,
    createAdapter: function () { return RemoteAdapter(); },
    testConnection: testConnection
  };
})();
