/* ==========================================================================
   NutriClinic Pro — views-planning.js
   Diet Plan Builder, Follow-Up Management, Reports & PDF.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;
  var ui = CN.ui;

  /* --------------------------------------------------------- plan storage -- */
  /** The patient's plan document, or null when none exists yet. */
  function loadPlan(patientId) {
    return CN.store.byPatient('plans', patientId).then(function (rows) {
      return rows[0] || null;
    });
  }

  function activeVersion(plan) {
    if (!plan || !plan.versions || !plan.versions.length) return null;
    return plan.versions.filter(function (v) { return v.id === plan.activeVersionId; })[0] ||
      plan.versions[plan.versions.length - 1];
  }

  /** Persist a new version onto the patient's plan document. */
  function saveVersion(patientId, version) {
    return loadPlan(patientId).then(function (plan) {
      if (!plan) {
        plan = { id: U.uid('pln'), patientId: patientId, title: 'Diet plan',
          createdAt: new Date().toISOString(), versions: [], activeVersionId: null };
      }
      // Never mutate an existing version — append a new one.
      version.versionNo = (plan.versions.length ? Math.max.apply(null,
        plan.versions.map(function (v) { return v.versionNo || 0; })) + 1 : 1);
      plan.versions.push(version);
      plan.activeVersionId = version.id;
      return CN.store.put('plans', plan).then(function () { return { plan: plan, version: version }; });
    });
  }

  /* ================================================================ BUILDER  */
  var Builder = {
    title: 'nav.planner',

    render(host, ctx) {
      var patient = ctx.patient;
      if (!patient) { ui.needPatient(host); return; }

      host.innerHTML = ui.pageHead('pl.title', 'pl.subtitle');

      Promise.all([
        CN.store.settings(),
        CN.store.byPatient('assessments', patient.id),
        loadPlan(patient.id),
        CN.store.byPatient('measurements', patient.id),
        CN.store.all('templates'),
        CN.store.all('recipes')
      ]).then(function (r) {
        var settings = r[0], assessments = r[1], plan = r[2], ms = r[3], templates = r[4];
        var approved = ui.approvedAssessment(assessments, patient.id);
        // Register recipes before anything renders, so they resolve as foods.
        CN.planner.setRecipeIndex(r[5] || []);

        if (!approved) {
          host.innerHTML += ui.notice(CN.t('pl.needApprovedTarget'), 'warn') +
            CN.empty(CN.t('pl.noPlans'), CN.t('pl.needApprovedTarget'),
              '<button class="btn btn-primary" data-go="energy">' + U.esc(CN.t('nav.energy')) + '</button>');
          U.on(host, 'click', '[data-go]', function (e, el) { CN.app.go(el.getAttribute('data-go')); });
          return;
        }

        var version = activeVersion(plan);

        /* ---- generation controls ---- */
        var html = ui.card('pl.generate',
          '<div class="inline-fields">' +
          '<div class="field"><label for="g-duration">' + U.esc(CN.t('pl.duration')) + '</label>' +
            '<input id="g-duration" type="number" min="1" max="28" value="' +
            U.esc(settings.defaultDuration || 7) + '"/></div>' +
          '<div class="field"><label for="g-start">' + U.esc(CN.t('pl.startsOn')) + '</label>' +
            '<input id="g-start" type="date" value="' + U.todayISO() + '"/></div>' +
          '<div class="field"><label for="g-template">' + U.esc(CN.t('pl.templates')) + '</label>' +
            '<select id="g-template">' + CN.options(
              [{ value: '', label: CN.t('common.none') }].concat(
                (templates || []).map(function (t) { return { value: t.id, label: t.name }; }))
            ) + '</select></div>' +
          '</div>' +
          '<div class="field"><label>' + U.esc(CN.t('pl.approaches')) + '</label>' +
            '<div class="chip-row" id="g-approaches">' + CN.approaches.all.map(function (a) {
              var checked = (version && version.approachCodes || ['mediterranean']).indexOf(a.code) !== -1;
              return '<label class="check" style="margin:0"><input type="checkbox" value="' + a.code + '"' +
                (checked ? ' checked' : '') + '/> <span>' + U.esc(a.nameEn) + '</span></label>';
            }).join('') + '</div></div>' +
          '<div id="g-compat"></div>' +
          '<div class="btn-row">' +
            '<button class="btn btn-primary" id="g-generate">' + CN.icon('sparkles', 16) + ' ' +
              U.esc(CN.t('pl.generate')) + '</button>' +
            (version ? '<button class="btn" id="g-save-template">' + CN.icon('save', 16) + ' ' +
              U.esc(CN.t('pl.saveTemplate')) + '</button>' : '') +
          '</div>');

        /* ---- current plan ---- */
        if (version) {
          var adherence = CN.planner.adherenceToTarget(version);
          html += '<div class="grid cols-4 mb2">' +
            ui.stat('en.target', U.nf(version.targetKcal, 0) + ' <small>kcal</small>',
              version.approachCodes.map(function (c) {
                var a = CN.approaches.byCode(c); return a ? a.nameEn : c;
              }).join(' + '), 'accent') +
            ui.stat('pl.weekTotals', U.nf(adherence.average.kcal, 0) + ' <small>kcal</small>',
              (adherence.deviation.kcal > 0 ? '+' : '') + U.nf(adherence.deviation.kcal, 0) + ' vs target') +
            ui.stat('en.protein', U.nf(adherence.average.protein, 0) + ' <small>g</small>',
              version.macros && version.macros.proteinG
                ? (adherence.deviation.protein > 0 ? '+' : '') + U.nf(adherence.deviation.protein, 0) + ' g' : '') +
            ui.stat('common.status', ui.planStatus(version.status),
              CN.t('common.version') + ' ' + version.versionNo) +
            '</div>';

          // Deviation warnings — the plan must stay on its approved targets.
          var devHtml = '';
          if (adherence.kcalStatus !== 'on' && adherence.kcalStatus !== 'na') {
            var tone = adherence.kcalStatus === 'over' ? 'alert' : 'warn';
            devHtml += ui.notice(CN.t('pl.needApproval2') + ' ' +
              (adherence.kcalStatus === 'over' ? CN.t('pl.over') : CN.t('pl.under')) + ' — ' +
              (adherence.deviation.kcal > 0 ? '+' : '') + U.nf(adherence.deviation.kcal, 0) + ' kcal/day', tone);
          }
          if (adherence.sodiumOver > 0) {
            devHtml += ui.notice(CN.t('en.sodium') + ': +' + U.nf(adherence.sodiumOver, 0) + ' mg over the ceiling', 'warn');
          }
          (version.warnings || []).forEach(function (w) { devHtml += ui.notice(w, 'warn'); });
          if (devHtml) html += devHtml;

          html += ui.card(null, planMarkup(version),
            null, { flush: false });

          html += '<div class="btn-row mb2">' +
            (version.status !== 'approved'
              ? '<button class="btn btn-primary" id="g-approve">' + CN.icon('check', 16) + ' ' +
                U.esc(CN.t('pl.approve')) + '</button>' : '') +
            '<button class="btn" data-go="reports">' + CN.icon('printer', 16) + ' ' +
              U.esc(CN.t('nav.reports')) + '</button>' +
            '<button class="btn" data-go="followup">' + CN.icon('calendar', 16) + ' ' +
              U.esc(CN.t('nav.followup')) + '</button>' +
            '</div>';

          // Version history + diff
          if (plan.versions.length > 1) {
            html += ui.card('pl.versions',
              '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
              '<th>' + U.esc(CN.t('common.version')) + '</th>' +
              '<th>' + U.esc(CN.t('common.date')) + '</th>' +
              '<th class="num">' + U.esc(CN.t('en.target')) + '</th>' +
              '<th>' + U.esc(CN.t('common.status')) + '</th>' +
              '<th></th></tr></thead><tbody>' +
              U.sortBy(plan.versions, 'versionNo', 'desc').map(function (v) {
                return '<tr' + (v.id === version.id ? ' style="background:#F8FAFD"' : '') + '>' +
                  '<td>v' + U.esc(v.versionNo) + '</td>' +
                  '<td>' + U.esc(U.fmtDate(v.createdAt)) + '</td>' +
                  '<td class="num">' + ui.num(v.targetKcal, 0) + '</td>' +
                  '<td>' + ui.planStatus(v.status) + '</td>' +
                  '<td class="right"><button class="btn btn-xs" data-view-v="' + U.esc(v.id) + '">' +
                    U.esc(CN.t('common.view')) + '</button> ' +
                    '<button class="btn btn-xs" data-diff-v="' + U.esc(v.id) + '">' +
                    U.esc(CN.t('pl.diff')) + '</button></td></tr>';
              }).join('') + '</tbody></table></div>');
          }
        } else {
          html += CN.empty(CN.t('pl.noPlans'), CN.t('pl.noPlansMsg'));
        }

        host.innerHTML += html;

        /* ---- wiring ---- */
        function selectedApproaches() {
          return U.$$('#g-approaches input:checked').map(function (i) { return i.value; });
        }

        function updateCompat() {
          var codes = selectedApproaches();
          var el = U.$('#g-compat');
          if (!el) return;
          if (codes.length < 2) { el.innerHTML = ''; return; }
          var ev = CN.approaches.evaluate(codes);
          el.innerHTML = ev.pairs.map(function (p) {
            var tone = p.level === 'incompatible' ? 'alert' : (p.level === 'caution' ? 'warn' :
              (p.level === 'redundant' ? 'info' : 'ok'));
            return ui.notice(
              CN.i18n.lang === 'ar' ? (CN.approaches.byCode(p.a).nameAr + ' + ' + CN.approaches.byCode(p.b).nameAr)
                : (CN.approaches.byCode(p.a).nameEn + ' + ' + CN.approaches.byCode(p.b).nameEn)) +
              ' — ' + p.rationale, tone);
          }).join('');
        }
        updateCompat();
        U.on(host, 'change', '#g-approaches input', updateCompat);

        U.on(host, 'click', '#g-generate', function () {
          var codes = selectedApproaches();
          if (!codes.length) { CN.toast(CN.t('pl.selectApproach'), 'warn'); return; }
          var ev = CN.approaches.evaluate(codes);
          if (!ev.ok) {
            CN.toast(CN.t('pl.incompatible'), 'alert', 5000);
            return;
          }
          var lim = CN.approaches.mergedLimits(codes);
          var profile = CN.approaches.mergedMacros(codes) ||
            { proteinPct: 20, carbPct: 45, fatPct: 35 };
          var recomputed = CN.engine.macros({
            targetKcal: approved.targetKcal, weightKg: approved.weightKg, profile: profile,
            method: lim.proteinPerKg ? 'hybrid' : 'percent',
            proteinPerKg: lim.proteinPerKg || 0.8,
            fiberMin: lim.fiberMin, sodiumMaxMg: lim.sodiumMaxMg
          });

          /* ---- Energy Calculator -> Plan Builder contract -------------------
             The clinician approved macro targets on the Energy Calculator. Those
             are the decision of record, so this plan uses them. Recomputing here
             would silently substitute this screen's approach profiles for what
             was actually approved, and the plan's own deviation checks would
             then be measured against the wrong baseline.

             normaliseMacros() also repairs an assessment written by the earlier
             build, which could store percentages while omitting the gram values
             the builder reads. */
          var approvedMacros = CN.engine.normaliseMacros(approved.macros, approved.targetKcal);
          var macro = recomputed;
          var macrosSource = 'recomputed';
          var macrosNote = null;

          if (approvedMacros && approvedMacros.complete) {
            macro = approvedMacros;
            macrosSource = 'approved';
            if (approvedMacros.derivedFromPercentages) {
              macrosSource = 'approved_derived';
              macrosNote = 'The approved target stored macro percentages without gram targets. ' +
                'Grams were derived from the percentages and the calorie target (' +
                U.nf(approvedMacros.proteinG, 0) + ' g protein, ' +
                U.nf(approvedMacros.carbG, 0) + ' g carbohydrate, ' +
                U.nf(approvedMacros.fatG, 0) + ' g fat). Review before approving this plan.';
            }
          } else {
            macrosNote = 'No usable macro targets were found on the approved assessment, so this plan ' +
              'recomputed them from the selected approaches. The Energy Calculator is the authoritative ' +
              'source — approve a target there to carry its macro split into this plan.';
          }

          // Flag a material disagreement between the approved split and this
          // screen's approach profiles, rather than letting either silently win.
          var divergence = null;
          if (approvedMacros && approvedMacros.complete && recomputed) {
            var refProtein = approvedMacros.proteinG || 0;
            var deltaProtein = (recomputed.proteinG || 0) - refProtein;
            var deltaEnergy = (recomputed.energyFromMacros || 0) - (approved.targetKcal || 0);
            if ((refProtein > 0 && Math.abs(deltaProtein) / refProtein > 0.15) ||
                Math.abs(deltaEnergy) > 100) {
              divergence = {
                approvedProteinG: refProtein,
                profileProteinG: recomputed.proteinG,
                proteinGDelta: U.round(deltaProtein, 0),
                energyDelta: U.round(deltaEnergy, 0)
              };
              macrosNote = (macrosNote ? macrosNote + '  ' : '') +
                'Note: the approaches selected on this screen would give ' +
                U.nf(divergence.profileProteinG, 0) + ' g protein (' +
                (divergence.proteinGDelta > 0 ? '+' : '') + U.nf(divergence.proteinGDelta, 0) +
                ' g) against the approved target. The approved values are used.';
            }
          }

          var templateId = U.$('#g-template') ? U.$('#g-template').value : '';
          var tpl = (templates || []).filter(function (t) { return t.id === templateId; })[0];

          var versionNew;
          if (tpl) {
            versionNew = CN.planner.fromTemplate(tpl, {
              patient: patient, targetKcal: approved.targetKcal, macros: macro,
              durationDays: U.parseNum(U.$('#g-duration').value),
              startDate: U.$('#g-start').value, assessmentId: approved.id
            });
          } else {
            versionNew = CN.planner.generate({
              patient: patient, targetKcal: approved.targetKcal, macros: macro,
              approachCodes: codes,
              durationDays: U.parseNum(U.$('#g-duration').value),
              startDate: U.$('#g-start').value,
              patternKey: lim.pattern, assessmentId: approved.id,
              generatedBy: 'engine'
            });
          }

          if (!versionNew || !versionNew.ok) {
            CN.toast(CN.t('pl.needApprovedTarget'), 'alert');
            return;
          }
          versionNew.status = 'pending_approval';
          // Record which macro targets the plan actually used, so the choice is
          // auditable rather than inferred from the numbers.
          versionNew.macrosSource = macrosSource;
          versionNew.macrosDivergence = divergence;
          if (macrosNote) {
            versionNew.warnings = (versionNew.warnings || []).concat([macrosNote]);
          }
          saveVersion(patient.id, versionNew).then(function () {
            CN.toast(CN.t('common.saved'));
            CN.app.refresh();
          });
        });

        U.on(host, 'click', '#g-approve', function () {
          version.status = 'approved';
          version.approvedAt = new Date().toISOString();
          version.approvedBy = 'clinician';
          loadPlan(patient.id).then(function (p) {
            return CN.store.put('plans', p);
          }).then(function () {
            CN.toast(CN.t('pl.approved'));
            CN.app.refresh();
          });
        });

        U.on(host, 'click', '#g-save-template', function () {
          // A proper modal rather than window.prompt, which blocks the tab and is
          // suppressed entirely in some embedded browser contexts.
          var m = CN.modal({
            title: CN.t('pl.saveTemplate'),
            body: '<div class="field"><label for="tpl-name">' + U.esc(CN.t('rc.name')) +
              '</label><input id="tpl-name" type="text" value="Template ' +
              U.esc(U.fmtDate(U.todayISO())) + '"/></div>',
            actions: [
              { label: CN.t('common.cancel'), kind: 'ghost' },
              { label: CN.t('common.save'), kind: 'primary', close: false,
                onClick(node) {
                  var name = (U.$('#tpl-name', node).value || '').trim();
                  if (!name) { CN.toast(CN.t('common.noData'), 'warn'); return false; }
                  CN.store.put('templates', CN.planner.toTemplate(version, name)).then(function () {
                    CN.toast(CN.t('common.saved'));
                    m.close();
                    CN.app.refresh();
                  });
                  return false;
                } }
            ]
          });
        });

        U.on(host, 'click', '[data-view-v]', function (e, el) {
          var id = el.getAttribute('data-view-v');
          loadPlan(patient.id).then(function (p) {
            p.activeVersionId = id;
            return CN.store.put('plans', p);
          }).then(function () { CN.app.refresh(); });
        });

        U.on(host, 'click', '[data-diff-v]', function (e, el) {
          var other = plan.versions.filter(function (v) { return v.id === el.getAttribute('data-diff-v'); })[0];
          openDiff(version, other);
        });

        U.on(host, 'click', '[data-go]', function (e, el) { CN.app.go(el.getAttribute('data-go')); });

        wirePlanEditing(host, patient, plan, version);
      });
    }
  };

  /* ------------------------------------------------------- plan rendering -- */
  function planMarkup(version) {
    var lang = CN.i18n.lang;
    var html = '<div class="row mb1"><strong>' + U.esc(CN.t('pl.weekTotals')) + '</strong>' +
      '<div class="grow"></div>' +
      '<span class="muted">' + U.nf(version.targetKcal, 0) + ' kcal ' + U.esc(CN.t('pl.perDay')) + '</span></div>';

    html += version.days.map(function (day) {
      var status = '';
      var dev = Math.abs(day.totals.kcal - version.targetKcal) / version.targetKcal;
      if (dev > 0.08) {
        status = '<span class="chip ' + (day.totals.kcal > version.targetKcal ? 'alert' : 'gold') + '">' +
          (day.totals.kcal > version.targetKcal ? U.esc(CN.t('pl.over')) : U.esc(CN.t('pl.under'))) +
          ' ' + (day.totals.kcal > version.targetKcal ? '+' : '') +
          U.nf(day.totals.kcal - version.targetKcal, 0) + '</span>';
      }
      return '<div class="plan-day"><div class="plan-day-head">' +
        '<h4>' + U.esc((lang === 'ar' ? 'اليوم ' : 'Day ') + (day.dayIndex + 1)) +
        ' · ' + U.esc(U.fmtDate(day.date)) + '</h4>' +
        status +
        '<span class="muted mono">' + U.nf(day.totals.kcal, 0) + ' kcal · P ' + U.nf(day.totals.protein, 0) +
        ' · C ' + U.nf(day.totals.carb, 0) + ' · F ' + U.nf(day.totals.fat, 0) + '</span>' +
        '<button class="btn btn-xs" data-add-meal="' + day.dayIndex + '">' + CN.icon('plus', 12) + ' ' +
          U.esc(CN.t('pl.addMeal')) + '</button>' +
        '</div>' +
        day.meals.map(function (meal, mi) {
          return '<div class="meal"><div class="meal-head">' +
            '<strong>' + U.esc(lang === 'ar' ? (meal.labelAr || meal.labelEn) : meal.labelEn) + '</strong>' +
            (meal.time ? '<span class="chip">' + U.esc(meal.time) + '</span>' : '') +
            '<div class="grow"></div>' +
            '<button class="btn btn-xs" data-add-item="' + day.dayIndex + ':' + mi + '">' + CN.icon('plus', 12) + '</button> ' +
            '<button class="btn btn-xs" data-del-meal="' + day.dayIndex + ':' + mi + '">' + CN.icon('trash', 12) + '</button>' +
            '</div>' +
            meal.items.map(function (item) {
              var food = CN.planner.resolveFood(item.foodId);
              var name = CN.planner.itemName(item, lang);
              var portion = food ? CN.pdf.portionText(food, item.grams, lang) : '';
              return '<div class="item-row">' +
                '<div class="food-name"><span>' + U.esc(name) +
                  (item.isRecipe ? ' <span class="chip navy" style="font-size:.68rem">' +
                    U.esc(CN.t('rc.title')) + '</span>' : '') +
                  (item.needsVerify ? ' <span class="chip gold" style="font-size:.68rem">' +
                    U.esc(CN.t('fd.verify')) + '</span>' : '') +
                  (item.approximate ? ' <span class="chip" style="font-size:.68rem">≈</span>' : '') +
                  '</span>' +
                  (portion ? '<small>' + U.esc(portion) + '</small>' : '') + '</div>' +
                '<input type="number" step="5" value="' + U.esc(item.grams) + '" data-grams="' +
                  U.esc(item.id) + '" data-loc="' + day.dayIndex + ':' + mi + '" style="width:80px"/>' +
                '<span class="qty">' + U.nf(item.kcal, 0) + ' kcal</span>' +
                '<span class="nowrap">' +
                  '<button class="btn btn-xs" data-swap="' + U.esc(item.id) + ':' + day.dayIndex + ':' + mi +
                    '" title="' + U.esc(CN.t('pl.smartReplace')) + '">' + CN.icon('swap', 12) + '</button> ' +
                  '<button class="btn btn-xs" data-del-item="' + U.esc(item.id) + ':' + day.dayIndex + ':' + mi +
                    '">' + CN.icon('x', 12) + '</button>' +
                '</span>' +
                '</div>';
            }).join('') +
            (meal.instructions ? '<p class="muted" style="font-size:.8rem;margin:.3rem 0 0">' +
              U.esc(meal.instructions) + '</p>' : '') +
            '<div class="meal-totals">' +
            '<span>' + U.esc(CN.t('pl.mealTotals')) + ': <b>' + U.nf(meal.totals.kcal, 0) + ' kcal</b></span>' +
            '<span>P <b>' + U.nf(meal.totals.protein, 0) + ' g</b></span>' +
            '<span>C <b>' + U.nf(meal.totals.carb, 0) + ' g</b></span>' +
            '<span>F <b>' + U.nf(meal.totals.fat, 0) + ' g</b></span>' +
            '</div></div>';
        }).join('') + '</div>';
    }).join('');
    return html;
  }

  /* --------------------------------------------------------- plan editing -- */
  function wirePlanEditing(host, patient, plan, version) {
    if (!version) return;

    function persist() {
      return loadPlan(patient.id).then(function (p) {
        p.versions = p.versions.map(function (v) { return v.id === version.id ? version : v; });
        return CN.store.put('plans', p);
      });
    }

    // Gram edits recalculate everything downstream.
    U.on(host, 'change', '[data-grams]', function (e, el) {
      var loc = el.getAttribute('data-loc').split(':');
      var id = el.getAttribute('data-grams');
      CN.planner.setItemGrams(version, Number(loc[0]), Number(loc[1]), id, U.parseNum(el.value));
      var violations = CN.planner.restrictionViolations(version, patient);
      persist().then(function () {
        if (violations.length) CN.toast(CN.t('pl.restrictionViolation'), 'alert', 5000);
        else CN.toast(CN.t('pl.edited'));
        CN.app.refresh();
      });
    });

    U.on(host, 'click', '[data-del-item]', function (e, el) {
      var parts = el.getAttribute('data-del-item').split(':');
      CN.planner.removeItem(version, Number(parts[1]), Number(parts[2]), parts[0]);
      persist().then(function () { CN.app.refresh(); });
    });

    U.on(host, 'click', '[data-add-meal]', function (e, el) {
      CN.planner.addMeal(version, Number(el.getAttribute('data-add-meal')));
      persist().then(function () { CN.app.refresh(); });
    });

    U.on(host, 'click', '[data-del-meal]', function (e, el) {
      var parts = el.getAttribute('data-del-meal').split(':');
      CN.confirm({ title: CN.t('pl.removeMeal'), message: CN.t('common.irreversible') }).then(function (ok) {
        if (!ok) return;
        CN.planner.removeMeal(version, Number(parts[0]), Number(parts[1]));
        persist().then(function () { CN.app.refresh(); });
      });
    });

    U.on(host, 'click', '[data-add-item]', function (e, el) {
      var parts = el.getAttribute('data-add-item').split(':');
      openFoodPicker(patient, version, Number(parts[0]), Number(parts[1]), function () {
        persist().then(function () { CN.app.refresh(); });
      });
    });

    // Smart replace drawer.
    U.on(host, 'click', '[data-swap]', function (e, el) {
      var parts = el.getAttribute('data-swap').split(':');
      var itemId = parts[0], dayI = Number(parts[1]), mealI = Number(parts[2]);
      var meal = version.days[dayI].meals[mealI];
      var item = meal.items.filter(function (i) { return i.id === itemId; })[0];
      if (!item) return;
      openSwapDrawer(patient, version, dayI, mealI, item, function () {
        persist().then(function () { CN.app.refresh(); });
      });
    });
  }

  /** Drawer listing ranked alternatives for one item. */
  function openSwapDrawer(patient, version, dayI, mealI, item, onDone) {
    // Resolve through the planner so a recipe item shows its real name.
    var food = CN.planner.resolveFood(item.foodId);
    var objective = 'kcal';
    var drawerRef = null;

    function results() {
      return CN.planner.suggestSwaps(item, {
        patient: patient, approachCodes: version.approachCodes,
        objective: objective, limit: 10
      });
    }

    function listHtml() {
      var opts = results();
      if (!opts.length) return CN.empty(CN.t('pl.noSwap'), '');
      return '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
        '<th>' + U.esc(CN.t('fd.title')) + '</th><th class="num">' + U.esc(CN.t('fd.grams')) + '</th>' +
        '<th class="num">' + U.esc(CN.t('common.kcal')) + '</th><th>' + U.esc(CN.t('fd.protein')) + '</th>' +
        '<th></th></tr></thead><tbody>' +
        opts.map(function (o, i) {
          return '<tr><td>' + U.esc(CN.i18n.lang === 'ar' ? (o.food.nameAr || o.food.nameEn) : o.food.nameEn) +
            (o.approximate ? '<div class="muted" style="font-size:.74rem">' + U.esc(CN.t('pl.approx')) + '</div>' : '') +
            (o.penalty ? '<div class="muted" style="font-size:.74rem">' + U.esc(o.penalty) + '</div>' : '') +
            '</td><td class="num">' + U.nf(o.grams, 0) + ' g</td>' +
            '<td class="num">' + U.nf(o.nutrients.kcal, 0) + '</td>' +
            '<td class="num">' + U.nf(o.nutrients.protein, 1) + ' g</td>' +
            '<td class="right"><span class="chip">' + U.nf(o.similarity * 100, 0) + '%</span> ' +
            '<button class="btn btn-xs btn-primary" data-pick="' + i + '">' + U.esc(CN.t('common.apply')) +
            '</button></td></tr>';
        }).join('') + '</tbody></table></div>';
    }

    var body = '<p class="muted" style="font-size:.85rem">' + U.esc(CN.t('pl.swapHint')) + '</p>' +
      '<div class="row mb1"><label class="label" style="margin:0">' + U.esc(CN.t('pl.swapObj')) + '</label>' +
      '<select id="swap-obj">' + CN.options([
        { value: 'kcal', label: CN.t('pl.objKcal') },
        { value: 'protein', label: CN.t('pl.objProtein') },
        { value: 'carb', label: CN.t('pl.objCarb') },
        { value: 'fat', label: CN.t('pl.objFat') }
      ], objective) + '</select></div>' +
      '<div id="swap-list">' + listHtml() + '</div>';

    drawerRef = CN.drawer({
      title: CN.t('pl.swapTitle', { food: food ? (CN.i18n.lang === 'ar' ? food.nameAr : food.nameEn) : item.foodId }),
      body: body
    });

    U.on(drawerRef.node, 'change', '#swap-obj', function (e, el) {
      objective = el.value;
      U.$('#swap-list', drawerRef.node).innerHTML = listHtml();
    });

    U.on(drawerRef.node, 'click', '[data-pick]', function (e, el) {
      var opts = results();
      var pick = opts[Number(el.getAttribute('data-pick'))];
      if (!pick) return;
      CN.planner.applySwap(version, dayI, mealI, item.id, pick.food.id, pick.grams, true);
      var violations = CN.planner.restrictionViolations(version, patient);
      if (violations.length) CN.toast(CN.t('pl.restrictionViolation'), 'alert', 5000);
      else CN.toast(pick.approximate ? CN.t('pl.approx') : CN.t('common.saved'),
        pick.approximate ? 'warn' : 'ok');
      drawerRef.close();
      onDone();
    });
  }

  /** Searchable food picker for adding an item to a meal. */
  function openFoodPicker(patient, version, dayI, mealI, onDone) {
    var rstr = CN.planner.buildRestrictions(patient.restrictions);
    var body = '<div class="field"><input type="search" id="pick-q" placeholder="' +
      U.esc(CN.t('fd.search')) + '"/></div>' +
      '<div id="pick-list" class="scroll-y"></div>';

    var ref = CN.modal({
      title: CN.t('pl.addItem'), wide: true, body: body,
      actions: [{ label: CN.t('common.close'), kind: 'ghost' }]
    });

    function draw(q) {
      var s = (q || '').trim().toLowerCase();
      // Recipes are selectable items on exactly the same footing as foods.
      var list = CN.foods.search(q).slice();
      CN.planner.recipes().forEach(function (r) {
        var rf = CN.planner.recipeAsFood(r);
        if (!rf) return;
        if (!s || (rf.nameEn + ' ' + (rf.nameAr || '')).toLowerCase().indexOf(s) !== -1) list.push(rf);
      });
      list.sort(function (a, b) {
        return String(a.nameEn).localeCompare(String(b.nameEn));
      });

      var rows = list.slice(0, 40);
      var el = U.$('#pick-list', ref.node);
      if (!rows.length) { el.innerHTML = CN.empty(CN.t('fd.none'), CN.t('fd.noneMsg')); return; }
      el.innerHTML = '<div class="table-wrap"><table class="tbl compact"><tbody>' +
        rows.map(function (f) {
          var blocked = CN.planner.buildRestrictions(patient.restrictions).hard
            .some(function (fn) { return fn(f); });
          var defaultG = (f.isRecipe && f.servingG) ? f.servingG : 100;
          return '<tr' + (blocked ? ' style="opacity:.45"' : '') + '><td>' +
            U.esc(CN.i18n.lang === 'ar' ? (f.nameAr || f.nameEn) : f.nameEn) +
            (f.isRecipe ? ' <span class="chip navy" style="font-size:.68rem">' +
              U.esc(CN.t('rc.title')) + '</span>' : '') +
            '<div class="muted" style="font-size:.75rem">' + U.nf(f.kcal, 0) + ' kcal/100 g · ' +
            U.esc(CN.foods.categoryLabel(f.category)) +
            (f.isRecipe && f.servingG ? ' · ' + U.esc(CN.t('rc.perServing')) + ' ' +
              U.nf((f.servingG / 100) * f.kcal, 0) + ' kcal' : '') + '</div></td>' +
            '<td class="right">' + (blocked
              ? '<span class="chip alert">' + U.esc(CN.t('pl.restrictionViolation')) + '</span>'
              : '<input type="number" step="5" value="' + defaultG + '" style="width:70px" data-g="' +
                U.esc(f.id) + '"/> ' +
                '<button class="btn btn-xs btn-primary" data-add="' + U.esc(f.id) + '">' +
                U.esc(CN.t('common.add')) + '</button>') + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    }
    draw('');

    U.on(ref.node, 'input', '#pick-q', U.debounce(function (e, el) { draw(el.value); }, 180));
    U.on(ref.node, 'click', '[data-add]', function (e, el) {
      var id = el.getAttribute('data-add');
      var gEl = U.$('[data-g="' + id + '"]', ref.node);
      CN.planner.addItem(version, dayI, mealI, id, U.parseNum(gEl && gEl.value) || 100);
      ref.close();
      onDone();
    });
  }

  /** Version comparison modal. */
  function openDiff(a, b) {
    var d = CN.planner.diff(a, b);
    if (!d) return;
    var body = '<div class="grid cols-3 mb2">' +
      '<div class="stat"><div class="stat-label">' + U.esc(CN.t('common.version')) + ' ' + U.esc(a.versionNo) +
        '</div><div class="stat-value">' + U.nf(d.totals.avgKcalA, 0) + ' <small>kcal</small></div></div>' +
      '<div class="stat"><div class="stat-label">' + U.esc(CN.t('common.version')) + ' ' + U.esc(b.versionNo) +
        '</div><div class="stat-value">' + U.nf(d.totals.avgKcalB, 0) + ' <small>kcal</small></div></div>' +
      '<div class="stat' + (d.totals.deltaKcal ? ' accent' : '') + '"><div class="stat-label">' +
        U.esc(CN.t('common.difference')) + '</div><div class="stat-value">' +
        (d.totals.deltaKcal > 0 ? '+' : '') + U.nf(d.totals.deltaKcal, 0) + ' <small>kcal</small></div></div>' +
      '</div>';

    if (d.identical) {
      body += ui.notice(CN.t('pl.noChanges'), 'info');
    } else {
      function section(labelKey, rows, render) {
        if (!rows.length) return '';
        return '<h4>' + U.esc(CN.t(labelKey)) + ' (' + rows.length + ')</h4>' +
          '<div class="table-wrap mb2"><table class="tbl compact"><tbody>' +
          rows.slice(0, 40).map(render).join('') + '</tbody></table></div>';
      }
      function foodName(id) {
        var f = CN.planner.resolveFood(id);
        return f ? (CN.i18n.lang === 'ar' ? (f.nameAr || f.nameEn) : f.nameEn) : id;
      }
      body += section('common.add', d.added, function (r) {
        return '<tr><td>' + U.esc('Day ' + (r.day + 1) + ' · ' + r.meal) + '</td><td>' +
          U.esc(foodName(r.food)) +
          '</td><td class="num">' + U.nf(r.grams, 0) + ' g</td></tr>';
      });
      body += section('common.remove', d.removed, function (r) {
        return '<tr><td>' + U.esc('Day ' + (r.day + 1) + ' · ' + r.meal) + '</td><td>' +
          U.esc(foodName(r.food)) + '</td><td class="num">' + U.nf(r.grams, 0) + ' g</td></tr>';
      });
      body += section('common.change', d.changed, function (r) {
        return '<tr><td>' + U.esc('Day ' + (r.day + 1) + ' · ' + r.meal) + '</td><td>' +
          U.esc(foodName(r.food)) + '</td><td class="num">' + U.nf(r.from, 0) + ' → ' + U.nf(r.to, 0) +
          ' g</td><td class="num">' + (r.deltaKcal > 0 ? '+' : '') + U.nf(r.deltaKcal, 0) + ' kcal</td></tr>';
      });
    }

    CN.modal({ title: CN.t('pl.diff'), wide: true, body: body,
      actions: [{ label: CN.t('common.close'), kind: 'ghost' }] });
  }

  /* ============================================================== FOLLOW-UP  */
  var FollowUp = {
    title: 'nav.followup',

    render(host, ctx) {
      var patient = ctx.patient;
      if (!patient) { ui.needPatient(host); return; }

      host.innerHTML = ui.pageHead('fu.title', 'fu.subtitle',
        '<button class="btn btn-primary" id="fu-new">' + CN.icon('plus', 16) + ' ' +
        U.esc(CN.t('fu.new')) + '</button>');

      Promise.all([
        CN.store.byPatient('followups', patient.id),
        CN.store.byPatient('measurements', patient.id),
        CN.store.byPatient('assessments', patient.id),
        loadPlan(patient.id),
        CN.store.all('recipes')
      ]).then(function (r) {
        CN.planner.setRecipeIndex(r[4] || []);
        var followups = U.sortBy(r[0], 'attendedAt', 'desc');
        var ms = U.sortBy(r[1], 'measuredAt', 'asc');
        var assessments = r[2];
        var plan = r[3];
        var version = activeVersion(plan);
        var approved = ui.approvedAssessment(assessments, patient.id);

        var html = '';

        /* ---- progress analysis ---- */
        var prog = CN.engine.progress(ms, ms.length ? ms[ms.length - 1].targetWeightKg : null);
        if (prog) {
          var expected = approved ? approved.weeklyRateKg : null;
          var cmp = expected !== null && expected !== undefined
            ? CN.engine.compareToExpected(prog.weeklyChange, expected) : null;

          html += '<div class="grid cols-4 mb2">' +
            ui.stat('fu.totalChange', (prog.totalChange > 0 ? '+' : '') + U.nf(prog.totalChange, 1) +
              ' <small>kg</small>', U.fmtDate(prog.firstDate) + ' → ' + U.fmtDate(prog.lastDate), 'accent') +
            ui.stat('fu.pctChange', (prog.pctChange > 0 ? '+' : '') + U.nf(prog.pctChange, 1) + ' <small>%</small>',
              prog.days + ' ' + CN.t('common.days')) +
            ui.stat('fu.weeklyChange', U.nf(prog.weeklyChange, 2) + ' <small>kg/wk</small>',
              expected !== null && expected !== undefined
                ? CN.t('fu.expected') + ': ' + U.nf(expected, 2) : null) +
            ui.stat('bc.delta', prog.leanChange !== null
                ? (prog.leanChange > 0 ? '+' : '') + U.nf(prog.leanChange, 1) + ' <small>kg</small>'
                : '<span class="muted">—</span>',
              prog.fatChange !== null
                ? (CN.i18n.lang === 'ar' ? 'الدهون ' : 'fat ') + (prog.fatChange > 0 ? '+' : '') +
                  U.nf(prog.fatChange, 1) + ' %' : null) +
            '</div>';

          if (cmp) html += ui.notice(cmp.en, cmp.verdict === 'on_track' ? 'ok' :
            (cmp.verdict === 'stalled' || cmp.verdict === 'reversed' ? 'warn' : 'info'));
        }

        /* ---- reassessment ---- */
        if (approved && prog) {
          var lastWeights = ms.filter(function (m) { return m.weightKg; });
          var recent = lastWeights.slice(-3);
          var actualWeekly = null;
          if (recent.length >= 2) {
            var span = U.daysBetween(recent[0].measuredAt, recent[recent.length - 1].measuredAt);
            if (span > 0) actualWeekly = U.round((recent[recent.length - 1].weightKg - recent[0].weightKg) / (span / 7), 2);
          }
          var latestFu = followups[0];
          var result = CN.engine.reassess({
            previousTargetKcal: approved.targetKcal,
            goal: approved.goal,
            expectedWeeklyKg: approved.weeklyRateKg,
            actualWeeklyKg: actualWeekly,
            adherence: latestFu ? latestFu.adherence : 'none',
            atTarget: !!(prog.targetWeightKg && prog.toTarget !== null && prog.toTarget <= 0.5),
            weeks: recent.length >= 2 ? U.round(U.daysBetween(recent[0].measuredAt, recent[recent.length - 1].measuredAt) / 7, 1) : 0,
            weightTrendFlat: actualWeekly !== null && Math.abs(actualWeekly) < 0.1,
            fluidOrMedChange: !!(latestFu && latestFu.medicationChanges)
          });

          var reassessHtml = '';
          if (result.ok) {
            reassessHtml =
              '<div class="grid cols-3 mb1">' +
              '<div class="stat"><div class="stat-label">' + U.esc(CN.t('en.prevTarget')) + '</div>' +
                '<div class="stat-value">' + U.nf(result.previous, 0) + ' <small>kcal</small></div></div>' +
              '<div class="stat accent"><div class="stat-label">' + U.esc(CN.t('en.newTarget')) + '</div>' +
                '<div class="stat-value">' + U.nf(result.suggested, 0) + ' <small>kcal</small></div>' +
                '<div class="stat-foot">' + (result.changed
                  ? (result.suggested - result.previous > 0 ? '+' : '') + U.nf(result.suggested - result.previous, 0) + ' kcal'
                  : CN.t('pl.noChanges')) + '</div></div>' +
              '<div class="stat"><div class="stat-label">' + U.esc(CN.t('fu.actualTrend')) + '</div>' +
                '<div class="stat-value">' + (actualWeekly === null ? '—' : U.nf(actualWeekly, 2) +
                  ' <small>kg/wk</small>') + '</div></div>' +
              '</div>' +
              '<ul style="margin:0 0 .9rem 1.1rem;font-size:.88rem">' +
              result.rationale.map(function (x) { return '<li>' + U.esc(x) + '</li>'; }).join('') +
              (result.factors.map(function (x) { return '<li class="muted">' + U.esc(x) + '</li>'; }).join('')) +
              '</ul>' +
              ui.notice(CN.t('fu.plateauNote'), 'info') +
              (result.changed
                ? '<div class="btn-row"><button class="btn btn-primary" id="fu-apply">' +
                  CN.icon('check', 16) + ' ' + U.esc(CN.t('fu.applyChange')) + '</button>' +
                  '<button class="btn" id="fu-keep">' + U.esc(CN.t('fu.keepTarget')) + '</button></div>'
                : '');

            html += ui.card('fu.reassess', reassessHtml);
          }
        }

        /* ---- follow-up records ---- */
        if (!followups.length) {
          html += CN.empty(CN.t('fu.none'), CN.t('fu.noneMsg'),
            '<button class="btn btn-primary" data-new="1">' + U.esc(CN.t('fu.new')) + '</button>');
        } else {
          html += ui.card('fu.title',
            '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
            '<th>' + U.esc(CN.t('fu.attended')) + '</th>' +
            '<th>' + U.esc(CN.t('fu.adherence')) + '</th>' +
            '<th>' + U.esc(CN.t('fu.feedback')) + '</th>' +
            '<th>' + U.esc(CN.t('fu.next')) + '</th></tr></thead><tbody>' +
            followups.map(function (f) {
              return '<tr><td>' + U.esc(U.fmtDate(f.attendedAt || f.scheduledFor)) + '</td>' +
                '<td>' + (f.adherence ? ui.tag(CN.t('adh.' + f.adherence),
                  f.adherence === 'high' ? 'navy' : (f.adherence === 'low' ? 'gold' : '')) : '—') + '</td>' +
                '<td>' + U.esc(f.feedback || '—') + '</td>' +
                '<td>' + U.esc(f.nextAppointmentAt ? U.fmtDate(f.nextAppointmentAt) : '—') + '</td></tr>';
            }).join('') + '</tbody></table></div>');
        }

        /* ---- modify previous plan ---- */
        if (version) {
          html += ui.card('fu.modifyPrevious',
            '<p class="muted" style="font-size:.85rem">' + U.esc(CN.t('fu.modifyHint')) + '</p>' +
            '<div class="btn-row">' +
            '<button class="btn" id="fu-duplicate">' + CN.icon('copy', 16) + ' ' +
              U.esc(CN.t('fu.modifyPrevious')) + '</button>' +
            '<button class="btn" data-go="planner">' + U.esc(CN.t('nav.planner')) + '</button></div>');
        }

        host.innerHTML += html;

        U.on(host, 'click', '#fu-new, [data-new]', function () { FollowUp.openNew(patient, approved, ms); });
        U.on(host, 'click', '[data-go]', function (e, el) { CN.app.go(el.getAttribute('data-go')); });

        U.on(host, 'click', '#fu-apply', function () {
          Promise.all([
            CN.store.byPatient('assessments', patient.id),
            CN.store.byPatient('measurements', patient.id)
          ]).then(function (rr) {
            var a = ui.approvedAssessment(rr[0], patient.id);
            var mm = U.sortBy(rr[1], 'measuredAt', 'desc')[0] || {};
            var last = U.sortBy(rr[0], 'assessedAt', 'desc')[0];
            // A reassessment is recorded as a new approved assessment, never
            // as an edit to the previous one.
            var copy = Object.assign({}, last, {
              id: U.uid('asm'),
              assessedAt: new Date().toISOString(),
              targetKcal: result.suggested,
              approvedAt: new Date().toISOString(),
              approvedBy: 'clinician',
              reassessedFrom: a ? a.id : null,
              rationale: ['Reassessed at follow-up against measured weight trend.'],
              weightKg: mm.weightKg, heightCm: mm.heightCm
            });
            return CN.store.put('assessments', copy);
          }).then(function () {
            CN.toast(CN.t('fu.applied'));
            CN.app.refresh();
          });
        });

        U.on(host, 'click', '#fu-keep', function () {
          CN.toast(CN.t('fu.keepTarget'), 'info');
        });

        U.on(host, 'click', '#fu-duplicate', function () {
          // Duplicate the active version and rescale it to the current target.
          var copyVersion = JSON.parse(JSON.stringify(version));
          copyVersion.id = U.uid('ver');
          copyVersion.status = 'draft';
          copyVersion.createdAt = new Date().toISOString();
          copyVersion.parentVersionId = version.id;
          copyVersion.versionNo = 1;
          copyVersion.approvedAt = null;
          copyVersion.generatedBy = 'clinician';
          CN.planner.recalc(copyVersion);
          saveVersion(patient.id, copyVersion).then(function () {
            CN.toast(CN.t('common.saved'));
            CN.app.go('planner');
          });
        });
      });
    },

    openNew(patient, approved, measurements) {
      var latest = measurements && measurements.length ? measurements[measurements.length - 1] : {};
      var body = '<div class="inline-fields">' +
        '<div class="field"><label for="f-attended">' + U.esc(CN.t('fu.attended')) + '</label>' +
          '<input id="f-attended" type="date" value="' + U.todayISO() + '"/></div>' +
        '<div class="field"><label for="f-weight">' + U.esc(CN.t('pat.weight')) + ' (kg)</label>' +
          '<input id="f-weight" type="number" step="0.1"/></div>' +
        '<div class="field"><label for="f-waist">' + U.esc(CN.t('new.waist')) + ' (cm)</label>' +
          '<input id="f-waist" type="number" step="0.5" value="' + U.esc(latest.waistCm || '') + '"/></div>' +
        '<div class="field"><label for="f-bodyFat">' + U.esc(CN.t('new.bodyFat')) + ' (%)</label>' +
          '<input id="f-bodyFat" type="number" step="0.1"/></div>' +
        '<div class="field"><label for="f-height">' + U.esc(CN.t('new.height')) + ' (cm)</label>' +
          '<input id="f-height" type="number" step="0.5" value="' + U.esc(latest.heightCm || '') + '"/></div>' +
        '<div class="field"><label for="f-adherence">' + U.esc(CN.t('fu.adherence')) + '</label>' +
          '<select id="f-adherence">' + CN.options([
            { value: 'high', label: CN.t('adh.high') }, { value: 'moderate', label: CN.t('adh.moderate') },
            { value: 'low', label: CN.t('adh.low') }, { value: 'none', label: CN.t('adh.none') }
          ], 'moderate') + '</select></div>' +
        '<div class="field"><label for="f-next">' + U.esc(CN.t('fu.next')) + '</label>' +
          '<input id="f-next" type="date"/></div>' +
        '</div>' +
        '<div class="field"><label for="f-appetite">' + U.esc(CN.t('fu.appetite')) + '</label>' +
          '<input id="f-appetite" type="text"/></div>' +
        '<div class="field"><label for="f-gi">' + U.esc(CN.t('fu.gi')) + '</label>' +
          '<input id="f-gi" type="text"/></div>' +
        '<div class="field"><label for="f-feedback">' + U.esc(CN.t('fu.feedback')) + '</label>' +
          '<textarea id="f-feedback"></textarea></div>' +
        '<div class="field"><label for="f-observations">' + U.esc(CN.t('fu.observations')) + '</label>' +
          '<textarea id="f-observations"></textarea></div>' +
        '<div class="field"><label for="f-medChanges">' + U.esc(CN.t('fu.medChanges')) + '</label>' +
          '<input id="f-medChanges" type="text"/></div>';

      var m = CN.modal({
        title: CN.t('fu.new'), wide: true, body: body,
        actions: [
          { label: CN.t('common.cancel'), kind: 'ghost' },
          { label: CN.t('common.save'), kind: 'primary', close: false,
            onClick(node) {
              var attended = U.$('#f-attended', node).value || U.todayISO();
              var weight = U.parseNum(U.$('#f-weight', node).value);
              var writes = [];

              // A follow-up weight is also a measurement — history is appended.
              if (weight > 0) {
                writes.push(CN.store.put('measurements', {
                  id: U.uid('mea'), patientId: patient.id, measuredAt: attended,
                  weightKg: weight,
                  heightCm: U.parseNum(U.$('#f-height', node).value) || latest.heightCm || null,
                  targetWeightKg: latest.targetWeightKg || null,
                  waistCm: U.parseNum(U.$('#f-waist', node).value),
                  bodyFatPct: U.parseNum(U.$('#f-bodyFat', node).value),
                  source: 'clinic_scale', notes: 'Recorded at follow-up.'
                }));
              }

              writes.push(CN.store.put('followups', {
                id: U.uid('fu'), patientId: patient.id,
                scheduledFor: attended, attendedAt: attended,
                adherence: U.$('#f-adherence', node).value,
                appetiteChange: U.$('#f-appetite', node).value,
                giSymptoms: U.$('#f-gi', node).value,
                feedback: U.$('#f-feedback', node).value,
                observations: U.$('#f-observations', node).value,
                medicationChanges: U.$('#f-medChanges', node).value,
                nextAppointmentAt: U.$('#f-next', node).value || null,
                createdAt: new Date().toISOString()
              }));

              Promise.all(writes).then(function () {
                CN.toast(CN.t('common.saved'));
                m.close();
                CN.app.refresh();
              });
              return false;
            } }
        ]
      });
    }
  };

  /* ================================================================ REPORTS  */
  var Reports = {
    title: 'nav.reports',

    render(host, ctx) {
      var patient = ctx.patient;
      if (!patient) { ui.needPatient(host); return; }

      host.innerHTML = ui.pageHead('rp.title', 'rp.subtitle');

      Promise.all([
        CN.store.settings(),
        loadPlan(patient.id),
        CN.store.byPatient('measurements', patient.id),
        CN.store.byPatient('assessments', patient.id),
        CN.store.all('recipes')
      ]).then(function (r) {
        // Recipes must resolve before the report is built, or a recipe item
        // would print as a bare id.
        CN.planner.setRecipeIndex(r[4] || []);
        var settings = r[0], plan = r[1], ms = r[2], assessments = r[3];
        var version = activeVersion(plan);
        var approved = ui.approvedAssessment(assessments, patient.id);

        var html = ui.card('rp.contents',
          '<div class="grid cols-2">' +
          '<div class="field"><label for="r-mode">' + U.esc(CN.t('rp.modeBranded')) + '</label>' +
            '<select id="r-mode">' + CN.options([
              { value: 'branded', label: CN.t('rp.modeBranded') },
              { value: 'plain', label: CN.t('rp.modePlain') }
            ], settings.reportMode) + '</select>' +
            '<div class="hint">' + U.esc(CN.t('rp.modePlainHint')) + '</div></div>' +
          '<div class="field"><label for="r-heading">' + U.esc(CN.t('rp.reportHeading')) + '</label>' +
            '<input id="r-heading" type="text" value="' + U.esc(settings.reportHeading || '') + '"/></div>' +
          '<div class="field"><label for="r-accent">' + U.esc(CN.t('rp.accent')) + '</label>' +
            '<input id="r-accent" type="color" value="' + U.esc(settings.reportAccent || '#14213D') +
            '" style="max-width:90px;padding:2px"/></div>' +
          '<div class="field"><label for="r-font">' + U.esc(CN.t('rp.fontSize')) + '</label>' +
            '<select id="r-font">' + CN.options([
              { value: '0.9', label: CN.t('rp.fontSmall') },
              { value: '1', label: CN.t('rp.fontNormal') },
              { value: '1.15', label: CN.t('rp.fontLarge') }
            ], String(settings.reportFontScale || 1)) + '</select></div>' +
          '</div>' +
          '<div class="check"><input type="checkbox" id="r-nutrients"' +
            (settings.reportShowNutrients !== false ? ' checked' : '') + '/>' +
            '<label for="r-nutrients">' + U.esc(CN.t('rp.showNutrients')) + '</label></div>' +
          '<div class="check"><input type="checkbox" id="r-signature"' +
            (settings.reportShowSignature !== false ? ' checked' : '') + '/>' +
            '<label for="r-signature">' + U.esc(CN.t('rp.showSignature')) + '</label></div>' +
          '<div class="btn-row mb2">' +
            '<button class="btn btn-primary" id="r-preview">' + CN.icon('eye', 16) + ' ' +
              U.esc(CN.t('rp.previewBtn')) + '</button>' +
            '<button class="btn" id="r-print">' + CN.icon('printer', 16) + ' ' +
              U.esc(CN.t('rp.printBtn')) + '</button>' +
            '<button class="btn" id="r-save">' + CN.icon('save', 16) + ' ' + U.esc(CN.t('common.save')) + '</button>' +
          '</div>' +
          ui.notice(CN.t('rp.previewHint'), 'info'));

        if (!version) {
          html += ui.notice(CN.t('rp.noPlan'), 'warn');
        } else if (version.status !== 'approved') {
          html += ui.notice(CN.t('pl.pending'), 'warn');
        }

        host.innerHTML += html;

        function collect() {
          var mode = U.$('#r-mode').value;
          return {
            patient: patient,
            measurements: ms,
            assessment: approved,
            macros: (version && version.macros) || (approved && approved.macros) || null,
            plan: version,
            settings: Object.assign({}, settings, {
              reportMode: mode,
              reportHeading: U.$('#r-heading').value,
              reportAccent: U.$('#r-accent').value,
              reportFontScale: Number(U.$('#r-font').value) || 1
            }),
            mode: mode,
            accent: U.$('#r-accent').value,
            fontScale: Number(U.$('#r-font').value) || 1,
            showNutrients: U.$('#r-nutrients').checked,
            showSignature: U.$('#r-signature').checked
          };
        }

        U.on(host, 'click', '#r-preview', function () {
          if (!version) { CN.toast(CN.t('rp.noPlan'), 'warn'); return; }
          CN.pdf.preview(collect());
        });
        U.on(host, 'click', '#r-print', function () {
          if (!version) { CN.toast(CN.t('rp.noPlan'), 'warn'); return; }
          CN.pdf.print(collect());
        });
        U.on(host, 'click', '#r-save', function () {
          CN.store.saveSettings({
            reportMode: U.$('#r-mode').value,
            reportHeading: U.$('#r-heading').value,
            reportAccent: U.$('#r-accent').value,
            reportFontScale: Number(U.$('#r-font').value) || 1,
            reportShowNutrients: U.$('#r-nutrients').checked,
            reportShowSignature: U.$('#r-signature').checked
          }).then(function () { CN.toast(CN.t('rp.saved')); });
        });
      });
    }
  };

  CN.views = CN.views || {};
  CN.views.planner = Builder;
  CN.views.followup = FollowUp;
  CN.views.reports = Reports;
  CN.planHelpers = { loadPlan: loadPlan, activeVersion: activeVersion, saveVersion: saveVersion };
})();
