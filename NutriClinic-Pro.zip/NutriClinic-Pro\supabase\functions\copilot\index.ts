// ============================================================================
//  NutriClinic Pro — secure AI Copilot provider
//  Supabase Edge Function (Deno). One provider, implemented end to end.
// ============================================================================
//
//  WHY THIS EXISTS
//    The browser must never hold a provider key. Any key shipped to a browser is
//    readable by whoever opens the page, and brief §19 forbids it. So the client
//    posts to THIS function, the function holds the key in its environment, and
//    the key never leaves the server.
//
//  WHAT IT ENFORCES
//    1. The caller must present a valid Supabase session token. An anonymous
//       request is refused before anything else happens.
//    2. The caller must belong to a clinic. A signed-in user with no membership
//       gets nothing.
//    3. The instruction is screened for direct identifiers (email addresses and
//       long digit runs). A request that looks like it carries contact details is
//       REFUSED rather than forwarded — refusing is safer than silently
//       stripping, because the caller then knows the request did not go out.
//    4. The provider key is read from the environment at call time. It is never
//       logged, never returned, and never echoed in an error.
//    5. Every call is written to audit_log with the acting user and clinic. The
//       insert uses the service-role client, which exists only here — this is the
//       one legitimate home for that key.
//
//  WHAT IT DOES NOT DO
//    It does not invent clinical numbers. The system prompt forbids producing
//    them, and the application already computes every value deterministically in
//    engine.js. If the provider is unreachable the function returns a clear
//    error and the client reports that no model was consulted — it never
//    fabricates a reply.
//
//  ---------------------------------------------------------------------------
//  DEPLOY
//    supabase functions deploy copilot
//
//  PROVIDER CONFIGURATION  (values live in the function environment, never here)
//    supabase secrets set AI_PROVIDER_KEY=...        your provider's secret key
//    supabase secrets set AI_MODEL=...               e.g. gpt-4o-mini
//    supabase secrets set AI_PROVIDER_URL=...        optional; defaults to OpenAI
//
//    SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY are provided automatically to
//    every Edge Function by the platform. Do not set them yourself, and do not
//    copy the service-role value anywhere else.
//
//  The client points Settings → AI configuration → Proxy endpoint at
//    https://<project-ref>.supabase.co/functions/v1/copilot
//  and sends the user's session token as a bearer credential. That token
//  identifies the CLINICIAN; it is not a provider credential.
// ============================================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, 'Content-Type': 'application/json' },
  });
}

/** Email addresses and long digit runs — the shapes a direct identifier takes. */
const IDENTIFIER_PATTERN =
  /[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}|\+?\d[\d\s().-]{7,}\d/;

const SYSTEM_PROMPT = [
  'You are a clinical nutrition assistant embedded in a clinician-facing workstation.',
  '',
  'Hard rules, which you must not break:',
  '- NEVER state a calorie, macronutrient, or portion figure of your own. Every number in this',
  '  system is produced by a deterministic calculation engine. If a figure is needed, refer the',
  '  clinician to the Energy Calculator or the Diet Plan Builder.',
  '- Produce DRAFTS only. A clinician must review and approve anything before it is used.',
  '- Never diagnose, never prescribe, never suggest a medication or a dose change.',
  '- If the request lacks the clinical context you would need, say what is missing rather than',
  '  guessing.',
  '- Be concise and use plain clinical language.',
].join('\n');

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);

  /* ---- 1. The caller must be a signed-in user ---------------------------- */
  const authHeader = req.headers.get('Authorization') ?? '';
  if (!authHeader.startsWith('Bearer ')) {
    return json({ error: 'Not authenticated. Sign in first.' }, 401);
  }

  const asUser = createClient(
    Deno.env.get('SUPABASE_URL')!,
    Deno.env.get('SUPABASE_ANON_KEY')!,
    { global: { headers: { Authorization: authHeader } } },
  );

  const { data: userData, error: userError } = await asUser.auth.getUser();
  const user = userData?.user;
  if (userError || !user) {
    return json({ error: 'Your session is not valid. Sign in again.' }, 401);
  }

  /* ---- 2. The caller must belong to a clinic ----------------------------- */
  // This query runs under the caller's own token, so row level security applies:
  // it can only ever return clinics they are a member of.
  const { data: memberships, error: memberError } = await asUser
    .from('clinic_members')
    .select('clinic_id, role');

  if (memberError) return json({ error: 'Could not verify clinic membership.' }, 500);
  if (!memberships || memberships.length === 0) {
    return json({ error: 'This account is not a member of a clinic.' }, 403);
  }
  const clinicId = memberships[0].clinic_id as string;

  /* ---- 3. Read and screen the request ----------------------------------- */
  const body = await req.json().catch(() => null);
  if (!body) return json({ error: 'Malformed request body.' }, 400);

  const instruction = typeof body.instruction === 'string'
    ? body.instruction.slice(0, 4000)
    : '';
  if (!instruction.trim()) return json({ error: 'No instruction supplied.' }, 400);

  if (IDENTIFIER_PATTERN.test(instruction)) {
    // Refused, not silently scrubbed: the caller needs to know it did not go out.
    return json({
      error: 'The instruction appears to contain contact details (an email address or a long ' +
        'number). Remove them and try again — identifiable information is not sent to the provider.',
    }, 422);
  }

  // Context is rebuilt from an allow-list of clinical fields. Nothing is passed
  // through wholesale, so a future client change cannot widen what is disclosed.
  const context = body.patient
    ? {
        ageBand: body.patient.ageBand ?? null,
        sex: body.patient.sex ?? null,
        goal: body.patient.goal ?? null,
        conditions: Array.isArray(body.patient.conditions)
          ? body.patient.conditions.slice(0, 8)
          : [],
        restrictionCount: body.patient.restrictionCount ?? null,
      }
    : null;

  const targets = body.targets
    ? {
        kcal: body.targets.kcal ?? null,
        proteinG: body.targets.proteinG ?? null,
        carbG: body.targets.carbG ?? null,
        fatG: body.targets.fatG ?? null,
      }
    : null;

  const userTurn = [
    context ? `Patient context (de-identified): ${JSON.stringify(context)}` : 'No patient selected.',
    targets ? `Clinician-approved targets, for reference only: ${JSON.stringify(targets)}` : '',
    body.followUpCount ? `Follow-up records on file: ${body.followUpCount}` : '',
    `Instruction: ${instruction}`,
  ].filter(Boolean).join('\n');

  /* ---- 4. Call the provider -------------------------------------------- */
  const apiKey = Deno.env.get('AI_PROVIDER_KEY');
  if (!apiKey) {
    return json({
      error: 'The AI provider is not configured on the server. An administrator must set ' +
        'AI_PROVIDER_KEY as a function secret.',
    }, 503);
  }

  const providerUrl = Deno.env.get('AI_PROVIDER_URL') ?? 'https://api.openai.com/v1/chat/completions';
  const model = Deno.env.get('AI_MODEL') ?? 'gpt-4o-mini';

  let providerText = '';
  let providerStatus = 0;

  try {
    const response = await fetch(providerUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        // The key is attached here, server-side, and nowhere else in the system.
        'Authorization': `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model,
        temperature: 0.2,
        messages: [
          { role: 'system', content: SYSTEM_PROMPT },
          { role: 'user', content: userTurn },
        ],
      }),
    });

    providerStatus = response.status;
    if (!response.ok) {
      // The provider's message may echo the key back; it is never forwarded.
      await response.text();
      await audit(clinicId, user.id, 'copilot_error', null, `provider_status=${response.status}`);
      return json({
        error: `The AI provider rejected the request (HTTP ${response.status}).`,
      }, 502);
    }

    const payload = await response.json();
    providerText = payload?.choices?.[0]?.message?.content ?? '';

    if (!providerText.trim()) {
      await audit(clinicId, user.id, 'copilot_empty', null, `provider_status=${providerStatus}`);
      return json({ error: 'The provider returned an empty response.' }, 502);
    }
  } catch (err) {
    await audit(clinicId, user.id, 'copilot_network_error', null, String(err).slice(0, 200));
    return json({
      error: 'The AI provider could not be reached. No model was consulted; nothing was generated.',
    }, 502);
  }

  /* ---- 5. Audit the call ------------------------------------------------ */
  const patientRef = typeof body.patientRef === 'string' ? body.patientRef : null;
  await audit(clinicId, user.id, 'copilot_call', patientRef, `model=${model}`);

  return json({
    text: providerText,
    // Stated explicitly so the client can show which mode produced the content.
    provider: 'external',
    model,
  });
});

/**
 * Writes an audit entry using the service-role client.
 *
 * audit_log has no INSERT policy, so a client can never forge an entry — and
 * that also means this function cannot write one with the caller's token. The
 * service-role key is the correct tool here and exists only in this environment.
 * A failure to audit is logged but never blocks the clinician's request.
 */
async function audit(
  clinicId: string,
  userId: string,
  action: string,
  patientId: string | null,
  detail: string,
) {
  try {
    const admin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );
    await admin.from('audit_log').insert({
      clinic_id: clinicId,
      user_id: userId,
      action,
      entity: 'copilot',
      entity_id: null,
      patient_id: patientId,
      detail: { note: detail },
    });
  } catch (e) {
    console.error('[copilot] audit insert failed:', String(e));
  }
}
