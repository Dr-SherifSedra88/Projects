/* ==========================================================================
   NutriClinic Pro — views-core.js
   Shared UI helpers, plus Dashboard, Patients, New Patient and Settings.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  /* ------------------------------------------------------------- shared UI -- */
  var ui = CN.ui = {
    /** Standard page header. */
    pageHead(titleKey, subtitleKey, actionsHtml) {
      return '<div class="page-head"><div class="grow">' +
        '<h1>' + U.esc(CN.t(titleKey)) + '</h1>' +
        (subtitleKey ? '<p>' + U.esc(CN.t(subtitleKey)) + '</p>' : '') +
        '</div>' + (actionsHtml ? '<div class="btn-row">' + actionsHtml + '</div>' : '') + '</div>';
    },

    stat(labelKey, value, foot, tone) {
      return '<div class="stat' + (tone ? ' ' + tone : '') + '">' +
        '<div class="stat-label">' + U.esc(CN.t(labelKey)) + '</div>' +
        '<div class="stat-value">' + value + '</div>' +
        (foot ? '<div class="stat-foot">' + U.esc(foot) + '</div>' : '') + '</div>';
    },

    card(titleKey, bodyHtml, headActions, opts) {
      opts = opts || {};
      var head = titleKey
        ? '<div class="card-head"><h3>' + U.esc(CN.t(titleKey)) + '</h3><div class="grow"></div>' +
          (headActions || '') + '</div>'
        : '';
      return '<section class="card' + (opts.flush ? ' flush' : '') + '">' + head + bodyHtml + '</section>';
    },

    notice(text, tone) {
      return '<div class="notice ' + (tone || 'info') + '">' + U.esc(text) + '</div>';
    },

    /** Prompt shown whenever a module needs an active patient. */
    needPatient(host) {
      host.innerHTML = ui.pageHead('topbar.noPatient', null, '') +
        CN.empty(CN.t('common.selectPatient'),
          CN.i18n.lang === 'ar'
            ? 'اختر مريضًا من قائمة المرضى أو سجّل مريضًا جديدًا للبدء.'
            : 'Choose a patient from the Patients list, or register a new one, to begin.',
          '<button class="btn btn-primary" data-go="patients">' + U.esc(CN.t('nav.patients')) + '</button>');
    },

    tag(text, tone) { return '<span class="chip' + (tone ? ' ' + tone : '') + '">' + U.esc(text) + '</span>'; },

    /** Status chip for a plan version. */
    planStatus(status) {
      var map = { draft: ['pl.draft', ''], pending_approval: ['pl.pending', 'gold'],
        approved: ['pl.approved', 'navy'], superseded: ['pl.superseded', ''] };
      var m = map[status] || ['pl.draft', ''];
      return ui.tag(CN.t(m[0]), m[1]);
    },

    /** Numeric cell with consistent formatting. */
    num(v, dp, unit) {
      if (v === null || v === undefined || !isFinite(Number(v))) return '<span class="muted">—</span>';
      return U.nf(v, dp === undefined ? 0 : dp) + (unit ? ' <span class="muted">' + unit + '</span>' : '');
    },

    /** BMI cell coloured by classification (never green). */
    bmiCell(v) {
      if (v === null || v === undefined) return '<span class="muted">—</span>';
      var c = CN.engine.bmiClass(v);
      var tone = c.level === 'alert' ? 'alert' : (c.level === 'warn' ? 'gold' : '');
      return U.nf(v, 1) + ' ' + ui.tag(CN.i18n.lang === 'ar' ? c.ar : c.en, tone);
    },

    /** Latest measurement for a patient id. */
    latestMeasurement(measurements, patientId) {
      var rows = measurements.filter(function (m) { return m.patientId === patientId; })
        .sort(function (a, b) { return String(b.measuredAt).localeCompare(String(a.measuredAt)); });
      return rows[0] || null;
    },

    /** Approved energy assessment for a patient, if any. */
    approvedAssessment(assessments, patientId) {
      var rows = (assessments || []).filter(function (a) {
        return a.patientId === patientId && a.approvedAt && a.targetKcal;
      }).sort(function (a, b) { return String(b.assessedAt).localeCompare(String(a.assessedAt)); });
      return rows[0] || null;
    },

    /** Human completion for the assessment form. */
    completeLabel(present, total) {
      return present + ' / ' + total;
    }
  };

  /* --------------------------------------------------------- Dashboard ----- */
  var Dashboard = {
    title: 'nav.dashboard',
    render(host, ctx) {
      host.innerHTML = ui.pageHead('dash.title', 'dash.subtitle');
      host.innerHTML += '<div id="dash-body">' + ui.card(null,
        '<div class="muted">' + U.esc(CN.t('boot.loading')) + '</div>') + '</div>';

      Promise.all([
        CN.store.all('patients'),
        CN.store.all('measurements'),
        CN.store.all('followups'),
        CN.store.all('plans'),
        CN.store.settings()
      ]).then(function (r) {
        var patients = r[0], measurements = r[1], followups = r[2], plans = r[3], settings = r[4];
        var body = U.$('#dash-body');
        if (!body) return;

        var now = new Date();
        var monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
        var todayIso = U.todayISO();

        var newThisMonth = patients.filter(function (p) {
          return p.registeredAt && p.registeredAt >= monthStart;
        }).length;

        var upcoming = [], overdue = [];
        followups.forEach(function (f) {
          if (!f.nextAppointmentAt) return;
          if (f.nextAppointmentAt >= todayIso) upcoming.push(f);
          else overdue.push(f);
        });

        var pending = 0;
        plans.forEach(function (pl) {
          (pl.versions || []).forEach(function (v) {
            if (v.status === 'draft' || v.status === 'pending_approval') pending++;
          });
        });

        var html = '';

        /* ---- optional clinic identity prompt --------------------------------
           Shown once, dismissible, and NEVER blocking. The Dashboard is fully
           usable without it; Settings holds the complete form. */
        var clinicUnset = !String(settings.clinicName || '').trim() ||
          settings.clinicName === 'NutriClinic Pro';
        var identityHidden = false;
        try { identityHidden = localStorage.getItem('cn.identityPrompt') === 'hidden'; }
        catch (e) { /* storage may be blocked */ }
        if (clinicUnset && !identityHidden) {
          html += '<div class="notice warn" id="dash-identity"><div class="row">' +
            '<div class="grow"><strong>' + U.esc(CN.t('st.identity')) + '</strong><br>' +
            U.esc(CN.i18n.lang === 'ar'
              ? 'أدخل بيانات العيادة من الإعدادات وقتما تشاء. التطبيق يعمل بالكامل بدونها.'
              : 'You can set your clinic details in Settings whenever you like. The application works fully without them.') +
            '</div>' +
            '<button class="btn btn-sm btn-primary" data-go="settings">' +
              U.esc(CN.t('common.settings')) + '</button>' +
            '<button class="btn btn-sm btn-ghost" data-hide-identity="1">' +
              U.esc(CN.t('common.close')) + '</button>' +
            '</div></div>';
        }

        /* ---- quick access ----------------------------------------------------
           Present with zero patients and with many, so navigation never depends
           on registering anyone first. */
        function tile(route, icon, labelKey, focus) {
          return '<button class="btn" style="justify-content:flex-start;width:100%;text-align:start" ' +
            'data-tile="' + route + '"' + (focus ? ' data-focus="' + focus + '"' : '') + '>' +
            CN.icon(icon, 16) + '<span style="margin-inline-start:.5rem">' +
            U.esc(CN.t(labelKey)) + '</span></button>';
        }
        html += ui.card('dash.quick',
          '<div class="grid cols-3">' +
            tile('dashboard', 'grid', 'nav.dashboard') +
            tile('patients', 'users', 'nav.patients') +
            tile('newPatient', 'user-plus', 'nav.newPatient') +
            tile('followup', 'calendar', 'nav.followup') +
            tile('assessment', 'clipboard', 'nav.assessment') +
            tile('bodyComp', 'activity', 'nav.bodyComp') +
            tile('energy', 'flame', 'nav.energy') +
            tile('planner', 'utensils', 'nav.planner') +
            tile('copilot', 'sparkles', 'nav.copilot') +
            tile('references', 'book', 'nav.references', '#kb-card') +
            tile('foods', 'apple', 'nav.foods') +
            tile('foods', 'list', 'rc.title', '#rc-list') +
            tile('reports', 'file-text', 'nav.reports') +
            tile('settings', 'sliders', 'nav.settings') +
          '</div>' +
          '<p class="muted" style="font-size:.78rem;margin:.6rem 0 0">' +
            U.esc(CN.i18n.lang === 'ar'
              ? 'استبدال الأطعمة الذكي متاح لكل صنف داخل منشئ الخطة الغذائية.'
              : 'Smart food exchange is available on every item inside the Diet Plan Builder.') +
          '</p>');

        /* ---- first-run guidance, non-blocking ---- */
        if (!patients.length) {
          html += ui.card(null, CN.empty(CN.t('dash.noPatients'), CN.t('dash.noPatientsMsg'),
            '<button class="btn btn-primary" data-go="newPatient">' +
              U.esc(CN.t('nav.newPatient')) + '</button>' +
            ' <button class="btn" data-act="seed">' + U.esc(CN.t('st.seed')) + '</button>'));
        }

        html += '<div class="grid cols-4 mb2">' +
          ui.stat('dash.totalPatients', U.nf(patients.length, 0), null, 'accent') +
          ui.stat('dash.activePatients', U.nf(patients.filter(function (p) { return p.isActive !== false; }).length, 0)) +
          ui.stat('dash.newThisMonth', U.nf(newThisMonth, 0)) +
          ui.stat('dash.pending', U.nf(pending, 0), null, pending ? 'alert' : '') +
          '</div>';

        html += '<div class="grid cols-4 mb2">' +
          ui.stat('dash.upcoming', U.nf(upcoming.length, 0)) +
          ui.stat('dash.overdue', U.nf(overdue.length, 0), null, overdue.length ? 'alert' : '') +
          ui.stat('dash.quick', '', null) +
          '</div>';

        // Recent patients table
        var recent = U.sortBy(patients, 'registeredAt', 'desc').slice(0, 6);
        var rowsHtml = recent.map(function (p) {
          var m = ui.latestMeasurement(measurements, p.id);
          var age = U.ageFrom(p.dob);
          return '<tr class="row-click" data-open-row="' + U.esc(p.id) + '">' +
            '<td><strong>' + U.esc(p.name) + '</strong><div class="muted" style="font-size:.78rem">' +
              U.esc(p.code || '') + '</div></td>' +
            '<td>' + (age === null ? '—' : age) + '</td>' +
            '<td>' + U.esc(CN.t('sex.' + (p.sex || 'undisclosed'))) + '</td>' +
            '<td class="num">' + ui.num(m ? m.weightKg : null, 1, 'kg') + '</td>' +
            '<td>' + (m ? ui.bmiCell(CN.engine.bmi(m.heightCm, m.weightKg)) : '<span class="muted">—</span>') + '</td>' +
            '<td>' + U.esc(CN.t('goal.' + (p.goal || 'maintenance'))) + '</td>' +
            '<td><button class="btn btn-xs" data-open="' + U.esc(p.id) + '">' + U.esc(CN.t('pat.openRecord')) + '</button></td>' +
            '</tr>';
        }).join('');

        html += ui.card('dash.recent',
          '<div class="table-wrap"><table class="tbl"><thead><tr>' +
          '<th>' + U.esc(CN.t('pat.name')) + '</th><th>' + U.esc(CN.t('pat.age')) + '</th>' +
          '<th>' + U.esc(CN.t('pat.sex')) + '</th><th class="num">' + U.esc(CN.t('pat.weight')) + '</th>' +
          '<th>' + U.esc(CN.t('pat.bmi')) + '</th><th>' + U.esc(CN.t('pat.goal')) + '</th><th></th>' +
          '</tr></thead><tbody>' + rowsHtml + '</tbody></table></div>');

        // Goal split donut
        var byGoal = U.groupBy(patients, function (p) { return p.goal || 'maintenance'; });
        var segs = Object.keys(byGoal).map(function (k, i) {
          return { label: CN.t('goal.' + k), value: byGoal[k].length, tone: CN.charts.series[i % 3] };
        });
        html += ui.card('dash.goalSplit',
          CN.charts.donut({ size: 190, segments: segs, centerValue: patients.length, centerLabel: CN.t('dash.totalPatients') }) +
          CN.charts.legend(segs.map(function (s) { return { label: s.label + ' (' + s.value + ')', tone: s.tone }; })));

        // Weight trend across patients (average of latest weights by month is
        // not meaningful across patients; show per-patient first→last change).
        var trendBars = patients.slice(0, 8).map(function (p) {
          var prog = CN.engine.progress(measurements.filter(function (m) { return m.patientId === p.id; }), null);
          return {
            label: p.name.split(' ')[0],
            value: prog ? Math.abs(prog.totalChange) : 0,
            tone: prog && prog.direction === 'loss' ? 'navy' : 'gold',
            tip: prog ? (prog.totalChange > 0 ? '+' : '') + prog.totalChange + ' kg over ' + prog.days + ' days'
              : 'No measurements'
          };
        });
        if (trendBars.some(function (b) { return b.value > 0; })) {
          html += ui.card('dash.progress',
            CN.charts.bar({ bars: trendBars, height: 240, yUnit: 'kg' }) +
            '<p class="muted" style="font-size:.8rem;margin:.4rem 0 0">' +
            U.esc(CN.i18n.lang === 'ar'
              ? 'القيمة المطلقة للتغير في الوزن منذ أول قياس.'
              : 'Absolute weight change since the first recorded measurement.') + '</p>');
        }

        // §18 clinic reporting: search and filter across the whole patient list.
        html += ui.card('pat.title',
          '<div class="row mb1">' +
            '<input type="search" id="dash-q" placeholder="' + U.esc(CN.t('pat.search')) +
              '" style="max-width:270px"/>' +
            '<select id="dash-goal" style="max-width:185px">' + CN.options(
              [{ value: '', label: CN.t('common.all') },
               { value: 'weight_loss', label: CN.t('goal.weight_loss') },
               { value: 'maintenance', label: CN.t('goal.maintenance') },
               { value: 'weight_gain', label: CN.t('goal.weight_gain') },
               { value: 'therapeutic', label: CN.t('goal.therapeutic') }]) + '</select>' +
            '<select id="dash-fu" style="max-width:190px">' + CN.options([
              { value: '', label: CN.t('common.all') },
              { value: 'due', label: CN.t('dash.upcoming') },
              { value: 'overdue', label: CN.t('dash.overdue') },
              { value: 'none', label: CN.t('common.none') }
            ]) + '</select>' +
            '<input type="date" id="dash-from" style="max-width:155px" title="' +
              U.esc(CN.t('pat.registered')) + '"/>' +
            '<input type="date" id="dash-to" style="max-width:155px" title="' +
              U.esc(CN.t('pat.registered')) + '"/>' +
            '<div class="grow"></div><span class="muted" id="dash-count"></span>' +
          '</div>' +
          '<div id="dash-table"></div>');

        body.innerHTML = html;

        /* ---- reporting table ---- */
        var fuByPatient = {};
        followups.forEach(function (f) {
          var cur = fuByPatient[f.patientId];
          var next = f.nextAppointmentAt;
          if (!cur || (next && (!cur.next || next > cur.next))) {
            fuByPatient[f.patientId] = { next: next || null };
          }
        });

        function drawPatients() {
          var q = (U.$('#dash-q').value || '').trim().toLowerCase();
          var goal = U.$('#dash-goal').value;
          var fu = U.$('#dash-fu').value;
          var from = U.$('#dash-from').value;
          var to = U.$('#dash-to').value;
          var today = U.todayISO();

          var rows = patients.filter(function (p) {
            if (goal && (p.goal || 'maintenance') !== goal) return false;
            if (from && (p.registeredAt || '') < from) return false;
            if (to && (p.registeredAt || '') > to) return false;
            if (q) {
              var hay = (p.name || '') + ' ' + (p.code || '') + ' ' + (p.phone || '') + ' ' +
                ((p.conditions || []).join(' '));
              if (hay.toLowerCase().indexOf(q) === -1) return false;
            }
            if (fu) {
              var rec = fuByPatient[p.id];
              if (fu === 'none' && rec && rec.next) return false;
              if (fu === 'due' && (!rec || !rec.next || rec.next < today)) return false;
              if (fu === 'overdue' && (!rec || !rec.next || rec.next >= today)) return false;
            }
            return true;
          });

          var countEl = U.$('#dash-count');
          if (countEl) countEl.textContent = CN.t('pat.count', { n: rows.length });

          var wrap = U.$('#dash-table');
          if (!rows.length) {
            wrap.innerHTML = CN.empty(CN.t('pat.none'), CN.t('pat.noneMsg'));
            return;
          }
          wrap.innerHTML = '<div class="table-wrap"><table class="tbl"><thead><tr>' +
            '<th>' + U.esc(CN.t('pat.name')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.code')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.age')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.goal')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('pat.weight')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.bmi')) + '</th>' +
            '<th>' + U.esc(CN.t('fu.next')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.registered')) + '</th></tr></thead><tbody>' +
            rows.map(function (p) {
              var m = ui.latestMeasurement(measurements, p.id);
              var age = U.ageFrom(p.dob);
              var rec = fuByPatient[p.id];
              var fuCell = (rec && rec.next)
                ? (rec.next < today
                    ? ui.tag(U.fmtDate(rec.next), 'alert')
                    : ui.tag(U.fmtDate(rec.next), 'gold'))
                : '<span class="muted">—</span>';
              return '<tr class="row-click" data-open-row="' + U.esc(p.id) + '">' +
                '<td><strong>' + U.esc(p.name) + '</strong>' +
                  ((p.conditions || []).length
                    ? '<div class="muted" style="font-size:.76rem">' +
                      U.esc(p.conditions.join(' · ')) + '</div>' : '') + '</td>' +
                '<td class="mono">' + U.esc(p.code || '—') + '</td>' +
                '<td class="num">' + (age === null ? '—' : age) + '</td>' +
                '<td>' + U.esc(CN.t('goal.' + (p.goal || 'maintenance'))) + '</td>' +
                '<td class="num">' + ui.num(m ? m.weightKg : null, 1) + '</td>' +
                '<td>' + (m ? ui.bmiCell(CN.engine.bmi(m.heightCm, m.weightKg))
                            : '<span class="muted">—</span>') + '</td>' +
                '<td>' + fuCell + '</td>' +
                '<td>' + U.esc(U.fmtDate(p.registeredAt)) + '</td></tr>';
            }).join('') + '</tbody></table></div>';
        }

        drawPatients();
        ['#dash-q', '#dash-goal', '#dash-fu', '#dash-from', '#dash-to'].forEach(function (sel) {
          U.on(body, 'input', sel, U.debounce(drawPatients, 180));
          U.on(body, 'change', sel, drawPatients);
        });

        U.on(body, 'click', '[data-open-row]', function (e, el) {
          // Ignore clicks that landed on an action control inside the row.
          if (e.target.closest('button,a,input,select,textarea,label')) return;
          CN.app.openPatient(el.getAttribute('data-open-row'), 'assessment');
        });
        U.on(body, 'click', '[data-open]', function (e, el) {
          CN.app.openPatient(el.getAttribute('data-open'), 'assessment');
        });
        U.on(body, 'click', '[data-go]', function (e, el) { CN.app.go(el.getAttribute('data-go')); });
        U.on(body, 'click', '[data-tile]', function (e, el) {
          CN.app.go(el.getAttribute('data-tile'), el.getAttribute('data-focus') || null);
        });
        U.on(body, 'click', '[data-hide-identity]', function () {
          try { localStorage.setItem('cn.identityPrompt', 'hidden'); } catch (e) { /* ignore */ }
          var card = U.$('#dash-identity');
          if (card) card.remove();
        });
        U.on(body, 'click', '[data-act="seed"]', function () {
          CN.store.seedDemo().then(function () { CN.app.refresh(); CN.toast(CN.t('common.saved')); });
        });
      });
    }
  };

  /* ---------------------------------------------------------- Patients ----- */
  var patState = { q: '', sort: 'registeredAt', dir: 'desc' };

  var Patients = {
    title: 'nav.patients',
    render(host, ctx) {
      host.innerHTML = ui.pageHead('pat.title', 'pat.subtitle',
        '<button class="btn btn-primary" data-go="newPatient">' + CN.icon('user-plus', 16) + ' ' +
        U.esc(CN.t('nav.newPatient')) + '</button>');

      host.innerHTML += '<div class="card"><div class="row mb1">' +
        '<input type="search" id="pat-q" placeholder="' + U.esc(CN.t('pat.search')) +
        '" value="' + U.esc(patState.q) + '" style="max-width:420px"/>' +
        '<select id="pat-sort" style="max-width:220px">' +
        CN.options([
          { value: 'registeredAt', label: CN.t('pat.registered') },
          { value: 'name', label: CN.t('pat.name') },
          { value: 'code', label: CN.t('pat.code') }
        ], patState.sort) + '</select>' +
        '<div class="grow"></div><span class="muted" id="pat-count"></span></div>' +
        '<div id="pat-table"></div></div>';

      function load() {
        Promise.all([CN.store.all('patients'), CN.store.all('measurements')]).then(function (r) {
          var patients = r[0], measurements = r[1];
          var q = patState.q.trim().toLowerCase();
          var filtered = patients.filter(function (p) {
            if (!q) return true;
            return (p.name || '').toLowerCase().indexOf(q) !== -1 ||
              (p.code || '').toLowerCase().indexOf(q) !== -1 ||
              (p.phone || '').indexOf(q) !== -1;
          });
          filtered = U.sortBy(filtered, patState.sort, patState.dir);

          var countEl = U.$('#pat-count');
          if (countEl) countEl.textContent = CN.t('pat.count', { n: filtered.length });

          var wrap = U.$('#pat-table');
          if (!wrap) return;

          if (!filtered.length) {
            wrap.innerHTML = CN.empty(CN.t('pat.none'), CN.t('pat.noneMsg'),
              '<button class="btn btn-primary" data-go="newPatient">' + U.esc(CN.t('nav.newPatient')) + '</button>');
            return;
          }

          wrap.innerHTML = '<div class="table-wrap"><table class="tbl"><thead><tr>' +
            '<th>' + U.esc(CN.t('pat.name')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.code')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.age')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.sex')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.phone')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('pat.weight')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.bmi')) + '</th>' +
            '<th>' + U.esc(CN.t('pat.goal')) + '</th>' +
            '<th>' + U.esc(CN.t('common.actions')) + '</th></tr></thead><tbody>' +
            filtered.map(function (p) {
              var m = ui.latestMeasurement(measurements, p.id);
              var age = U.ageFrom(p.dob);
              return '<tr class="row-click" data-open-row="' + U.esc(p.id) + '">' +
                '<td><strong>' + U.esc(p.name) + '</strong>' +
                  (p.conditions && p.conditions.length
                    ? '<div class="muted" style="font-size:.76rem">' + U.esc(p.conditions.join(' · ')) + '</div>' : '') +
                '</td>' +
                '<td class="mono">' + U.esc(p.code || '—') + '</td>' +
                '<td class="num">' + (age === null ? '—' : age) + '</td>' +
                '<td>' + U.esc(CN.t('sex.' + (p.sex || 'undisclosed'))) + '</td>' +
                '<td class="mono">' + U.esc(p.phone || '—') + '</td>' +
                '<td class="num">' + ui.num(m ? m.weightKg : null, 1, 'kg') + '</td>' +
                '<td>' + (m ? ui.bmiCell(CN.engine.bmi(m.heightCm, m.weightKg)) : '<span class="muted">—</span>') + '</td>' +
                '<td>' + U.esc(CN.t('goal.' + (p.goal || 'maintenance'))) + '</td>' +
                '<td class="nowrap"><button class="btn btn-xs" data-open="' + U.esc(p.id) + '">' +
                  U.esc(CN.t('common.open')) + '</button> ' +
                  '<button class="btn btn-xs" data-edit="' + U.esc(p.id) + '">' + CN.icon('pencil', 13) + '</button> ' +
                  '<button class="btn btn-xs" data-del="' + U.esc(p.id) + '">' + CN.icon('trash', 13) + '</button></td>' +
                '</tr>';
            }).join('') + '</tbody></table></div>';
        });
      }

      U.on(host, 'input', '#pat-q', U.debounce(function (e, el) {
        patState.q = el.value; load();
      }, 200));
      U.on(host, 'change', '#pat-sort', function (e, el) {
        patState.sort = el.value; load();
      });
      U.on(host, 'click', '[data-open-row]', function (e, el) {
        // A click on Edit/Delete/Open inside the row must not also open it.
        if (e.target.closest('button,a,input,select,textarea,label')) return;
        CN.app.openPatient(el.getAttribute('data-open-row'), 'assessment');
      });
      U.on(host, 'click', '[data-open]', function (e, el) {
        CN.app.openPatient(el.getAttribute('data-open'), 'assessment');
      });
      U.on(host, 'click', '[data-edit]', function (e, el) {
        NewPatient.openEditor(el.getAttribute('data-edit'));
      });
      U.on(host, 'click', '[data-del]', function (e, el) {
        var id = el.getAttribute('data-del');
        CN.confirm({ title: CN.t('pat.deleteTitle'), message: CN.t('pat.deleteMsg'),
          confirmLabel: CN.t('common.yesDelete') }).then(function (ok) {
          if (!ok) return;
          CN.store.deletePatient(id).then(function () {
            if (CN.app.patientId === id) CN.app.setPatient(null);
            CN.toast(CN.t('common.saved'));
            load();
          });
        });
      });
      U.on(host, 'click', '[data-go]', function (e, el) { CN.app.go(el.getAttribute('data-go')); });

      load();
    }
  };

  /* -------------------------------------------------------- New Patient ---- */
  var NewPatient = {
    title: 'nav.newPatient',

    /** Blank form model. */
    blank() {
      return {
        name: '', code: '', sex: 'female', dob: '', phone: '', email: '', occupation: '',
        registeredAt: U.todayISO(), goal: 'weight_loss',
        emergency: { name: '', phone: '', relation: '' },
        conditions: '', medications: '', supplements: '', surgeries: '', familyHistory: '',
        giNotes: '', notes: '', pregnancy: '',
        lifestyle: {
          activity: 'light', exercise: '', sleep: '', smoking: '', water: '', meals: '3',
          preferences: '', disliked: '', cultural: '', budget: '', cooking: '', eatingHabits: ''
        },
        restrictions: [],
        custom: {},
        measure: { heightCm: '', weightKg: '', targetWeightKg: '', waistCm: '', hipCm: '',
          bodyFatPct: '', muscleMassKg: '', visceralFat: '', totalBodyWaterPct: '' }
      };
    },

    /** Generate the next sequential patient code for the clinic. */
    nextCode(patients) {
      var max = 1000;
      patients.forEach(function (p) {
        var m = /(\d+)\s*$/.exec(p.code || '');
        if (m) max = Math.max(max, parseInt(m[1], 10));
      });
      return 'NC-' + (max + 1);
    },

    render(host, ctx) {
      CN.store.settings().then(function (s) {
        NewPatient.renderForm(host, NewPatient.blank(), null, s.customFields || []);
      });
    },

    /** Edit an existing patient. */
    openEditor(id) {
      CN.store.get('patients', id).then(function (p) {
        if (!p) return;
        CN.store.all('measurements').then(function (ms) {
          var latest = ui.latestMeasurement(ms, id);
          var model = Object.assign(NewPatient.blank(), p);
          model.conditions = (p.conditions || []).join('; ');
          model.lifestyle = Object.assign(NewPatient.blank().lifestyle, p.lifestyle || {});
          model.restrictions = (p.restrictions || []).map(function (r) { return Object.assign({}, r); });
          if (latest) {
            model.measure = {
              heightCm: latest.heightCm || '', weightKg: latest.weightKg || '',
              targetWeightKg: latest.targetWeightKg || '', waistCm: latest.waistCm || '',
              hipCm: latest.hipCm || '', bodyFatPct: latest.bodyFatPct || '',
              muscleMassKg: latest.muscleMassKg || '', visceralFat: latest.visceralFat || '',
              totalBodyWaterPct: latest.totalBodyWaterPct || ''
            };
          }
          var host = U.$('#view');
          CN.store.settings().then(function (s) {
            NewPatient.renderForm(host, model, p, s.customFields || []);
          });
        });
      });
    },

    renderForm(host, model, existing, customFields) {
      var L = CN.t;

      host.innerHTML = ui.pageHead(existing ? 'common.edit' : 'new.title', 'new.subtitle',
        '<button class="btn" data-go="patients">' + U.esc(L('common.back')) + '</button>');

      var goalOpts = CN.options([
        { value: 'weight_loss', label: L('goal.weight_loss') },
        { value: 'maintenance', label: L('goal.maintenance') },
        { value: 'weight_gain', label: L('goal.weight_gain') },
        { value: 'therapeutic', label: L('goal.therapeutic') }
      ], model.goal);

      var sexOpts = CN.options([
        { value: 'female', label: L('sex.female') },
        { value: 'male', label: L('sex.male') },
        { value: 'other', label: L('sex.other') },
        { value: 'undisclosed', label: L('sex.undisclosed') }
      ], model.sex);

      var actOpts = CN.options(Object.keys(CN.engine.ACTIVITY).map(function (k) {
        return { value: k, label: L('act.' + (k === 'very' ? 'very' : (k === 'extreme' ? 'extreme' : k))) };
      }), model.lifestyle.activity);

      var html = '';

      // Personal
      html += '<div class="fieldset"><legend>' + U.esc(L('new.personal')) + '</legend><div class="inline-fields">' +
        '<div class="field"><label for="p-name">' + U.esc(L('pat.name')) + ' *</label>' +
          '<input id="p-name" type="text" value="' + U.esc(model.name) + '"/></div>' +
        '<div class="field"><label for="p-code">' + U.esc(L('pat.code')) + '</label>' +
          '<input id="p-code" type="text" value="' + U.esc(model.code) + '" placeholder="NC-XXXX"/></div>' +
        '<div class="field"><label for="p-sex">' + U.esc(L('pat.sex')) + '</label>' +
          '<select id="p-sex">' + sexOpts + '</select></div>' +
        '<div class="field"><label for="p-dob">' + U.esc(L('new.dob')) + '</label>' +
          '<input id="p-dob" type="date" value="' + U.esc(model.dob) + '"/></div>' +
        '<div class="field"><label for="p-phone">' + U.esc(L('pat.phone')) + '</label>' +
          '<input id="p-phone" type="tel" value="' + U.esc(model.phone) + '"/></div>' +
        '<div class="field"><label for="p-email">' + U.esc(L('new.email')) + '</label>' +
          '<input id="p-email" type="email" value="' + U.esc(model.email) + '"/></div>' +
        '<div class="field"><label for="p-occupation">' + U.esc(L('new.occupation')) + '</label>' +
          '<input id="p-occupation" type="text" value="' + U.esc(model.occupation) + '"/></div>' +
        '<div class="field"><label for="p-goal">' + U.esc(L('en.goal')) + '</label>' +
          '<select id="p-goal">' + goalOpts + '</select></div>' +
        '</div></div>';

      // Anthropometry
      html += '<div class="fieldset"><legend>' + U.esc(L('new.anthropometry')) + '</legend><div class="inline-fields">' +
        '<div class="field"><label for="m-heightCm">' + U.esc(L('new.height')) + ' (cm)</label>' +
          '<input id="m-heightCm" type="number" step="0.5" value="' + U.esc(model.measure.heightCm) + '"/></div>' +
        '<div class="field"><label for="m-weightKg">' + U.esc(L('new.weight')) + ' (kg)</label>' +
          '<input id="m-weightKg" type="number" step="0.1" value="' + U.esc(model.measure.weightKg) + '"/></div>' +
        '<div class="field"><label for="m-targetWeightKg">' + U.esc(L('new.targetWeight')) + ' (kg)</label>' +
          '<input id="m-targetWeightKg" type="number" step="0.1" value="' + U.esc(model.measure.targetWeightKg) + '"/></div>' +
        '<div class="field"><label for="m-waistCm">' + U.esc(L('new.waist')) + ' (cm)</label>' +
          '<input id="m-waistCm" type="number" step="0.5" value="' + U.esc(model.measure.waistCm) + '"/></div>' +
        '<div class="field"><label for="m-hipCm">' + U.esc(L('new.hip')) + ' (cm)</label>' +
          '<input id="m-hipCm" type="number" step="0.5" value="' + U.esc(model.measure.hipCm) + '"/></div>' +
        '<div class="field"><label for="m-bodyFatPct">' + U.esc(L('new.bodyFat')) + ' (%)</label>' +
          '<input id="m-bodyFatPct" type="number" step="0.1" value="' + U.esc(model.measure.bodyFatPct) + '"/></div>' +
        '<div class="field"><label for="m-muscleMassKg">' + U.esc(L('new.muscle')) + ' (kg)</label>' +
          '<input id="m-muscleMassKg" type="number" step="0.1" value="' + U.esc(model.measure.muscleMassKg) + '"/></div>' +
        '<div class="field"><label for="m-visceralFat">' + U.esc(L('new.visceral')) + '</label>' +
          '<input id="m-visceralFat" type="number" step="1" value="' + U.esc(model.measure.visceralFat) + '"/></div>' +
        '<div class="field"><label for="m-totalBodyWaterPct">' + U.esc(L('new.tbw')) + ' (%)</label>' +
          '<input id="m-totalBodyWaterPct" type="number" step="0.1" value="' + U.esc(model.measure.totalBodyWaterPct) + '"/></div>' +
        '</div>' +
        '<div id="live-bmi" class="muted" style="font-size:.82rem"></div></div>';

      // Medical
      html += '<div class="fieldset"><legend>' + U.esc(L('new.medical')) + '</legend>' +
        '<div class="field"><label for="p-conditions">' + U.esc(L('new.conditions')) + '</label>' +
          '<input id="p-conditions" type="text" value="' + U.esc(model.conditions) + '"/>' +
          '<div class="hint">' + U.esc(L('new.conditionsHint')) + '</div></div>' +
        '<div class="inline-fields">' +
        '<div class="field"><label for="p-medications">' + U.esc(L('new.medications')) + '</label>' +
          '<textarea id="p-medications">' + U.esc(model.medications) + '</textarea></div>' +
        '<div class="field"><label for="p-supplements">' + U.esc(L('new.supplements')) + '</label>' +
          '<textarea id="p-supplements">' + U.esc(model.supplements) + '</textarea></div>' +
        '<div class="field"><label for="p-surgeries">' + U.esc(L('new.surgeries')) + '</label>' +
          '<textarea id="p-surgeries">' + U.esc(model.surgeries) + '</textarea></div>' +
        '<div class="field"><label for="p-familyHistory">' + U.esc(L('new.family')) + '</label>' +
          '<textarea id="p-familyHistory">' + U.esc(model.familyHistory) + '</textarea></div>' +
        '<div class="field"><label for="p-giNotes">' + U.esc(L('new.giNotes')) + '</label>' +
          '<textarea id="p-giNotes">' + U.esc(model.giNotes) + '</textarea></div>' +
        '<div class="field"><label for="p-pregnancy">' + U.esc(L('new.pregnancy')) + '</label>' +
          '<input id="p-pregnancy" type="text" value="' + U.esc(model.pregnancy) + '"/></div>' +
        '</div>' +
        '<div class="field"><label for="p-notes">' + U.esc(L('new.notes')) + '</label>' +
          '<textarea id="p-notes">' + U.esc(model.notes) + '</textarea></div></div>';

      // Lifestyle
      var ls = model.lifestyle;
      html += '<div class="fieldset"><legend>' + U.esc(L('new.lifestyle')) + '</legend><div class="inline-fields">' +
        '<div class="field"><label for="l-activity">' + U.esc(L('new.activity')) + '</label><select id="l-activity">' +
          actOpts + '</select></div>' +
        '<div class="field"><label for="l-exercise">' + U.esc(L('new.exercise')) + '</label>' +
          '<input id="l-exercise" type="text" value="' + U.esc(ls.exercise) + '"/></div>' +
        '<div class="field"><label for="l-sleep">' + U.esc(L('new.sleep')) + '</label>' +
          '<input id="l-sleep" type="text" value="' + U.esc(ls.sleep) + '"/></div>' +
        '<div class="field"><label for="l-smoking">' + U.esc(L('new.smoking')) + '</label>' +
          '<input id="l-smoking" type="text" value="' + U.esc(ls.smoking) + '"/></div>' +
        '<div class="field"><label for="l-water">' + U.esc(L('new.water')) + ' (ml)</label>' +
          '<input id="l-water" type="text" value="' + U.esc(ls.water) + '"/></div>' +
        '<div class="field"><label for="l-meals">' + U.esc(L('new.meals')) + '</label>' +
          '<input id="l-meals" type="text" value="' + U.esc(ls.meals) + '"/></div>' +
        '<div class="field"><label for="l-preferences">' + U.esc(L('new.preferences')) + '</label>' +
          '<input id="l-preferences" type="text" value="' + U.esc(ls.preferences) + '"/></div>' +
        '<div class="field"><label for="l-disliked">' + U.esc(L('new.disliked')) + '</label>' +
          '<input id="l-disliked" type="text" value="' + U.esc(ls.disliked) + '"/></div>' +
        '<div class="field"><label for="l-cultural">' + U.esc(L('new.cultural')) + '</label>' +
          '<input id="l-cultural" type="text" value="' + U.esc(ls.cultural) + '"/></div>' +
        '<div class="field"><label for="l-budget">' + U.esc(L('new.budget')) + '</label>' +
          '<input id="l-budget" type="text" value="' + U.esc(ls.budget) + '"/></div>' +
        '<div class="field"><label for="l-cooking">' + U.esc(L('new.cooking')) + '</label>' +
          '<input id="l-cooking" type="text" value="' + U.esc(ls.cooking) + '"/></div>' +
        '<div class="field"><label for="l-eatingHabits">' + U.esc(L('new.eatingHabits')) + '</label>' +
          '<input id="l-eatingHabits" type="text" value="' + U.esc(ls.eatingHabits) + '"/></div>' +
        '</div></div>';

      // Restrictions
      var cf = customFields || [];
      if (cf.length) {
        html += '<div class="fieldset"><legend>' + U.esc(L('new.customFields')) + '</legend>' +
          '<div class="inline-fields">' + cf.map(function (f) {
            var val = (model.custom && model.custom[f.key] !== undefined) ? model.custom[f.key] : '';
            var id = 'cf-' + f.key;
            if (f.type === 'boolean') {
              return '<div class="field"><label for="' + id + '">' + U.esc(f.label) + '</label>' +
                '<select id="' + id + '" data-cf="' + U.esc(f.key) + '">' + CN.options([
                  { value: '', label: '—' },
                  { value: 'yes', label: L('common.yes') },
                  { value: 'no', label: L('common.no') }
                ], val) + '</select></div>';
            }
            var type = f.type === 'number' ? 'number' : (f.type === 'date' ? 'date' : 'text');
            return '<div class="field"><label for="' + id + '">' + U.esc(f.label) + '</label>' +
              '<input id="' + id + '" type="' + type + '" data-cf="' + U.esc(f.key) + '" value="' +
              U.esc(val) + '"/></div>';
          }).join('') + '</div></div>';
      }

      html += '<div class="fieldset"><legend>' + U.esc(L('new.restrictions')) + '</legend>' +
        '<div id="restr-list"></div>' +
        '<div class="row tight mt0">' +
        '<select id="r-kind" style="max-width:200px">' + CN.options([
          { value: 'allergy', label: L('rest.allergy') },
          { value: 'intolerance', label: L('rest.intolerance') },
          { value: 'preference', label: L('rest.preference') },
          { value: 'religious', label: L('rest.religious') },
          { value: 'medical', label: L('rest.medical') }
        ]) + '</select>' +
        '<input id="r-substance" type="text" placeholder="' + U.esc(L('new.restrictionSubstance')) +
          '" style="max-width:240px" list="allergen-list"/>' +
        '<datalist id="allergen-list">' + CN.foods.allergens.map(function (a) {
          return '<option value="' + U.esc(a[0]) + '">' + U.esc(a[1]) + '</option>';
        }).join('') + '</datalist>' +
        '<button class="btn" id="r-add" type="button">' + CN.icon('plus', 15) + ' ' +
          U.esc(L('new.addRestriction')) + '</button>' +
        '</div></div>';

      html += '<div class="btn-row mb2">' +
        '<button class="btn btn-primary" id="p-save">' + CN.icon('save', 16) + ' ' + U.esc(L('common.save')) + '</button>' +
        '<button class="btn" data-go="patients">' + U.esc(L('common.cancel')) + '</button>' +
        '</div>';

      host.innerHTML += html;

      /* ---- restrictions repeater ---- */
      var restrictions = model.restrictions || [];
      function drawRestrictions() {
        var el = U.$('#restr-list');
        if (!el) return;
        if (!restrictions.length) {
          el.innerHTML = '<p class="muted" style="font-size:.85rem">' + U.esc(L('common.none')) + '</p>';
          return;
        }
        el.innerHTML = '<div class="table-wrap mb1"><table class="tbl compact"><thead><tr>' +
          '<th>' + U.esc(L('new.restrictionKind')) + '</th><th>' + U.esc(L('new.restrictionSubstance')) +
          '</th><th></th></tr></thead><tbody>' +
          restrictions.map(function (r, i) {
            return '<tr><td>' + U.esc(L('rest.' + r.kind)) + '</td><td>' +
              U.esc(CN.foods.allergenLabel(r.substance, CN.i18n.lang)) + '</td>' +
              '<td class="right"><button class="btn btn-xs" type="button" data-r-del="' + i + '">' +
              CN.icon('trash', 13) + '</button></td></tr>';
          }).join('') + '</tbody></table></div>';
      }
      drawRestrictions();

      U.on(host, 'click', '#r-add', function () {
        var kind = U.$('#r-kind').value;
        var substance = (U.$('#r-substance').value || '').trim();
        if (!substance) return;
        restrictions.push({ kind: kind, substance: substance, diagnosed: kind === 'allergy' });
        U.$('#r-substance').value = '';
        drawRestrictions();
      });
      U.on(host, 'click', '[data-r-del]', function (e, el) {
        restrictions.splice(Number(el.getAttribute('data-r-del')), 1);
        drawRestrictions();
      });

      /* ---- live BMI ---- */
      function updateBmi() {
        var h = U.parseNum(U.$('#m-heightCm').value);
        var w = U.parseNum(U.$('#m-weightKg').value);
        var el = U.$('#live-bmi');
        if (!el) return;
        var b = CN.engine.bmi(h, w);
        if (b === null) { el.textContent = ''; return; }
        var c = CN.engine.bmiClass(b);
        el.innerHTML = 'BMI <strong>' + U.nf(b, 1) + '</strong> · ' +
          U.esc(CN.i18n.lang === 'ar' ? c.ar : c.en) +
          (h ? ' · ' + U.esc(L('bc.whr')) + ' ' + (CN.engine.whr(U.parseNum(U.$('#m-waistCm').value), U.parseNum(U.$('#m-hipCm').value)) || '—') : '');
      }
      ['m-heightCm', 'm-weightKg', 'm-waistCm', 'm-hipCm'].forEach(function (id) {
        U.on(host, 'input', '#' + id, updateBmi);
      });
      updateBmi();

      /* ---- save ---- */
      U.on(host, 'click', '#p-save', function () {
        var name = (U.$('#p-name').value || '').trim();
        if (!name) { CN.toast(L('new.needName'), 'alert'); U.$('#p-name').focus(); return; }

        CN.store.all('patients').then(function (all) {
          var code = (U.$('#p-code').value || '').trim() ||
            (existing && existing.code) || NewPatient.nextCode(all);

          var record = Object.assign({}, existing || {}, {
            id: existing ? existing.id : U.uid('pat'),
            name: name,
            code: code,
            sex: U.$('#p-sex').value,
            dob: U.$('#p-dob').value,
            phone: U.$('#p-phone').value,
            email: U.$('#p-email').value,
            occupation: U.$('#p-occupation').value,
            goal: U.$('#p-goal').value,
            registeredAt: (existing && existing.registeredAt) || U.todayISO(),
            conditions: (U.$('#p-conditions').value || '').split(';').map(function (s) { return s.trim(); }).filter(Boolean),
            medications: U.$('#p-medications').value,
            supplements: U.$('#p-supplements').value,
            surgeries: U.$('#p-surgeries').value,
            familyHistory: U.$('#p-familyHistory').value,
            giNotes: U.$('#p-giNotes').value,
            pregnancy: U.$('#p-pregnancy').value,
            notes: U.$('#p-notes').value,
            restrictions: restrictions,
            custom: (function () {
              // Values for whatever fields the clinic defined in Settings.
              var out = {};
              U.$$('[data-cf]', host).forEach(function (el) {
                var v = el.value;
                if (v !== '' && v !== null && v !== undefined) out[el.getAttribute('data-cf')] = v;
              });
              return out;
            })(),
            lifestyle: {
              activity: U.$('#l-activity').value, exercise: U.$('#l-exercise').value,
              sleep: U.$('#l-sleep').value, smoking: U.$('#l-smoking').value,
              water: U.$('#l-water').value, meals: U.$('#l-meals').value,
              preferences: U.$('#l-preferences').value, disliked: U.$('#l-disliked').value,
              cultural: U.$('#l-cultural').value, budget: U.$('#l-budget').value,
              cooking: U.$('#l-cooking').value, eatingHabits: U.$('#l-eatingHabits').value
            }
          });

          CN.store.put('patients', record).then(function () {
            var height = U.parseNum(U.$('#m-heightCm').value);
            var weight = U.parseNum(U.$('#m-weightKg').value);
            var chain = Promise.resolve();
            // Only write a measurement when there is something to record.
            if (height || weight) {
              var m = {
                id: U.uid('mea'), patientId: record.id, measuredAt: U.todayISO(),
                heightCm: height, weightKg: weight,
                targetWeightKg: U.parseNum(U.$('#m-targetWeightKg').value),
                waistCm: U.parseNum(U.$('#m-waistCm').value),
                hipCm: U.parseNum(U.$('#m-hipCm').value),
                bodyFatPct: U.parseNum(U.$('#m-bodyFatPct').value),
                muscleMassKg: U.parseNum(U.$('#m-muscleMassKg').value),
                visceralFat: U.parseNum(U.$('#m-visceralFat').value),
                totalBodyWaterPct: U.parseNum(U.$('#m-totalBodyWaterPct').value),
                source: 'clinic_scale', notes: existing ? 'Updated from patient record.' : 'Baseline.'
              };
              chain = CN.store.put('measurements', m);
            }
            return chain;
          }).then(function () {
            CN.toast(L('new.created'));
            CN.bus.emit('data', { action: 'patient-saved' });
            CN.app.openPatient(record.id, 'assessment');
          });
        });
      });

      U.on(host, 'click', '[data-go]', function (e, el) { CN.app.go(el.getAttribute('data-go')); });
    }
  };

  /* ---------------------------------------------------------- Settings ----- */
  var Settings = {
    title: 'nav.settings',
    render(host, ctx) {
      host.innerHTML = ui.pageHead('st.title', 'st.subtitle');
      CN.store.settings().then(function (s) {
        var html = '';

        var caps = CN.store.capabilities();
        if (caps.engine === 'memory') {
          html += ui.notice(CN.t('st.storageWarn'), 'alert');
        } else if (caps.engine === 'localstorage') {
          html += ui.notice(CN.t('st.storageLocalNote'), 'warn');
        }

        html += '<div class="grid cols-2">';

        html += '<section class="card"><div class="card-head"><h3>' + U.esc(CN.t('st.identity')) + '</h3></div>' +
          '<div class="field"><label for="s-clinicName">' + U.esc(CN.t('rp.clinicName')) + '</label>' +
            '<input id="s-clinicName" type="text" value="' + U.esc(s.clinicName) + '"/></div>' +
          '<div class="field"><label for="s-physicianName">' + U.esc(CN.t('rp.physician')) + '</label>' +
            '<input id="s-physicianName" type="text" value="' + U.esc(s.physicianName) + '"/></div>' +
          '<div class="field"><label for="s-physicianTitle">' + U.esc(CN.t('rp.profTitle')) + '</label>' +
            '<input id="s-physicianTitle" type="text" value="' + U.esc(s.physicianTitle) + '"/></div>' +
          '<div class="field"><label for="s-clinicPhone">' + U.esc(CN.t('common.from')) + ' / ' + U.esc(CN.t('pat.phone')) + '</label>' +
            '<input id="s-clinicPhone" type="text" value="' + U.esc(s.clinicPhone) + '"/></div>' +
          '<div class="field"><label for="s-clinicEmail">' + U.esc(CN.t('new.email')) + '</label>' +
            '<input id="s-clinicEmail" type="email" value="' + U.esc(s.clinicEmail) + '"/></div>' +
          '<div class="field"><label for="s-clinicAddress">' + U.esc(CN.t('rp.contact')) + '</label>' +
            '<input id="s-clinicAddress" type="text" value="' + U.esc(s.clinicAddress) + '"/></div>' +
          '</section>';

        html += '<section class="card"><div class="card-head"><h3>' + U.esc(CN.t('st.defaults')) + '</h3></div>' +
          '<div class="field"><label for="s-defaultFormula">' + U.esc(CN.t('st.defaultFormula')) + '</label>' +
            '<select id="s-defaultFormula">' + CN.options([
              { value: 'mifflin_st_jeor', label: CN.engine.FORMULAS.mifflin_st_jeor.en },
              { value: 'harris_benedict', label: CN.engine.FORMULAS.harris_benedict.en },
              { value: 'harris_benedict_revised', label: CN.engine.FORMULAS.harris_benedict_revised.en }
            ], s.defaultFormula) + '</select></div>' +
          '<div class="field"><label for="s-defaultActivity">' + U.esc(CN.t('st.defaultActivity')) + '</label>' +
            '<select id="s-defaultActivity">' + CN.options(Object.keys(CN.engine.ACTIVITY).map(function (k) {
              return { value: k, label: CN.engine.ACTIVITY[k].en };
            }), s.defaultActivity) + '</select></div>' +
          '<div class="field"><label for="s-defaultDeficit">' + U.esc(CN.t('st.defaultDeficit')) + '</label>' +
            '<select id="s-defaultDeficit">' + CN.options([
              { value: 'mild', label: CN.engine.DEFICIT_BANDS.mild.en },
              { value: 'moderate', label: CN.engine.DEFICIT_BANDS.moderate.en },
              { value: 'larger', label: CN.engine.DEFICIT_BANDS.larger.en }
            ], s.defaultDeficit) + '</select></div>' +
          '<div class="field"><label for="s-defaultSurplus">' + U.esc(CN.t('st.defaultSurplus')) + '</label>' +
            '<select id="s-defaultSurplus">' + CN.options([
              { value: 'mild', label: CN.engine.SURPLUS_BANDS.mild.en },
              { value: 'moderate', label: CN.engine.SURPLUS_BANDS.moderate.en },
              { value: 'larger', label: CN.engine.SURPLUS_BANDS.larger.en }
            ], s.defaultSurplus) + '</select></div>' +
          '<div class="field"><label for="s-defaultDuration">' + U.esc(CN.t('st.defaultDuration')) + '</label>' +
            '<input id="s-defaultDuration" type="number" min="1" max="28" value="' + U.esc(s.defaultDuration) + '"/></div>' +
          '<div class="field"><label for="s-portionDisplay">' + U.esc(CN.t('st.portionDisplay')) + '</label>' +
            '<select id="s-portionDisplay">' + CN.options([
              { value: 'both', label: CN.t('st.portionBoth') },
              { value: 'household', label: CN.t('st.portionHousehold') },
              { value: 'grams', label: CN.t('st.portionGrams') }
            ], s.portionDisplay) + '</select></div>' +
          '<div class="field"><label for="s-lang">' + U.esc(CN.t('common.language')) + '</label>' +
            '<select id="s-lang">' + CN.options([
              { value: 'en', label: CN.t('common.english') },
              { value: 'ar', label: CN.t('common.arabic') }
            ], CN.i18n.lang) + '</select></div>' +
          '</section>';

        html += '</div>';

        /* --- §3 clinician-defined custom fields ----------------------------
           Extensible without touching source, as the brief requires. */
        var cfFields = (s.customFields || []).slice();
        html += '<section class="card"><div class="card-head"><h3>' +
          U.esc(CN.t('new.customFields')) + '</h3></div>' +
          '<p class="muted" style="font-size:.85rem">' +
            U.esc(CN.t('new.customFieldsHint')) + '</p>' +
          '<div id="cf-list"></div>' +
          '<div class="row tight mt0">' +
            '<input id="cf-label" type="text" style="max-width:240px" placeholder="' +
              U.esc(CN.t('new.customFields')) + '"/>' +
            '<select id="cf-type" style="max-width:150px">' + CN.options([
              { value: 'text', label: 'Text' },
              { value: 'number', label: 'Number' },
              { value: 'date', label: 'Date' },
              { value: 'boolean', label: 'Yes / No' }
            ]) + '</select>' +
            '<button class="btn" id="cf-add" type="button">' + CN.icon('plus', 15) + ' ' +
              U.esc(CN.t('common.add')) + '</button>' +
          '</div></section>';

        // AI configuration — clearly marked optional and off by default.
        html += '<section class="card"><div class="card-head"><h3>' + U.esc(CN.t('st.ai')) + '</h3></div>' +
          '<div class="check"><input type="checkbox" id="s-aiEnabled"' + (s.aiEnabled ? ' checked' : '') + '/>' +
            '<label for="s-aiEnabled">' + U.esc(CN.t('st.aiEnabled')) + '</label></div>' +
          '<div class="inline-fields">' +
          '<div class="field"><label for="s-aiEndpoint">' + U.esc(CN.t('st.aiProvider')) + '</label>' +
            '<input id="s-aiEndpoint" type="text" value="' + U.esc(s.aiEndpoint) + '" placeholder="https://…"/></div>' +
          '</div>' +
          ui.notice(CN.t('st.aiProxyHint'), 'warn') +
          ui.notice(CN.t('st.aiHint'), 'info') +
          '</section>';

        /* --- optional server backend (§4) ---------------------------------- */
        var be = CN.backend || null;
        var beCfg = be ? be.loadConfig() : { url: '', anonKey: '' };
        var beUser = be ? be.currentUser() : null;
        var beRole = be ? be.currentRole() : null;
        var beRemote = CN.store.isRemote();

        html += '<section class="card" id="sb-card"><div class="card-head"><h3>' +
          U.esc(CN.t('st.backend')) + '</h3><div class="grow"></div>' +
          '<span class="chip' + (beRemote ? ' navy' : '') + '">' +
            U.esc(CN.t(beRemote ? 'st.backendConnected' : 'st.backendLocal')) + '</span></div>' +
          ui.notice(CN.t('st.backendHint'), 'info');

        if (!be) {
          html += ui.notice('The backend module is not loaded.', 'warn') + '</section>';
        } else {
          html += '<div class="inline-fields">' +
            '<div class="field"><label for="sb-url">' + U.esc(CN.t('st.backendUrl')) + '</label>' +
              '<input id="sb-url" type="text" value="' + U.esc(beCfg.url) +
              '" placeholder="https://xxxx.supabase.co"/></div>' +
            '<div class="field"><label for="sb-key">' + U.esc(CN.t('st.backendKey')) + '</label>' +
              '<input id="sb-key" type="text" value="' + U.esc(beCfg.anonKey) + '"/></div>' +
            '</div>' +
            ui.notice(CN.t('st.backendKeyHint'), 'warn') +
            '<div class="btn-row mb2">' +
              '<button class="btn" id="sb-save">' + CN.icon('save', 15) + ' ' +
                U.esc(CN.t('st.backendSave')) + '</button>' +
              '<button class="btn" id="sb-test">' + CN.icon('database', 15) + ' ' +
                U.esc(CN.t('st.backendTest')) + '</button>' +
            '</div>' +
            '<div id="sb-status"></div>';

          if (beUser) {
            html += '<hr/><p><strong>' + U.esc(CN.t('st.backendSignedInAs')) + ':</strong> ' +
              U.esc(beUser.email || '—') +
              (beRole ? ' · ' + U.esc(CN.t('st.backendRole')) + ': ' + U.esc(beRole) : '') +
              '</p>' +
              '<div class="btn-row"><button class="btn btn-accent" id="sb-signout">' +
                U.esc(CN.t('st.backendSignOut')) + '</button></div>';
          } else {
            html += '<hr/><div class="inline-fields">' +
              '<div class="field"><label for="sb-email">' + U.esc(CN.t('st.backendEmail')) +
                '</label><input id="sb-email" type="email" autocomplete="username"/></div>' +
              '<div class="field"><label for="sb-secret">' + U.esc(CN.t('st.backendSecret')) +
                '</label><input id="sb-secret" type="password" autocomplete="current-password"/></div>' +
              '<div class="field"><label for="sb-clinic">' + U.esc(CN.t('st.backendClinicName')) +
                '</label><input id="sb-clinic" type="text"/></div>' +
              '</div>' +
              '<div class="btn-row">' +
                '<button class="btn btn-primary" id="sb-signin">' +
                  U.esc(CN.t('st.backendSignIn')) + '</button>' +
                '<button class="btn" id="sb-signup">' +
                  U.esc(CN.t('st.backendSignUp')) + '</button>' +
              '</div>';
          }
          html += '</section>';
        }

        // Data management
        html += '<section class="card"><div class="card-head"><h3>' + U.esc(CN.t('st.data')) + '</h3></div>' +
          '<div class="grid cols-2">' +
          '<div><p class="muted" style="font-size:.85rem">' + U.esc(CN.t('st.backupHint')) + '</p>' +
            '<button class="btn btn-primary" id="s-backup">' + CN.icon('download', 16) + ' ' +
              U.esc(CN.t('st.backup')) + '</button></div>' +
          '<div><p class="muted" style="font-size:.85rem">' + U.esc(CN.t('st.restoreHint')) + '</p>' +
            '<input type="file" id="s-restore-file" accept="application/json,.json" style="margin-bottom:.5rem;"/>' +
            '<button class="btn" id="s-restore">' + CN.icon('upload', 16) + ' ' + U.esc(CN.t('st.restore')) + '</button></div>' +
          '</div>' +
          '<hr/>' +
          '<p class="muted" style="font-size:.85rem">' + U.esc(CN.t('st.storage')) + ': <strong>' +
            U.esc(CN.t(caps.label)) + '</strong></p>' +
          '<div class="btn-row">' +
            '<button class="btn" id="s-seed">' + CN.icon('database', 16) + ' ' + U.esc(CN.t('st.seed')) + '</button>' +
          '</div>' +
          '<hr/>' +
          '<h4 style="color:#800020">' + U.esc(CN.t('st.danger')) + '</h4>' +
          '<button class="btn btn-accent" id="s-wipe">' + CN.icon('trash', 16) + ' ' + U.esc(CN.t('st.wipe')) + '</button>' +
          '</section>';

        html += '<div class="btn-row"><button class="btn btn-primary" id="s-save">' +
          CN.icon('save', 16) + ' ' + U.esc(CN.t('common.save')) + '</button></div>';

        host.innerHTML += html;

        /* --- custom field editor --- */
        function drawCf() {
          var el = U.$('#cf-list');
          if (!el) return;
          if (!cfFields.length) {
            el.innerHTML = '<p class="muted" style="font-size:.85rem">' +
              U.esc(CN.t('new.customFieldNone')) + '</p>';
            return;
          }
          el.innerHTML = '<div class="table-wrap mb1"><table class="tbl compact"><thead><tr>' +
            '<th>' + U.esc(CN.t('common.name')) + '</th>' +
            '<th>' + U.esc(CN.t('new.restrictionKind')) + '</th><th></th></tr></thead><tbody>' +
            cfFields.map(function (f, i) {
              return '<tr><td>' + U.esc(f.label) + '</td><td>' + U.esc(f.type) + '</td>' +
                '<td class="right"><button class="btn btn-xs" type="button" data-cf-del="' + i +
                '">' + CN.icon('trash', 12) + '</button></td></tr>';
            }).join('') + '</tbody></table></div>';
        }
        drawCf();

        U.on(host, 'click', '#cf-add', function () {
          var label = (U.$('#cf-label').value || '').trim();
          if (!label) return;
          // A stable key so stored values survive a later rename of the label.
          var key = 'cf_' + label.toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, '_').slice(0, 40);
          if (cfFields.some(function (f) { return f.key === key; })) {
            CN.toast(CN.t('common.noData'), 'warn');
            return;
          }
          cfFields.push({ key: key, label: label, type: U.$('#cf-type').value });
          U.$('#cf-label').value = '';
          drawCf();
        });

        U.on(host, 'click', '[data-cf-del]', function (e, el) {
          cfFields.splice(Number(el.getAttribute('data-cf-del')), 1);
          drawCf();
        });

        /* --- backend handlers --- */
        if (be) {
          function sbStoreConfig() {
            CN.backend.saveConfig(U.$('#sb-url').value, U.$('#sb-key').value);
          }

          U.on(host, 'click', '#sb-save', function () {
            sbStoreConfig();
            CN.toast(CN.t('st.backendSaved'));
          });

          U.on(host, 'click', '#sb-test', function () {
            var out = U.$('#sb-status');
            sbStoreConfig();
            out.innerHTML = '<p class="muted">Testing\u2026</p>';
            CN.backend.testConnection().then(function (r) {
              out.innerHTML = ui.notice(
                r.ok
                  ? 'Connection OK.' + (r.clinicId
                      ? ' Clinic found. Role: ' + (r.role || 'member') + '.'
                      : ' ' + (r.reason || ''))
                  : 'Connection failed: ' + r.reason,
                r.ok ? 'ok' : 'alert');
            });
          });

          U.on(host, 'click', '#sb-signin', function () {
            var email = U.$('#sb-email').value;
            var pw = U.$('#sb-secret').value;
            if (!email || !pw) { CN.toast(CN.t('st.backendNeedsEmail'), 'warn'); return; }
            CN.backend.signIn(email, pw)
              .then(function () { return CN.store.enableRemote(); })
              .then(function () {
                CN.toast(CN.t('st.backendConnected'));
                CN.app.setPatient(null);
                CN.app.refresh();
              })
              .catch(function (e) {
                U.$('#sb-status').innerHTML = ui.notice(e.message || String(e), 'alert');
              });
          });

          U.on(host, 'click', '#sb-signup', function () {
            var email = U.$('#sb-email').value;
            var pw = U.$('#sb-secret').value;
            var clinicName = U.$('#sb-clinic').value;
            if (!email || !pw) { CN.toast(CN.t('st.backendNeedsEmail'), 'warn'); return; }
            CN.backend.signUp(email, pw, clinicName)
              .then(function (r) {
                if (r.signedIn) {
                  return CN.store.enableRemote().then(function () { return { ok: true }; });
                }
                return { ok: false };
              })
              .then(function (res) {
                if (res.ok) {
                  CN.toast(CN.t('st.backendConnected'));
                  CN.app.refresh();
                } else {
                  U.$('#sb-status').innerHTML = ui.notice(CN.t('st.backendSignedUp'), 'info');
                }
              })
              .catch(function (e) {
                U.$('#sb-status').innerHTML = ui.notice(e.message || String(e), 'alert');
              });
          });

          U.on(host, 'click', '#sb-signout', function () {
            CN.confirm({ title: CN.t('st.backendSignOut'),
              message: CN.t('st.backendConfirmSignOut') }).then(function (ok) {
              if (!ok) return;
              CN.backend.signOut()
                .then(function () { return CN.store.disableRemote(); })
                .then(function () {
                  CN.app.setPatient(null);
                  CN.app.refresh();
                });
            });
          });
        }

        U.on(host, 'click', '#s-save', function () {
          CN.store.saveSettings({
            clinicName: U.$('#s-clinicName').value,
            physicianName: U.$('#s-physicianName').value,
            physicianTitle: U.$('#s-physicianTitle').value,
            clinicPhone: U.$('#s-clinicPhone').value,
            clinicEmail: U.$('#s-clinicEmail').value,
            clinicAddress: U.$('#s-clinicAddress').value,
            defaultFormula: U.$('#s-defaultFormula').value,
            defaultActivity: U.$('#s-defaultActivity').value,
            defaultDeficit: U.$('#s-defaultDeficit').value,
            defaultSurplus: U.$('#s-defaultSurplus').value,
            defaultDuration: Number(U.$('#s-defaultDuration').value) || 7,
            portionDisplay: U.$('#s-portionDisplay').value,
            customFields: cfFields,
            aiEnabled: U.$('#s-aiEnabled').checked,
            aiEndpoint: U.$('#s-aiEndpoint').value
          }).then(function () {
            var lang = U.$('#s-lang').value;
            if (lang !== CN.i18n.lang) CN.i18n.setLang(lang);
            CN.toast(CN.t('st.saved'));
          });
        });

        U.on(host, 'click', '#s-backup', function () {
          CN.store.backup().then(function (json) {
            U.download('nutriclinic-backup-' + U.todayISO() + '.json', json, 'application/json');
          });
        });

        U.on(host, 'click', '#s-restore', function () {
          var input = U.$('#s-restore-file');
          if (!input.files || !input.files.length) { CN.toast(CN.t('st.noFile'), 'alert'); return; }
          CN.confirm({ title: CN.t('st.restore'), message: CN.t('st.restoreConfirm'), kind: 'accent' })
            .then(function (ok) {
              if (!ok) return;
              return U.readFile(input.files[0]).then(function (text) {
                return CN.store.restore(text);
              }).then(function () {
                CN.toast(CN.t('st.restored'));
                CN.app.setPatient(null);
                CN.app.refresh();
              }).catch(function (e) {
                CN.toast(e.message || 'Restore failed', 'alert', 5000);
              });
            });
        });

        U.on(host, 'click', '#s-seed', function () {
          CN.confirm({ title: CN.t('st.seed'), message: CN.t('st.seedConfirm') }).then(function (ok) {
            if (!ok) return;
            CN.store.seedDemo().then(function () {
              CN.toast(CN.t('common.saved'));
              CN.app.refresh();
            });
          });
        });

        U.on(host, 'click', '#s-wipe', function () {
          CN.confirm({ title: CN.t('st.wipe'), message: CN.t('st.wipeConfirm'),
            confirmLabel: CN.t('common.yesDelete') }).then(function (ok) {
            if (!ok) return;
            CN.store.wipe().then(function () {
              CN.toast(CN.t('st.wiped'));
              CN.app.setPatient(null);
              CN.app.refresh();
            });
          });
        });
      });
    }
  };

  CN.views = CN.views || {};
  CN.views.dashboard = Dashboard;
  CN.views.patients = Patients;
  CN.views.newPatient = NewPatient;
  CN.views.settings = Settings;
  CN.NewPatient = NewPatient;
})();
