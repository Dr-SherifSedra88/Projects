/* ==========================================================================
   NutriClinic Pro — engine.js
   Deterministic clinical calculation engine.

   Every numerical value the application shows for energy, macronutrients,
   body composition or progress originates here. The Copilot may *explain* a
   result; it never produces one (brief §21).

   All functions are pure: same input, same output, no side effects, no I/O.
   That makes them independently testable — see tests/engine-tests.html.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;

  var KCAL_PER_KG_FAT = 7700;

  /* Activity multipliers. Values are the conventional factors; the chosen
     factor is always displayed alongside the result. */
  var ACTIVITY = {
    sedentary: { factor: 1.200, en: 'Sedentary (little or no exercise)', ar: 'قليل الحركة (بدون تمرين)' },
    light:     { factor: 1.375, en: 'Lightly active (1–3 days/week)', ar: 'نشاط خفيف (١–٣ أيام أسبوعيًا)' },
    moderate:  { factor: 1.550, en: 'Moderately active (3–5 days/week)', ar: 'نشاط متوسط (٣–٥ أيام)' },
    very:      { factor: 1.725, en: 'Very active (6–7 days/week)', ar: 'نشاط عالٍ (٦–٧ أيام)' },
    extreme:   { factor: 1.900, en: 'Extremely active (physical work + training)', ar: 'نشاط شديد (عمل بدني وتدريب)' }
  };

  /* Deficit bands. These are starting points for clinical judgement, not
     universal prescriptions (brief §5 step 3). */
  var DEFICIT_BANDS = {
    mild:     { lo: 250, hi: 300, en: 'Mild deficit', ar: 'عجز بسيط' },
    moderate: { lo: 400, hi: 500, en: 'Moderate deficit', ar: 'عجز متوسط' },
    larger:   { lo: 600, hi: 750, en: 'High deficit', ar: 'عجز مرتفع' }
  };

  var SURPLUS_BANDS = {
    mild:     { lo: 200, hi: 300, en: 'Mild surplus', ar: 'فائض بسيط' },
    moderate: { lo: 300, hi: 500, en: 'Moderate surplus', ar: 'فائض متوسط' },
    larger:   { lo: 500, hi: 700, en: 'High surplus', ar: 'فائض مرتفع' }
  };

  var FORMULAS = {
    mifflin_st_jeor: { en: 'Mifflin-St Jeor (1990)', ar: 'ميفلين-سانت جور (١٩٩٠)' },
    harris_benedict: { en: 'Harris-Benedict (1919)', ar: 'هاريس-بينديكت (١٩١٩)' },
    harris_benedict_revised: { en: 'Revised Harris-Benedict (Roza 1984)', ar: 'هاريس-بينديكت المنقّحة (روزا ١٩٨٤)' },
    device_measured: { en: 'Device-reported (measured)', ar: 'قياس جهاز (مقيسة)' },
    manual: { en: 'Manually entered', ar: 'مُدخلة يدويًا' }
  };

  /* --------------------------------------------------------------- helpers -- */
  function isMale(sex) { return String(sex) === 'male'; }

  /** Body mass index. Null when inputs are missing or non-positive. */
  function bmi(heightCm, weightKg) {
    var h = Number(heightCm), w = Number(weightKg);
    if (!(h > 0) || !(w > 0)) return null;
    return U.round(w / Math.pow(h / 100, 2), 1);
  }

  /** WHO classification. Severity is mapped to the locked palette, never green. */
  function bmiClass(value) {
    if (value === null || value === undefined) return { key: 'unknown', level: 'muted', en: 'Not assessed', ar: 'لم يُقيَّم' };
    if (value < 18.5) return { key: 'underweight', level: 'warn', en: 'Underweight', ar: 'نقص في الوزن' };
    if (value < 25) return { key: 'normal', level: 'ok', en: 'Healthy range', ar: 'وزن صحي' };
    if (value < 30) return { key: 'overweight', level: 'warn', en: 'Overweight', ar: 'زيادة في الوزن' };
    if (value < 35) return { key: 'obese1', level: 'alert', en: 'Obesity class I', ar: 'سمنة درجة أولى' };
    if (value < 40) return { key: 'obese2', level: 'alert', en: 'Obesity class II', ar: 'سمنة درجة ثانية' };
    return { key: 'obese3', level: 'alert', en: 'Obesity class III', ar: 'سمنة درجة ثالثة' };
  }

  /** Healthy weight range for a height, from the BMI 18.5–24.9 band. */
  function healthyWeightRange(heightCm) {
    var h = Number(heightCm);
    if (!(h > 0)) return null;
    var m = h / 100, m2 = m * m;
    return { low: U.round(18.5 * m2, 1), high: U.round(24.9 * m2, 1) };
  }

  function waistRisk(waistCm, sex) {
    var w = Number(waistCm);
    if (!(w > 0)) return null;
    var high = isMale(sex) ? 102 : 88;
    var raised = isMale(sex) ? 94 : 80;
    if (w >= high) return { level: 'alert', en: 'Substantially increased risk', ar: 'خطورة مرتفعة بدرجة كبيرة' };
    if (w >= raised) return { level: 'warn', en: 'Increased risk', ar: 'خطورة مرتفعة' };
    return { level: 'ok', en: 'Within reference range', ar: 'داخل المدى المرجعي' };
  }

  function whr(waistCm, hipCm) {
    var a = Number(waistCm), b = Number(hipCm);
    if (!(a > 0) || !(b > 0)) return null;
    return U.round(a / b, 2);
  }

  /* ------------------------------------------------------------------ BMR -- */
  /**
   * Basal metabolic rate.
   * Returns { value, formula, isEstimated, label } or null when inputs are
   * insufficient. A device-reported value is never labelled as an estimate.
   */
  function bmr(input) {
    input = input || {};
    var kg = Number(input.weightKg), cm = Number(input.heightCm), age = Number(input.age);
    var formula = input.formula || 'mifflin_st_jeor';

    if (formula === 'device_measured' || formula === 'manual') {
      var supplied = Number(input.overrideValue);
      if (!(supplied > 0)) return null;
      return {
        value: U.round(supplied, 0),
        formula: formula,
        formulaLabel: FORMULAS[formula].en,
        isEstimated: false,
        source: formula === 'device_measured' ? 'device' : 'manual',
        inputs: { weightKg: kg, heightCm: cm, age: age, sex: input.sex }
      };
    }

    if (!(kg > 0) || !(cm > 0) || !(age >= 0)) return null;
    var male = isMale(input.sex), v;

    switch (formula) {
      case 'harris_benedict':
        v = male
          ? 66.5 + (13.75 * kg) + (5.003 * cm) - (6.775 * age)
          : 655.1 + (9.563 * kg) + (1.850 * cm) - (4.676 * age);
        break;
      case 'harris_benedict_revised':
        v = male
          ? 88.362 + (13.397 * kg) + (4.799 * cm) - (5.677 * age)
          : 447.593 + (9.247 * kg) + (3.098 * cm) - (4.330 * age);
        break;
      case 'mifflin_st_jeor':
      default:
        v = (10 * kg) + (6.25 * cm) - (5 * age) + (male ? 5 : -161);
        break;
    }

    if (!(v > 0)) return null;
    return {
      value: U.round(v, 0),
      formula: formula,
      formulaLabel: FORMULAS[formula].en,
      isEstimated: true,
      source: 'equation',
      inputs: { weightKg: kg, heightCm: cm, age: age, sex: input.sex }
    };
  }

  /** Total daily energy expenditure. `bmrValue` must come from bmr(). */
  function tdee(bmrValue, activityKey, overrideFactor) {
    var b = Number(bmrValue);
    if (!(b > 0)) return null;
    var factor = Number(overrideFactor);
    if (!(factor > 0)) {
      var a = ACTIVITY[activityKey] || ACTIVITY.moderate;
      factor = a.factor;
    }
    return {
      value: U.round(b * factor, 0),
      factor: U.round(factor, 3),
      activityKey: activityKey || 'moderate',
      activityLabel: (ACTIVITY[activityKey] || ACTIVITY.moderate).en
    };
  }

  /* --------------------------------------------------------------- safety -- */
  /**
   * Clinical safety screen. Returns an array of flags:
   *   { level: 'alert'|'warn'|'info', en, ar, requiresReview }
   * Level 'alert' always sets requiresReview.
   */
  function safetyFlags(ctx) {
    ctx = ctx || {};
    var p = ctx.patient || {};
    var flags = [];
    var conditions = ((p.conditions || []).join(' ') + ' ' + (ctx.conditions || '')).toLowerCase();
    var pregnant = /pregnan|لactat|lactat/.test(String(p.pregnancy || '').toLowerCase()) ||
      /pregnant|lactating|breastfeed|حامل|مرضع/.test(conditions);
    var bmiVal = ctx.bmi;

    if (pregnant) {
      flags.push({
        level: 'alert', requiresReview: true,
        en: 'Pregnancy or lactation recorded. Energy restriction for weight loss is not appropriate; refer for obstetric dietetic input.',
        ar: 'يوجد حمل أو رضاعة. تقييد الطاقة لخفض الوزن غير مناسب؛ يلزم تحويل لخبير تغذية توليد.'
      });
    }
    if (/eating disorder|anorex|bulimi|اضطراب/.test(conditions)) {
      flags.push({
        level: 'alert', requiresReview: true,
        en: 'Eating disorder recorded or suspected. Restrictive patterns and fasting windows are contraindicated; prioritise specialist referral.',
        ar: 'يوجد اضطراب أكل مُسجّل أو مشتبه به. الأنظمة المقيّدة ونوافذ الصيام ممنوعة؛ الأولوية للتحويل التخصصي.'
      });
    }
    if (bmiVal !== null && bmiVal !== undefined && bmiVal < 18.5 && ctx.goal === 'weight_loss') {
      flags.push({
        level: 'alert', requiresReview: true,
        en: 'Body mass index is below 18.5 while the goal is weight reduction. This combination should not proceed without review.',
        ar: 'مؤشر كتلة الجسم أقل من ١٨٫٥ مع هدف خفض الوزن. هذه التركيبة لا تستمر دون مراجعة.'
      });
    }
    if (/kidney|renal|ckd/.test(conditions)) {
      flags.push({
        level: 'alert', requiresReview: true,
        en: 'Renal disease recorded. Protein must be individually restricted and potassium and phosphate limits driven by laboratory values.',
        ar: 'يوجد مرض كلوي. يجب تحديد البروتين فرديًا وربط حدود البوتاسيوم والفوسفات بالتحاليل.'
      });
    }
    if (/type 1|diabetes type 1|سكري النوع الأول/.test(conditions)) {
      flags.push({
        level: 'alert', requiresReview: true,
        en: 'Type 1 diabetes recorded. Ketogenic and fasting patterns require specialist supervision; risk of euglycaemic ketoacidosis and severe hypoglycaemia.',
        ar: 'يوجد سكري من النوع الأول. النظام الكيتوني والصيام يتطلبان إشرافًا تخصصيًا؛ خطر الحماض الكيتوني ونقص السكر الحاد.'
      });
    }
    if (/heart failure|cardiac failure|هبوط القلب/.test(conditions)) {
      flags.push({
        level: 'warn', requiresReview: false,
        en: 'Heart failure recorded. Sodium and fluid targets should be individualised; routine fluid restriction is not universal.',
        ar: 'يوجد هبوط بالقلب. تُحدَّد أهداف الصوديوم والسوائل فرديًا؛ تقييد السوائل ليس قاعدة عامة.'
      });
    }
    if (Number(ctx.age) >= 70) {
      flags.push({
        level: 'warn', requiresReview: false,
        en: 'Age 70 or above. Protein requirement is higher (1.0–1.2 g/kg) and aggressive deficits accelerate lean-mass loss.',
        ar: 'العمر ٧٠ عامًا أو أكثر. الاحتياج للبروتين أعلى (١٫٠–١٫٢ جم/كجم) والعجز الكبير يسرّع فقد الكتلة العضلية.'
      });
    }

    // Energy floor and rate checks are only meaningful with a target.
    if (ctx.targetKcal && ctx.bmrValue) {
      var floor = isMale(p.sex) ? 1500 : 1200;
      if (ctx.targetKcal < floor) {
        flags.push({
          level: 'alert', requiresReview: true,
          en: 'The proposed target of ' + U.nf(ctx.targetKcal, 0) + ' kcal/day is below the ' + U.nf(floor, 0) +
            ' kcal/day floor used for this patient. Targets this low require dietetic supervision.',
          ar: 'الهدف المقترح ' + U.nf(ctx.targetKcal, 0) + ' ك.ح/يوم أقل من الحد الآمن ' + U.nf(floor, 0) +
            ' ك.ح/يوم. هذا المستوى يتطلب إشرافًا تخصصيًا.'
        });
      }
      if (ctx.targetKcal < ctx.bmrValue * 0.9) {
        flags.push({
          level: 'warn', requiresReview: true,
          en: 'The proposed target is below the calculated BMR. Intakes under BMR are rarely sustainable and should be justified explicitly.',
          ar: 'الهدف المقترح أقل من معدل الأيض الأساسي. هذا المستوى نادرًا ما يكون مستدامًا ويجب تبريره صراحةً.'
        });
      }
    }

    if (ctx.weeklyRateKg !== null && ctx.weeklyRateKg !== undefined && ctx.weightKg > 0) {
      var pctPerWeek = Math.abs(ctx.weeklyRateKg) / ctx.weightKg * 100;
      if (pctPerWeek > 1.0) {
        flags.push({
          level: 'warn', requiresReview: true,
          en: 'The predicted rate of change (' + U.nf(Math.abs(ctx.weeklyRateKg), 2) + ' kg/week, ' +
            U.nf(pctPerWeek, 1) + '% of body weight) exceeds the commonly accepted 1% weekly ceiling.',
          ar: 'المعدل المتوقع (' + U.nf(Math.abs(ctx.weeklyRateKg), 2) + ' كجم/أسبوع، ' +
            U.nf(pctPerWeek, 1) + '% من وزن الجسم) يتجاوز الحد المقبول وهو ١٪ أسبوعيًا.'
        });
      }
    }

    if (bmiVal !== null && bmiVal !== undefined && bmiVal < 16) {
      flags.push({
        level: 'alert', requiresReview: true,
        en: 'Severe underweight (BMI below 16). Assess refeeding syndrome risk before advancing nutrition.',
        ar: 'نقص شديد في الوزن (مؤشر أقل من ١٦). قيّم خطر متلازمة إعادة التغذية قبل زيادة التغذية.'
      });
    }

    return flags;
  }

  /* ------------------------------------------------------- energy targeting - */
  /**
   * Full energy assessment: BMR → TDEE → target for the stated goal.
   * Never derives the deficit from BMR (brief §5 step 3).
   *
   * input: { weightKg, heightCm, age, sex, formula, overrideValue,
   *          activity, activityOverride, goal, band, patient, conditions }
   */
  function assess(input) {
    input = input || {};
    var b = bmr(input);
    if (!b) return { ok: false, reason: 'insufficient' };

    var t = tdee(b.value, input.activity, input.activityOverride);
    if (!t) return { ok: false, reason: 'insufficient' };

    var goal = input.goal || 'maintenance';
    var weight = Number(input.weightKg) || 0;
    var bmiVal = bmi(input.heightCm, weight);
    var bandKey = input.band || 'moderate';
    var band, delta = 0, target = t.value, rationale = [];

    if (goal === 'weight_loss') {
      band = DEFICIT_BANDS[bandKey] || DEFICIT_BANDS.moderate;
      delta = -Math.round((band.lo + band.hi) / 2);

      // Hard safety floor, applied before anything else is reported.
      var floor = isMale(input.sex) ? 1500 : 1200;
      if (t.value + delta < floor) {
        delta = floor - t.value;
        rationale.push('The deficit was reduced so the target does not fall below the ' +
          U.nf(floor, 0) + ' kcal/day safety floor.');
      }
      // Never exceed 30% of TDEE.
      var maxDeficit = Math.round(t.value * 0.30);
      if (Math.abs(delta) > maxDeficit) {
        delta = -maxDeficit;
        rationale.push('The deficit was capped at 30% of total daily expenditure.');
      }
      target = t.value + delta;

      rationale.push('Deficit applied to the estimated total daily expenditure of ' +
        U.nf(t.value, 0) + ' kcal/day, not to the basal metabolic rate.');
      rationale.push(band.en + ' of ' + U.nf(band.lo, 0) + '–' + U.nf(band.hi, 0) +
        ' kcal/day, a starting range to be adjusted against observed progress.');
      if (bmiVal !== null) rationale.push('Current BMI ' + U.nf(bmiVal, 1) + ' (' + bmiClass(bmiVal).en + ').');

    } else if (goal === 'weight_gain') {
      band = SURPLUS_BANDS[bandKey] || SURPLUS_BANDS.moderate;
      delta = Math.round((band.lo + band.hi) / 2);
      var maxSurplus = Math.round(t.value * 0.20);
      if (delta > maxSurplus) {
        delta = maxSurplus;
        rationale.push('The surplus was capped at 20% of total daily expenditure.');
      }
      target = t.value + delta;
      rationale.push(band.en + ' of ' + U.nf(band.lo, 0) + '–' + U.nf(band.hi, 0) + ' kcal/day.');
      rationale.push('A modest surplus favours lean tissue gain over fat gain, particularly with resistance training.');
      if (bmiVal !== null && bmiVal >= 25) {
        rationale.push('Note: current BMI is ' + U.nf(bmiVal, 1) + ', which is above the healthy range.');
      }

    } else {
      // Maintenance, and the default for a therapeutic goal.
      delta = 0;
      target = t.value;
      rationale.push('Maintenance intake set at the estimated total daily expenditure of ' +
        U.nf(t.value, 0) + ' kcal/day.');
      rationale.push('Adjust against the observed weight trend at each follow-up rather than holding this figure fixed.');
    }

    var weeklyRateKg = U.round(delta * 7 / KCAL_PER_KG_FAT, 2);
    var flags = safetyFlags({
      patient: input.patient, conditions: input.conditions, bmi: bmiVal,
      age: input.age, goal: goal, targetKcal: target, bmrValue: b.value,
      weeklyRateKg: weeklyRateKg, weightKg: weight
    });

    return {
      ok: true,
      bmr: b.value,
      bmrIsEstimated: b.isEstimated,
      bmrSource: b.source,
      bmrFormula: b.formula,
      bmrFormulaLabel: b.formulaLabel,
      tdee: t.value,
      activityFactor: t.factor,
      activityKey: t.activityKey,
      goal: goal,
      bandKey: bandKey,
      band: band ? { lo: band.lo, hi: band.hi, en: band.en, ar: band.ar } : null,
      deltaKcal: delta,
      targetKcal: Math.round(target),
      weeklyRateKg: weeklyRateKg,
      monthlyRateKg: U.round(weeklyRateKg * 4.345, 2),
      bmi: bmiVal,
      bmiClass: bmiClass(bmiVal),
      rationale: rationale,
      flags: flags,
      requiresReview: flags.some(function (f) { return f.requiresReview; })
    };
  }

  /* ---------------------------------------------------------------- macros - */
  /**
   * Macronutrient targets.
   * method 'per_kg'    — protein from g/kg, remainder shared by the approach profile
   * method 'percent'   — all three from the approach profile
   * method 'hybrid'    — protein from g/kg, carbohydrate and fat split the remainder
   */
  function macros(input) {
    input = input || {};
    var kcal = Number(input.targetKcal);
    var weight = Number(input.weightKg);
    if (!(kcal > 0)) return null;

    var profile = input.profile || { proteinPct: 20, carbPct: 45, fatPct: 35 };
    var method = input.method || 'percent';
    var proteinPerKg = Number(input.proteinPerKg) || 0.8;
    var pGrams, cGrams, fGrams;

    if (method !== 'percent' && weight > 0) {
      pGrams = proteinPerKg * weight;
      var remaining = Math.max(0, kcal - pGrams * 4);
      // Split the remainder by the ratio implied by the non-protein profile.
      var carbShare = profile.carbPct / Math.max(1, profile.carbPct + profile.fatPct);
      cGrams = (remaining * carbShare) / 4;
      fGrams = (remaining * (1 - carbShare)) / 9;
    } else {
      pGrams = (kcal * profile.proteinPct / 100) / 4;
      cGrams = (kcal * profile.carbPct / 100) / 4;
      fGrams = (kcal * profile.fatPct / 100) / 9;
    }

    pGrams = Math.max(0, pGrams);
    cGrams = Math.max(0, cGrams);
    fGrams = Math.max(0, fGrams);

    var recomputed = pGrams * 4 + cGrams * 4 + fGrams * 9;
    var fiber = Number(input.fiberMin) || (kcal < 1400 ? 22 : 28);
    var sodium = Number(input.sodiumMaxMg) || 2300;
    var fluidMl = weight > 0 ? Math.round(weight * 33) : 2000;

    return {
      proteinG: U.round(pGrams, 0),
      carbG: U.round(cGrams, 0),
      fatG: U.round(fGrams, 0),
      proteinPerKg: weight > 0 ? U.round(pGrams / weight, 1) : null,
      proteinPct: U.round(pGrams * 4 / Math.max(1, recomputed) * 100, 0),
      carbPct: U.round(cGrams * 4 / Math.max(1, recomputed) * 100, 0),
      fatPct: U.round(fGrams * 9 / Math.max(1, recomputed) * 100, 0),
      fiberG: fiber,
      sodiumMaxMg: sodium,
      fluidMl: fluidMl,
      energyFromMacros: Math.round(recomputed),
      method: method
    };
  }

  /* -------------------------------------------------------------- progress - */
  /**
   * Longitudinal progress from measurement history (oldest → newest).
   * Returns null when there are fewer than two usable points.
   */
  function progress(measurements, targetWeightKg) {
    var pts = (measurements || [])
      .filter(function (m) { return Number(m.weightKg) > 0 && m.measuredAt; })
      .slice()
      .sort(function (a, b) { return String(a.measuredAt).localeCompare(String(b.measuredAt)); });
    if (pts.length < 2) return null;

    var first = pts[0], last = pts[pts.length - 1];
    var days = U.daysBetween(first.measuredAt, last.measuredAt);
    var totalChange = U.round(last.weightKg - first.weightKg, 2);
    var pctChange = U.round(totalChange / first.weightKg * 100, 1);
    var weeks = days > 0 ? days / 7 : null;
    var weekly = weeks ? U.round(totalChange / weeks, 2) : null;

    var bmiFirst = bmi(first.heightCm || last.heightCm, first.weightKg);
    var bmiLast = bmi(last.heightCm || first.heightCm, last.weightKg);

    var fatChange = (first.bodyFatPct && last.bodyFatPct)
      ? U.round(last.bodyFatPct - first.bodyFatPct, 1) : null;

    // Lean mass is the part of the change that is not fat.
    var leanChange = null;
    if (first.bodyFatPct && last.bodyFatPct) {
      var lean1 = first.weightKg * (1 - first.bodyFatPct / 100);
      var lean2 = last.weightKg * (1 - last.bodyFatPct / 100);
      leanChange = U.round(lean2 - lean1, 2);
    }

    var toTarget = (Number(targetWeightKg) > 0)
      ? U.round(last.weightKg - targetWeightKg, 2) : null;
    var startToTarget = (Number(targetWeightKg) > 0)
      ? U.round(first.weightKg - targetWeightKg, 2) : null;
    var progressPct = (startToTarget !== null && startToTarget !== 0)
      ? U.round(U.clamp((first.weightKg - last.weightKg) / startToTarget * 100, -999, 999), 1) : null;

    return {
      points: pts,
      firstDate: first.measuredAt,
      lastDate: last.measuredAt,
      days: days,
      weeks: weeks ? U.round(weeks, 1) : null,
      firstWeight: first.weightKg,
      lastWeight: last.weightKg,
      totalChange: totalChange,
      pctChange: pctChange,
      weeklyChange: weekly,
      bmiFirst: bmiFirst,
      bmiLast: bmiLast,
      fatChange: fatChange,
      leanChange: leanChange,
      targetWeightKg: Number(targetWeightKg) > 0 ? targetWeightKg : null,
      toTarget: toTarget,
      progressPct: progressPct,
      direction: totalChange < 0 ? 'loss' : (totalChange > 0 ? 'gain' : 'flat')
    };
  }

  /**
   * Compare an observed rate against the rate the plan predicted.
   * Returns { verdict, ratio, en } where verdict is one of:
   *   ahead | on_track | slower | stalled | faster
   */
  function compareToExpected(actualWeeklyKg, expectedWeeklyKg) {
    var a = Number(actualWeeklyKg), e = Number(expectedWeeklyKg);
    if (!isFinite(a) || !isFinite(e) || e === 0) {
      return { verdict: 'unknown', ratio: null, en: 'Insufficient data to compare with the expected trend.' };
    }
    var sameDirection = (a <= 0 && e <= 0) || (a >= 0 && e >= 0);
    var ratio = Math.abs(a) / Math.abs(e);

    var verdict;
    if (!sameDirection) verdict = 'reversed';
    else if (ratio < 0.25) verdict = 'stalled';
    else if (ratio < 0.7) verdict = 'slower';
    else if (ratio > 1.35) verdict = 'faster';
    else verdict = 'on_track';

    var en = {
      stalled: 'Progress has effectively stalled against the predicted rate.',
      slower: 'Progress is slower than predicted.',
      on_track: 'Progress is consistent with the predicted rate.',
      faster: 'Progress is faster than predicted.',
      reversed: 'Weight is moving in the opposite direction to the plan.'
    }[verdict];

    return { verdict: verdict, ratio: U.round(ratio, 2), en: en };
  }

  /* ----------------------------------------------------------- reassessment */
  /**
   * Propose a revised energy target at follow-up.
   * Never reduces calories on the basis of a short plateau alone, and never
   * changes anything without clinician approval (brief §15).
   *
   * ctx: { previousTargetKcal, goal, expectedWeeklyKg, actualWeeklyKg,
   *        adherence ('high'|'moderate'|'low'|'none'), atTarget, weeks,
   *        fluidOrMedChange, weightTrendFlat }
   */
  function reassess(ctx) {
    ctx = ctx || {};
    var prev = Number(ctx.previousTargetKcal);
    if (!(prev > 0)) {
      return { ok: false, reason: 'no_previous_target' };
    }

    var factors = [], changes = [];
    var cmp = compareToExpected(ctx.actualWeeklyKg, ctx.expectedWeeklyKg);
    var adherence = ctx.adherence || 'none';
    var suggested = prev;

    if (ctx.goal === 'weight_loss') {
      if (ctx.atTarget) {
        changes.push('Target weight has been reached. A maintenance target is proposed rather than a continued deficit.');
        suggested = prev + Math.abs(Number(ctx.expectedWeeklyKg) || 400) * KCAL_PER_KG_FAT / 7;
      } else if (cmp.verdict === 'stalled' || cmp.verdict === 'slower') {
        if (adherence === 'low' || adherence === 'none') {
          factors.push('Adherence is ' + adherence + ', which plausibly explains the shortfall.');
          changes.push('No calorie reduction is proposed. A short plateau with poor adherence is not a reason to cut energy.');
        } else if (ctx.weightTrendFlat && (ctx.weeks || 0) < 3) {
          factors.push('The plateau spans fewer than three weeks.');
          changes.push('No calorie reduction is proposed yet. Adherence, fluid shifts and measurement variation are considered first.');
        } else if (ctx.fluidOrMedChange) {
          factors.push('Fluid status or medication has changed.');
          changes.push('No calorie reduction is proposed until the recent change has settled.');
        } else {
          factors.push('Adherence is ' + adherence + ' and the plateau has persisted for ' + (ctx.weeks || '3+') + ' weeks.');
          changes.push('A reduction of 100–150 kcal/day is proposed.');
          suggested = prev - 125;
        }
      } else if (cmp.verdict === 'faster') {
        factors.push('Observed loss is materially faster than predicted.');
        changes.push('An increase of 100–150 kcal/day is proposed to protect lean mass.');
        suggested = prev + 125;
      } else if (cmp.verdict === 'reversed') {
        factors.push('Weight is moving in the opposite direction to the plan.');
        changes.push('The target is left unchanged pending review — this pattern needs clinical explanation rather than an arithmetic adjustment.');
      } else {
        changes.push('Progress is consistent with the plan; the target is unchanged.');
      }
    } else if (ctx.goal === 'weight_gain') {
      if (cmp.verdict === 'stalled' || cmp.verdict === 'slower') {
        changes.push('An increase of 150–200 kcal/day is proposed to maintain the surplus.');
        suggested = prev + 175;
      } else if (cmp.verdict === 'faster') {
        factors.push('Gain is faster than intended, which will include fat mass.');
        changes.push('A reduction of 150 kcal/day is proposed.');
        suggested = prev - 150;
      } else {
        changes.push('The surplus is producing the intended rate; the target is unchanged.');
      }
    } else {
      changes.push('Maintenance: the target is adjusted only against the observed trend.');
      if (cmp.verdict === 'faster' || cmp.verdict === 'slower') {
        suggested = prev + (cmp.verdict === 'faster' && ctx.actualWeeklyKg > 0 ? -150 : 0);
      }
    }

    suggested = Math.round(suggested / 25) * 25;   // round to a practical step

    return {
      ok: true,
      previous: prev,
      suggested: suggested,
      changed: suggested !== prev,
      comparison: cmp,
      factors: factors,
      rationale: changes,
      requiresApproval: true,
      // Nothing is applied here — the caller must record clinician approval.
      applied: false
    };
  }

  /** Predicted weekly change (kg) for a given daily energy delta. */
  function weeklyRate(deltaKcal) {
    var d = Number(deltaKcal);
    if (!isFinite(d)) return null;
    return U.round(d * 7 / KCAL_PER_KG_FAT, 2);
  }

  /* ------------------------------------------------------- macro contract -- */
  /**
   * Normalise a macronutrient record to the canonical shape.
   *
   * Two shapes exist in the wild, because this application was rebuilt from an
   * earlier implementation:
   *
   *   this build       { proteinG, carbG, fatG, proteinPct, carbPct, fatPct }
   *   the earlier one  { pG, cG, fG, p, c, f }
   *
   * The earlier Energy Calculator could persist only the percentages and omit
   * the gram values, while the Diet Plan Builder reads the grams. An assessment
   * stored that way therefore carried no usable macro targets at all — the stop
   * point between the two modules.
   *
   * Rather than require a data migration, this resolves either shape and
   * DERIVES the missing representation from the other plus the calorie target.
   * A record written by either build comes back complete.
   */
  function normaliseMacros(m, targetKcal) {
    if (!m) return null;

    function pick() {
      for (var i = 0; i < arguments.length; i++) {
        var v = arguments[i];
        if (v !== undefined && v !== null && v !== '' && isFinite(Number(v))) return Number(v);
      }
      return null;
    }

    var kcal = pick(targetKcal, m.targetKcal, m.target);
    var pPct = pick(m.proteinPct, m.p, m.proteinPercent);
    var cPct = pick(m.carbPct, m.c, m.carbPercent);
    var fPct = pick(m.fatPct, m.f, m.fatPercent);
    var pG = pick(m.proteinG, m.pG);
    var cG = pick(m.carbG, m.cG);
    var fG = pick(m.fatG, m.fG);

    // A record carrying percentages but no grams is the exact failure this
    // function exists to repair: the grams are derived, not lost.
    var derived = false;
    if (pG === null && pPct !== null && kcal > 0) { pG = U.round(kcal * pPct / 100 / 4, 0); derived = true; }
    if (cG === null && cPct !== null && kcal > 0) { cG = U.round(kcal * cPct / 100 / 4, 0); derived = true; }
    if (fG === null && fPct !== null && kcal > 0) { fG = U.round(kcal * fPct / 100 / 9, 0); derived = true; }

    var energy = (pG !== null && cG !== null && fG !== null)
      ? (pG * 4) + (cG * 4) + (fG * 9) : null;

    // And the inverse, so a percentage-only consumer is satisfied too.
    if (energy > 0) {
      if (pPct === null) pPct = U.round(pG * 4 / energy * 100, 0);
      if (cPct === null) cPct = U.round(cG * 4 / energy * 100, 0);
      if (fPct === null) fPct = U.round(fG * 9 / energy * 100, 0);
    }

    return {
      proteinG: pG, carbG: cG, fatG: fG,
      proteinPct: pPct, carbPct: cPct, fatPct: fPct,
      proteinPerKg: pick(m.proteinPerKg),
      fiberG: pick(m.fiberG, m.fiber),
      sodiumMaxMg: pick(m.sodiumMaxMg, m.sodium),
      fluidMl: pick(m.fluidMl, m.fluids),
      method: m.method || m.mode || null,
      /** True when the grams had to be derived — worth surfacing, not hiding. */
      derivedFromPercentages: derived,
      /** False when the record cannot yield usable gram targets. */
      complete: pG !== null && cG !== null && fG !== null
    };
  }

  CN.engine = {
    // constants exposed for tests and the UI
    ACTIVITY: ACTIVITY,
    DEFICIT_BANDS: DEFICIT_BANDS,
    SURPLUS_BANDS: SURPLUS_BANDS,
    FORMULAS: FORMULAS,
    KCAL_PER_KG_FAT: KCAL_PER_KG_FAT,
    // pure functions
    bmi: bmi,
    bmiClass: bmiClass,
    healthyWeightRange: healthyWeightRange,
    waistRisk: waistRisk,
    whr: whr,
    bmr: bmr,
    tdee: tdee,
    assess: assess,
    macros: macros,
    safetyFlags: safetyFlags,
    progress: progress,
    compareToExpected: compareToExpected,
    reassess: reassess,
    weeklyRate: weeklyRate,
    normaliseMacros: normaliseMacros,
    isMale: isMale
  };
})();
