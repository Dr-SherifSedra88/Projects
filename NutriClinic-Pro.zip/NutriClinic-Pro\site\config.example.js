/* ==========================================================================
   NutriClinic Pro — deployment configuration TEMPLATE
   ==========================================================================

   HOW TO USE
     Copy this file to  config.js  (same folder) and fill in your project's
     values.  config.js is optional: if it is absent the application runs
     entirely on the local device, and nothing here is required.

   ---------------------------------------------------------------------------
   WHICH KEY GOES HERE — read this before pasting anything
   ---------------------------------------------------------------------------
   Fill in the ANON (public) key only.

     Supabase dashboard → Project Settings → API
       • "Project URL"              → supabaseUrl
       • "anon / public" API key    → supabaseAnonKey

   The anon key is PUBLIC BY DESIGN. It is sent from the browser on every
   request and grants nothing on its own, because every table in
   docs/supabase-schema.sql enables row-level security and has no policy that
   admits an anonymous request. That is precisely why it is safe to publish
   alongside the site, and why the app can work with no server of its own.

   DO NOT put the service_role key in this file, or anywhere the browser can
   read. It bypasses row-level security completely and would expose every
   patient record in the project. Use it only from a server, a migration
   script, or the Supabase dashboard.

   The same rule applies to AI provider keys: this application never holds
   one. It calls a proxy that holds the credential — see Settings and README.

   Files to keep out of version control and out of a public deployment:
     config.js   (if you would rather not publish your project URL)
   ========================================================================== */

window.NUTRICLINIC_CONFIG = {
  // Example: 'https://abcdefghijklmnop.supabase.co'
  // Leave empty to run entirely on this device.
  supabaseUrl: '',

  // Example: a long public key beginning 'eyJ...' from the anon / public slot.
  // Leave empty to run entirely on this device.
  supabaseAnonKey: ''
};
