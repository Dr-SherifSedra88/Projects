/* ==========================================================================
   NutriClinic Pro — views-clinical.js
   Clinical Assessment, Energy Calculator, Body Composition.
   ========================================================================== */
(function () {
  'use strict';
  var CN = window.CN = window.CN || {};
  var U = CN.util;
  var ui = CN.ui;

  /* ------------------------------------------------------------- helpers --- */
  /** Laboratory flag from a result against its own reference range.
      This is a flag for attention — never a diagnosis (brief §4). */
  function flagFor(value, low, high) {
    var v = Number(value);
    if (!isFinite(v)) return 'unknown';
    var hasLow = (low !== null && low !== undefined && low !== '' && isFinite(Number(low)));
    var hasHigh = (high !== null && high !== undefined && high !== '' && isFinite(Number(high)));
    if (hasHigh && v > Number(high) * 1.5) return 'critical';
    if (hasLow && Number(low) > 0 && v < Number(low) * 0.6) return 'critical';
    if (hasLow && v < Number(low)) return 'low';
    if (hasHigh && v > Number(high)) return 'high';
    return 'normal';
  }

  function flagChip(flag) {
    var map = {
      low: ['asm.flagLow', 'gold'], normal: ['asm.flagNormal', ''], high: ['asm.flagHigh', 'gold'],
      critical: ['asm.flagCritical', 'alert'], unknown: ['asm.flagUnknown', '']
    };
    var m = map[flag] || map.unknown;
    return '<span class="chip' + (m[1] ? ' ' + m[1] : '') + '">' + U.esc(CN.t(m[0])) + '</span>';
  }

  /** Reference lab analytes offered as a starting point for a new panel. */
  var ANALYTES = [
    { key: 'Fasting glucose', unit: 'mmol/L', low: 3.9, high: 5.6 },
    { key: 'Postprandial glucose', unit: 'mmol/L', low: null, high: 7.8 },
    { key: 'HbA1c', unit: '%', low: 4.0, high: 5.7 },
    { key: 'Total cholesterol', unit: 'mmol/L', low: null, high: 5.2 },
    { key: 'LDL cholesterol', unit: 'mmol/L', low: null, high: 3.0 },
    { key: 'HDL cholesterol', unit: 'mmol/L', low: 1.0, high: 2.0 },
    { key: 'Triglycerides', unit: 'mmol/L', low: null, high: 1.7 },
    { key: 'Creatinine', unit: 'µmol/L', low: 53, high: 97 },
    { key: 'eGFR', unit: 'mL/min/1.73m²', low: 90, high: 120 },
    { key: 'ALT', unit: 'U/L', low: null, high: 40 },
    { key: 'AST', unit: 'U/L', low: null, high: 40 },
    { key: 'TSH', unit: 'mIU/L', low: 0.4, high: 4.0 },
    { key: 'Haemoglobin', unit: 'g/L', low: 120, high: 160 },
    { key: 'Ferritin', unit: 'µg/L', low: 30, high: 300 },
    { key: 'Vitamin D (25-OH)', unit: 'nmol/L', low: 75, high: 200 },
    { key: 'Vitamin B12', unit: 'pmol/L', low: 148, high: 664 },
    { key: 'Sodium', unit: 'mmol/L', low: 135, high: 145 },
    { key: 'Potassium', unit: 'mmol/L', low: 3.5, high: 5.1 },
    { key: 'Calcium', unit: 'mmol/L', low: 2.2, high: 2.6 },
    { key: 'Phosphate', unit: 'mmol/L', low: 0.8, high: 1.5 },
    { key: 'Albumin', unit: 'g/L', low: 35, high: 50 },
    { key: 'CRP', unit: 'mg/L', low: null, high: 5 }
  ];

  /* --------------------------------------------------- Clinical Assessment - */
  var Assessment = {
    title: 'nav.assessment',

    /** Items that may be needed before a plan is finalised. */
    missingItems(patient, measurements, labs) {
      var missing = [];
      var m = measurements.length ? measurements[measurements.length - 1] : null;
      if (!m || !m.heightCm) missing.push(CN.i18n.lang === 'ar' ? 'الطول' : 'Height');
      if (!m || !m.weightKg) missing.push(CN.i18n.lang === 'ar' ? 'الوزن' : 'Weight');
      if (!m || !m.waistCm) missing.push(CN.i18n.lang === 'ar' ? 'محيط الخصر' : 'Waist circumference');
      if (!patient.conditions || !patient.conditions.length) {
        missing.push(CN.i18n.lang === 'ar' ? 'الأمراض الحالية' : 'Current medical conditions');
      }
      if (!labs.length) missing.push(CN.i18n.lang === 'ar' ? 'تحاليل معملية' : 'Laboratory investigations');
      var hasRestr = (patient.restrictions || []).length > 0;
      if (!hasRestr) missing.push(CN.i18n.lang === 'ar' ? 'الحساسية والقيود الغذائية' : 'Allergies and dietary restrictions');
      return missing;
    },

    render(host, ctx) {
      var patient = ctx.patient;
      if (!patient) { ui.needPatient(host); return; }

      host.innerHTML = ui.pageHead('asm.title', 'asm.subtitle',
        '<button class="btn btn-primary" id="asm-new">' + CN.icon('plus', 16) + ' ' +
        U.esc(CN.t('asm.newPanel')) + '</button>');

      Promise.all([
        CN.store.byPatient('labs', patient.id),
        CN.store.byPatient('measurements', patient.id),
        CN.store.byPatient('attachments', patient.id)
      ]).then(function (r) {
        var labs = U.sortBy(r[0], 'collectedOn', 'desc');
        var measurements = r[1];
        var attachments = U.sortBy(r[2], 'createdAt', 'desc');

        var html = ui.notice(CN.t('asm.disclaimer'), 'info');

        var missing = Assessment.missingItems(patient, measurements, labs);
        if (missing.length) {
          html += ui.notice(CN.t('asm.missingMsg') + ' ' + missing.join(' · '), 'warn');
        }

        // Blood pressure is recorded as a visit measurement (see the card below).
        if (!labs.length) {
          html += CN.empty(CN.t('asm.none'), CN.t('asm.noneMsg'),
            '<button class="btn btn-primary" data-new="1">' + U.esc(CN.t('asm.newPanel')) + '</button>');
        } else {
          html += ui.card('asm.history', labs.map(function (panel, i) {
            return '<div class="mb2">' +
              '<div class="row mb1"><strong>' + U.esc(U.fmtDate(panel.collectedOn)) + '</strong>' +
              (panel.laboratoryName ? ui.tag(panel.laboratoryName) : '') +
              (panel.fasting ? ui.tag(CN.t('asm.fasting')) : '') +
              '<div class="grow"></div>' +
              '<button class="btn btn-xs" data-del-panel="' + U.esc(panel.id) + '">' +
                CN.icon('trash', 13) + '</button></div>' +
              '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
              '<th>' + U.esc(CN.t('asm.analyte')) + '</th>' +
              '<th class="num">' + U.esc(CN.t('asm.value')) + '</th>' +
              '<th>' + U.esc(CN.t('asm.unit')) + '</th>' +
              '<th>' + U.esc(CN.t('asm.refText')) + '</th>' +
              '<th>' + U.esc(CN.t('asm.flag')) + '</th></tr></thead><tbody>' +
              (panel.results || []).map(function (res) {
                var flag = flagFor(res.value, res.refLow, res.refHigh);
                var range = (res.refLow === null || res.refLow === undefined || res.refLow === '')
                  ? (res.refHigh !== null && res.refHigh !== undefined && res.refHigh !== '' ? '≤ ' + res.refHigh : '—')
                  : (res.refHigh !== null && res.refHigh !== undefined && res.refHigh !== ''
                    ? res.refLow + ' – ' + res.refHigh : '≥ ' + res.refLow);
                return '<tr><td>' + U.esc(res.analyte) + '</td>' +
                  '<td class="num"><strong>' + U.esc(res.value) + '</strong></td>' +
                  '<td>' + U.esc(res.unit || '') + '</td>' +
                  '<td class="mono">' + U.esc(range) + '</td>' +
                  '<td>' + flagChip(flag) + '</td></tr>';
              }).join('') + '</tbody></table></div></div>';
          }).join(''));

        }

        /* --- blood pressure ------------------------------------------------
           Stored as a measurement so it sits in the same append-only history
           as every other observation. Recording it never overwrites a
           previous reading. */
        var bpRows = measurements.filter(function (m) { return m.systolic && m.diastolic; })
          .sort(function (a, b) { return String(b.measuredAt).localeCompare(String(a.measuredAt)); });
        var latestBp = bpRows[0];

        html += ui.card('asm.bp',
          '<div class="row">' +
            (latestBp
              ? '<div class="stat"><div class="stat-label">' + U.esc(CN.t('asm.bp')) + '</div>' +
                '<div class="stat-value">' + U.nf(latestBp.systolic, 0) + '/' +
                U.nf(latestBp.diastolic, 0) + ' <small>mmHg</small></div>' +
                '<div class="stat-foot">' + U.esc(U.fmtDate(latestBp.measuredAt)) + '</div></div>'
              : '<span class="muted">' + U.esc(CN.t('asm.bpNone')) + '</span>') +
            '<div class="grow"></div>' +
            '<button class="btn btn-sm" id="asm-bp">' + CN.icon('activity', 15) + ' ' +
              U.esc(CN.t('asm.recordBp')) + '</button>' +
          '</div>' +
          (bpRows.length > 1
            ? '<div class="table-wrap" style="margin-top:.7rem"><table class="tbl compact"><tbody>' +
              bpRows.slice(0, 6).map(function (m) {
                return '<tr><td>' + U.esc(U.fmtDate(m.measuredAt)) + '</td>' +
                  '<td class="num">' + U.nf(m.systolic, 0) + '/' + U.nf(m.diastolic, 0) +
                  ' mmHg</td></tr>';
              }).join('') + '</tbody></table></div>'
            : ''));

        /* --- attachments ---------------------------------------------------
           Real storage, not a decorative control. Documents are held in
           IndexedDB on this device and can be downloaded back. */
        html += ui.card('asm.attachments',
          '<p class="muted" style="font-size:.85rem">' + U.esc(CN.t('asm.attachmentsMsg')) + '</p>' +
          (attachments.length
            ? '<div class="table-wrap mb1"><table class="tbl compact"><tbody>' +
              attachments.map(function (a) {
                return '<tr><td>' + CN.icon('file-text', 14) + ' ' + U.esc(a.filename) +
                  ((a.blob || a.storagePath) ? ''
                    : '<div class="muted" style="font-size:.76rem">' +
                      U.esc(CN.t('asm.attachMissing')) + '</div>') +
                  '</td><td class="num">' + U.nf((a.byteSize || 0) / 1024, 0) + ' KB</td>' +
                  '<td>' + U.esc(U.fmtDate(a.createdAt)) + '</td>' +
                  '<td class="right nowrap">' +
                    ((a.blob || a.storagePath)
                      ? '<button class="btn btn-xs" data-att-get="' + U.esc(a.id) + '">' +
                        U.esc(CN.t('asm.attachDownload')) + '</button> '
                      : '') +
                    '<button class="btn btn-xs" data-att-del="' + U.esc(a.id) + '">' +
                      CN.icon('trash', 12) + '</button>' +
                  '</td></tr>';
              }).join('') + '</tbody></table></div>'
            : '<p class="muted">' + U.esc(CN.t('asm.attachNone')) + '</p>') +
          '<label class="btn btn-sm" style="display:inline-flex;cursor:pointer">' +
            CN.icon('upload', 15) + ' ' + U.esc(CN.t('asm.attachAdd')) +
            '<input type="file" id="asm-file" multiple style="display:none"/></label>' +
          '<p class="muted" style="font-size:.78rem;margin:.5rem 0 0">' +
            U.esc(CN.t('asm.attachHint')) + '</p>');

        host.innerHTML += html;

        /* --- attachment handlers --- */
        U.on(host, 'change', '#asm-file', function (e, el) {
          var files = Array.prototype.slice.call(el.files || []);
          if (!files.length) return;
          var caps = CN.store.capabilities();
          Promise.all(files.map(function (file) {
            if (file.size > caps.maxAttachmentBytes) {
              CN.toast(CN.t('asm.attachTooBig') + ' ' + file.name, 'alert', 6000);
              return null;
            }
            // The File is structured-cloneable, so it stores as-is.
            return CN.store.put('attachments', {
              id: U.uid('att'), patientId: patient.id, kind: 'document',
              filename: file.name, mime: file.type || 'application/octet-stream',
              byteSize: file.size, blob: file,
              createdAt: new Date().toISOString()
            });
          })).then(function () {
            CN.toast(CN.t('asm.attachStored'));
            CN.app.refresh();
          });
        });

        U.on(host, 'click', '[data-att-get]', function (e, el) {
          CN.store.get('attachments', el.getAttribute('data-att-get')).then(function (a) {
            if (!a) { CN.toast(CN.t('asm.attachMissing'), 'alert', 5000); return; }

            // Server mode: the document lives in private object storage, so ask
            // for a short-lived signed URL instead of expecting a local Blob.
            if (a.storagePath && CN.store.isRemote() && CN.backend) {
              CN.backend.signedUrl(a.storagePath, 300).then(function (url) {
                window.open(url, '_blank', 'noopener');
              }).catch(function (err) {
                CN.toast(err.message || 'Could not open the document.', 'alert', 6000);
              });
              return;
            }

            if (!a.blob) { CN.toast(CN.t('asm.attachMissing'), 'alert', 5000); return; }
            var url = URL.createObjectURL(a.blob);
            var link = document.createElement('a');
            link.href = url; link.download = a.filename;
            document.body.appendChild(link); link.click();
            setTimeout(function () { URL.revokeObjectURL(url); link.remove(); }, 0);
          });
        });

        U.on(host, 'click', '[data-att-del]', function (e, el) {
          CN.confirm({ title: CN.t('common.delete'), message: CN.t('common.irreversible'),
            confirmLabel: CN.t('common.yesDelete') }).then(function (ok) {
            if (!ok) return;
            CN.store.del('attachments', el.getAttribute('data-att-del')).then(function () {
              CN.toast(CN.t('common.saved'));
              CN.app.refresh();
            });
          });
        });

        U.on(host, 'click', '#asm-bp', function () {
          CN.modal({
            title: CN.t('asm.recordBp'),
            body: '<div class="inline-fields">' +
              '<div class="field"><label for="bp-sys">' + U.esc(CN.t('asm.systolic')) +
                ' (mmHg)</label><input id="bp-sys" type="number" step="1" value="' +
                U.esc(latestBp ? latestBp.systolic : '') + '"/></div>' +
              '<div class="field"><label for="bp-dia">' + U.esc(CN.t('asm.diastolic')) +
                ' (mmHg)</label><input id="bp-dia" type="number" step="1" value="' +
                U.esc(latestBp ? latestBp.diastolic : '') + '"/></div>' +
              '<div class="field"><label for="bp-date">' + U.esc(CN.t('common.date')) +
                '</label><input id="bp-date" type="date" value="' + U.todayISO() + '"/></div>' +
              '</div>',
            actions: [
              { label: CN.t('common.cancel'), kind: 'ghost' },
              { label: CN.t('common.save'), kind: 'primary', close: false,
                onClick(node) {
                  var s = U.parseNum(U.$('#bp-sys', node).value);
                  var d = U.parseNum(U.$('#bp-dia', node).value);
                  if (!(s > 0) || !(d > 0)) { CN.toast(CN.t('common.noData'), 'warn'); return false; }
                  CN.store.put('measurements', {
                    id: U.uid('mea'), patientId: patient.id,
                    measuredAt: U.$('#bp-date', node).value || U.todayISO(),
                    systolic: s, diastolic: d,
                    source: 'clinic_scale', notes: 'Blood pressure only.'
                  }).then(function () {
                    CN.toast(CN.t('asm.bpSaved'));
                    CN.closeLayer();
                    CN.app.refresh();
                  });
                  return false;
                } }
            ]
          });
        });

        U.on(host, 'click', '#asm-new, [data-new]', function () { Assessment.openPanel(patient); });
        U.on(host, 'click', '[data-del-panel]', function (e, el) {
          var id = el.getAttribute('data-del-panel');
          CN.confirm({ title: CN.t('common.delete'), message: CN.t('common.irreversible'),
            confirmLabel: CN.t('common.yesDelete') }).then(function (ok) {
            if (!ok) return;
            CN.store.del('labs', id).then(function () {
              CN.toast(CN.t('common.saved'));
              CN.app.refresh();
            });
          });
        });
      });
    },

    /** Modal for entering a laboratory panel with a dynamic result list. */
    openPanel(patient) {
      var rows = [{ analyte: '', value: '', unit: '', refLow: '', refHigh: '' }];

      function drawRows() {
        return rows.map(function (r, i) {
          return '<tr data-row="' + i + '">' +
            '<td><input list="analyte-list" data-f="analyte" value="' + U.esc(r.analyte) + '"/></td>' +
            '<td><input type="number" step="any" data-f="value" value="' + U.esc(r.value) + '" style="width:90px"/></td>' +
            '<td><input data-f="unit" value="' + U.esc(r.unit) + '" style="width:90px"/></td>' +
            '<td><input type="number" step="any" data-f="refLow" value="' + U.esc(r.refLow) + '" style="width:80px"/></td>' +
            '<td><input type="number" step="any" data-f="refHigh" value="' + U.esc(r.refHigh) + '" style="width:80px"/></td>' +
            '<td><button type="button" class="btn btn-xs" data-del-row="' + i + '">' + CN.icon('x', 12) + '</button></td>' +
            '</tr>';
        }).join('');
      }

      var body = '<datalist id="analyte-list">' + ANALYTES.map(function (a) {
        return '<option value="' + U.esc(a.key) + '"></option>';
      }).join('') + '</datalist>' +
        '<div class="inline-fields">' +
        '<div class="field"><label for="panel-date">' + U.esc(CN.t('asm.collectedOn')) + '</label>' +
          '<input id="panel-date" type="date" value="' + U.todayISO() + '"/></div>' +
        '<div class="field"><label for="panel-lab">' + U.esc(CN.t('asm.labName')) + '</label>' +
          '<input id="panel-lab" type="text"/></div>' +
        '<div class="field"><label for="panel-fasting">' + U.esc(CN.t('asm.fasting')) + '</label>' +
          '<select id="panel-fasting"><option value="yes">' + U.esc(CN.t('common.yes')) + '</option>' +
          '<option value="no">' + U.esc(CN.t('common.no')) + '</option></select></div>' +
        '</div>' +
        '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
        '<th>' + U.esc(CN.t('asm.analyte')) + '</th><th>' + U.esc(CN.t('asm.value')) + '</th>' +
        '<th>' + U.esc(CN.t('asm.unit')) + '</th><th>' + U.esc(CN.t('asm.refLow')) + '</th>' +
        '<th>' + U.esc(CN.t('asm.refHigh')) + '</th><th></th></tr></thead>' +
        '<tbody id="panel-rows">' + drawRows() + '</tbody></table></div>' +
        '<button type="button" class="btn btn-sm mt0" id="panel-add-row" style="margin-top:.6rem">' +
          CN.icon('plus', 14) + ' ' + U.esc(CN.t('asm.addAnalyte')) + '</button>';

      var m = CN.modal({
        title: CN.t('asm.newPanel'), wide: true, body: body,
        actions: [
          { label: CN.t('common.cancel'), kind: 'ghost' },
          { label: CN.t('common.save'), kind: 'primary', close: false,
            onClick(node) {
              // Harvest current inputs before rebuilding.
              U.$$('#panel-rows tr', node).forEach(function (tr) {
                var i = Number(tr.getAttribute('data-row'));
                U.$$('input', tr).forEach(function (inp) {
                  rows[i][inp.getAttribute('data-f')] = inp.value;
                });
              });
              var results = rows.filter(function (r) {
                return (r.analyte || '').trim() && String(r.value).trim() !== '';
              }).map(function (r) {
                return {
                  analyte: r.analyte.trim(),
                  value: U.parseNum(r.value),
                  unit: r.unit || '',
                  refLow: U.parseNum(r.refLow),
                  refHigh: U.parseNum(r.refHigh)
                };
              });
              if (!results.length) { CN.toast(CN.t('common.noData'), 'warn'); return false; }

              CN.store.put('labs', {
                id: U.uid('lab'), patientId: patient.id,
                collectedOn: U.$('#panel-date', node).value || U.todayISO(),
                laboratoryName: U.$('#panel-lab', node).value,
                fasting: U.$('#panel-fasting', node).value === 'yes',
                results: results
              }).then(function () {
                CN.toast(CN.t('asm.panelSaved'));
                m.close();
                CN.app.refresh();
              });
              return false;
            } }
        ]
      });

      U.on(m.node, 'click', '#panel-add-row', function () {
        U.$$('#panel-rows tr', m.node).forEach(function (tr) {
          var i = Number(tr.getAttribute('data-row'));
          U.$$('input', tr).forEach(function (inp) { rows[i][inp.getAttribute('data-f')] = inp.value; });
        });
        rows.push({ analyte: '', value: '', unit: '', refLow: '', refHigh: '' });
        U.$('#panel-rows', m.node).innerHTML = drawRows();
      });

      U.on(m.node, 'click', '[data-del-row]', function (e, el) {
        var i = Number(el.getAttribute('data-del-row'));
        if (rows.length <= 1) return;
        rows.splice(i, 1);
        U.$('#panel-rows', m.node).innerHTML = drawRows();
      });

      // Pre-fill unit and ranges from the reference list when a name is chosen.
      U.on(m.node, 'change', '#panel-rows input[data-f="analyte"]', function (e, el) {
        var hit = ANALYTES.filter(function (a) {
          return a.key.toLowerCase() === (el.value || '').toLowerCase();
        })[0];
        if (!hit) return;
        var tr = el.closest('tr');
        U.$('input[data-f="unit"]', tr).value = hit.unit;
        U.$('input[data-f="refLow"]', tr).value = hit.low === null ? '' : hit.low;
        U.$('input[data-f="refHigh"]', tr).value = hit.high === null ? '' : hit.high;
      });
    }
  };

  /* ----------------------------------------------------- Energy Calculator - */
  var Energy = {
    title: 'nav.energy',

    render(host, ctx) {
      var patient = ctx.patient;
      if (!patient) { ui.needPatient(host); return; }

      host.innerHTML = ui.pageHead('en.title', 'en.subtitle');

      Promise.all([
        CN.store.settings(),
        CN.store.byPatient('measurements', patient.id),
        CN.store.byPatient('assessments', patient.id),
        CN.planHelpers.loadPlan(patient.id)
      ]).then(function (r) {
        var settings = r[0];
        var ms = U.sortBy(r[1], 'measuredAt', 'desc');
        var assessments = r[2];
        var planVersion = CN.planHelpers.activeVersion(r[3]);
        var latest = ms[0] || null;

        if (!latest || !latest.weightKg || !latest.heightCm) {
          host.innerHTML += CN.empty(CN.t('en.needMeasure'), '',
            '<button class="btn btn-primary" data-go="bodyComp">' + U.esc(CN.t('nav.bodyComp')) + '</button>');
          U.on(host, 'click', '[data-go]', function (e, el) { CN.app.go(el.getAttribute('data-go')); });
          return;
        }

        var age = U.ageFrom(patient.dob);

        var html = '';

        /* --- the calculation chain, at a glance ---------------------------
           BMR → TDEE → deficit/surplus → approved target → diet plan.
           Each stage states whether it is complete, so a clinician can see
           exactly where the workflow currently stands. */
        var approvedNow = ui.approvedAssessment(assessments, patient.id);
        var haveInputs = !!(latest && latest.weightKg && latest.heightCm);
        var chain = [
          { key: 'en.step1', done: haveInputs },
          { key: 'en.step2', done: haveInputs },
          { key: 'en.step3', done: !!approvedNow },
          { key: 'en.target', done: !!approvedNow },
          { key: 'pl.title', done: !!planVersion }
        ];
        html += ui.card('common.summary',
          '<div class="row tight">' + chain.map(function (c, i) {
            return '<span class="chip' + (c.done ? ' navy' : '') + '">' +
              (c.done ? CN.icon('check', 12) : (i + 1) + '.') + ' ' +
              U.esc(CN.t(c.key)) + '</span>' +
              (i < chain.length - 1 ? ' <span class="muted">→</span> ' : '');
          }).join('') + '</div>' +
          (haveInputs && !approvedNow
            ? ui.notice(CN.t('en.approvalNote'), 'warn') : ''));

        // ---- Step 1: BMR -------------------------------------------------
        html += ui.card('en.step1',
          '<div class="inline-fields">' +
          '<div class="field"><label for="e-formula">' + U.esc(CN.t('en.formula')) + '</label>' +
            '<select id="e-formula">' + CN.options([
              { value: 'mifflin_st_jeor', label: CN.engine.FORMULAS.mifflin_st_jeor.en },
              { value: 'harris_benedict', label: CN.engine.FORMULAS.harris_benedict.en },
              { value: 'harris_benedict_revised', label: CN.engine.FORMULAS.harris_benedict_revised.en },
              { value: 'device_measured', label: CN.engine.FORMULAS.device_measured.en },
              { value: 'manual', label: CN.engine.FORMULAS.manual.en }
            ], settings.defaultFormula) + '</select></div>' +
          '<div class="field"><label for="e-weight">' + U.esc(CN.t('pat.weight')) + ' (kg)</label>' +
            '<input id="e-weight" type="number" step="0.1" value="' + U.esc(latest.weightKg) + '"/></div>' +
          '<div class="field"><label for="e-height">' + U.esc(CN.t('new.height')) + ' (cm)</label>' +
            '<input id="e-height" type="number" step="0.5" value="' + U.esc(latest.heightCm) + '"/></div>' +
          '<div class="field"><label for="e-age">' + U.esc(CN.t('pat.age')) + '</label>' +
            '<input id="e-age" type="number" value="' + U.esc(age === null ? '' : age) + '"/></div>' +
          '<div class="field" id="e-override-wrap" style="display:none">' +
            '<label for="e-override">' + U.esc(CN.t('en.bmrManual')) + ' (kcal)</label>' +
            '<input id="e-override" type="number" step="1"/></div>' +
          '</div>' +
          '<div id="e-bmr-out"></div>') ;

        // ---- Step 2: TDEE ------------------------------------------------
        html += ui.card('en.step2',
          '<div class="inline-fields">' +
          '<div class="field"><label for="e-activity">' + U.esc(CN.t('en.activity')) + '</label>' +
            '<select id="e-activity">' + CN.options(Object.keys(CN.engine.ACTIVITY).map(function (k) {
              return { value: k, label: CN.engine.ACTIVITY[k].en };
            }), settings.defaultActivity) + '</select></div>' +
          '<div class="field"><label for="e-factor">' + U.esc(CN.t('en.multiplier')) + '</label>' +
            '<input id="e-factor" type="number" step="0.005"/></div>' +
          '</div>' +
          '<div id="e-tdee-out"></div>' +
          '<p class="muted" style="font-size:.83rem">' + U.esc(CN.t('en.tdeeHint')) + '</p>');

        // ---- Step 3: target ---------------------------------------------
        html += ui.card('en.step3',
          '<div class="inline-fields">' +
          '<div class="field"><label for="e-goal">' + U.esc(CN.t('en.goal')) + '</label>' +
            '<select id="e-goal">' + CN.options([
              { value: 'weight_loss', label: CN.t('goal.weight_loss') },
              { value: 'maintenance', label: CN.t('goal.maintenance') },
              { value: 'weight_gain', label: CN.t('goal.weight_gain') },
              { value: 'therapeutic', label: CN.t('goal.therapeutic') }
            ], patient.goal || 'weight_loss') + '</select></div>' +
          '<div class="field"><label for="e-band">' + U.esc(CN.t('en.deficit')) + ' / ' + U.esc(CN.t('en.surplus')) + '</label>' +
            '<select id="e-band">' +
            '<optgroup label="' + U.esc(CN.t('en.deficit')) + '">' +
            CN.options([
              { value: 'mild', label: CN.engine.DEFICIT_BANDS.mild.en },
              { value: 'moderate', label: CN.engine.DEFICIT_BANDS.moderate.en },
              { value: 'larger', label: CN.engine.DEFICIT_BANDS.larger.en }
            ], settings.defaultDeficit) + '</optgroup>' +
            '<optgroup label="' + U.esc(CN.t('en.surplus')) + '">' +
            CN.options([
              { value: 'mild', label: CN.engine.SURPLUS_BANDS.mild.en },
              { value: 'moderate', label: CN.engine.SURPLUS_BANDS.moderate.en },
              { value: 'larger', label: CN.engine.SURPLUS_BANDS.larger.en }
            ], settings.defaultSurplus) + '</optgroup>' +
            '</select></div>' +
          '</div>' +
          '<div id="e-target-out"></div>');

        // ---- Step 4: macros ---------------------------------------------
        html += ui.card('en.step4',
          '<div class="inline-fields">' +
          '<div class="field"><label for="e-method">' + U.esc(CN.t('en.method')) + '</label>' +
            '<select id="e-method">' + CN.options([
              { value: 'percent', label: CN.t('en.methodPercent') },
              { value: 'per_kg', label: CN.t('en.methodPerKg') },
              { value: 'hybrid', label: CN.t('en.methodHybrid') }
            ], 'hybrid') + '</select></div>' +
          '<div class="field"><label for="e-profile">' + U.esc(CN.t('pl.approaches')) + '</label>' +
            '<select id="e-profile">' + CN.options(
              [{ value: '', label: CN.t('common.none') }].concat(CN.approaches.all.map(function (a) {
                return { value: a.code, label: a.nameEn };
              })), 'mediterranean') + '</select></div>' +
          '</div>' +
          '<div id="e-macro-out"></div>');

        // ---- history + approval -----------------------------------------
        var approved = ui.approvedAssessment(assessments, patient.id);
        if (approved) {
          html += ui.card('en.approvedBy',
            '<p>' + U.esc(CN.t('en.target')) + ': <strong>' + U.nf(approved.targetKcal, 0) + ' kcal</strong> · ' +
            U.esc(U.fmtDate(approved.assessedAt)) + '</p>' +
            '<p class="muted" style="font-size:.83rem">' + U.esc(CN.t('en.approvalNote')) + '</p>');
        }

        if (assessments.length) {
          var hist = U.sortBy(assessments, 'assessedAt', 'desc');
          html += ui.card('bc.history',
            '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
            '<th>' + U.esc(CN.t('common.date')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('en.bmr')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('en.tdee')) + '</th>' +
            '<th class="num">' + U.esc(CN.t('en.target')) + '</th>' +
            '<th>' + U.esc(CN.t('common.status')) + '</th></tr></thead><tbody>' +
            hist.map(function (a) {
              return '<tr><td>' + U.esc(U.fmtDate(a.assessedAt)) + '</td>' +
                '<td class="num">' + ui.num(a.bmr, 0) + '</td>' +
                '<td class="num">' + ui.num(a.tdee, 0) + '</td>' +
                '<td class="num"><strong>' + ui.num(a.targetKcal, 0) + '</strong></td>' +
                '<td>' + (a.approvedAt
                  ? ui.tag(CN.t('en.approvedBy'), 'navy')
                  : ui.tag(CN.t('en.notApproved'), 'gold')) + '</td></tr>';
            }).join('') + '</tbody></table></div>');
        }

        host.innerHTML += html;

        /* ---- computation, run on every change ---- */
        function compute() {
          var formula = U.$('#e-formula').value;
          U.$('#e-override-wrap').style.display =
            (formula === 'device_measured' || formula === 'manual') ? '' : 'none';

          var input = {
            weightKg: U.parseNum(U.$('#e-weight').value),
            heightCm: U.parseNum(U.$('#e-height').value),
            age: U.parseNum(U.$('#e-age').value),
            sex: patient.sex,
            formula: formula,
            overrideValue: U.parseNum(U.$('#e-override').value),
            activity: U.$('#e-activity').value,
            activityOverride: U.parseNum(U.$('#e-factor').value),
            goal: U.$('#e-goal').value,
            band: U.$('#e-band').value,
            patient: patient
          };

          var b = CN.engine.bmr(input);
          var bmrOut = U.$('#e-bmr-out');
          if (!b) {
            bmrOut.innerHTML = ui.notice(CN.t('en.needMeasure'), 'warn');
            U.$('#e-tdee-out').innerHTML = '';
            U.$('#e-target-out').innerHTML = '';
            U.$('#e-macro-out').innerHTML = '';
            return;
          }
          bmrOut.innerHTML = '<div class="row">' +
            '<div class="stat" style="flex:1"><div class="stat-label">' + U.esc(CN.t('en.bmr')) + '</div>' +
            '<div class="stat-value">' + U.nf(b.value, 0) + ' <small>kcal</small></div>' +
            '<div class="stat-foot">' + U.esc(b.isEstimated ? CN.t('en.bmrEst') : CN.t('en.bmrDevice')) +
            ' · ' + U.esc(b.formulaLabel) + '</div></div></div>' +
            ui.notice(CN.t('en.bmrHint'), 'info');

          var result = CN.engine.assess(input);
          if (!result.ok) return;

          U.$('#e-tdee-out').innerHTML = '<div class="stat"><div class="stat-label">' +
            U.esc(CN.t('en.tdee')) + '</div><div class="stat-value">' + U.nf(result.tdee, 0) +
            ' <small>kcal</small></div><div class="stat-foot">' +
            U.esc(CN.t('en.multiplier')) + ' × ' + U.nf(result.activityFactor, 3) + '</div></div>';

          // Target panel, including every safety flag the engine raised.
          var flagHtml = '';
          if (result.flags.length) {
            flagHtml = '<h4>' + U.esc(CN.t('en.safety')) + '</h4>' + result.flags.map(function (f) {
              var tone = f.level === 'alert' ? 'alert' : (f.level === 'warn' ? 'warn' : 'info');
              return ui.notice(CN.i18n.lang === 'ar' ? (f.ar || f.en) : f.en, tone);
            }).join('');
          } else {
            flagHtml = ui.notice(CN.t('en.noFlags'), 'ok');
          }

          var rate = result.weeklyRateKg;
          var rateHtml = (rate && result.goal !== 'maintenance')
            ? '<div class="stat"><div class="stat-label">' + U.esc(CN.t('en.rate')) + '</div>' +
              '<div class="stat-value">' + (rate > 0 ? '+' : '') + U.nf(rate, 2) +
              ' <small>kg/week</small></div>' +
              '<div class="stat-foot">≈ ' + U.nf(Math.abs(result.monthlyRateKg), 1) +
              ' kg/month at this rate</div></div>'
            : '';

          U.$('#e-target-out').innerHTML =
            '<div class="grid cols-3 mb2">' +
            '<div class="stat accent"><div class="stat-label">' + U.esc(CN.t('en.target')) + '</div>' +
              '<div class="stat-value">' + U.nf(result.targetKcal, 0) + ' <small>kcal</small></div>' +
              '<div class="stat-foot">' + (result.goal === 'maintenance' ? U.esc(CN.t('en.maintenance'))
                : (result.band ? U.esc(result.band.en) : '') + ' · ' +
                  (result.deltaKcal > 0 ? '+' : '') + U.nf(result.deltaKcal, 0) + ' kcal') + '</div></div>' +
            rateHtml +
            '<div class="stat' + (result.requiresReview ? ' alert' : '') + '"><div class="stat-label">' +
              U.esc(CN.t('en.safety')) + '</div><div class="stat-value">' +
              (result.requiresReview ? '!' : '✓') + '</div><div class="stat-foot">' +
              U.esc(result.requiresReview
                ? (CN.i18n.lang === 'ar' ? 'يتطلب مراجعة' : 'Requires review')
                : CN.t('en.noFlags')) + '</div></div>' +
            '</div>' +
            '<h4>' + U.esc(CN.t('en.explain')) + '</h4>' +
            '<ul style="margin:0 0 1rem 1.1rem;font-size:.88rem">' +
            result.rationale.map(function (x) { return '<li>' + U.esc(x) + '</li>'; }).join('') + '</ul>' +
            flagHtml +
            '<div class="btn-row"><button class="btn btn-primary" id="e-approve">' +
              CN.icon('check', 16) + ' ' + U.esc(CN.t('en.approve')) + '</button></div>';

          // Macros
          var code = U.$('#e-profile').value;
          var profile = code && CN.approaches.byCode(code)
            ? CN.approaches.byCode(code).macros
            : { proteinPct: 20, carbPct: 45, fatPct: 35 };
          profile = profile || { proteinPct: 20, carbPct: 45, fatPct: 35 };
          var limits = code ? CN.approaches.mergedLimits([code]) : {};
          var macros = CN.engine.macros({
            targetKcal: result.targetKcal,
            weightKg: input.weightKg,
            profile: profile,
            method: U.$('#e-method').value,
            proteinPerKg: limits.proteinPerKg || 0.8,
            fiberMin: limits.fiberMin,
            sodiumMaxMg: limits.sodiumMaxMg
          });

          U.$('#e-macro-out').innerHTML =
            '<div class="grid cols-3">' +
            '<div class="stat"><div class="stat-label">' + U.esc(CN.t('en.protein')) + '</div>' +
              '<div class="stat-value">' + U.nf(macros.proteinG, 0) + ' <small>g</small></div>' +
              '<div class="stat-foot">' + U.nf(macros.proteinPct, 0) + '% · ' +
              U.nf(macros.proteinPerKg, 1) + ' g/kg</div></div>' +
            '<div class="stat"><div class="stat-label">' + U.esc(CN.t('en.carb')) + '</div>' +
              '<div class="stat-value">' + U.nf(macros.carbG, 0) + ' <small>g</small></div>' +
              '<div class="stat-foot">' + U.nf(macros.carbPct, 0) + '%</div></div>' +
            '<div class="stat"><div class="stat-label">' + U.esc(CN.t('en.fat')) + '</div>' +
              '<div class="stat-value">' + U.nf(macros.fatG, 0) + ' <small>g</small></div>' +
              '<div class="stat-foot">' + U.nf(macros.fatPct, 0) + '%</div></div>' +
            '</div>' +
            '<div class="row tight" style="margin-top:.8rem">' +
              ui.tag(CN.t('en.fiber') + ' ' + macros.fiberG + ' g') +
              ui.tag(CN.t('en.sodium') + ' ≤ ' + U.nf(macros.sodiumMaxMg, 0) + ' mg') +
              ui.tag(CN.t('en.fluid') + ' ≈ ' + U.nf(macros.fluidMl, 0) + ' ml') +
            '</div>';

          // Approval records the assessment; nothing downstream uses an
          // unapproved target.
          U.on(U.$('#e-target-out'), 'click', '#e-approve', function () {
            CN.store.put('assessments', {
              id: U.uid('asm'),
              patientId: patient.id,
              assessedAt: new Date().toISOString(),
              measurementId: latest.id,
              formula: result.bmrFormula,
              bmr: result.bmr, bmrIsEstimated: result.bmrIsEstimated,
              tdee: result.tdee,
              activityFactor: result.activityFactor,
              activityKey: result.activityKey,
              goal: result.goal,
              bandKey: result.bandKey,
              deltaKcal: result.deltaKcal,
              targetKcal: result.targetKcal,
              weeklyRateKg: result.weeklyRateKg,
              bmi: result.bmi,
              weightKg: input.weightKg,
              heightCm: input.heightCm,
              age: input.age,
              macros: macros,
              profileCode: code,
              rationale: result.rationale,
              flags: result.flags,
              requiresReview: result.requiresReview,
              approvedAt: new Date().toISOString(),
              approvedBy: 'clinician'
            }).then(function () {
              CN.toast(CN.t('en.approved'));
              CN.app.refresh();
            });
          });
        }

        // The activity factor field mirrors the selected activity level.
        function syncFactor() {
          var a = CN.engine.ACTIVITY[U.$('#e-activity').value] || CN.engine.ACTIVITY.moderate;
          U.$('#e-factor').value = a.factor;
        }
        syncFactor();

        ['#e-formula', '#e-weight', '#e-height', '#e-age', '#e-override', '#e-activity',
         '#e-goal', '#e-band', '#e-method', '#e-profile'].forEach(function (sel) {
          U.on(host, 'input', sel, compute);
          U.on(host, 'change', sel, function () {
            if (sel === '#e-activity') syncFactor();
            compute();
          });
        });
        U.on(host, 'input', '#e-factor', compute);

        compute();
      });
    }
  };

  /* ------------------------------------------------------- Body Composition */
  var BodyComp = {
    title: 'nav.bodyComp',

    render(host, ctx) {
      var patient = ctx.patient;
      if (!patient) { ui.needPatient(host); return; }

      host.innerHTML = ui.pageHead('bc.title', 'bc.subtitle',
        '<button class="btn btn-primary" id="bc-new">' + CN.icon('plus', 16) + ' ' +
        U.esc(CN.t('bc.newMeasurement')) + '</button>' +
        '<button class="btn" id="bc-chart">' + CN.icon('activity', 16) + ' ' + U.esc(CN.t('bc.trend')) + '</button>');

      CN.store.byPatient('measurements', patient.id).then(function (rows) {
        var ms = U.sortBy(rows, 'measuredAt', 'asc');
        if (!ms.length) {
          host.innerHTML += CN.empty(CN.t('bc.none'), CN.t('bc.noneMsg'),
            '<button class="btn btn-primary" data-new="1">' + U.esc(CN.t('bc.newMeasurement')) + '</button>');
          U.on(host, 'click', '#bc-new, [data-new]', function () { BodyComp.openNew(patient); });
          return;
        }

        var target = ms[ms.length - 1].targetWeightKg;
        var prog = CN.engine.progress(ms, target);
        var html = '';

        if (prog) {
          html += '<div class="grid cols-4 mb2">' +
            ui.stat('pat.weight', U.nf(prog.lastWeight, 1) + ' <small>kg</small>', U.fmtDate(prog.lastDate), 'accent') +
            ui.stat('bc.delta', (prog.totalChange > 0 ? '+' : '') + U.nf(prog.totalChange, 1) + ' <small>kg</small>',
              prog.days + ' ' + CN.t('common.days') + ' · ' + U.nf(prog.weeklyChange, 2) + ' kg/wk') +
            ui.stat('pat.bmi', U.nf(prog.bmiLast, 1) + ' <small>' + U.esc(CN.t('sex.' + (patient.sex || 'undisclosed'))) + '</small>',
              CN.i18n.lang === 'ar' ? CN.engine.bmiClass(prog.bmiLast).ar : CN.engine.bmiClass(prog.bmiLast).en,
              CN.engine.bmiClass(prog.bmiLast).level === 'alert' ? 'alert' : '') +
            (prog.fatChange !== null
              ? ui.stat('new.bodyFat', (prog.fatChange > 0 ? '+' : '') + U.nf(prog.fatChange, 1) + ' <small>%</small>',
                  prog.leanChange !== null ? (CN.i18n.lang === 'ar' ? 'تغير الكتلة العضلية ' : 'lean mass ') +
                    (prog.leanChange > 0 ? '+' : '') + U.nf(prog.leanChange, 1) + ' kg' : '')
              : ui.stat('new.bodyFat', '<span class="muted">—</span>')) +
            '</div>';
        }

        // Weight chart with the target line where one is set.
        var labels = ms.map(function (m) { return U.fmtDate(m.measuredAt, { day: '2-digit', month: 'short' }); });
        html += ui.card('bc.trend',
          CN.charts.line({
            height: 280,
            series: [{ name: CN.t('pat.weight'), color: 'navy',
              points: ms.map(function (m, i) { return { x: i, y: m.weightKg, tip: U.fmtDate(m.measuredAt) + ': ' + m.weightKg + ' kg' }; }) }],
            xLabels: labels,
            targetLines: prog && prog.targetWeightKg ? [{ value: prog.targetWeightKg, label: CN.t('common.target') + ' ' + prog.targetWeightKg + ' kg' }] : [],
            yUnit: 'kg'
          }) +
          CN.charts.legend([
            { label: CN.t('pat.weight'), tone: 'navy' },
            (prog && prog.targetWeightKg ? { label: CN.t('common.target'), tone: 'burgundy' } : null)
          ].filter(Boolean)));

        // BMI and body-fat series, when enough points exist.
        var bmiPts = ms.map(function (m, i) {
          return { x: i, y: CN.engine.bmi(m.heightCm, m.weightKg), tip: U.fmtDate(m.measuredAt) };
        }).filter(function (p) { return p.y !== null; });
        if (bmiPts.length > 1) {
          html += ui.card('bc.bmiTrend', CN.charts.line({ height: 220, series: [{ name: 'BMI', color: 'navy', points: bmiPts }], xLabels: labels }));
        }
        var fatPts = ms.map(function (m, i) {
          return { x: i, y: m.bodyFatPct, tip: U.fmtDate(m.measuredAt) };
        }).filter(function (p) { return p.y !== null && p.y !== undefined; });
        if (fatPts.length > 1) {
          html += ui.card('bc.fatTrend',
            CN.charts.line({ height: 220, series: [{ name: 'Body fat %', color: 'gold', points: fatPts }], xLabels: labels }));
        }

        // History table, newest first.
        var desc = ms.slice().reverse();
        html += ui.card('bc.history',
          '<div class="table-wrap"><table class="tbl compact"><thead><tr>' +
          '<th>' + U.esc(CN.t('common.date')) + '</th>' +
          '<th class="num">' + U.esc(CN.t('pat.weight')) + '</th>' +
          '<th class="num">' + U.esc(CN.t('pat.bmi')) + '</th>' +
          '<th class="num">' + U.esc(CN.t('new.waist')) + '</th>' +
          '<th class="num">' + U.esc(CN.t('new.bodyFat')) + '</th>' +
          '<th class="num">' + U.esc(CN.t('new.muscle')) + '</th>' +
          '<th>' + U.esc(CN.t('bc.source')) + '</th>' +
          '<th></th></tr></thead><tbody>' +
          desc.map(function (m) {
            return '<tr><td>' + U.esc(U.fmtDate(m.measuredAt)) + '</td>' +
              '<td class="num">' + ui.num(m.weightKg, 1) + '</td>' +
              '<td class="num">' + ui.num(CN.engine.bmi(m.heightCm, m.weightKg), 1) + '</td>' +
              '<td class="num">' + ui.num(m.waistCm, 1) + '</td>' +
              '<td class="num">' + ui.num(m.bodyFatPct, 1) + '</td>' +
              '<td class="num">' + ui.num(m.muscleMassKg, 1) + '</td>' +
              '<td>' + U.esc(CN.t('src.' + (m.source || 'clinic_scale'))) + '</td>' +
              '<td class="right"><button class="btn btn-xs" data-del-m="' + U.esc(m.id) + '">' +
                CN.icon('trash', 12) + '</button></td></tr>';
          }).join('') + '</tbody></table></div>');

        host.innerHTML += html;

        U.on(host, 'click', '#bc-new, [data-new]', function () { BodyComp.openNew(patient, ms[ms.length - 1]); });
        U.on(host, 'click', '[data-del-m]', function (e, el) {
          var id = el.getAttribute('data-del-m');
          CN.confirm({ title: CN.t('common.delete'), message: CN.t('common.irreversible'),
            confirmLabel: CN.t('common.yesDelete') }).then(function (ok) {
            if (!ok) return;
            CN.store.del('measurements', id).then(function () {
              CN.toast(CN.t('common.saved'));
              CN.app.refresh();
            });
          });
        });
      });
    },

    openNew(patient, prev) {
      prev = prev || {};
      var body = '<div class="inline-fields">' +
        '<div class="field"><label for="b-date">' + U.esc(CN.t('common.date')) + '</label>' +
          '<input id="b-date" type="date" value="' + U.todayISO() + '"/></div>' +
        '<div class="field"><label for="b-weightKg">' + U.esc(CN.t('new.weight')) + ' (kg)</label>' +
          '<input id="b-weightKg" type="number" step="0.1"/></div>' +
        '<div class="field"><label for="b-heightCm">' + U.esc(CN.t('new.height')) + ' (cm)</label>' +
          '<input id="b-heightCm" type="number" step="0.5" value="' + U.esc(prev.heightCm || '') + '"/></div>' +
        '<div class="field"><label for="b-targetWeightKg">' + U.esc(CN.t('new.targetWeight')) + ' (kg)</label>' +
          '<input id="b-targetWeightKg" type="number" step="0.1" value="' + U.esc(prev.targetWeightKg || '') + '"/></div>' +
        '<div class="field"><label for="b-waistCm">' + U.esc(CN.t('new.waist')) + ' (cm)</label>' +
          '<input id="b-waistCm" type="number" step="0.5"/></div>' +
        '<div class="field"><label for="b-hipCm">' + U.esc(CN.t('new.hip')) + ' (cm)</label>' +
          '<input id="b-hipCm" type="number" step="0.5"/></div>' +
        '<div class="field"><label for="b-bodyFatPct">' + U.esc(CN.t('new.bodyFat')) + ' (%)</label>' +
          '<input id="b-bodyFatPct" type="number" step="0.1"/></div>' +
        '<div class="field"><label for="b-muscleMassKg">' + U.esc(CN.t('new.muscle')) + ' (kg)</label>' +
          '<input id="b-muscleMassKg" type="number" step="0.1"/></div>' +
        '<div class="field"><label for="b-visceralFat">' + U.esc(CN.t('new.visceral')) + '</label>' +
          '<input id="b-visceralFat" type="number" step="1"/></div>' +
        '<div class="field"><label for="b-totalBodyWaterPct">' + U.esc(CN.t('new.tbw')) + ' (%)</label>' +
          '<input id="b-totalBodyWaterPct" type="number" step="0.1"/></div>' +
        '<div class="field"><label for="b-systolic">' + U.esc(CN.t('asm.systolic')) + ' (mmHg)</label>' +
          '<input id="b-systolic" type="number" step="1"/></div>' +
        '<div class="field"><label for="b-diastolic">' + U.esc(CN.t('asm.diastolic')) + ' (mmHg)</label>' +
          '<input id="b-diastolic" type="number" step="1"/></div>' +
        '<div class="field"><label for="b-source">' + U.esc(CN.t('bc.source')) + '</label>' +
          '<select id="b-source">' + CN.options([
            { value: 'clinic_scale', label: CN.t('src.clinic_scale') },
            { value: 'bioimpedance', label: CN.t('src.bioimpedance') },
            { value: 'device', label: CN.t('src.device') },
            { value: 'patient_reported', label: CN.t('src.patient_reported') }
          ]) + '</select></div>' +
        '</div>';

      var m = CN.modal({
        title: CN.t('bc.newMeasurement'), wide: true, body: body,
        actions: [
          { label: CN.t('common.cancel'), kind: 'ghost' },
          { label: CN.t('common.save'), kind: 'primary', close: false,
            onClick(node) {
              var w = U.parseNum(U.$('#b-weightKg', node).value);
              if (!(w > 0)) { CN.toast(CN.t('en.needMeasure'), 'warn'); return false; }
              CN.store.put('measurements', {
                id: U.uid('mea'), patientId: patient.id,
                measuredAt: U.$('#b-date', node).value || U.todayISO(),
                weightKg: w,
                heightCm: U.parseNum(U.$('#b-heightCm', node).value),
                targetWeightKg: U.parseNum(U.$('#b-targetWeightKg', node).value),
                waistCm: U.parseNum(U.$('#b-waistCm', node).value),
                hipCm: U.parseNum(U.$('#b-hipCm', node).value),
                bodyFatPct: U.parseNum(U.$('#b-bodyFatPct', node).value),
                muscleMassKg: U.parseNum(U.$('#b-muscleMassKg', node).value),
                visceralFat: U.parseNum(U.$('#b-visceralFat', node).value),
                totalBodyWaterPct: U.parseNum(U.$('#b-totalBodyWaterPct', node).value),
                systolic: U.parseNum(U.$('#b-systolic', node).value),
                diastolic: U.parseNum(U.$('#b-diastolic', node).value),
                source: U.$('#b-source', node).value
              }).then(function () {
                CN.toast(CN.t('bc.saved'));
                m.close();
                CN.app.refresh();
              });
              return false;
            } }
        ]
      });
    }
  };

  CN.views = CN.views || {};
  CN.views.assessment = Assessment;
  CN.views.energy = Energy;
  CN.views.bodyComp = BodyComp;
  CN.flagForLab = flagFor;
})();
